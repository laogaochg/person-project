package com.ifp.core.exception;

public class JdbcException extends BaseRuntimeException
{
  private static final long serialVersionUID = 8496695318073736940L;

  public JdbcException()
  {
  }

  public JdbcException(String errorMessage)
  {
    super(errorMessage);
  }

  public JdbcException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public JdbcException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public JdbcException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public JdbcException(Throwable cause)
  {
    super(cause);
  }
}