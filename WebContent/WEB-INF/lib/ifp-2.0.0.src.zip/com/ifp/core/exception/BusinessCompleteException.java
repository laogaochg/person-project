package com.ifp.core.exception;

public class BusinessCompleteException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public BusinessCompleteException()
  {
  }

  public BusinessCompleteException(String errorMessage)
  {
    super(errorMessage);
  }

  public BusinessCompleteException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public BusinessCompleteException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public BusinessCompleteException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public BusinessCompleteException(Throwable cause)
  {
    super(cause);
  }
}