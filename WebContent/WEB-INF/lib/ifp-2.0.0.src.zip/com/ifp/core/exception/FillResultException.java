package com.ifp.core.exception;

public class FillResultException extends BaseRuntimeException
{
  private static final long serialVersionUID = 8496695318073736940L;

  public FillResultException()
  {
  }

  public FillResultException(String errorMessage)
  {
    super(errorMessage);
  }

  public FillResultException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public FillResultException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public FillResultException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public FillResultException(Throwable cause)
  {
    super(cause);
  }
}