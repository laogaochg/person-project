package com.ifp.core.exception;

public class ElementNotSupportException extends BaseRuntimeException
{
  private static final long serialVersionUID = 8496695318073736640L;

  public ElementNotSupportException()
  {
  }

  public ElementNotSupportException(String errorMessage)
  {
    super(errorMessage);
  }

  public ElementNotSupportException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public ElementNotSupportException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public ElementNotSupportException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public ElementNotSupportException(Throwable cause)
  {
    super(cause);
  }
}