package com.ifp.core.exception;

public class RpcException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public RpcException()
  {
  }

  public RpcException(String errorMessage)
  {
    super(errorMessage);
  }

  public RpcException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public RpcException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public RpcException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public RpcException(Throwable cause)
  {
    super(cause);
  }
}