package com.ifp.core.exception;

public class DataChangeException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public DataChangeException()
  {
  }

  public DataChangeException(String errorMessage)
  {
    super(errorMessage);
  }

  public DataChangeException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public DataChangeException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public DataChangeException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public DataChangeException(Throwable cause)
  {
    super(cause);
  }
}