package com.ifp.core.exception;

public class FtpTransferException extends FtpException
{
  private static final long serialVersionUID = 1L;

  public FtpTransferException()
  {
  }

  public FtpTransferException(String errorMessage)
  {
    super(errorMessage);
  }

  public FtpTransferException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public FtpTransferException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public FtpTransferException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public FtpTransferException(Throwable cause)
  {
    super(cause);
  }
}