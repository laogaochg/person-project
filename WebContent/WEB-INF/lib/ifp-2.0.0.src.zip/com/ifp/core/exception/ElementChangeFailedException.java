package com.ifp.core.exception;

public class ElementChangeFailedException extends BaseRuntimeException
{
  private static final long serialVersionUID = 8496695318073736640L;

  public ElementChangeFailedException()
  {
  }

  public ElementChangeFailedException(String errorMessage)
  {
    super(errorMessage);
  }

  public ElementChangeFailedException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public ElementChangeFailedException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public ElementChangeFailedException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public ElementChangeFailedException(Throwable cause)
  {
    super(cause);
  }
}