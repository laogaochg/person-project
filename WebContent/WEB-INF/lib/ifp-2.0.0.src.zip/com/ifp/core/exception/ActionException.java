package com.ifp.core.exception;

public class ActionException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public ActionException()
  {
  }

  public ActionException(String errorMessage)
  {
    super(errorMessage);
  }

  public ActionException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public ActionException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public ActionException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public ActionException(Throwable cause)
  {
    super(cause);
  }
}