package com.ifp.core.exception;

public class MvcException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public MvcException()
  {
  }

  public MvcException(String errorMessage)
  {
    super(errorMessage);
  }

  public MvcException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public MvcException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public MvcException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public MvcException(Throwable cause)
  {
    super(cause);
  }
}