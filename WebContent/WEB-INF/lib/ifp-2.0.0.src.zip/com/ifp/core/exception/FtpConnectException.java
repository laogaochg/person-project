package com.ifp.core.exception;

public class FtpConnectException extends FtpException
{
  private static final long serialVersionUID = 1L;

  public FtpConnectException()
  {
  }

  public FtpConnectException(String errorMessage)
  {
    super(errorMessage);
  }

  public FtpConnectException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public FtpConnectException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public FtpConnectException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public FtpConnectException(Throwable cause)
  {
    super(cause);
  }
}