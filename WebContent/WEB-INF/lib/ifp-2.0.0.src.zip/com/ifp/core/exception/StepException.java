package com.ifp.core.exception;

public class StepException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public StepException()
  {
  }

  public StepException(String errorMessage)
  {
    super(errorMessage);
  }

  public StepException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public StepException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public StepException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public StepException(Throwable cause)
  {
    super(cause);
  }
}