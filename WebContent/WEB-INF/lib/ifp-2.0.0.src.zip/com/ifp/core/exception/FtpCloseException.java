package com.ifp.core.exception;

public class FtpCloseException extends FtpException
{
  private static final long serialVersionUID = 1L;

  public FtpCloseException()
  {
  }

  public FtpCloseException(String errorMessage)
  {
    super(errorMessage);
  }

  public FtpCloseException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public FtpCloseException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public FtpCloseException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public FtpCloseException(Throwable cause)
  {
    super(cause);
  }
}