package com.ifp.core.exception;

public class FtpException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public FtpException()
  {
  }

  public FtpException(String errorMessage)
  {
    super(errorMessage);
  }

  public FtpException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public FtpException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public FtpException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public FtpException(Throwable cause)
  {
    super(cause);
  }
}