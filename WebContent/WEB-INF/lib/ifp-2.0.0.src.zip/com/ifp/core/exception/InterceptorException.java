package com.ifp.core.exception;

public class InterceptorException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public InterceptorException()
  {
  }

  public InterceptorException(String errorMessage)
  {
    super(errorMessage);
  }

  public InterceptorException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public InterceptorException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public InterceptorException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public InterceptorException(Throwable cause)
  {
    super(cause);
  }
}