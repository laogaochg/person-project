package com.ifp.core.exception;

public class FlowException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public FlowException()
  {
  }

  public FlowException(String errorMessage)
  {
    super(errorMessage);
  }

  public FlowException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public FlowException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public FlowException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public FlowException(Throwable cause)
  {
    super(cause);
  }
}