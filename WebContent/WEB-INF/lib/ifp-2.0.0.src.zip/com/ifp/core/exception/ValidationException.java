package com.ifp.core.exception;

public class ValidationException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public ValidationException()
  {
  }

  public ValidationException(String errorMessage)
  {
    super(errorMessage);
  }

  public ValidationException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public ValidationException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public ValidationException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public ValidationException(Throwable cause)
  {
    super(cause);
  }
}