package com.ifp.core.exception;

public class RecordOutOfRangeException extends BaseRuntimeException
{
  private static final long serialVersionUID = 8496395318073736940L;

  public RecordOutOfRangeException()
  {
  }

  public RecordOutOfRangeException(String errorMessage)
  {
    super(errorMessage);
  }

  public RecordOutOfRangeException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public RecordOutOfRangeException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public RecordOutOfRangeException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public RecordOutOfRangeException(Throwable cause)
  {
    super(cause);
  }
}