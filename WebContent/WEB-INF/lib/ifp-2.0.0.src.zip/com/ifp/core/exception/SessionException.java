package com.ifp.core.exception;

public class SessionException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public SessionException()
  {
  }

  public SessionException(String errorMessage)
  {
    super(errorMessage);
  }

  public SessionException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public SessionException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public SessionException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public SessionException(Throwable cause)
  {
    super(cause);
  }
}