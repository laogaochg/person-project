package com.ifp.core.exception;

public class DubbovException extends BaseRuntimeException
{
  private static final long serialVersionUID = 8496695318073736940L;

  public DubbovException()
  {
  }

  public DubbovException(String errorMessage)
  {
    super(errorMessage);
  }

  public DubbovException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public DubbovException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public DubbovException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public DubbovException(Throwable cause)
  {
    super(cause);
  }
}