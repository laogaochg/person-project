package com.ifp.core.exception;

public class TransactionFaildException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public TransactionFaildException()
  {
  }

  public TransactionFaildException(String errorMessage)
  {
    super(errorMessage);
  }

  public TransactionFaildException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public TransactionFaildException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public TransactionFaildException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public TransactionFaildException(Throwable cause)
  {
    super(cause);
  }
}