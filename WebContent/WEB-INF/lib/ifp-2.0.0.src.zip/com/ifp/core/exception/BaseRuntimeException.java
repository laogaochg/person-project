package com.ifp.core.exception;

public class BaseRuntimeException extends RuntimeException
{
  private static final long serialVersionUID = 7254894132443453562L;
  private String errorCode = "SYEC0001";
  private String errorMessage = "系统繁忙,请稍后再试";

  public BaseRuntimeException()
  {
  }

  public BaseRuntimeException(String errorMessage)
  {
    super(errorMessage);
    this.errorMessage = errorMessage;
  }

  public BaseRuntimeException(String errorCode, String errorMessage)
  {
    super(errorMessage);
    this.errorMessage = errorMessage;
    this.errorCode = errorCode;
  }

  public BaseRuntimeException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
    this.errorCode = errorCode;
    this.errorMessage = errorMessage;
  }

  public BaseRuntimeException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
    this.errorMessage = errorMessage;
  }

  public BaseRuntimeException(Throwable cause)
  {
    super(cause);
  }

  public String getMessage()
  {
    String errorMsg = getErrorMessage();
    if (this.errorCode != null) {
      if (errorMsg != null)
        errorMsg = "[" + this.errorCode + "] " + errorMsg;
      else
        errorMsg = "[" + this.errorCode + "]";

    }

    return errorMsg;
  }

  public String toString()
  {
    if (getCause() == null)
      return super.toString();

    return super.toString() + " cause: " + getCause().toString();
  }

  public String getErrorCode() {
    return this.errorCode;
  }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  public String getErrorMessage() {
    if (null == this.errorMessage)
      return super.getMessage();

    return this.errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }
}