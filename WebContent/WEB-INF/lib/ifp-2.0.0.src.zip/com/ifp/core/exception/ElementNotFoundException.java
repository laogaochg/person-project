package com.ifp.core.exception;

public class ElementNotFoundException extends BaseRuntimeException
{
  private static final long serialVersionUID = 8496695318073736640L;

  public ElementNotFoundException()
  {
  }

  public ElementNotFoundException(String errorMessage)
  {
    super(errorMessage);
  }

  public ElementNotFoundException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public ElementNotFoundException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public ElementNotFoundException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public ElementNotFoundException(Throwable cause)
  {
    super(cause);
  }
}