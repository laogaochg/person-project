package com.ifp.core.page;

import org.apache.commons.lang3.StringUtils;

public class Page
{
  public static final String ASC = "asc";
  public static final String DESC = "desc";
  protected int pageNo = 1;
  protected int pageSize = 10;
  protected String orderBy = null;
  protected String order = null;
  protected boolean autoCount = true;
  protected long totalCount = -1L;

  public Page()
  {
  }

  public Page(int pageSize)
  {
    this.pageSize = pageSize;
  }

  public Page(int pageNo, int pageSize) {
    this.pageNo = pageNo;
    this.pageSize = pageSize;
  }

  public int getPageNo()
  {
    return this.pageNo;
  }

  public void setPageNo(int pageNo)
  {
    this.pageNo = pageNo;

    if (pageNo < 1)
      this.pageNo = 1;
  }

  public Page pageNo(int thePageNo)
  {
    setPageNo(thePageNo);
    return this;
  }

  public int getPageSize()
  {
    return this.pageSize;
  }

  public void setPageSize(int pageSize)
  {
    this.pageSize = pageSize;
  }

  public Page pageSize(int thePageSize)
  {
    setPageSize(thePageSize);
    return this;
  }

  public int getFirst()
  {
    return ((this.pageNo - 1) * this.pageSize + 1);
  }

  public String getOrderBy()
  {
    return this.orderBy;
  }

  public void setOrderBy(String orderBy)
  {
    this.orderBy = orderBy;
  }

  public Page orderBy(String theOrderBy)
  {
    setOrderBy(theOrderBy);
    return this;
  }

  public String getOrder()
  {
    return this.order;
  }

  public void setOrder(String order)
  {
    String lowcaseOrder = StringUtils.lowerCase(order);

    String[] orders = StringUtils.split(lowcaseOrder, ',');
    String[] arr$ = orders; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String orderStr = arr$[i$];
      if ((!(StringUtils.equals("desc", orderStr))) && (!(StringUtils.equals("asc", orderStr))))
        throw new IllegalArgumentException("排序方向" + orderStr + "不是合法值");

    }

    this.order = lowcaseOrder;
  }

  public Page order(String theOrder)
  {
    setOrder(theOrder);
    return this;
  }

  public boolean isOrderBySetted()
  {
    return ((StringUtils.isNotBlank(this.orderBy)) && (StringUtils.isNotBlank(this.order)));
  }

  public boolean isAutoCount()
  {
    return this.autoCount;
  }

  public void setAutoCount(boolean autoCount)
  {
    this.autoCount = autoCount;
  }

  public Page autoCount(boolean theAutoCount)
  {
    setAutoCount(theAutoCount);
    return this;
  }

  public long getTotalCount()
  {
    return this.totalCount;
  }

  public void setTotalCount(long totalCount)
  {
    this.totalCount = totalCount;
  }

  public long getTotalPages()
  {
    if (this.totalCount < -3763400818934415360L) {
      return -1L;
    }

    long count = this.totalCount / this.pageSize;
    if (this.totalCount % this.pageSize > -3763400818934415360L)
      count += -3763399805322133503L;

    return count;
  }

  public boolean isHasNext()
  {
    return (this.pageNo + 1 <= getTotalPages());
  }

  public int getNextPage()
  {
    if (isHasNext())
      return (this.pageNo + 1);

    return this.pageNo;
  }

  public boolean isHasPre()
  {
    return (this.pageNo - 1 >= 1);
  }

  public int getPrePage()
  {
    if (isHasPre())
      return (this.pageNo - 1);

    return this.pageNo;
  }
}