package com.ifp.core.validation;

import com.ifp.core.exception.ValidationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListPatternValidation extends IFPAbstractValidation
{
  public boolean validate(String attribute, Object input, String desc)
    throws Exception
  {
    if (null == input)
      return true;

    try
    {
      List inputList = (List)input;

      String[] patternArray = attribute.split(",");
      Map patternMap = new HashMap();
      for (int i = 0; i < patternArray.length; ++i) {
        String pattern = patternArray[i];
        int index = pattern.indexOf("(");
        String key = pattern.substring(0, index);
        patternMap.put(key, pattern.substring(index + 1, pattern.length() - 1));
        patternArray[i] = key;
      }

      for (i = 0; i < inputList.size(); ++i) {
        Map map = (Map)inputList.get(i);
        String[] arr$ = patternArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String key = arr$[i$];
          Object object = map.get(key);
          if ((object instanceof String) && (!(((String)object).matches((String)patternMap.get(key)))))
            throw new ValidationException("SYEC0003", "[" + key + "]格式有误: " + object);
        }
      }
    }
    catch (ClassCastException e) {
      throw new ValidationException("SYEC0003", "[" + desc + "]不是list: " + input);
    } catch (Exception e) {
      throw e;
    }
    return true;
  }
}