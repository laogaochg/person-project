package com.ifp.core.validation;

import com.ifp.core.exception.ValidationException;

public class PatternValidation extends IFPAbstractValidation
{
  public boolean validate(String attribute, Object input, String desc)
    throws Exception
  {
    String PatternString = attribute;
    if ((input instanceof String) && (!(((String)input).matches(PatternString))))
      throw new ValidationException("SYEC0003", "[" + desc + "]格式有误: " + input);

    return true;
  }
}