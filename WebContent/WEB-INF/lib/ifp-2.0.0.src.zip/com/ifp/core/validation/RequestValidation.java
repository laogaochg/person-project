package com.ifp.core.validation;

import com.ifp.core.exception.ValidationException;
import com.ifp.core.util.StringUtil;

public class RequestValidation extends IFPAbstractValidation
{
  public boolean validate(String attribute, Object input, String desc)
    throws Exception
  {
    if (!(StringUtil.hasText(input))) {
      throw new ValidationException("SYEC0003", "[" + desc + "]不能为空: " + input);
    }

    return true;
  }
}