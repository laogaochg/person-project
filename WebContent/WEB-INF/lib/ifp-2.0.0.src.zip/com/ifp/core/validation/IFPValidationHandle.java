package com.ifp.core.validation;

import com.ifp.core.exception.BaseException;
import com.ifp.core.util.SpringContextsUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IFPValidationHandle
{
  public static final String IFP_TYPE_FIX = ";";
  public static final String IFP_FIELD_FIX = ";";
  public static final String IFP_FIELDNAME = "fieldName";
  public static final String IFP_TYPEAME = "typeName";
  public static final String IFP_ATTRIBUTE = "attribute";
  public static final String SETATTRIBUTE_METHOD = "setAttribute";
  public static final String SETINPUT_METHOD = "setInput";
  public static final String SETDESC_METHOD = "setDesc";
  private static Map<String, IFPValidation> validationMap = new HashMap();
  private static Map<String, List> checkListMap = new HashMap();

  public static boolean doCheck(String validationName, Object input, String attribute, String desc)
    throws BaseException
  {
    IFPValidation validation = (IFPValidation)validationMap.get(validationName);
    if (null == validation)
      validation = (IFPValidation)SpringContextsUtil.getBean(validationName);

    try
    {
      return validation.validate(attribute, input, desc);
    } catch (BaseException e) {
      throw e;
    } catch (Exception e) {
      throw new BaseException("格式校验异常!" + e);
    }
  }

  public static List getCheckList(String fieldName, String type)
  {
    List list = new ArrayList();
    List fieldNameList = new ArrayList();
    List typeList = new ArrayList();
    if (fieldName.contains(";")) {
      String[] fields = fieldName.split(";");
      for (int j = 0; j < fields.length; ++j) {
        String fName = fields[j].trim();
        fieldNameList.add(fName);
      }
    } else {
      fieldNameList.add(fieldName);
    }
    if (type.contains(";")) {
      String[] types = type.split(";");
      for (int i = 0; i < types.length; ++i) {
        String typec = types[i].trim();
        if (!("".equals(typec))) {
          int index = typec.indexOf("{");
          String typeName = typec;
          String attribute = "";
          if (index != -1) {
            typeName = typec.substring(0, index);
            attribute = typec.substring(index + 1, typec.length() - 1);
          }
          Map typeMap = new HashMap();
          typeMap.put("typeName", typeName);
          typeMap.put("attribute", attribute);
          typeList.add(typeMap);
        }
      }
    } else {
      int index = type.indexOf("{");
      String typeName = type;
      String attribute = "";
      if (index != -1) {
        typeName = type.substring(0, index);
        attribute = type.substring(index + 1, type.length() - 1);
      }
      Map typeMap = new HashMap();
      typeMap.put("typeName", typeName);
      typeMap.put("attribute", attribute);
      typeList.add(typeMap);
    }
    list = getList(fieldNameList, typeList);
    return list;
  }

  public static List getCheckList(String fieldName, String type, String transCode) {
    List checkList = (List)checkListMap.get(transCode + fieldName);
    if (null == checkList) {
      checkList = getCheckList(fieldName, type);
      checkListMap.put(transCode + fieldName, checkList);
    }
    return checkList;
  }

  private static List getList(List fieldNameList, List typeList) {
    List list = new ArrayList();
    for (int i = 0; i < fieldNameList.size(); ++i) {
      String fieldName = fieldNameList.get(i).toString();
      for (int j = 0; j < typeList.size(); ++j) {
        Map map = new HashMap();
        map.put("fieldName", fieldName);
        Map typeMap = (Map)typeList.get(j);
        map.putAll(typeMap);
        list.add(map);
      }
    }

    return list;
  }
}