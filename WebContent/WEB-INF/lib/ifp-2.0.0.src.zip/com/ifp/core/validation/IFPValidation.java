package com.ifp.core.validation;

public abstract interface IFPValidation
{
  public abstract boolean validate(String paramString1, Object paramObject, String paramString2)
    throws Exception;
}