package com.ifp.core.validation;

import com.ifp.core.exception.ValidationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListPatternValidationEx extends IFPAbstractValidation
{
  private final String fieldRegex = "\\|\\|";
  private final Map<String, String> patternMap;

  public ListPatternValidationEx()
  {
    this.fieldRegex = "\\|\\|";
    this.patternMap = new HashMap(); }

  public void init() { this.patternMap.put("moneyFormat", "^?(([1-9]\\d*)|0)(\\.[\\d]{1,2})?$");
  }

  public boolean validate(String attribute, Object input, String desc) throws Exception
  {
    if (null == input)
      return true;

    try
    {
      List inputList = (List)input;

      String[] patternArray = attribute.split("\\|\\|");
      Map patternMapEx = new HashMap();
      for (int i = 0; i < patternArray.length; ++i) {
        String pattern = patternArray[i];
        int index = pattern.indexOf("(");
        String key = pattern.substring(0, index);
        patternMapEx.put(key, pattern.substring(index + 1, pattern.length() - 1));
        patternArray[i] = key;
      }
      for (i = 0; i < inputList.size(); ++i) {
        Map map = (Map)inputList.get(i);
        String[] arr$ = patternArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String key = arr$[i$];
          Object value = map.get(key);
          if (value instanceof String) {
            String patternString = (String)patternMapEx.get(key);
            if (this.patternMap.get(patternString) != null) {
              patternString = (String)this.patternMap.get(patternString);
              if (((String)value).matches(patternString)) break label330;
              throw new ValidationException("SYEC0003", "[" + key + "]格式有误: " + value);
            }

            label330: if (!(((String)value).matches(patternString)))
              throw new ValidationException("SYEC0003", "[" + key + "]格式有误: " + value);
          }
        }
      }
    }
    catch (ClassCastException e)
    {
      throw new ValidationException("SYEC0003", "[" + desc + "]不是list: " + input);
    } catch (Exception e) {
      throw e;
    }
    return true;
  }
}