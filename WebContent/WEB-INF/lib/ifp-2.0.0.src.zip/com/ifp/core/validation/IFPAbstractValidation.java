package com.ifp.core.validation;

public abstract class IFPAbstractValidation
  implements IFPValidation
{
  public boolean validate(String attribute, Object input, String desc)
    throws Exception
  {
    return true;
  }
}