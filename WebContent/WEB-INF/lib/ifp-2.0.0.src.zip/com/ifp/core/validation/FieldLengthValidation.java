package com.ifp.core.validation;

import com.ifp.core.exception.ValidationException;
import java.util.List;

public class FieldLengthValidation extends IFPAbstractValidation
{
  public boolean validate(String attribute, Object input, String desc)
    throws Exception
  {
    String maxLength = attribute;

    if (input != null)
      if (input instanceof String) {
        String inputStr = (String)input;
        if (!("".equals(inputStr.trim()))) {
          int inputLen = inputStr.length();
          if (inputLen > Integer.valueOf(maxLength).intValue())
            throw new ValidationException("SYEC0003", "[" + desc + "]长度有误: " + input);
        }
      }
      else if (input instanceof List) {
        List inputList = (List)input;
        if (inputList.size() > Integer.valueOf(maxLength).intValue())
          throw new ValidationException("SYEC0003", "[" + desc + "]长度有误: " + input);
      }
      else {
        throw new ValidationException("SYEC0003", "[" + desc + "]参数类型有误:" + input);
      }

    return true;
  }
}