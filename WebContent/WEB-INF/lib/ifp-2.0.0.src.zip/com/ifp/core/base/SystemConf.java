package com.ifp.core.base;

import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.BaseRuntimeException;
import com.ifp.core.listener.ISettingReloadListener;
import com.ifp.core.util.DataMapChangeUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.core.util.UrlUtil;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.StringUtils;

public class SystemConf
  implements Serializable, InitializingBean
{
  private static final long serialVersionUID = 1L;
  public static SystemConf conf;
  private Map<String, Object> confMap;
  private Map<String, Map<String, String>> aprMap;
  private Map<String, ISettingReloadListener> reloadMap;
  private String webRootPath;
  private String localIp;

  public void afterPropertiesSet()
    throws Exception
  {
    conf = this;
  }

  public Object getConfByKey(String key) {
    return this.confMap.get(key);
  }

  public String getStringConfByKey(String key, String defaultValue) {
    Object value = this.confMap.get(key);
    if (null != value) {
      if (value instanceof String)
        return ((String)value);

      return String.valueOf(value);
    }

    return defaultValue;
  }

  public int getIntConfByKey(String key, int defaultValue)
  {
    Object value = this.confMap.get(key);
    if (null != value) {
      if (value instanceof Boolean)
        return ((Integer)value).intValue();

      return Integer.parseInt((String)value);
    }

    return defaultValue;
  }

  public boolean getBooleanConfByKey(String key, boolean defaultValue)
  {
    Object value = this.confMap.get(key);
    if (null != value) {
      if (value instanceof Boolean)
        return ((Boolean)value).booleanValue();

      return Boolean.parseBoolean((String)value);
    }

    return defaultValue;
  }

  public double getDoubleConfByKey(String key, double defaultValue)
  {
    Object value = this.confMap.get(key);
    if (null != value) {
      if (value instanceof Double)
        return ((Double)value).doubleValue();

      return Double.parseDouble((String)value);
    }

    return defaultValue;
  }

  public Object putConfByKey(String key, Object value)
  {
    return this.confMap.put(key, value);
  }

  public String getAprByKey(String name, String key) {
    Map aMap = (Map)this.aprMap.get(name);
    if (null != aMap)
      return ((String)aMap.get(key));

    return null;
  }

  public String putAprByKey(String name, String key, String value)
  {
    Map aMap = (Map)this.aprMap.get(name);
    if (null != aMap)
      return ((String)aMap.put(key, value));

    return null;
  }

  public Map<String, String> getAprByKey(String name)
  {
    return ((Map)this.aprMap.get(name));
  }

  public Map<String, String> putAprByKey(String name, Map<String, String> aprMap) {
    return ((Map)this.aprMap.put(name, aprMap));
  }

  public ISettingReloadListener putReloadListener(String key, ISettingReloadListener listener)
  {
    return ((ISettingReloadListener)this.reloadMap.put(key, listener));
  }

  public ISettingReloadListener getReloadListener(String key)
  {
    return ((ISettingReloadListener)this.reloadMap.get(key));
  }

  public String getWebRootPath()
    throws Exception
  {
    if (StringUtil.hasText(this.webRootPath))
      return this.webRootPath;

    if ((null != this.confMap) && (this.confMap.containsKey("webPath")))
      return ((String)this.confMap.get("webPath"));

    String rootPath = UrlUtil.getClassPath(super.getClass());
    if (StringUtil.hasText(rootPath)) {
      int index = rootPath.indexOf("WEB-INF");
      if (index != -1)
        rootPath = rootPath.substring(0, index);

    }

    if (!(StringUtil.hasText(rootPath))) {
      rootPath = UrlUtil.getWebRootPath(super.getClass());
    }

    if ((null != this.confMap) && (!(StringUtil.hasText(rootPath)))) {
      String webRootKey = (String)this.confMap.get("webAppRootKey");

      if (StringUtil.hasText(webRootKey))
        rootPath = System.getProperty(webRootKey);
      else
        rootPath = System.getProperty("web.root");

    }

    if (StringUtil.hasText(rootPath)) {
      rootPath = rootPath.replaceAll("\\\\", "/");
      if (!(rootPath.endsWith("/"))) {
        rootPath = rootPath + "/";
      }

      this.webRootPath = rootPath;
      return rootPath;
    }
    throw new BaseException("SYEC0003", "获取应用路径出错!");
  }

  private void getBlogicDefaultParams(Map<String, Object> confMap)
  {
    DataMap defaultParamsMap = new DataMap();

    defaultParamsMap.put("errorCode", "");
    defaultParamsMap.put("errorMsg", "");
    defaultParamsMap.put("reqId", "");
    defaultParamsMap.put("pcid", "");
    defaultParamsMap.put("flumeReqIp", "");
    defaultParamsMap.put("cid", "");
    defaultParamsMap.put("ifpV2LocalServerFlow", "");
    try
    {
      Map defaultMap = (Map)confMap.get("blogicDefautlParams");
      if (null != defaultMap) {
        Iterator iterator = defaultMap.entrySet().iterator();
        while (iterator.hasNext()) {
          Map.Entry entry = (Map.Entry)iterator.next();
          String key = (String)entry.getKey();
          Object value = entry.getValue();
          if (null == value)
            defaultParamsMap.put(key, "");
          else if (value instanceof Map)
            defaultParamsMap.put(key, DataMapChangeUtil.mapToDataMap((Map)value));
          else if (value instanceof String)
            defaultParamsMap.put(key, ((String)value).trim());
          else
            throw new BaseRuntimeException("class type is not support: " + value.getClass());
        }
      }
    }
    catch (BaseRuntimeException e) {
      throw e;
    } catch (Exception e) {
      throw new BaseRuntimeException("getBlogicDefaultParams error!", e);
    }

    confMap.put("blogicDefautlParams", defaultParamsMap);
  }

  public String getLocalIp() {
    if (StringUtil.hasText(this.localIp))
    {
      return this.localIp;
    }
    if (this.confMap.containsKey("localIp"))
    {
      return ((String)this.confMap.get("localIp"));
    }
    InetAddress addr = null;
    try {
      addr = InetAddress.getLocalHost();
    } catch (UnknownHostException e) {
      e.printStackTrace();
    }

    byte[] ipAddr = addr.getAddress();
    String ipAddrStr = "";
    for (int i = 0; i < ipAddr.length; ++i) {
      if (i > 0)
        ipAddrStr = ipAddrStr + ".";

      ipAddrStr = ipAddrStr + (ipAddr[i] & 0xFF);
    }
    this.localIp = ipAddrStr;
    this.confMap.put("localIp", ipAddrStr);
    return ipAddrStr;
  }

  public boolean isServiceMock(String consumerId)
  {
    boolean disjunctor = BooleanUtils.toBoolean((String)this.confMap.get("rpcMock"));
    if (!(disjunctor))
      return false;

    Map serviceMock = (Map)this.confMap.get("serviceMock");
    if ((null == serviceMock) || (serviceMock.size() == 0) || (!(StringUtils.hasText(consumerId))))
      return false;

    for (Iterator i$ = serviceMock.entrySet().iterator(); i$.hasNext(); ) { Map.Entry serviceDisjunctor = (Map.Entry)i$.next();
      String serviceName = (String)serviceDisjunctor.getKey();

      if (serviceName.matches(".*(?<!\\.)[\\*\\?].*")) {
        serviceName = serviceName.replaceAll("(?<!\\.)([\\*\\?])", ".$1");
        serviceDisjunctor.setValue(serviceName);
      }

      if (consumerId.matches(serviceName))
        return BooleanUtils.toBoolean((String)serviceDisjunctor.getValue());
    }

    return false;
  }

  public Map<String, Object> getConfMap() {
    return this.confMap;
  }

  public void setConfMap(Map<String, Object> confMap) {
    String key = (String)confMap.get("errorInfoLocation");
    if (null == key) {
      confMap.put("errorInfoLocation", "body");
    }

    getBlogicDefaultParams(confMap);

    this.confMap = confMap;
  }

  public Map<String, Map<String, String>> getAprMap() {
    return this.aprMap;
  }

  public void setAprMap(Map<String, Map<String, String>> aprMap) {
    this.aprMap = aprMap;
  }

  public void setLocalIp(String localIp) {
    this.localIp = localIp;
  }

  public Map<String, ISettingReloadListener> getReloadMap() {
    return this.reloadMap;
  }

  public void setReloadMap(Map<String, ISettingReloadListener> reloadMap) {
    this.reloadMap = reloadMap;
  }
}