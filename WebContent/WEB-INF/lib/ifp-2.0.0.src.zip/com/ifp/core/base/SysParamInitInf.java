package com.ifp.core.base;

public abstract interface SysParamInitInf
{
  public abstract void init();
}