package com.ifp.core.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

public class CookieUtil
{
  public static void addCookie(HttpServletResponse response, Cookie cookie, boolean isHttpOnly)
  {
    StringBuffer buffer = new StringBuffer();
    String path = cookie.getPath();
    String domain = cookie.getDomain();
    boolean isSecure = cookie.getSecure();
    buffer.append(cookie.getName()).append("=").append(cookie.getValue()).append(";");
    int maxAge = cookie.getMaxAge();

    if (maxAge == 0)
      buffer.append("Expires=Thu Jan 01 08:00:00 CST 1970;");
    else if (maxAge > 0)
      buffer.append("Max-Age=").append(maxAge).append(";");
    else {
      buffer.append("Max-Age=-1;");
    }

    if (null != domain) {
      buffer.append("domain=").append(domain).append(";");
    }

    if (null != path) {
      buffer.append("path=").append(path).append(";");
    }

    if (isSecure) {
      buffer.append("secure;");
    }

    if (isHttpOnly)
      buffer.append("HTTPOnly");

    response.addHeader("Set-Cookie", buffer.toString());
  }
}