package com.ifp.core.util;

import java.io.File;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;

public class UrlUtil
{
  public static File getClassFile(Class clazz)
  {
    URL path = clazz.getResource(clazz.getName().substring(clazz.getName().lastIndexOf(".") + 1) + ".classs");

    if (path == null) {
      String name = clazz.getName().replaceAll("[.]", "/");
      path = clazz.getResource("/" + name + ".class");
    }
    return new File(path.getFile());
  }

  public static String getClassFilePath(Class clazz)
    throws Exception
  {
    File file;
    try
    {
      file = getClassFile(clazz);
      if (null != file)
        return URLDecoder.decode(file.getAbsolutePath(), "UTF-8");

      throw new Exception("get classPath error!");
    }
    catch (Exception e) {
      throw e;
    }
  }

  public static File getClassPathFile(Class clazz)
    throws UnsupportedEncodingException
  {
    File file = getClassFile(clazz);
    int i = 0; for (int count = clazz.getName().split("[.]").length; i < count; ++i) {
      file = file.getParentFile();
    }

    if (file.getName().toUpperCase().endsWith(".JAR!")) {
      file = file.getParentFile().getParentFile();
      String fileHead = "file:\\";
      String filePath = file.getAbsolutePath();
      int index = filePath.lastIndexOf(fileHead);
      if (index < 0)
        filePath = filePath + File.separator + "classes";
      else
        filePath = filePath.substring(index + fileHead.length()) + File.separator + "classes";

      file = new File(URLDecoder.decode(filePath, "UTF-8"));
    }

    return file;
  }

  public static String getClassPath(Class clazz)
    throws Exception
  {
    File file;
    try
    {
      file = getClassPathFile(clazz);
      if (null != file) {
        String fileHead = "file:" + File.separator;
        String filePath = file.getAbsolutePath();
        int index = filePath.lastIndexOf(fileHead);
        if (index >= 0)
          filePath = filePath.substring(index + fileHead.length() - 1);

        return URLDecoder.decode(filePath, "UTF-8");
      }
      throw new Exception("get classPath error!");
    }
    catch (Exception e) {
      throw e;
    }
  }

  public static File getWebRootPathFile(Class clazz)
    throws Exception
  {
    File file = getClassFile(clazz);
    int i = 0; for (int count = clazz.getName().split("[.]").length; i < count; ++i)
      file = file.getParentFile().getParentFile().getParentFile();
    if (file.getName().toUpperCase().endsWith(".JAR!"))
      file = file.getParentFile().getParentFile().getParentFile();

    return file;
  }

  public static String getWebRootPath(Class clazz)
    throws Exception
  {
    File file;
    try
    {
      file = getWebRootPathFile(clazz);
      if (null != file) {
        String filePath = file.getAbsolutePath();
        int index = filePath.lastIndexOf("file:\\");
        if (index >= 0)
          filePath = filePath.substring(index + 1);

        return URLDecoder.decode(filePath, "UTF-8");
      }
      throw new Exception("get classPath error!");
    }
    catch (Exception e) {
      throw e;
    }
  }

  public static void main(String[] args) throws Exception {
    System.out.println(getClassFilePath(UrlUtil.class));
    System.out.println(getClassPath(UrlUtil.class));
  }
}