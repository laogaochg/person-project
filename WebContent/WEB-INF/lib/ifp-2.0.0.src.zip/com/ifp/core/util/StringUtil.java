package com.ifp.core.util;

import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class StringUtil
{
  public static final String allChar = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  public static int generateRandomStringIndex = 62;

  public static String generateRandomString(int length)
  {
    StringBuffer sb = new StringBuffer();
    Random random = new Random(Thread.currentThread().getId());
    Random random2 = new Random();
    for (int i = 0; i < length; ++i)
      if (i % 2 == 0)
        sb.append("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(random.nextInt(generateRandomStringIndex)));
      else
        sb.append("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(random2.nextInt(generateRandomStringIndex)));


    return sb.toString();
  }

  public static int getStringLen(String str, String charsetName)
  {
    String anotherString = null;
    if ((null == str) || ("".equals(str)))
      return 0;

    try
    {
      anotherString = new String(str.getBytes(charsetName), "ISO8859_1");
    }
    catch (UnsupportedEncodingException ex) {
    }
    return anotherString.length();
  }

  public static String toLowerCaseFirstOne(String s)
  {
    if (Character.isLowerCase(s.charAt(0)))
      return s;

    return Character.toLowerCase(s.charAt(0)) + s.substring(1);
  }

  public static String toUpperCaseFirstOne(String s)
  {
    if (Character.isUpperCase(s.charAt(0)))
      return s;

    return Character.toUpperCase(s.charAt(0)) + s.substring(1);
  }

  public static boolean hasText(String s)
  {
    return ((null != s) && (s.trim().length() > 0));
  }

  public static boolean hasText(Object s)
  {
    if ((null != s) && (s instanceof String) && (s.toString().trim().length() > 0))
      return true;

    if ((null != s) && (s instanceof List) && (((List)s).size() > 0))
      return true;

    if ((null != s) && (s instanceof Map) && (((Map)s).size() > 0)) {
      return true;
    }

    if ((null != s) && (s instanceof DataField) && (((DataField)s).getValue().length() > 0)) {
      return true;
    }

    if ((null != s) && (s instanceof DataMap) && (((DataMap)s).size() > 0)) {
      return true;
    }

    return ((null != s) && (s instanceof DataList) && (((DataList)s).size() > 0));
  }

  public static String getText(String s)
  {
    return ((null == s) ? "" : s.trim());
  }

  public static String getText(String s, String defalut)
  {
    return (((null == s) || ("".equals(s))) ? defalut : s.trim());
  }

  public static String formatHtmlText(String s)
  {
    s = getText(s);
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < s.length(); ++i) {
      char c = s.charAt(i);
      switch (c)
      {
      case '"':
        sb.append("&quot;");
        break;
      case '<':
        sb.append("&lt;");
        break;
      case '>':
        sb.append("&gt;");
        break;
      case '\'':
        sb.append("&#x27;");
        break;
      default:
        sb.append(c);
      }
    }
    return sb.toString();
  }

  public static String formatHtmlText1(String s)
  {
    s = getText(s);
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < s.length(); ++i) {
      char c = s.charAt(i);
      switch (c)
      {
      case '&':
        sb.append("&amp;");
        break;
      case '"':
        sb.append("&quot;");
        break;
      case '<':
        sb.append("&lt;");
        break;
      case '>':
        sb.append("&gt;");
        break;
      case '\'':
        sb.append("&#x27;");
        break;
      default:
        sb.append(c);
      }
    }
    return sb.toString();
  }

  public static String formatHtmlText2(String s)
  {
    s = getText(s);
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < s.length(); ++i) {
      char c = s.charAt(i);
      switch (c)
      {
      case '&':
        sb.append("&amp;");
        break;
      case '"':
        sb.append("&quot;");
        break;
      case '<':
        sb.append("&lt;");
        break;
      case '>':
        sb.append("&gt;");
        break;
      case '\'':
        sb.append("&#x27;");
        break;
      case '/':
        sb.append("&#x2f;");
        break;
      default:
        sb.append(c);
      }
    }
    return sb.toString();
  }

  public static String unformatHtmlText(String s) {
    s = getText(s);
    return s.replaceAll("&lt;", "<").replaceAll("&quot;", "\"").replaceAll("&amp;", "&").replaceAll("&gt;", ">").replaceAll("&#x27;", "'").replaceAll("&#x2f;", "/");
  }

  public static String formatJSONText(String s)
  {
    s = (s == null) ? "" : s;
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < s.length(); ++i) {
      char c = s.charAt(i);
      switch (c)
      {
      case '"':
        sb.append("\\\"");
        break;
      case '\\':
        sb.append("\\\\");
        break;
      case '/':
        sb.append("\\/");
        break;
      case '\b':
        sb.append("\\b");
        break;
      case '\f':
        sb.append("\\f");
        break;
      case '\n':
        sb.append("\\n");
        break;
      case '\r':
        sb.append("\\r");
        break;
      case '\t':
        sb.append("\\t");
        break;
      default:
        sb.append(c);
      }
    }
    return sb.toString();
  }

  public static String unformatJSONText(String s)
  {
    return ((null == s) ? "" : s);
  }

  public static String formatXMLText(String s)
  {
    s = getText(s);

    return s.replaceAll("\\&", "&amp;").replaceAll("\"", "&quot;").replaceAll("<", "&lt;");
  }

  public static String unformatXMLText(String s)
  {
    s = getText(s);
    return s.replaceAll("&lt;", "<").replaceAll("&quot;", "\"").replaceAll("&amp;", "&");
  }

  public static String compress(String str)
  {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    try {
      GZIPOutputStream gzip = new GZIPOutputStream(out);
      gzip.write(str.getBytes());
      gzip.close();
      return out.toString("ISO-8859-1");
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  public static String uncompress(String str)
  {
    if ((str == null) || (str.length() == 0))
      return str;

    ByteArrayOutputStream out = new ByteArrayOutputStream();
    try {
      ByteArrayInputStream in = new ByteArrayInputStream(str.getBytes("ISO-8859-1"));
      GZIPInputStream gunzip = new GZIPInputStream(in);
      byte[] buffer = new byte[256];

      while ((n = gunzip.read(buffer)) >= 0) {
        int n;
        out.write(buffer, 0, n);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return out.toString();
  }

  public static String inputStreamToString(InputStream is)
    throws IOException
  {
    BufferedReader in = new BufferedReader(new InputStreamReader(is, "UTF-8"));
    StringBuffer buffer = new StringBuffer();
    String line = "";
    while ((line = in.readLine()) != null) {
      buffer.append(line);
    }

    return buffer.toString();
  }

  public static String getValue(Object object) {
    if (object instanceof DataField)
      return ((DataField)object).getValue();

    return ((String)object);
  }

  public static void setValue(Map map, String key, String value)
  {
    if (map instanceof DataMap)
      map.put(key, new DataField(key, value));
    else
      map.put(key, value);
  }

  public static void main(String[] args)
  {
    System.out.println(uncompress(compress("你好")));
    String htmlStr = formatHtmlText("<script type=\"javascript\">'hi'&'how are you/!</script>");
    System.out.println(htmlStr);
    System.out.println(unformatHtmlText(htmlStr));
  }
}