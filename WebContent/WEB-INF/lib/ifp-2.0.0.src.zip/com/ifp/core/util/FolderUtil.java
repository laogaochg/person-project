package com.ifp.core.util;

import java.io.File;
import java.io.PrintStream;

public class FolderUtil
{
  public static boolean creatDirectory(String filePath)
  {
    boolean flag = true;
    filePath = filePath.replaceAll("\\\\", "/");
    String[] dirs = filePath.split("/");
    if (dirs.length > 0) {
      String tempPath = "";
      try {
        for (int i = 0; i < dirs.length; ++i) {
          tempPath = tempPath + dirs[i] + "/";
          File file = new File(tempPath);
          if (!(file.isDirectory()))
            flag = (flag) && (file.mkdir());
        }
      }
      catch (SecurityException e) {
        throw e;
      }
    }
    return flag;
  }

  public static boolean makeFilePath(String filePath)
    throws Exception
  {
    boolean flag = true;
    try {
      File file = new File(filePath);
      if (!(file.isDirectory()))
        file.mkdir();
    }
    catch (Exception e) {
      throw e;
    }
    return flag;
  }

  public static boolean deleteDir(String filePath)
    throws Exception
  {
    filePath = filePath.replaceAll("\\\\", "/");
    File file = new File(filePath);

    return deleteDir(file);
  }

  public static boolean deleteDir(File file)
    throws Exception
  {
    boolean flag = false;
    try {
      if ((file == null) || (!(file.exists())))
        return true;
      if (file.isDirectory()) {
        File[] files = file.listFiles();
        if ((null != files) && (files.length > 0))
          for (int i = 0; i < files.length; ++i)
            flag = deleteDir(files[i]);

        else
          flag = true;
      }
      else {
        flag = true;
      }

      if (flag)
        flag = file.delete();
    }
    catch (Exception e) {
      throw e;
    }
    return flag;
  }

  public static void main(String[] args) throws Exception {
    String filePath = "d:/2009/12/13/";
    boolean flag = creatDirectory(filePath);
    System.out.println("文件夹创建成功？" + flag);

    System.out.println(makeFilePath("d:/2010"));

    System.out.println(deleteDir("d:/2009/"));
  }
}