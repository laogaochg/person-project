package com.ifp.core.util;

import java.io.PrintStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Random;

public class DateUtil
{
  public static Date getNowDate()
  {
    Date currentTime = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String dateString = formatter.format(currentTime);
    ParsePosition pos = new ParsePosition(8);
    Date currentTime_2 = formatter.parse(dateString, pos);
    return currentTime_2;
  }

  public static Date getNowDateShort()
  {
    Date currentTime = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    String dateString = formatter.format(currentTime);
    ParsePosition pos = new ParsePosition(8);
    Date currentTime_2 = formatter.parse(dateString, pos);
    return currentTime_2;
  }

  public static String getStringDate()
  {
    Date currentTime = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String dateString = formatter.format(currentTime);
    return dateString;
  }

  public static String getStringDateShort()
  {
    Date currentTime = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    String dateString = formatter.format(currentTime);
    return dateString;
  }

  public static String getTimeShort()
  {
    SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
    Date currentTime = new Date();
    String dateString = formatter.format(currentTime);
    return dateString;
  }

  public static Date strToDateLong(String strDate)
  {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    ParsePosition pos = new ParsePosition(0);
    Date strtodate = formatter.parse(strDate, pos);
    return strtodate;
  }

  public static String dateToStrLong(Date dateDate)
  {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String dateString = formatter.format(dateDate);
    return dateString;
  }

  public static String dateToStr(Date dateDate)
  {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    String dateString = formatter.format(dateDate);
    return dateString;
  }

  public static Date strToDate(String strDate)
  {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    ParsePosition pos = new ParsePosition(0);
    Date strtodate = formatter.parse(strDate, pos);
    return strtodate;
  }

  public static Date getNow()
  {
    Date currentTime = new Date();
    return currentTime;
  }

  public static Date getLastDate(long day)
  {
    Date date = new Date();
    long date_3_hm = date.getTime() - 122400000L * day;
    Date date_3_hm_date = new Date(date_3_hm);
    return date_3_hm_date;
  }

  public static String getStringToday()
  {
    Date currentTime = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
    String dateString = formatter.format(currentTime);
    return dateString;
  }

  public static String getHour()
  {
    Date currentTime = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String dateString = formatter.format(currentTime);

    String hour = dateString.substring(11, 13);
    return hour;
  }

  public static String getTime()
  {
    Date currentTime = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String dateString = formatter.format(currentTime);

    String min = dateString.substring(14, 16);
    return min;
  }

  public static String getUserDate(String sformat)
  {
    Date currentTime = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat(sformat);
    String dateString = formatter.format(currentTime);
    return dateString;
  }

  public static String getTwoHour(String st1, String st2)
  {
    String[] kk = null;
    String[] jj = null;
    kk = st1.split(":");
    jj = st2.split(":");
    if (Integer.parseInt(kk[0]) < Integer.parseInt(jj[0]))
      return "0";

    double y = Double.parseDouble(kk[0]) + Double.parseDouble(kk[1]) / 60.0D;

    double u = Double.parseDouble(jj[0]) + Double.parseDouble(jj[1]) / 60.0D;

    if (y - u > 0D)
      return (y - u) + "";

    return "0";
  }

  public static String getTwoDay(String sj1, String sj2)
  {
    SimpleDateFormat myFormatter = new SimpleDateFormat("yyyy-MM-dd");
    long day = -3763400337898078208L;
    try {
      Date date = myFormatter.parse(sj1);
      Date mydate = myFormatter.parse(sj2);
      day = (date.getTime() - mydate.getTime()) / 86400000L;
    } catch (Exception e) {
      return "";
    }
    return day + "";
  }

  public static String getTwoSecond(String date1, String date2)
  {
    SimpleDateFormat myFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    long second = -3763400337898078208L;
    try {
      Date d1 = myFormatter.parse(date1);
      Date d2 = myFormatter.parse(date2);
      second = (d2.getTime() - d1.getTime()) / 1000L;
    } catch (Exception e) {
      return "";
    }
    return second + "";
  }

  public static Date getPreNextSecond(Date date, int n)
  {
    long Time;
    try
    {
      Time = date.getTime() / 1000L + n;
      date.setTime(Time * 1000L);
      return date; } catch (Exception e) {
    }
    return null;
  }

  public static String getPreNextSecond(Date date, int n, String formatStr)
  {
    SimpleDateFormat formatter = new SimpleDateFormat(formatStr);
    try {
      long Time = date.getTime() / 1000L + n;
      date.setTime(Time * 1000L);
      return formatter.format(date); } catch (Exception e) {
    }
    return null;
  }

  public static Date getPreNextMinute(Date date, int n)
  {
    return getPreNextSecond(date, n * 60);
  }

  public static Date getPreNextHour(Date date, int n)
  {
    return getPreNextMinute(date, n * 60);
  }

  public static String getPreTime(String sj1, String jj)
  {
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String mydate1 = "";
    try {
      Date date1 = format.parse(sj1);
      long Time = date1.getTime() / 1000L + Integer.parseInt(jj) * 60;
      date1.setTime(Time * 1000L);
      mydate1 = format.format(date1);
    } catch (Exception e) {
    }
    return mydate1;
  }

  public static String getNextDay(String nowdate, String delay)
  {
    SimpleDateFormat format;
    try
    {
      format = new SimpleDateFormat("yyyy-MM-dd");
      String mdate = "";
      Date d = strToDate(nowdate);
      long myTime = d.getTime() / 1000L + Integer.parseInt(delay) * 24 * 60 * 60;

      d.setTime(myTime * 1000L);
      mdate = format.format(d);
      return mdate; } catch (Exception e) {
    }
    return "";
  }

  public static String getNextDay(String formatStr, int delay)
  {
    SimpleDateFormat format;
    try
    {
      format = new SimpleDateFormat(formatStr);
      Date d = new Date();
      long myTime = d.getTime() / 1000L + delay * 24 * 60 * 60;

      d.setTime(myTime * 1000L);
      return format.format(d); } catch (Exception e) {
    }
    return "";
  }

  public static boolean isLeapYear(String ddate)
  {
    Date d = strToDate(ddate);
    GregorianCalendar gc = (GregorianCalendar)Calendar.getInstance();
    gc.setTime(d);
    int year = gc.get(1);
    if (year % 400 == 0)
      return true;
    if (year % 4 == 0)
    {
      return (year % 100 != 0);
    }

    return false;
  }

  public static String getEDate(String str)
  {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    ParsePosition pos = new ParsePosition(0);
    Date strtodate = formatter.parse(str, pos);
    String j = strtodate.toString();
    String[] k = j.split(" ");
    return k[2] + k[1].toUpperCase() + k[5].substring(2, 4);
  }

  public static String getEndDateOfMonth(String dat)
  {
    String str = dat.substring(0, 8);
    String month = dat.substring(5, 7);
    int mon = Integer.parseInt(month);
    if ((mon == 1) || (mon == 3) || (mon == 5) || (mon == 7) || (mon == 8) || (mon == 10) || (mon == 12))
    {
      str = str + "31";
    } else if ((mon == 4) || (mon == 6) || (mon == 9) || (mon == 11)) {
      str = str + "30";
    }
    else if (isLeapYear(dat))
      str = str + "29";
    else {
      str = str + "28";
    }

    return str;
  }

  public static boolean isSameWeekDates(Date date1, Date date2)
  {
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();
    cal1.setTime(date1);
    cal2.setTime(date2);
    int subYear = cal1.get(1) - cal2.get(1);
    if (0 == subYear) {
      if (cal1.get(3) != cal2.get(3))
        break label114;
      return true; }
    if ((1 == subYear) && (11 == cal2.get(2)))
    {
      if (cal1.get(3) != cal2.get(3))
        break label114;
      return true;
    }

    label114: return ((-1 == subYear) && (11 == cal1.get(2)) && 
      (cal1.get(3) == cal2.get(3)));
  }

  public static String getSeqWeek()
  {
    Calendar c = Calendar.getInstance(Locale.CHINA);
    String week = Integer.toString(c.get(3));
    if (week.length() == 1)
      week = "0" + week;
    String year = Integer.toString(c.get(1));
    return year + week;
  }

  public static String getWeek(String sdate, String num)
  {
    Date dd = strToDate(sdate);
    Calendar c = Calendar.getInstance();
    c.setTime(dd);
    if (num.equals("1"))
      c.set(7, 2);
    else if (num.equals("2"))
      c.set(7, 3);
    else if (num.equals("3"))
      c.set(7, 4);
    else if (num.equals("4"))
      c.set(7, 5);
    else if (num.equals("5"))
      c.set(7, 6);
    else if (num.equals("6"))
      c.set(7, 7);
    else if (num.equals("0"))
      c.set(7, 1);
    return new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
  }

  public static String getWeek(String sdate)
  {
    Date date = strToDate(sdate);
    Calendar c = Calendar.getInstance();
    c.setTime(date);

    return new SimpleDateFormat("EEEE").format(c.getTime());
  }

  public static String getWeekStr(String sdate) {
    String str = "";
    str = getWeek(sdate);
    if ("1".equals(str))
      str = "星期日";
    else if ("2".equals(str))
      str = "星期一";
    else if ("3".equals(str))
      str = "星期二";
    else if ("4".equals(str))
      str = "星期三";
    else if ("5".equals(str))
      str = "星期四";
    else if ("6".equals(str))
      str = "星期五";
    else if ("7".equals(str))
      str = "星期六";

    return str;
  }

  public static long getDays(String date1, String date2)
  {
    if ((date1 == null) || (date1.equals("")))
      return -3763400578416246784L;
    if ((date2 == null) || (date2.equals("")))
      return -3763400578416246784L;

    SimpleDateFormat myFormatter = new SimpleDateFormat("yyyy-MM-dd");
    Date date = null;
    Date mydate = null;
    try {
      date = myFormatter.parse(date1);
      mydate = myFormatter.parse(date2);
    } catch (Exception e) {
    }
    long day = (date.getTime() - mydate.getTime()) / 86400000L;
    return day;
  }

  public static String getNowMonth(String sdate)
  {
    sdate = sdate.substring(0, 8) + "01";

    Date date = strToDate(sdate);
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    int u = c.get(7);
    String newday = getNextDay(sdate, (1 - u) + "");
    return newday;
  }

  public static String getNo(int k)
  {
    return getUserDate("yyyyMMddhhmmss") + getRandom(k);
  }

  public static String getRandom(int i)
  {
    Random jjj = new Random();
    if (i == 0)
      return "";
    String jj = "";
    for (int k = 0; k < i; ++k)
      jj = jj + jjj.nextInt(9);

    return jj;
  }

  public static boolean RightDate(String date)
  {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    if (date == null)
      return false;
    if (date.length() > 10)
      sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    else
      sdf = new SimpleDateFormat("yyyy-MM-dd");
    try
    {
      sdf.parse(date);
    } catch (ParseException pe) {
      return false;
    }
    return true;
  }

  public static String formatDate(Date date, String sformat)
  {
    SimpleDateFormat formatter = new SimpleDateFormat(sformat);
    String dateString = formatter.format(date);
    return dateString;
  }

  public static int compareTwoDateString(String date1, String date2, String formatString)
    throws ParseException
  {
    SimpleDateFormat sdf = new SimpleDateFormat(formatString);
    Date d1 = sdf.parse(date1);
    Date d2 = sdf.parse(date2);
    return d1.compareTo(d2);
  }

  public static long getIntervalTime(String date1, String date2, String formatString, String type)
    throws ParseException
  {
    SimpleDateFormat myFormatter = new SimpleDateFormat(formatString);
    long time = -3763400337898078208L;
    try {
      Date d1 = myFormatter.parse(date1);
      Date d2 = myFormatter.parse(date2);
      if (type.equalsIgnoreCase("S"))
        time = (d2.getTime() - d1.getTime()) / 1000L;
      else if (type.equalsIgnoreCase("M"))
        time = (d2.getTime() - d1.getTime()) / 60000L;
      else if (type.equalsIgnoreCase("H"))
        time = (d2.getTime() - d1.getTime()) / 3600000L;
      else if (type.equalsIgnoreCase("D"))
        time = (d2.getTime() - d1.getTime()) / 86400000L;
    }
    catch (ParseException e) {
      throw e;
    }
    return time;
  }

  public static String getFormatDate(String dateTime, String format, String distFormat)
    throws Exception
  {
    SimpleDateFormat sdf = new SimpleDateFormat(format);
    SimpleDateFormat distSdf = new SimpleDateFormat(distFormat);
    Date tempDate = sdf.parse(dateTime);
    Calendar c = Calendar.getInstance();
    c.setTime(tempDate);

    return distSdf.format(c.getTime()); }

  public static void main(String[] args) throws Exception {
    String newDate = getStringDate();
    System.out.println(newDate);
    String newDate2 = getPreTime(newDate, "10");
    System.out.println(newDate2);
    String newDate3 = getFormatDate(newDate, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss");
    System.out.println(newDate3);
  }
}