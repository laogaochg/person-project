package com.ifp.core.util;

import com.ifp.core.log.Trace;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public class IpUtils
{
  public static Map<Integer, String> ipTable = new HashMap();

  public static String getIpAddr(HttpServletRequest request)
  {
    String ip = request.getHeader("X-Forwarded-For");
    if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip)))
      ip = request.getHeader("Proxy-Client-IP");

    if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip)))
      ip = request.getHeader("WL-Proxy-Client-IP");

    if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip)))
      ip = request.getHeader("HTTP_CLIENT_IP");

    if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip)))
      ip = request.getHeader("HTTP_X_FORWARDED_FOR");

    if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
      ip = request.getRemoteAddr();
      if (("127.0.0.1".equals(ip)) || ("0:0:0:0:0:0:0:1".equals(ip)))
        try
        {
          ip = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
          Trace.logError("COMMON", "get ip address error!", e);
        }
    }

    return ip;
  }

  public static boolean isLegalIp(HttpServletRequest request) {
    String ip = getIpAddr(request);
    return (!(ipTable.containsValue(ip)));
  }

  public static String getHostAddress() {
    try {
      return InetAddress.getByName(InetAddress.getLocalHost().getHostName()).getHostAddress(); } catch (Exception e) {
    }
    return null;
  }

  public static void main(String[] args) {
    System.out.println(getHostAddress());
  }
}