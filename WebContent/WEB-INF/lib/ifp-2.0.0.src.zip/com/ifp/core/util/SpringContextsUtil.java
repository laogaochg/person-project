package com.ifp.core.util;

import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class SpringContextsUtil
  implements ApplicationContextAware
{
  private static final Logger mLogger = LogManager.getLogger(SpringContextsUtil.class);
  private static ApplicationContext applicationContext;

  public void setApplicationContext(ApplicationContext applicationContext)
    throws BeansException
  {
    mLogger.info("springContextUtil initialize");
    applicationContext = applicationContext;
  }

  public static ApplicationContext getApplicationContext()
  {
    return applicationContext;
  }

  public static Object getBean(String name)
    throws BeansException
  {
    if (null == applicationContext)
      applicationContext = null;

    return applicationContext.getBean(name);
  }

  public static Object getRemoteBean(String name)
    throws BaseException
  {
    try
    {
      return applicationContext.getBean(name);
    }
    catch (NoSuchBeanDefinitionException e) {
      Trace.log("ACTION", 0, "remote bean '{}' not found, research '{}', exception: {}", new Object[] { name, "dubbov_" + name + "Flow", e.getMessage() });
      try
      {
        return getBean("dubbov_" + name + "Flow");
      } catch (Exception e1) {
        throw new BaseException("remote bean '" + name + "' and '" + "dubbov_" + name + "Flow" + "' are not found. please check the define of the remote bean.");
      }
    }
    catch (Exception e) {
      throw new BaseException("remote bean 'dubbov_" + name + "Flow" + "' error.", e);
    }
  }

  public static Object getBean(String name, Class<?> requiredType)
    throws BeansException
  {
    return applicationContext.getBean(name, requiredType);
  }

  public static boolean containsBean(String name)
  {
    return applicationContext.containsBean(name);
  }

  public static boolean isSingleton(String name)
    throws NoSuchBeanDefinitionException
  {
    return applicationContext.isSingleton(name);
  }

  public static Class<?> getType(String name)
    throws NoSuchBeanDefinitionException
  {
    return applicationContext.getType(name);
  }

  public static String[] getAliases(String name)
    throws NoSuchBeanDefinitionException
  {
    return applicationContext.getAliases(name);
  }

  public static <T> Map<String, T> getBeansOfType(Class<T> type)
    throws BeansException
  {
    return applicationContext.getBeansOfType(type);
  }
}