package com.ifp.core.util;

import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.session.IFPSession;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SerializeUtils
{
  public static String serialize(Object obj)
    throws BaseException
  {
    ByteArrayOutputStream byteArrayOutputStream = null;
    ObjectOutputStream objectOutputStream = null;
    try {
      byteArrayOutputStream = new ByteArrayOutputStream();
      objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
      objectOutputStream.writeObject(obj);
      String serStr = byteArrayOutputStream.toString("ISO-8859-1");
      serStr = URLEncoder.encode(serStr, "UTF-8");
      String str1 = serStr;

      return str1;
    }
    catch (Exception e)
    {
      throw new BaseException(e);
    } finally {
      try {
        if (null != objectOutputStream)
          objectOutputStream.close();
        if (null != byteArrayOutputStream)
          byteArrayOutputStream.close();
      } catch (Exception e2) {
        Trace.log("DATA", 3, "serialize Error:", e2);
      }
    }
  }

  public static Object unSerialize(String serStr)
    throws BaseException
  {
    if (!(StringUtil.hasText(serStr))) return null;
    ByteArrayInputStream byteArrayInputStream = null;
    ObjectInputStream objectInputStream = null;
    try {
      String redStr = URLDecoder.decode(serStr, "UTF-8");
      byteArrayInputStream = new ByteArrayInputStream(redStr.getBytes("ISO-8859-1"));
      objectInputStream = new ObjectInputStream(byteArrayInputStream);
      Object obj = objectInputStream.readObject();

      Object localObject1 = obj;

      return localObject1;
    }
    catch (Exception e)
    {
      throw new BaseException(e);
    } finally {
      try {
        if (null != objectInputStream)
          objectInputStream.close();
        if (null != byteArrayInputStream)
          byteArrayInputStream.close();
      } catch (Exception e2) {
        Trace.log("DATA", 3, "unSerialize Error:", e2);
      }
    }
  }

  public static void main(String[] args) throws Exception {
    List list = new ArrayList();
    HashMap map = new HashMap();
    map.put("number", "123");
    map.put("name", "test");
    list.add(map);
    HashMap map2 = new HashMap();
    map2.put("number", "1232");
    map2.put("name", "test2");
    list.add(map2);

    String str = serialize(list);
    System.err.println(str);
    List newList = (List)unSerialize(str);

    for (Iterator i$ = newList.iterator(); i$.hasNext(); ) { Map m = (HashMap)i$.next();
      System.out.println(m.get("number") + " " + m.get("name"));
    }

    IFPSession session = new IFPSession("sssss");
    String ss = serialize(session);
    System.out.println(ss);

    Object o = unSerialize(ss);
    if (o instanceof IFPSession)
    {
      System.out.println(((IFPSession)o).getId());
    }
  }
}