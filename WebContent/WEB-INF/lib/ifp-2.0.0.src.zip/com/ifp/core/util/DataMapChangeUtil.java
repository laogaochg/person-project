package com.ifp.core.util;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.DataChangeException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DataMapChangeUtil
{
  public static DataMap mapToDataMap(Map<String, Object> map, DataMap confMap)
    throws DataChangeException
  {
    DataMap dMap = new DataMap();
    dMap.setDefineMap(confMap);
    if (null != map) {
      Iterator iterator = confMap.keySet().iterator();
      while (iterator.hasNext()) {
        String key = (String)iterator.next();
        DataElement confElement = confMap.get(key);
        if (null != confElement) {
          if (confElement instanceof DataField) {
            DataField cField = (DataField)confElement;
            String value = (String)map.get(key);
            if (value != null)
              dMap.put(key, stringToDataField(value, cField));

            continue; } if (confElement instanceof DataMap) {
            DataMap cMap = (DataMap)confElement;
            List valueList = (List)map.get(key);
            if (valueList != null)
              dMap.put(key, listToDataList(valueList, cMap));

            continue; }
          throw new DataChangeException("element type is not support: " + confElement.getClass().getSimpleName());
        }

        throw new DataChangeException("element define is not found: " + key);
      }
    }
    else {
      throw new DataChangeException("in param: map is null");
    }

    return dMap;
  }

  public static DataList listToDataList(List<Map> list, DataMap confMap)
    throws DataChangeException
  {
    DataList dList = new DataList(confMap.getName());
    dList.setDefineMap(confMap);

    for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Map map = (Map)i$.next();
      DataMap dMap = mapToDataMap(map, confMap);
      dList.add(dMap);
    }

    return dList;
  }

  public static DataField stringToDataField(String value, DataField confField)
  {
    DataField df = confField.clone();
    df.setValue(value);
    return df;
  }

  public static void dataListToList(DataList dataList, List list)
    throws DataChangeException
  {
    if ((null != dataList) && (null != list))
      for (int j = 0; j < dataList.size(); ++j) {
        DataElement dataElement = dataList.get(j);
        if (null != dataElement) {
          if (dataElement instanceof DataMap) {
            Map map = new HashMap();
            dataMapToMap((DataMap)dataElement, map);
            list.add(map);
            break label156: } if (dataElement instanceof DataField) {
            DataField dataField = (DataField)dataElement;
            list.add(dataField.getValue());
            break label156: }
          throw new DataChangeException("element type is not support: " + dataElement.getClass().getSimpleName());
        }

        label156: throw new DataChangeException("dataElement is null in dataList, index: " + j);
      }

    else
      throw new DataChangeException("in param is null");
  }

  public static void dataMapToMap(DataMap dataMap, Map map)
    throws DataChangeException
  {
    if ((null != dataMap) && (null != map)) {
      Iterator iterator = dataMap.keySet().iterator();
      while (iterator.hasNext()) {
        String key = (String)iterator.next();
        DataElement dataElement = dataMap.get(key);
        if (null != dataElement) {
          if (dataElement instanceof DataField) {
            DataField dataField = (DataField)dataElement;
            map.put(key, dataField.getValue());
            continue; } if (dataElement instanceof DataList) {
            List list = new ArrayList();
            dataListToList((DataList)dataElement, list);
            map.put(key, list);
            continue; }
          throw new DataChangeException("element type is not support: " + dataElement.getClass().getSimpleName());
        }

        throw new DataChangeException("dataElement is null: " + key);
      }
    }
    else {
      throw new DataChangeException("in param is null");
    }
  }

  public static DataMap mapToDataMap(Map<String, Object> map)
    throws DataChangeException
  {
    DataMap dMap = new DataMap();
    if (null != map) {
      Iterator iterator = map.keySet().iterator();
      while (iterator.hasNext()) {
        String key = (String)iterator.next();
        Object object = map.get(key);
        if (null != object) {
          if (object instanceof String) {
            dMap.put(key, new DataField(key, (String)object)); continue; }
          if (object instanceof List) {
            dMap.put(key, listToDataList(key, (List)object)); continue; }
          if (object instanceof Map) {
            dMap.put(key, mapToDataMap((Map)object)); continue;
          }
          throw new DataChangeException("element type is not support: " + object.getClass().getSimpleName());
        }

        throw new DataChangeException("element define is not found: " + key);
      }
    }
    else {
      throw new DataChangeException("in param: map is null");
    }

    return dMap;
  }

  public static DataList listToDataList(String listName, List<Map> list)
    throws DataChangeException
  {
    DataList dList = new DataList(listName);
    if (null != list)
      for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Map map = (Map)i$.next();
        DataMap dMap = mapToDataMap(map);
        dList.add(dMap);
      }
    else {
      throw new DataChangeException("in param: list is null");
    }

    return dList;
  }
}