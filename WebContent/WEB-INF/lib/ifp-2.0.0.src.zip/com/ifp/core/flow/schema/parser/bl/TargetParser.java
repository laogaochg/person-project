package com.ifp.core.flow.schema.parser.bl;

import com.ifp.core.flow.step.StepTarget;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

public class TargetParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    builder.addPropertyValue("id", element.getAttribute("id"));
    builder.addPropertyValue("value", element.getAttribute("value"));

    String condition = element.getAttribute("condition");
    if (StringUtils.hasText(condition))
      builder.addPropertyValue("condition", element.getAttribute("condition"));
  }

  protected Class<StepTarget> getBeanClass(Element element)
  {
    return StepTarget.class;
  }
}