package com.ifp.core.flow.action.rpc;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.AbstractAction;
import com.ifp.core.flow.interceptor.processor.IProcessor;
import com.ifp.core.handle.ExceptionHandle;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.rpc.RPCHandle;
import org.springframework.util.StringUtils;

public abstract class AbstractRpcAction extends AbstractAction
{
  private String rpcName = "rpc";
  private IProcessor beforeProcessor;
  private IProcessor afterProcessor;
  private RPCHandle rpcHandle;

  public AbstractRpcAction()
  {
  }

  public AbstractRpcAction(String rpcName)
  {
    this.rpcName = rpcName;
  }

  public String getRpcName() {
    return this.rpcName;
  }

  public void preHandle(BlogicContext context)
    throws BaseException
  {
    if (null != this.beforeProcessor)
      this.beforeProcessor.process(context);
  }

  public void postHandle(BlogicContext context)
    throws BaseException
  {
    if (null != this.afterProcessor)
      this.afterProcessor.process(context);
  }

  public int execute(BlogicContext context, DataMap confMap) throws BaseException
  {
    try {
      preHandle(context);
      DataMap dataMap = (DataMap)context.getDataMap();

      String logicId = confMap.getElementValue("logicId");
      String methodName = null;
      if (confMap.containsKey("methodName"))
        methodName = getConfValue("methodName", dataMap, confMap);
      if (!(StringUtils.hasText(methodName))) {
        Trace.logDebug("FLOW", getRpcName() + "调远程服务时，没指定方法，默认调execute");
        methodName = "execute";
      }
      String mappingId = null;
      if (confMap.containsKey("mappingId"))
        mappingId = getConfValue("mappingId", dataMap, confMap);

      context.setLastExceLogic(logicId);
      Trace.log("FLOW", 0, getRpcName() + "调远程flow组件，调用远程flow的logicId为{}", new Object[] { logicId });

      if (null == this.rpcHandle) {
        this.rpcHandle = ((RPCHandle)SpringContextsUtil.getBean("rpcHandle"));
      }

      try
      {
        this.rpcHandle.executeRemoteServiceForBL(context, logicId, methodName, mappingId);
      }
      catch (BaseException e) {
        String errorCodeField = null;
        if (confMap.containsKey("errorCodeField"))
          errorCodeField = confMap.getElementValue("errorCodeField");

        String errorMsgField = null;
        if (confMap.containsKey("errorMsgField"))
          errorMsgField = confMap.getElementValue("errorMsgField");

        BaseException ex = ExceptionHandle.handleBaseException(e);

        if (StringUtils.hasText(errorCodeField))
          dataMap.put(errorCodeField, ex.getErrorCode());

        if (StringUtils.hasText(errorMsgField)) {
          dataMap.put(errorMsgField, ex.getErrorMessage());
        }

        throw e;
      }

      e = 0;

      return e; } finally { postHandle(context);
    }
  }

  public IProcessor getBeforeProcessor() {
    return this.beforeProcessor;
  }

  public void setBeforeProcessor(IProcessor beforeProcessor) {
    this.beforeProcessor = beforeProcessor;
  }

  public IProcessor getAfterProcessor() {
    return this.afterProcessor;
  }

  public void setAfterProcessor(IProcessor afterProcessor) {
    this.afterProcessor = afterProcessor;
  }
}