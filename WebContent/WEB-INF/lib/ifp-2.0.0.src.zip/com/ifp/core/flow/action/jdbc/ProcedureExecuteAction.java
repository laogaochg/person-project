package com.ifp.core.flow.action.jdbc;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.FillResultException;
import com.ifp.core.exception.JdbcException;
import com.ifp.core.jdbc.adapter.IJdbcAdapter;
import com.ifp.core.log.Trace;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;

public class ProcedureExecuteAction extends AbstractJDBCAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    String dataSource = confMap.getElementValue("dataSource");
    try
    {
      String procedureName = confMap.getElementValue("procedureName").trim();
      String inFields = confMap.getElementValue("inFields").replaceAll(" ", "");
      int outType = Integer.parseInt(confMap.getElementValue("outType"));
      String outFields = confMap.getElementValue("outFields").replaceAll(" ", "");

      String[] inFieldArray = ("".equals(inFields)) ? new String[0] : inFields.split(getFieldSeperatorRegex());
      for (int i = 0; i < inFieldArray.length; ++i) {
        inFieldArray[i] = dataMap.getElementValue(inFieldArray[i]);
        Trace.log("JDBC", 0, "inFields[{}]--->{}", new Object[] { Integer.valueOf(i), inFieldArray[i] });
      }

      String[] outFieldArray = ((outType == 0) || ("".equals(outFields))) ? new String[0] : outFields.split(getFieldSeperatorRegex());
      IJdbcAdapter jdbcAdapter = getJdbcAdapter(dataSource);
      JdbcTemplate jdbcTemplate = getJdbcTemplate(dataSource);
      String pSql = jdbcAdapter.getExecuteProcedureSql(procedureName, outType, inFieldArray, outFieldArray);
      Trace.log("JDBC", 1, "execProcSQL--->{}", new Object[] { pSql });

      jdbcTemplate.execute(new CallableStatementCreator(this, pSql, jdbcAdapter, inFieldArray, outType, outFieldArray) {
        public CallableStatement createCallableStatement() throws SQLException {
          CallableStatement cs = conn.prepareCall(this.val$pSql);

          this.val$jdbcAdapter.setInField(cs, this.val$inFieldArray);

          this.val$jdbcAdapter.setOutField(cs, this.val$outType, this.val$inFieldArray.length + 1, this.val$outFieldArray);

          return cs;
        }
      }
      , new CallableStatementCallback(this, outType, outFieldArray, dataMap, inFieldArray)
      {
        public Object doInCallableStatement()
          throws SQLException, DataAccessException
        {
          boolean hadResults = cs.execute();
          try {
            if (this.val$outType == 2) {
              String[] arr$ = this.val$outFieldArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String oFields = arr$[i$];
                ResultSet rs = cs.getResultSet();
                int index = oFields.indexOf("(");
                String listName = oFields.substring(0, index);
                DataList dList = (DataList)this.val$dataMap.get(listName);
                if (null != dList) {
                  String[] oFieldsArray = oFields.substring(index + 1, oFields.length() - 1).split(",");
                  while ((rs != null) && (rs.next())) {
                    DataMap dMap = dList.createSubDataMap();
                    for (int i = 0; i < oFieldsArray.length; ++i)
                      dMap.put(oFieldsArray[i], rs.getString(i + 1));

                    dList.add(dMap);
                  }
                } else {
                  throw new FillResultException("no dataList name:" + listName);
                }
                hadResults = cs.getMoreResults();
              }
            } else {
              int i = this.val$inFieldArray.length;
              for (int j = 0; j < this.val$outFieldArray.length; ++j) {
                String rst = cs.getString(++i);
                this.val$dataMap.put(this.val$outFieldArray[j], rst);
                Trace.log("JDBC", 0, "outField[{}]--->{}", new Object[] { Integer.valueOf(j), rst });
              }
            }
          } catch (FillResultException e) {
            throw e;
          } catch (Exception e) {
            throw new FillResultException(e);
          }

          return null;
        } } );
    }
    catch (Exception e) {
      throw new JdbcException(e);
    }

    return 0;
  }
}