package com.ifp.core.flow.action.time;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.AbstractAction;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class GetCurrentSystemTimeAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try {
      String timeFormat = confMap.getElementValue("timeFormat");
      String timeField = confMap.getElementValue("timeField");

      String time = "";
      Calendar calendar = Calendar.getInstance();
      Date date = calendar.getTime();

      if ((timeFormat == null) || ("".equals(timeFormat)))
        time = String.valueOf(date.getTime());

      SimpleDateFormat formatter = new SimpleDateFormat(timeFormat);
      time = formatter.format(date);

      dataMap.setElementValue(timeField, time);
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}