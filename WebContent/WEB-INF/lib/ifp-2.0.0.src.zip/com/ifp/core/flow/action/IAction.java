package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;

public abstract interface IAction
{
  public abstract int execute(BlogicContext paramBlogicContext, DataMap paramDataMap)
    throws BaseException;
}