package com.ifp.core.flow.step;

import java.util.List;
import java.util.Map;

public class FlowStep extends AbstractStep
{
  private Map<String, StepTarget> asyncTargetMap;
  private List<String> asyncWaitList;

  public Map<String, StepTarget> getAsyncTargetMap()
  {
    return this.asyncTargetMap;
  }

  public void setAsyncTargetMap(Map<String, StepTarget> asyncTargetMap) {
    this.asyncTargetMap = asyncTargetMap;
  }

  public List<String> getAsyncWaitList() {
    return this.asyncWaitList;
  }

  public void setAsyncWaitList(List<String> asyncWaitList) {
    this.asyncWaitList = asyncWaitList;
  }
}