package com.ifp.core.flow.service.impl;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.handle.ExceptionHandle;
import java.util.HashMap;
import java.util.Map;

public class FlowServiceNoExceptionImpl extends FlowServiceImpl
{
  public Map<String, Object> execute(Map<String, Object> dataMap)
    throws BaseException
  {
    Map map = null;
    String errorCode = "";
    String errorMsg = "";
    try {
      map = super.execute(dataMap);
    } catch (BaseException e) {
      BaseException ex = ExceptionHandle.handleBaseException(e);
      errorCode = ex.getErrorCode();
      errorMsg = ex.getErrorMessage();
    } catch (Exception e) {
      errorCode = "SYEC0001";
      errorMsg = "系统繁忙,请稍后再试";
    } finally {
      if (null == map)
        map = new HashMap();
      map.put("errorCode", errorCode);
      map.put("errorMsg", errorMsg);
    }
    return map;
  }

  public BlogicContext execute(BlogicContext blogicContext) throws BaseException {
    DataMap dataMap;
    String errorCode = "";
    String errorMsg = "";
    try {
      blogicContext = super.execute(blogicContext);
    } catch (BaseException e) {
      BaseException ex = ExceptionHandle.handleBaseException(e);
      errorCode = ex.getErrorCode();
      errorMsg = ex.getErrorMessage();
    } catch (Exception e) {
      errorCode = "SYEC0001";
      errorMsg = "系统繁忙,请稍后再试";
    } finally {
      DataMap dataMap = (DataMap)blogicContext.getDataMap();
      dataMap.setElementValue("errorCode", errorCode);
      dataMap.setElementValue("errorMsg", errorMsg);
    }
    return blogicContext;
  }
}