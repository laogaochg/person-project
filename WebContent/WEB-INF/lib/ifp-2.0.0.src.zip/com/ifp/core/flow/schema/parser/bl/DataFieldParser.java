package com.ifp.core.flow.schema.parser.bl;

import com.ifp.core.data.DataField;
import com.ifp.core.util.StringUtil;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

public class DataFieldParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String name = element.getAttribute("name");
    if (StringUtils.hasText(name)) {
      builder.addPropertyValue("name", element.getAttribute("name"));
    }

    String defaultValue = element.getAttribute("defaultValue");
    if (null == defaultValue)
      defaultValue = "";

    builder.addPropertyValue("defaultValue", defaultValue);

    String value = element.getAttribute("value");
    if (StringUtil.hasText(value))
      builder.addPropertyValue("value", value);
    else {
      builder.addPropertyValue("value", defaultValue);
    }

    String desc = element.getAttribute("desc");
    if (StringUtils.hasText(desc))
      builder.addPropertyValue("desc", desc);
    else
      builder.addPropertyValue("desc", "");
  }

  protected Class<DataField> getBeanClass(Element element)
  {
    return DataField.class;
  }
}