package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import org.springframework.util.StringUtils;

public class ThrowExceptionAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    String errorCode = confMap.getElementValue("errorCode");
    if (!(StringUtils.hasText(errorCode)))
      throw new ActionException("错误码为null");

    if (errorCode.trim().startsWith("#"))
      errorCode = ((DataMap)context.getDataMap()).getElementValue(errorCode.substring(1));

    ((DataMap)context.getDataMap()).put("errorCode", new DataField("errorCode", errorCode));

    String errorMsg = confMap.getElementValue("errorMsg");
    if (StringUtils.hasText(errorMsg)) {
      if (errorMsg.trim().startsWith("#"))
        errorMsg = ((DataMap)context.getDataMap()).getElementValue(errorMsg.substring(1));

      ((DataMap)context.getDataMap()).put("errorMsg", new DataField("errorMsg", errorMsg));
    }
    throw new ActionException(errorCode, errorMsg);
  }
}