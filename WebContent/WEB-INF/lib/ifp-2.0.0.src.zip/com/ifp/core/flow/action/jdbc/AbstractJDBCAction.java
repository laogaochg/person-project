package com.ifp.core.flow.action.jdbc;

import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.flow.action.AbstractAction;
import com.ifp.core.jdbc.adapter.IJdbcAdapter;
import com.ifp.core.log.Trace;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.jdbc.core.JdbcTemplate;

public abstract class AbstractJDBCAction extends AbstractAction
{
  private Map<String, Object> jdbcTemplateMap;
  private Pattern pattern;

  public AbstractJDBCAction()
  {
    this.pattern = Pattern.compile("#[A-Za-z0-9_.]+");
  }

  public List<String> getSqlParamValueList(String querySql, DataMap dataMap)
  {
    List inputList = new ArrayList();
    Matcher matcher = this.pattern.matcher(querySql);
    while (matcher.find()) {
      String key = querySql.substring(matcher.start(0) + 1, matcher.end(0));
      inputList.add(dataMap.getElementValue(key));
    }

    return inputList;
  }

  public Object[] getSqlParamValueListAndSql(String querySql, DataMap dataMap)
    throws Exception
  {
    Object[] rstObj = new Object[2];
    StringBuffer sql = new StringBuffer();
    List inputList = new ArrayList();

    Matcher matcher = this.pattern.matcher(querySql);
    int beginIndex = 0;
    int endIndex = 0;
    while (matcher.find()) {
      endIndex = matcher.start(0);
      sql.append(querySql.substring(beginIndex, endIndex));
      beginIndex = endIndex;
      endIndex = matcher.end(0);
      String key = querySql.substring(beginIndex + 1, endIndex);
      if (key.indexOf(".") < 0) {
        String value = dataMap.getElementValue(key);
        inputList.add(value);
        sql.append("?");
      } else {
        String[] names = key.split("\\.");
        if (names.length == 2) {
          DataList dList = (DataList)dataMap.get(names[0]);
          for (int i = 0; i < dList.size(); ++i) {
            DataMap dMap = (DataMap)dList.get(i);
            String value = dMap.getElementValue(names[1]);
            inputList.add(value);
            if (i == 0)
              sql.append("?");
            else
              sql.append(",?");
          }
        }
        else {
          throw new ActionException("list name must be *.*: " + key);
        }
      }

      beginIndex = endIndex;
    }
    sql.append(querySql.substring(beginIndex));

    rstObj[0] = sql.toString();
    rstObj[1] = inputList;
    return rstObj;
  }

  public void fillResultIntoDataList(ResultSet resultSet, DataList dataList, List<String> outputList)
    throws Exception
  {
    DataMap dataMap = dataList.createSubDataMap();
    fillResultIntoDataMap(resultSet, dataMap, outputList);
    dataList.add(dataMap);
  }

  public void fillResultIntoDataMap(ResultSet resultSet, DataMap dataMap, List<String> outputList)
    throws Exception
  {
    for (int i = 1; i <= outputList.size(); ++i) {
      String name = (String)outputList.get(i - 1);

      Object value = resultSet.getObject(i);
      if (null == value)
        dataMap.put(name, "");
      else
        dataMap.put(name, String.valueOf(value));
    }

    Trace.log("JDBC", 0, "{}", new Object[] { dataMap });
  }

  public JdbcTemplate getJdbcTemplate(String key)
  {
    return ((JdbcTemplate)this.jdbcTemplateMap.get(key));
  }

  public IJdbcAdapter getJdbcAdapter(String key)
  {
    return ((IJdbcAdapter)this.jdbcTemplateMap.get(key + "_Adapter"));
  }

  public Map<String, Object> getJdbcTemplateMap() {
    return this.jdbcTemplateMap;
  }

  public void setJdbcTemplateMap(Map<String, Object> jdbcTemplateMap) {
    this.jdbcTemplateMap = jdbcTemplateMap;
  }
}