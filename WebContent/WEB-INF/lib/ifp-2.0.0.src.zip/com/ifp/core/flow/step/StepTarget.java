package com.ifp.core.flow.step;

public class StepTarget extends AbstractTarget
{
}