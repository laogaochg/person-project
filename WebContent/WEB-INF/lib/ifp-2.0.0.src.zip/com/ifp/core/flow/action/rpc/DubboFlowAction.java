package com.ifp.core.flow.action.rpc;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;

public class DubboFlowAction extends AbstractRpcAction
{
  public DubboFlowAction()
  {
    super("dubbov");
  }

  public int execute(BlogicContext context, DataMap confMap) throws BaseException {
    return super.execute(context, confMap);
  }
}