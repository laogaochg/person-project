package com.ifp.core.flow.action.operation;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.AbstractAction;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

public class AmtSimpleMulDivAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try {
      String amtFields = confMap.getElementValue("amtFields");
      String operation = confMap.getElementValue("operation");
      String decimalNum = confMap.getElementValue("decimalNum");
      String roundMode = confMap.getElementValue("roundMode");
      String outputField = confMap.getElementValue("outputField");

      String[] fields = amtFields.split(getFieldSeperatorRegex());
      if (fields.length > 1) {
        BigDecimal bdField1 = new BigDecimal(dataMap.getElementValue(fields[0]));
        for (int i = 1; i < fields.length; ++i) {
          BigDecimal bdField2 = new BigDecimal(dataMap.getElementValue(fields[i]));
          if ("mul".equals(operation)) {
            bdField1 = bdField1.multiply(bdField2);
            bdField1 = bdField1.setScale(Integer.parseInt(decimalNum.trim()), Integer.parseInt(roundMode.trim()));
          } else if ("div".equals(operation)) {
            bdField1 = bdField1.divide(bdField2, Integer.parseInt(decimalNum.trim()), Integer.parseInt(roundMode.trim()));
          }
        }

        DecimalFormat df = new DecimalFormat(new StringBuilder().append("0").append(StringUtils.repeat("0", NumberUtils.toInt(decimalNum))).toString());

        dataMap.setElementValue(outputField, df.format(bdField1.doubleValue()));
      } else {
        throw new ActionException("amtFields must be more than one");
      }
    } catch (NumberFormatException e) {
      throw new ActionException("数据格式化错误，格式化数据含有非数字", e);
    } catch (BaseException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}