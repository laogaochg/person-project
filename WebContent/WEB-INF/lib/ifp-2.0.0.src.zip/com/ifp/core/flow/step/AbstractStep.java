package com.ifp.core.flow.step;

import com.ifp.core.data.DataMap;
import java.util.Map;

public abstract class AbstractStep
  implements IStep
{
  private String stepId;
  private String refBeanId;
  private DataMap confMap;
  private Map<String, StepTarget> targetMap;

  public AbstractStep()
  {
    this.confMap = new DataMap();
  }

  public String getStepId()
  {
    return this.stepId;
  }

  public void setStepId(String stepId) {
    this.stepId = stepId;
  }

  public String getRefBeanId() {
    return this.refBeanId;
  }

  public void setRefBeanId(String refBeanId) {
    this.refBeanId = refBeanId;
  }

  public DataMap getConfMap() {
    return this.confMap;
  }

  public void setConfMap(DataMap confMap) {
    this.confMap = confMap;
  }

  public Map<String, StepTarget> getTargetMap() {
    return this.targetMap;
  }

  public void setTargetMap(Map<String, StepTarget> targetMap) {
    this.targetMap = targetMap;
  }
}