package com.ifp.core.flow.action;

@Deprecated
public class DubboFlowAction extends com.ifp.core.flow.action.rpc.DubboFlowAction
{
}