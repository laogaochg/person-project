package com.ifp.core.flow.interceptor;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.InterceptorException;

public abstract interface IInterceptor
{
  public abstract int execute(ClogicContext paramClogicContext, DataMap paramDataMap)
    throws InterceptorException;
}