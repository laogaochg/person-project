package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.FlowHandle;
import com.ifp.core.flow.logic.BusinessLogic;
import com.ifp.core.flow.logic.Flow;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import java.util.Map;
import org.springframework.transaction.PlatformTransactionManager;

public class SubFlowAction extends AbstractAction
{
  private Map<String, PlatformTransactionManager> txManagerMap;

  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    String subLogicId = confMap.getElementValue("subFlowId");
    int result = 0;
    try {
      BusinessLogic logic = (BusinessLogic)SpringContextsUtil.getBean(context.getLogicCode());
      FlowHandle blFlowHandle = (FlowHandle)SpringContextsUtil.getBean("blFlowHandle");

      String parentLogicPath = context.getLogicPath();
      Map subLogicMap = logic.getSubFlow();
      Flow subLogic = (Flow)subLogicMap.get(subLogicId);
      if (null != subLogic)
        try {
          context.setLogicPath(parentLogicPath + "." + subLogicId);
          String resultValue = blFlowHandle.execute(subLogic, context);
          if (StringUtil.hasText(resultValue))
            try {
              result = Integer.parseInt(resultValue);
            } catch (Exception e) {
              result = -1;
            }
        }
        finally {
          context.setLogicPath(parentLogicPath);
        }
      else
        throw new ActionException("取得的子逻辑为空，请检查流程配置文件和加载程序！");
    }
    catch (ActionException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException("子逻辑块执行异常！subLogicId ：" + subLogicId, e);
    }
    return result;
  }

  public Map<String, PlatformTransactionManager> getTxManagerMap() {
    return this.txManagerMap;
  }

  public void setTxManagerMap(Map<String, PlatformTransactionManager> txManagerMap) {
    this.txManagerMap = txManagerMap;
  }
}