package com.ifp.core.flow.step;

import com.ifp.core.context.Context;
import com.ifp.core.exception.BaseException;

public abstract interface IStepHandle<T, E extends Context>
{
  public abstract int executeBean(T paramT, E paramE)
    throws BaseException;

  public abstract StepTarget getTargetStep(T paramT, E paramE, int paramInt, Exception paramException)
    throws BaseException;

  public abstract String getEndInfo(T paramT);
}