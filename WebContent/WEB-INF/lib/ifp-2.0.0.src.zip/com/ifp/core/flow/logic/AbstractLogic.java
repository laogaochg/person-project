package com.ifp.core.flow.logic;

import com.ifp.core.base.SystemConf;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.data.InputField;
import com.ifp.core.data.OutputField;
import com.ifp.core.exception.ElementNotSupportException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public abstract class AbstractLogic
  implements ILogic
{
  public String id;
  public String name;
  public boolean commonFlag;
  public DataMap defaultDataMap;
  public DataMap dataDictionary;
  public DataList inputParamsList;
  public DataList inputCommParamsList;
  public DataList outputParamsList;
  public DataList outputCommParamsList;
  public transient Flow flow;
  private DataMap defaultParamsMap;
  private SystemConf systemConf;

  public AbstractLogic()
  {
    this.commonFlag = false;

    this.defaultDataMap = new DataMap();
  }

  public void init()
  {
    Map inputCommParamsMap;
    Map outputCommParamsMap;
    Map.Entry entry;
    Iterator iterator;
    InputField iField;
    Map.Entry entry;
    String key;
    OutputField iField;
    String value;
    String key;
    String value;
    this.defaultParamsMap = ((DataMap)this.systemConf.getConfByKey("blogicDefautlParams"));

    boolean inputMergeFlag = Boolean.valueOf((String)this.systemConf.getConfByKey("inputMergeFlag")).booleanValue();
    if (inputMergeFlag) {
      inputCommParamsMap = (Map)this.systemConf.getConfByKey("blogicInputCommParams");
      if (null != inputCommParamsMap) {
        iterator = inputCommParamsMap.entrySet().iterator();
        while (iterator.hasNext()) {
          entry = (Map.Entry)iterator.next();
          iField = new InputField();
          key = (String)entry.getKey();
          iField.setName(key);
          value = (String)entry.getValue();
          iField.setSourceName((com.ifp.core.util.StringUtil.hasText(value)) ? value.trim() : key);
          this.inputParamsList.add(iField);
        }
      }
    } else {
      this.inputCommParamsList = new DataList();
      inputCommParamsMap = (Map)this.systemConf.getConfByKey("blogicInputCommParams");
      if (null != inputCommParamsMap) {
        iterator = inputCommParamsMap.entrySet().iterator();
        while (iterator.hasNext()) {
          entry = (Map.Entry)iterator.next();
          iField = new InputField();
          key = (String)entry.getKey();
          iField.setName(key);
          value = (String)entry.getValue();
          iField.setSourceName((com.ifp.core.util.StringUtil.hasText(value)) ? value.trim() : key);
          this.inputCommParamsList.add(iField);
        }
      }

    }

    boolean outputMergeFlag = Boolean.valueOf((String)this.systemConf.getConfByKey("outputMergeFlag")).booleanValue();
    if (outputMergeFlag) {
      outputCommParamsMap = (Map)this.systemConf.getConfByKey("blogicOutputCommParams");
      if (null != outputCommParamsMap) {
        iterator = outputCommParamsMap.entrySet().iterator();
        while (iterator.hasNext()) {
          entry = (Map.Entry)iterator.next();
          iField = new OutputField();
          key = (String)entry.getKey();
          iField.setName(key);
          value = (String)entry.getValue();
          iField.setTargetName((com.ifp.core.util.StringUtil.hasText(value)) ? value.trim() : key);
          this.outputParamsList.add(iField);
        }
      }
    } else {
      this.outputCommParamsList = new DataList();
      outputCommParamsMap = (Map)this.systemConf.getConfByKey("blogicOutputCommParams");
      if (null != outputCommParamsMap) {
        iterator = outputCommParamsMap.entrySet().iterator();
        while (iterator.hasNext()) {
          entry = (Map.Entry)iterator.next();
          iField = new OutputField();
          key = (String)entry.getKey();
          iField.setName(key);
          value = (String)entry.getValue();
          iField.setTargetName((com.ifp.core.util.StringUtil.hasText(value)) ? value.trim() : key);
          this.outputCommParamsList.add(iField);
        }
      }
    }

    this.dataDictionary.putAll(this.defaultParamsMap);

    this.dataDictionary.setDefineMap(this.dataDictionary);
    Iterator iterator = this.dataDictionary.values().iterator();
    while (iterator.hasNext()) {
      DataElement dataElement = (DataElement)iterator.next();
      if (dataElement instanceof DataField) {
        DataField dataField = (DataField)dataElement;
        this.defaultDataMap.put(dataField.getName(), dataField.clone());
      } else if (dataElement instanceof DataMap) {
        DataMap confDataMap = (DataMap)dataElement;
        DataList dataList = new DataList(confDataMap.getName());
        dataList.setDefineMap(confDataMap);
        this.defaultDataMap.put(confDataMap.getName(), dataList);
      } else {
        throw new ElementNotSupportException("element's type is not support:" + dataElement.getClass().getSimpleName());
      }
    }
  }

  public String getId() {
    return this.id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public boolean isCommonFlag() {
    return this.commonFlag;
  }

  public void setCommonFlag(boolean commonFlag) {
    this.commonFlag = commonFlag;
  }

  public DataMap getDataDictionary() {
    return this.dataDictionary;
  }

  public void setDataDictionary(DataMap dataDictionary) {
    this.dataDictionary = dataDictionary;
  }

  public DataList getInputParamsList() {
    return this.inputParamsList;
  }

  public void setInputParamsList(DataList inputParamsList) {
    this.inputParamsList = inputParamsList;
  }

  public DataList getOutputParamsList() {
    return this.outputParamsList;
  }

  public void setOutputParamsList(DataList outputParamsList) {
    this.outputParamsList = outputParamsList;
  }

  public Flow getFlow() {
    return this.flow;
  }

  public void setFlow(Flow flow) {
    this.flow = flow;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public SystemConf getSystemConf() {
    return this.systemConf;
  }

  public void setSystemConf(SystemConf systemConf) {
    this.systemConf = systemConf;
  }

  public DataMap getDefaultParamsMap() {
    return this.defaultParamsMap;
  }

  public void setDefaultParamsMap(DataMap defaultParamsMap) {
    this.defaultParamsMap = defaultParamsMap;
  }

  public DataList getInputCommParamsList() {
    return this.inputCommParamsList;
  }

  public void setInputCommParamsList(DataList inputCommParamsList) {
    this.inputCommParamsList = inputCommParamsList;
  }

  public DataList getOutputCommParamsList() {
    return this.outputCommParamsList;
  }

  public void setOutputCommParamsList(DataList outputCommParamsList) {
    this.outputCommParamsList = outputCommParamsList;
  }

  public DataMap getDefaultDataMap()
  {
    return this.defaultDataMap;
  }

  public void setDefaultDataMap(DataMap defaultDataMap) {
    this.defaultDataMap = defaultDataMap;
  }
}