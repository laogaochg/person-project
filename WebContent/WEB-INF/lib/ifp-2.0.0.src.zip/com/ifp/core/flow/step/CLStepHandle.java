package com.ifp.core.flow.step;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.InterceptorException;
import com.ifp.core.exception.StepException;
import com.ifp.core.flow.interceptor.IInterceptor;
import com.ifp.core.util.SpringContextsUtil;

public class CLStepHandle extends AbstractStepHandle<ClogicContext>
{
  public int executeBean(FlowStep step, ClogicContext context)
    throws BaseException
  {
    int flag = 0;
    try {
      IInterceptor interceptor = (IInterceptor)SpringContextsUtil.getBean(step.getRefBeanId());
      flag = interceptor.execute(context, step.getConfMap());
    } catch (InterceptorException ie) {
      throw ie;
    } catch (Exception e) {
      throw new StepException(e);
    }

    return flag;
  }
}