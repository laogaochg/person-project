package com.ifp.core.flow.action;

import com.ifp.core.base.SystemConf;
import com.ifp.core.data.DataMap;
import com.ifp.core.util.StringUtil;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractAction
  implements IAction
{
  private String id;
  private final String fieldSeperator = "||";
  private final String fieldSeperatorRegex = "\\|\\|";
  private final String fieldSeperator2 = ",";
  private final String fieldSeperatorRegex2 = ",";
  private SystemConf systemConf;

  public AbstractAction()
  {
    this.fieldSeperator = "||";

    this.fieldSeperatorRegex = "\\|\\|";

    this.fieldSeperator2 = ",";

    this.fieldSeperatorRegex2 = ",";
  }

  public List<String> getFieldList(String fieldsNames)
  {
    List list = new ArrayList();
    if (StringUtil.hasText(fieldsNames)) {
      String[] fields = fieldsNames.split("\\|\\|");
      String[] arr$ = fields; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String field = arr$[i$];
        list.add(field);
      }
    }

    return list;
  }

  public String getConfValue(String key, DataMap dataMap, DataMap confMap)
  {
    String value = confMap.getElementValue(key);
    if (value.startsWith("#"))
      value = dataMap.getElementValue(value.substring(1));

    return value;
  }

  public String getId() {
    return this.id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getFieldSeperator() {
    return "||";
  }

  public String getFieldSeperatorRegex() {
    return "\\|\\|";
  }

  public String getFieldSeperator2() {
    return ",";
  }

  public String getFieldSeperatorRegex2() {
    return ",";
  }

  public SystemConf getSystemConf() {
    return this.systemConf;
  }

  public void setSystemConf(SystemConf systemConf) {
    this.systemConf = systemConf;
  }
}