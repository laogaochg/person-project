package com.ifp.core.flow.log;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.IAction;
import com.ifp.core.log.IfpActionLogInfo;
import com.ifp.core.log.IfpActionLoggerInterface;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import java.util.Map;

public class IfpActionLoggerImpl
  implements IfpActionLoggerInterface
{
  private final IAction sqlExceAction = (IAction)SpringContextsUtil.getBean("sqlExecuteOneProxyAction");
  private final IAction seqAction = (IAction)SpringContextsUtil.getBean("getSequenceNumberAction");
  private String logSql = "insert into PUB_ACCESSLOG (VLG_FLOWNO,VLG_CHANNELID,VLG_TRANSCODE,VLG_SVRTRANSCODE,VLG_REQTIME,VLG_REPTIME,VLG_STATUS,VLG_REQTEXT,VLG_REPTEXT,VLG_IP,VLG_APPID,VLG_REQID,VLG_CID,VLG_PID) values (#flowNo,#channel,#transCode,#svrTranscode,#reqTime,#repTime,#status,#reqText,#repText,#channelIP,#appId,#reqId,#cid,#pcid)";
  private DataMap confMap = new DataMap(true);
  private boolean isLogText = true;

  public IfpActionLoggerImpl()
  {
    this.confMap.put("outputField", new DataField("outputField", "flowNo"));
    this.confMap.put("sequence", new DataField("sequence", "VLG_FLOW_NO"));
    this.confMap.put("execSql", new DataField("execSql", this.logSql));
    this.confMap.put("dataSource", new DataField("dataSource", "mainDB"));
    this.confMap.put("transType", new DataField("transType", "1"));
  }

  public void log(IContext context, IfpActionLogInfo logInfo) throws BaseException
  {
    BlogicContext blContext = (BlogicContext)context;
    DataMap dataMap = (DataMap)blContext.getDataMap();
    try {
      Map map = (Map)blContext.getTempMap().get("blogicMap");
      dataMap.put("flowNo", new DataField("flowNo"));
      setFlowNo(blContext);
      dataMap.put("reqId", new DataField("reqId", (String)map.get("reqId")));
      dataMap.put("pcid", new DataField("pcid", (String)map.get("pcid")));
      dataMap.put("cid", new DataField("cid", (String)map.get("cid")));
      dataMap.put("reqTime", new DataField("reqTime", (String)map.get("reqTime")));
      dataMap.put("transCode", new DataField("transCode", (String)map.get("transCode")));
      dataMap.put("svrTranscode", new DataField("svrTranscode", (String)map.get("svrTranscode")));
      if (isLogText())
      {
        dataMap.put("repText", new DataField("repText", (String)map.get("repText")));
        dataMap.put("reqText", new DataField("reqText", (String)map.get("reqText")));
      } else {
        dataMap.put("repText", new DataField("repText", ""));
        dataMap.put("reqText", new DataField("reqText", ""));
      }
      dataMap.put("channelIP", new DataField("channelIP", (String)map.get("flumeReqIp")));
      dataMap.put("channel", new DataField("channel", (String)map.get("channel")));
      dataMap.put("repTime", new DataField("repTime", (String)map.get("repTime")));
      dataMap.put("appId", new DataField("appId", (String)map.get("appId")));
      this.sqlExceAction.execute(blContext, this.confMap);
    } catch (Exception e) {
      Trace.log("DATA", 3, "记录访问日志异常：", e);
    }
  }

  private void setFlowNo(BlogicContext blContext)
  {
    DataMap dataMap = (DataMap)blContext.getDataMap();
    try {
      this.seqAction.execute(blContext, this.confMap);
    } catch (Exception e) {
      Trace.log("DATA", 3, "获取流水号异常：", e);
    }
  }

  public void log(IContext context, IfpActionLogInfo logInfo, Throwable t)
    throws BaseException
  {
    BlogicContext blContext = (BlogicContext)context;
    DataMap dataMap = (DataMap)blContext.getDataMap();
    if (t != null)
    {
      String status = "1";
      if (t instanceof BaseException)
      {
        status = ((BaseException)t).getErrorCode();
      }
      dataMap.put("status", new DataField("status", status));
    } else {
      dataMap.put("status", new DataField("status", "0"));
    }
    log(context, logInfo);
  }

  public boolean isLogText() {
    return this.isLogText;
  }

  public void setLogText(boolean isLogText) {
    this.isLogText = isLogText;
  }

  public String getLogSql() {
    return this.logSql;
  }

  public void setLogSql(String logSql) {
    this.logSql = logSql;
  }
}