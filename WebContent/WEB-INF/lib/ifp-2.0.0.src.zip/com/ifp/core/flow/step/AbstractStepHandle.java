package com.ifp.core.flow.step;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.Context;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.FlowException;
import com.ifp.core.log.Trace;
import com.ifp.core.spel.SpELHandle;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public abstract class AbstractStepHandle<T extends Context>
  implements IStepHandle<FlowStep, T>
{
  private SystemConf systemConf;
  private SpELHandle spelHandle;

  public StepTarget getTargetStep(FlowStep step, T context, int result, Exception ex)
    throws BaseException
  {
    StepTarget target = null;
    Map targetMap = step.getTargetMap();
    if (null != targetMap)
      try {
        Map.Entry entry;
        StepTarget stepTarget;
        String condition;
        Iterator iterator = targetMap.entrySet().iterator();

        if (null != ex) {
          while (iterator.hasNext()) {
            entry = (Map.Entry)iterator.next();
            stepTarget = (StepTarget)entry.getValue();
            if (null != stepTarget) {
              condition = stepTarget.getCondition();
              condition = (null == condition) ? "" : condition.trim();
              if ((!("".equals(condition))) && 
                (checkConditionWithEx(context, condition, result, ex)))
                return stepTarget;
            }
            else
            {
              throw new FlowException("目标转换对象为空！actionId.targetId:" + step.getStepId() + "." + ((String)entry.getKey()));
            }
          }
          throw ex;
        }
        while (iterator.hasNext()) {
          entry = (Map.Entry)iterator.next();
          stepTarget = (StepTarget)entry.getValue();
          if (null != stepTarget) {
            condition = stepTarget.getCondition();
            condition = (null == condition) ? "" : condition.trim();
            if (!("".equals(condition))) {
              if (!(checkCondition(context, condition, result))) break label276;
              return stepTarget;
            }

            label276: target = stepTarget;
          }
          else {
            throw new FlowException("目标转换对象为空！actionId.targetId:" + step.getStepId() + "." + ((String)entry.getKey()));
          }
        }
      }
      catch (BaseException be) {
        throw be;
      } catch (Exception e) {
        throw new FlowException(e);
      }


    if (null != ex) {
      throw new FlowException(ex);
    }

    return target;
  }

  public boolean checkConditionWithEx(T context, String condition, int result, Exception exception)
    throws Exception
  {
    boolean flag = false;
    condition = condition.trim();
    if (condition.matches("^\\s*exception\\s*:.*")) {
      String[] conditionArray = condition.replaceFirst("\\s*exception\\s*:\\s*", "").split("\\|");
      for (int i = 0; i < conditionArray.length; ++i) {
        String exceptionName = conditionArray[i].trim();

        if (exceptionName.equals(exception.getClass().getSimpleName())) {
          flag = true;
          break;
        }
      }
    }
    else if (condition.matches("^\\s*exception\\s*")) {
      flag = true;
    }
    Trace.log("ACTION", 3, "exception:{}", exception);
    return flag;
  }

  public boolean checkCondition(T context, String condition, int result)
    throws Exception
  {
    boolean flag = false;
    condition = condition.trim();
    if (condition.startsWith("result"))
    {
      if ((condition.indexOf("=") > -1) && (condition.indexOf("==") == -1) && (condition.indexOf("!=") == -1)) {
        int rsflag = Integer.parseInt(condition.replaceAll("\\s*result\\s*=\\s*", "").replaceAll("'", ""));
        if (rsflag == result)
          flag = true;
      }
      else {
        Map map = new HashMap();
        map.put("result", Integer.valueOf(result));
        condition = "#" + condition;
        flag = this.spelHandle.parseExpression(condition, map); }
    }
    else if (condition.startsWith("exception"))
      flag = false;
    else
      flag = this.spelHandle.parseExpression(condition, (DataMap)context.getDataMap());

    return flag;
  }

  public String getEndInfo(FlowStep step) {
    DataMap confMap = step.getConfMap();
    if (null != confMap) {
      DataField dataField = (DataField)confMap.get("value");
      if (null != dataField)
        return dataField.getValue();
    }

    return "0";
  }

  public SpELHandle getSpelHandle() {
    return this.spelHandle;
  }

  public void setSpelHandle(SpELHandle spelHandle) {
    this.spelHandle = spelHandle;
  }

  public SystemConf getSystemConf() {
    return this.systemConf;
  }

  public void setSystemConf(SystemConf systemConf) {
    this.systemConf = systemConf;
  }
}