package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.IfpActionLogInfo;
import org.springframework.util.StringUtils;

public class LoggerDefineAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    String businessCode = confMap.getElementValue("businessCode");

    if (!(StringUtils.hasText(businessCode))) {
      throw new ActionException("交易代码为空");
    }

    String logFormatStr = confMap.getElementValue("logFormatStr");

    if (!(StringUtils.hasText(logFormatStr))) {
      throw new ActionException("日志表达式为空");
    }

    String loggerClassName = confMap.getElementValue("loggerClassName");

    IfpActionLogInfo logInfo = new IfpActionLogInfo();
    logInfo.setLogFormat(logFormatStr);
    logInfo.setLoggerClassName(loggerClassName);
    logInfo.setBusinessCode(businessCode);
    context.setTemp("logFieldDefine", logInfo);
    return 0;
  }
}