package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import org.springframework.util.StringUtils;

public class StringAppendAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws ActionException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    String sourceFiledName = confMap.getElementValue("sourceFiledName");
    if (!(StringUtils.hasText(sourceFiledName)))
      throw new ActionException("原数据域为null");

    String targetFiledName = confMap.getElementValue("targetFiledName");
    if (!(StringUtils.hasText(targetFiledName)))
      throw new ActionException("目标数据域为null");

    String[] sourceFiledNames = sourceFiledName.split(getFieldSeperatorRegex());
    StringBuffer sb = new StringBuffer();
    try {
      for (int i = 0; i < sourceFiledNames.length; ++i)
        if (sourceFiledNames[i].startsWith("#"))
          sb.append(dataMap.getElementValue(sourceFiledNames[i].substring(1)));
        else
          sb.append(sourceFiledNames[i]);


      dataMap.setElementValue(targetFiledName, sb.toString());
    }
    catch (ActionException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }
    return 0;
  }
}