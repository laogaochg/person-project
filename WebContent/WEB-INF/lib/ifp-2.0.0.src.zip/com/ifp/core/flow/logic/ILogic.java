package com.ifp.core.flow.logic;

import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;

public abstract interface ILogic
{
  public abstract String getId();

  public abstract void setId(String paramString);

  public abstract String getName();

  public abstract void setName(String paramString);

  public abstract boolean isCommonFlag();

  public abstract void setCommonFlag(boolean paramBoolean);

  public abstract DataMap getDataDictionary();

  public abstract void setDataDictionary(DataMap paramDataMap);

  public abstract DataList getInputParamsList();

  public abstract void setInputParamsList(DataList paramDataList);

  public abstract DataList getOutputParamsList();

  public abstract void setOutputParamsList(DataList paramDataList);

  public abstract Flow getFlow();

  public abstract void setFlow(Flow paramFlow);

  public abstract void init();
}