package com.ifp.core.flow.action.jdbc;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.FillResultException;
import com.ifp.core.exception.JdbcException;
import com.ifp.core.exception.RecordOutOfRangeException;
import com.ifp.core.jdbc.adapter.IJdbcAdapter;
import com.ifp.core.log.Trace;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

public class SJTQueryMultPageAction extends AbstractJDBCAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    String dataSource = confMap.getElementValue("dataSource");
    int recordNum = 0;
    try
    {
      String queryFields = confMap.getElementValue("queryFields");
      String queryTables = confMap.getElementValue("queryTables");
      String queryCondition = confMap.getElementValue("queryCondition");
      String queryOrder = confMap.getElementValue("queryOrder");
      String pageNo = confMap.getElementValue("pageNo");
      String pageSize = confMap.getElementValue("pageSize");
      String totalSize = confMap.getElementValue("totalSize");
      String listName = confMap.getElementValue("listName");
      String outputFields = confMap.getElementValue("outputFields");

      if (queryCondition.startsWith("#"))
      {
        queryCondition = dataMap.getElementValue(queryCondition.substring(1));
      }

      String pageNoValue = dataMap.getElementValue(pageNo);
      pageNoValue = (org.apache.commons.lang.StringUtils.isEmpty(pageNoValue) == true) ? dataMap.getElementDefaultValue(pageNo) : pageNoValue;
      String pageSizeValue = dataMap.getElementValue(pageSize);
      pageSizeValue = (org.apache.commons.lang.StringUtils.isEmpty(pageSizeValue) == true) ? dataMap.getElementDefaultValue(pageSize) : pageSizeValue;
      int pNo = Integer.parseInt(pageNoValue);
      int pSize = Integer.parseInt(pageSizeValue);
      int startIndex = (pNo - 1) * pSize + 1;
      int endIndex = pNo * pSize;

      IJdbcAdapter jdbcAdapter = getJdbcAdapter(dataSource);

      String countSql = jdbcAdapter.getCountSql(queryTables, queryCondition);

      Object[] rstObject = getSqlParamValueListAndSql(countSql, dataMap);
      countSql = (String)rstObject[0];
      Trace.log("JDBC", 1, "countSQL--->{}", new Object[] { countSql });
      List inputList = (List)rstObject[1];
      Trace.log("JDBC", 1, "inputList--->{}", new Object[] { inputList });

      JdbcTemplate jdbcTemplate = getJdbcTemplate(dataSource);
      int tSize = ((Integer)jdbcTemplate.queryForObject(countSql, inputList.toArray(), Integer.class)).intValue();
      dataMap.setElementValue(totalSize, String.valueOf(tSize));

      if (tSize > 0)
      {
        if (startIndex > tSize) {
          throw new RecordOutOfRangeException("there had no record for page:" + pNo + "[startIndex:" + startIndex + ", totalSize:" + tSize + "]");
        }

        String querySql = jdbcAdapter.getPageQuerySql(queryFields, queryTables, queryCondition, queryOrder, startIndex, endIndex);

        rstObject = getSqlParamValueListAndSql(querySql, dataMap);
        querySql = (String)rstObject[0];
        Trace.log("JDBC", 1, "querySQL--->{}", new Object[] { querySql });
        inputList = (List)rstObject[1];
        Trace.log("JDBC", 1, "inputList--->{}", new Object[] { inputList });

        List outputList = getFieldList(outputFields);
        Trace.log("JDBC", 0, "outputList--->{}", new Object[] { outputList });

        DataList dataList = (DataList)dataMap.get(listName);
        List countList = jdbcTemplate.query(querySql, inputList.toArray(), new ParameterizedRowMapper(this, dataList, outputList) {
          public String mapRow(, int rowNum) throws SQLException {
            try {
              this.this$0.fillResultIntoDataList(rs, this.val$dataList, this.val$outputList);
            } catch (Exception e) {
              throw new FillResultException(e);
            }

            return "0";
          }

        });
        recordNum = countList.size();
      }
    }
    catch (Exception e) {
      throw new JdbcException(e);
    }

    return recordNum;
  }
}