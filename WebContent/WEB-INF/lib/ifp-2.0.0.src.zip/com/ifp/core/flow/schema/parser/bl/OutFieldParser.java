package com.ifp.core.flow.schema.parser.bl;

import com.ifp.core.data.OutputField;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

public class OutFieldParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String name = element.getAttribute("name");
    if (StringUtils.hasText(name)) {
      builder.addPropertyValue("name", name);
    }

    String targetName = element.getAttribute("targetName");
    if (StringUtils.hasText(targetName))
      builder.addPropertyValue("targetName", targetName);
    else if (StringUtils.hasText(name)) {
      builder.addPropertyValue("targetName", name);
    }

    String desc = element.getAttribute("desc");
    if (StringUtils.hasText(desc))
      builder.addPropertyValue("desc", desc);
    else
      builder.addPropertyValue("desc", "");
  }

  protected Class<OutputField> getBeanClass(Element element)
  {
    return OutputField.class;
  }
}