package com.ifp.core.flow.action;

import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.log.Trace;
import java.util.Iterator;
import java.util.List;

public abstract class FillFieldAction extends AbstractAction
{
  protected String replaceString(DataMap dataMap, String sourceStr, String connector)
    throws ActionException
  {
    if (!(org.springframework.util.StringUtils.hasText(connector)))
      connector = "";
    else
      connector = connector.trim();

    if (!(org.springframework.util.StringUtils.hasText(sourceStr))) {
      return sourceStr;
    }

    Trace.log("ACTION", 0, "拼接前{}", new Object[] { sourceStr });
    List fieldList = getFieldList(sourceStr);
    try {
      sourceStr = sourceStr.replaceAll("\\s+", "").replaceAll("\\|\\|", connector);
      for (Iterator i$ = fieldList.iterator(); i$.hasNext(); ) { String field = (String)i$.next();
        field = field.trim();
        if (field.startsWith("#"))
        {
          sourceStr = sourceStr.replaceAll(field.trim(), dataMap.getElementValue(field.substring(1)));
        }
        if ((field.startsWith("'")) && (field.endsWith("'")))
          sourceStr = sourceStr.replaceAll("\\s*" + field.trim() + "\\s*", org.apache.commons.lang.StringUtils.defaultString(dataMap.getElementValue(field.replaceAll("'", "")), ""));
      }
    }
    catch (Exception e) {
      throw new ActionException(e);
    }
    Trace.log("ACTION", 0, "拼接后{}", new Object[] { sourceStr });
    return sourceStr;
  }
}