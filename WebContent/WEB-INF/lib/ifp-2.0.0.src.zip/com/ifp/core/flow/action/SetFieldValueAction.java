package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import org.springframework.util.StringUtils;

public class SetFieldValueAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws ActionException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String fieldName = confMap.getElementValue("fieldName");
    if (!(StringUtils.hasText(fieldName))) {
      throw new ActionException("数据域列表为null");
    }

    String fieldValue = confMap.getElementValue("fieldValue");
    if (!(StringUtils.hasText(fieldValue))) {
      throw new ActionException("值列表为null");
    }

    String[] fieldNames = fieldName.split(getFieldSeperatorRegex());
    String[] fieldValues = fieldValue.split(getFieldSeperatorRegex());
    if (fieldNames.length != fieldValues.length)
      throw new ActionException("数据域列表与值列表个数对不上");

    try
    {
      for (int i = 0; i < fieldNames.length; ++i)
        dataMap.setElementValue(fieldNames[i], fieldValues[i]);
    }
    catch (ActionException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}