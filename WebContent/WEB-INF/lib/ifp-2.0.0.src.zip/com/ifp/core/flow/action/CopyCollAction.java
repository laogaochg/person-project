package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.ElementNotSupportException;
import org.springframework.util.StringUtils;

public class CopyCollAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws ActionException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String sourceCollName = confMap.getElementValue("sourceCollName");
    if (!(StringUtils.hasText(sourceCollName))) {
      throw new ActionException("来源数据集合列表为null");
    }

    String targetCollName = confMap.getElementValue("targetCollName");
    if (!(StringUtils.hasText(targetCollName))) {
      throw new ActionException("目标数据集合列表为null");
    }

    String[] sourceCollNames = sourceCollName.split(getFieldSeperatorRegex());
    String[] targetCollNames = targetCollName.split(getFieldSeperatorRegex());
    if (sourceCollNames.length != targetCollNames.length)
      throw new ActionException("来源与目标数据集合列表个数对不上");

    try
    {
      for (int i = 0; i < sourceCollNames.length; ++i) {
        DataList sDataList = (DataList)dataMap.get(sourceCollNames[i]);
        DataList tDataList = (DataList)dataMap.get(targetCollNames[i]);
        if (null == sDataList)
          throw new ActionException("找不到数据集合:" + sourceCollNames[i]);

        if (null == tDataList) {
          throw new ActionException("找不到数据集合:" + targetCollNames[i]);
        }

        if (sDataList == tDataList) {
          break label288:
        }

        label288: if (sDataList.getDefineMap().equals(tDataList.getDefineMap()))
          for (int j = 0; j < tDataList.size(); ++j)
            sDataList.add(tDataList.get(j).clone());

        else
          throw new ElementNotSupportException("dataList's define is not match");
      }
    }
    catch (ActionException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}