package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import org.springframework.util.StringUtils;

public class SetCollValueAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws ActionException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String collName = confMap.getElementValue("collName");
    if (!(StringUtils.hasText(collName))) {
      throw new ActionException("数据集合名称为null");
    }

    String fieldName = confMap.getElementValue("fieldName");
    if (!(StringUtils.hasText(fieldName))) {
      throw new ActionException("字段名称为null");
    }

    String collValue = confMap.getElementValue("collValue");
    if (!(StringUtils.hasText(collValue))) {
      throw new ActionException("数据集合值为null");
    }

    if (!(dataMap.containsKey(collName))) {
      throw new ActionException("数据集合不存在: " + collName);
    }

    DataElement dataElement = dataMap.get(collName);
    if (!(dataElement instanceof DataList))
      throw new ActionException("非集合类型: " + collName);

    try
    {
      DataList dataList = (DataList)dataElement;

      String[] recoreds = collValue.split(getFieldSeperatorRegex());
      String[] fNames = fieldName.split(getFieldSeperatorRegex());

      String[] arr$ = recoreds; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String recored = arr$[i$];
        String[] fields = recored.split("#");
        DataMap dMap = dataList.createSubDataMap();
        for (int i = 0; i < fNames.length; ++i) {
          String fName = fNames[i];
          dMap.put(fName, new DataField(fName, fields[i]));
        }
        dataList.add(dMap);
      }
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}