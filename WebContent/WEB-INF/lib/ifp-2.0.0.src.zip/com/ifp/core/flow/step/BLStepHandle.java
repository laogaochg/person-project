package com.ifp.core.flow.step;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.StepException;
import com.ifp.core.flow.action.AbstractAction;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.springframework.beans.BeansException;

public class BLStepHandle extends AbstractStepHandle<BlogicContext>
{
  private Map<String, AbstractAction> actionMap;

  public BLStepHandle()
  {
    this.actionMap = new HashMap(); }

  public void init() {
    Map actions = SpringContextsUtil.getBeansOfType(AbstractAction.class);
    for (Iterator i$ = actions.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entity = (Map.Entry)i$.next();
      this.actionMap.put(entity.getKey(), entity.getValue());
    }
  }

  public int executeBean(FlowStep step, BlogicContext context)
    throws BaseException
  {
    int flag = 0;
    try {
      String beanId = step.getRefBeanId();
      AbstractAction action = (AbstractAction)this.actionMap.get(beanId);
      if (null == action) {
        action = (AbstractAction)SpringContextsUtil.getBean(beanId);
        this.actionMap.put(beanId, action);
      }

      action.setId(step.getStepId());
      action.setSystemConf(getSystemConf());
      DataMap confMap = step.getConfMap();
      Trace.log("ACTION", 0, "get refer action: {} {}", new Object[] { step.getRefBeanId(), (confMap.containsKey("actionDesc")) ? confMap.getElementValue("actionDesc") : "" });

      flag = action.execute(context, confMap);
    } catch (BaseException e) {
      throw new StepException("SBAC0001", "组件执行异常:" + step.getStepId(), e);
    } catch (BeansException e) {
      throw new StepException("SBAC0001", "组件执行异常:" + step.getStepId() + ",请检查是否存在bean:" + step.getRefBeanId(), e);
    } catch (Exception e) {
      throw new StepException("SBAC0001", "组件执行异常:" + step.getStepId(), e);
    }

    return flag;
  }
}