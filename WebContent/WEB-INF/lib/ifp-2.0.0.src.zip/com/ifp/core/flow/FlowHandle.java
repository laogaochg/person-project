package com.ifp.core.flow;

import com.ifp.core.context.Context;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.FlowException;
import com.ifp.core.flow.logic.Flow;
import com.ifp.core.flow.logic.ILogic;
import com.ifp.core.flow.step.IStep;
import com.ifp.core.flow.step.IStepHandle;
import com.ifp.core.flow.step.StepTarget;
import com.ifp.core.log.FlumeLogInf;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.LogThread;
import com.ifp.core.log.Trace;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.SpringContextsUtil;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FlowHandle
{
  private IStepHandle stepHandle;
  private MonitorManager monitorManager;
  private LogHandle logHandle;
  private String startActionPrefix;
  private String endActionPrefix;
  private Map<String, ILogic> logicMap;

  public FlowHandle()
  {
    this.logHandle = ((LogHandle)SpringContextsUtil.getBean("logHandle"));

    this.startActionPrefix = "startAction";

    this.endActionPrefix = "endAction";

    this.logicMap = new HashMap(); }

  public ILogic getLogic(String logicId) {
    ILogic logic = (ILogic)this.logicMap.get(logicId);
    if (null == logic) {
      logic = (ILogic)SpringContextsUtil.getBean(logicId);
      this.logicMap.put(logicId, logic);
    }

    return logic;
  }

  public String executeComm(ILogic logic, Context context)
    throws BaseException
  {
    String logicPath = context.getLogicPath();
    context.setLogicPath(logicPath + "." + logic.getId());
    Trace.log("FLOW", 0, "start execute logic, name:{}, path:{}", new Object[] { context.getLogicCode(), context.getLogicPath() });
    return execute(logic.getFlow(), context);
  }

  public String execute(Context context)
    throws BaseException
  {
    ILogic logic = getLogic(context.getLogicCode());
    return execute(logic, context);
  }

  public String execute(ILogic logic, Context context)
    throws BaseException
  {
    String result;
    String logicPath;
    try
    {
      logicPath = context.getLogicPath();
      context.setLogicPath(logicPath + "." + logic.getId());
      Trace.log("FLOW", 0, "start execute logic, name:{}, path:{}", new Object[] { context.getLogicCode(), context.getLogicPath() });
      result = execute(logic.getFlow(), context);
    } catch (Exception e) {
      throw new FlowException("SBEC0001", "业务逻辑执行异常:" + context.getLogicPath(), e);
    }
    return result;
  }

  public String execute(Flow flow, Context context)
    throws BaseException
  {
    long startTime = System.currentTimeMillis();
    Trace.log("FLOW", 1, "start execute flow, logicId:{}", new Object[] { context.getLogicCode() });

    String result = executeStep(this.startActionPrefix + "0", flow.getStepMap(), context);
    Trace.log("FLOW", 1, "end execute flow, logicId:{}, time:{}ms", new Object[] { context.getLogicCode(), Long.valueOf(System.currentTimeMillis() - startTime) });
    return result;
  }

  private String executeStep(String stepId, Map<String, IStep> actionMap, Context context)
    throws BaseException
  {
    StringBuffer sb = new StringBuffer();
    long startTime = -3763400200459124736L;
    List flumeLogInfList = this.logHandle.getLogThread().getFlumeLogInfList();
    FlumeLogInf flumeLogInf = null;
    if (flumeLogInfList.size() > 0)
      flumeLogInf = (FlumeLogInf)flumeLogInfList.get(flumeLogInfList.size() - 1);
    while (true)
    {
      startTime = System.currentTimeMillis();

      if (!(this.logHandle.isDisable()))
        sb.append("#").append(this.logHandle.getActionMapping(stepId)).append("|").append(startTime);
      IStep step = (IStep)actionMap.get(stepId);
      if (null == step) {
        Trace.log("FLOW", 3, "找不到目标组件，请检查流程配置:{}.{}", new Object[] { context.getLogicCode(), stepId });

        if (null != flumeLogInf)
          flumeLogInf.setFlumeComInf(sb.toString());

        throw new FlowException("找不到目标组件，请检查流程配置");
      }
      StepTarget stepTarget = null;
      int result = -1;
      Exception ex = null;
      startTime = System.currentTimeMillis();
      Trace.log("FLOW", 1, "{}.{} start", new Object[] { context.getLogicPath(), step.getStepId() });
      try {
        if (null == this.monitorManager)
          this.monitorManager = ((MonitorManager)SpringContextsUtil.getBean("monitorManager"));
        this.monitorManager.setCurrentMonitorStep(context.getMonitorId(), step.getStepId());

        result = this.stepHandle.executeBean(step, context);
      }
      catch (Exception e) {
        if (null != flumeLogInf)
          flumeLogInf.setFlumeComInf(sb.toString());

        ex = e;
      } finally {
        Trace.log("FLOW", 1, "{}.{} end, result={}, time:{}ms", new Object[] { context.getLogicPath(), step.getStepId(), Integer.valueOf(result), Long.valueOf(System.currentTimeMillis() - startTime) });
      }

      stepTarget = this.stepHandle.getTargetStep(step, context, result, ex);
      if (null != stepTarget)
      {
        stepId = stepTarget.getValue();
        Trace.log("FLOW", 0, "get target Action: {}", new Object[] { stepId });
      } else {
        if (step.getStepId().matches(this.endActionPrefix + "[0-9]+"))
        {
          if (null != flumeLogInf)
            flumeLogInf.setFlumeComInf(sb.toString());

          return this.stepHandle.getEndInfo(step);
        }

        if (null != flumeLogInf)
          flumeLogInf.setFlumeComInf(sb.toString());

        throw new FlowException("找不到目标转移定义，请检查流程定义！actionId:" + step.getStepId());
      }
    }
  }

  public IStepHandle getStepHandle() {
    return this.stepHandle;
  }

  public void setStepHandle(IStepHandle stepHandle) {
    this.stepHandle = stepHandle; }

  public String getStartActionPrefix() {
    return this.startActionPrefix;
  }

  public void setStartActionPrefix(String startActionPrefix) {
    this.startActionPrefix = startActionPrefix;
  }

  public String getEndActionPrefix() {
    return this.endActionPrefix;
  }

  public void setEndActionPrefix(String endActionPrefix) {
    this.endActionPrefix = endActionPrefix;
  }

  public MonitorManager getMonitorManager() {
    return this.monitorManager;
  }

  public void setMonitorManager(MonitorManager monitorManager) {
    this.monitorManager = monitorManager;
  }
}