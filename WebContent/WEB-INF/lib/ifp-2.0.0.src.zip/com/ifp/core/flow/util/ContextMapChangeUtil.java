package com.ifp.core.flow.util;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.context.Context;
import com.ifp.core.context.IContext;
import com.ifp.core.data.CLInputField;
import com.ifp.core.data.CLInputList;
import com.ifp.core.data.CLOutputField;
import com.ifp.core.data.CLOutputList;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.data.InputField;
import com.ifp.core.data.OutputField;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.DataChangeException;
import com.ifp.core.flow.logic.BusinessLogic;
import com.ifp.core.log.Trace;
import com.ifp.core.util.DataMapChangeUtil;
import com.ifp.core.util.IpUtils;
import com.ifp.core.util.StringUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class ContextMapChangeUtil
{
  public static Map<String, Object> clogicContext2Map(IContext clogicContext, DataMap confMap, DataList paramsList)
    throws DataChangeException
  {
    Map clogicContextMap = new HashMap();
    if (null == clogicContext)
      return clogicContextMap;
    Map dataMap = (Map)clogicContext.getDataMap();
    Map blogicDataMap = Map2Map(dataMap, confMap, paramsList);
    clogicContextMap.put("flumeReqIp", IpUtils.getHostAddress());
    clogicContextMap.put("reqId", dataMap.get("reqId"));
    clogicContextMap.put("pcid", dataMap.get("pcid"));

    clogicContextMap.put("createTime", clogicContext.getCreateTime());
    clogicContextMap.put("monitorId", clogicContext.getMonitorId());
    clogicContextMap.put("dataMap", blogicDataMap);
    return clogicContextMap;
  }

  public static Map<String, Object> dataMap2Map(DataMap dataMap)
    throws DataChangeException
  {
    return dataMap2Map(dataMap, null, null, true);
  }

  public static Map<String, Object> dataMap2Map(DataMap dataMap, DataMap confMap, DataList paramsList, boolean isElementName)
    throws DataChangeException
  {
    Map blogicDataMap = new HashMap();
    Collection collection = null;
    if (null != dataMap) {
      if (null == paramsList)
        collection = dataMap.values();
      else
        collection = paramsList;

      if (null != collection) {
        DataElement dataElement = null;
        OutputField outField = null;
        InputField inField = null;
        String key = null;

        Iterator iterator = collection.iterator();
        while (true) { while (true) { if (!(iterator.hasNext())) break label185;
            dataElement = (DataElement)iterator.next();
            key = dataElement.getName();

            if (!(isElementName))
            {
              if (dataElement instanceof OutputField) {
                outField = (OutputField)dataElement;
                key = outField.getTargetName();
              } else if (dataElement instanceof InputField) {
                inField = (InputField)dataElement;
                key = inField.getSourceName();
              }
            }
            dataElement = dataMap.get(dataElement.getName());
            if (null == dataElement) break;
            putDataElement2Map(blogicDataMap, key, dataElement);
          }
          blogicDataMap.put(key, "");
        }
      }
    }

    label185: return blogicDataMap;
  }

  public static void putDataElement2Map(Map<String, Object> targetMap, String key, DataElement dataElement)
    throws DataChangeException
  {
    if (dataElement instanceof DataField) {
      targetMap.put(key, ((DataField)dataElement).getValue());
    } else if (dataElement instanceof DataMap) {
      Map map = new HashMap();
      DataMapChangeUtil.dataMapToMap((DataMap)dataElement, map);
      targetMap.put(key, map);
    } else if (dataElement instanceof DataList) {
      List list = new ArrayList();
      DataMapChangeUtil.dataListToList((DataList)dataElement, list);
      targetMap.put(key, list);
    } else {
      Trace.log("FLOW", 2, "DataMap转Map时遇到未知的数据类型{}:{}", new Object[] { key, (null != dataElement) ? dataElement.getClass() : dataElement });
    }
  }

  public static Map<String, Object> Map2Map(Map<String, Object> dataMap, DataMap confMap, DataList paramsList)
    throws DataChangeException
  {
    Map blogicDataMap = new HashMap();
    if ((null != dataMap) && 
      (null != paramsList)) {
      DataElement dataElement = null;
      OutputField outField = null;
      InputField inField = null;
      String key = null;

      for (int i = 0; i < paramsList.size(); ++i) {
        dataElement = paramsList.get(i);
        if (dataElement instanceof OutputField) {
          outField = (OutputField)dataElement;
          key = outField.getTargetName();
        } else if (dataElement instanceof InputField) {
          inField = (InputField)dataElement;
          key = inField.getSourceName();
        }
        if (null != dataMap.get(key))
          blogicDataMap.put(key, dataMap.get(key));
        else
          blogicDataMap.put(key, "");
      }

    }

    return blogicDataMap;
  }

  public static DataMap changeMapCL2BL(Map<String, Object> blogicDataMap)
    throws DataChangeException
  {
    return changeMapCL2BL(blogicDataMap, null, null, true);
  }

  public static BlogicContext map2Context(Map<String, Object> blogicContextMap, BusinessLogic businessLogic)
    throws DataChangeException
  {
    BlogicContext blogicContext = new BlogicContext();
    if (null == blogicContextMap)
      return blogicContext;

    DataMap dataMap = DataMapChangeUtil.mapToDataMap((Map)blogicContextMap.get("dataMap"), businessLogic.getDataDictionary());

    blogicContext.setLogicCode((String)blogicContextMap.get("logicCode"));
    blogicContext.setLogicPath((String)blogicContextMap.get("logicPath"));
    blogicContext.setCreateTime((String)blogicContextMap.get("createTime"));
    blogicContext.setMonitorId((String)blogicContextMap.get("monitorId"));
    blogicContext.setDataMap(dataMap);

    return blogicContext;
  }

  public static DataMap changeMapCL2BL(Map<String, Object> logicDataMap, BusinessLogic businessLogic, DataList paramsList, boolean isElementName)
    throws DataChangeException
  {
    DataMap dictMap = businessLogic.getDataDictionary();
    DataMap dataMap = businessLogic.getDefaultDataMap().clone();
    if (null != dictMap) {
      DataElement dataElement = null;
      OutputField outField = null;
      InputField inField = null;
      String sourceKey = null;

      if (null != paramsList)
        for (int i = 0; i < paramsList.size(); ++i) {
          dataElement = paramsList.get(i);
          if (!(isElementName))
          {
            if (dataElement instanceof OutputField) {
              outField = (OutputField)dataElement;
              sourceKey = outField.getTargetName();
            } else if (dataElement instanceof InputField) {
              inField = (InputField)dataElement;
              sourceKey = inField.getSourceName();
            }
          }
          else sourceKey = dataElement.getName();

          if (!(StringUtil.hasText(sourceKey)))
          {
            sourceKey = dataElement.getName();
          }

          String key = dataElement.getName();
          DataElement confElement = dictMap.get(key);
          Object sourceObj = logicDataMap.get(sourceKey);
          if (null != sourceObj) {
            if (null != confElement) {
              if (confElement instanceof DataField) {
                String value = String.valueOf(sourceObj);
                dataMap.put(key, stringToDataField(value, (DataField)confElement));
                break label323: } if (confElement instanceof DataMap) {
                List value = new ArrayList();
                if (sourceObj instanceof List)
                  value = (List)sourceObj;

                dataMap.put(key, listToDataList(value, (DataMap)confElement));
                break label323: }
              throw new DataChangeException("element type is not support: " + confElement.getClass().getSimpleName());
            }

            label323: throw new DataChangeException("element define is not found: " + key);
          }
        }
    }
    else
    {
      Trace.log("MVC", 2, "数据字典未定义[{}]", new Object[] { businessLogic.getId() });
    }

    return dataMap;
  }

  private static DataList listToDataList(List<Map> list, DataMap confMap)
    throws DataChangeException
  {
    DataList dList = new DataList(confMap.getName());
    dList.setDefineMap(confMap);
    if (null != list)
      for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Map map = (Map)i$.next();
        DataMap dMap = mapToDataMap(map, confMap);
        dList.add(dMap);
      }

    return dList;
  }

  private static DataMap mapToDataMap(Map<String, Object> map, DataMap confMap)
    throws DataChangeException
  {
    DataMap dMap = new DataMap();
    dMap.setDefineMap(confMap);
    if (null != map) {
      Iterator iterator = confMap.keySet().iterator();
      while (iterator.hasNext()) {
        String key = (String)iterator.next();
        DataElement confElement = confMap.get(key);
        if (null != confElement) {
          if (confElement instanceof DataField) {
            DataField cField = (DataField)confElement;
            dMap.put(key, stringToDataField((String)map.get(key), cField));
            continue; } if (confElement instanceof DataMap) {
            DataMap cMap = (DataMap)confElement;
            dMap.put(key, listToDataList((List)map.get(key), cMap));
            continue; }
          throw new DataChangeException("element type is not support: " + confElement.getClass().getSimpleName());
        }

        throw new DataChangeException("element define is not found: " + key);
      }
    }
    else {
      throw new DataChangeException("in param: map is null");
    }

    return dMap;
  }

  private static DataField stringToDataField(String value, DataField confField)
  {
    DataField df = confField.clone();
    if (null == value)
      value = "";

    df.setValue(value);
    return df;
  }

  private static boolean existKey(List<String> elementNames, String key)
  {
    boolean exist = false;

    for (Iterator i$ = elementNames.iterator(); i$.hasNext(); ) { String elementName = (String)i$.next();
      if (elementName.equalsIgnoreCase(key)) {
        exist = true;
        break;
      }
    }
    return exist;
  }

  public static void copyDataList(DataList source, DataList target)
  {
    DataMap defineMap = target.getDefineMap();
    if (null == defineMap) {
      target.copy(source);
      return;
    }

    for (int i = 0; i < source.size(); ++i) {
      DataMap dataMap = target.createSubDataMap();
      DataMap sourceDataMap = (DataMap)source.get(i);
      for (Iterator i$ = defineMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        if (entry.getValue() instanceof DataField)
          dataMap.put((String)entry.getKey(), sourceDataMap.getElementValue((String)entry.getKey()));
        else if (entry.getValue() instanceof DataList)
          copyDataList((DataList)sourceDataMap.get(entry.getKey()), (DataList)dataMap.get(entry.getKey()));
      }

      target.add(dataMap);
    }
  }

  public static void copyDataMap(DataMap source, DataMap target)
    throws BaseException
  {
    Set entrySet = source.entrySet();
    Iterator i$ = entrySet.iterator();
    while (true) { Map.Entry entry;
      DataElement dataElement;
      DataElement targetDataElement;
      while (true) { if (!(i$.hasNext())) return; entry = (Map.Entry)i$.next();
        dataElement = (DataElement)entry.getValue();
        targetDataElement = target.get(entry.getKey());
        if (targetDataElement != null)
          break;
      }
      if (dataElement instanceof DataField)
      {
        ((DataField)targetDataElement).setValue(((DataField)dataElement).getValue());
      } else if (dataElement instanceof DataList)
      {
        if (null == targetDataElement)
        {
          Trace.logWarn("DATA", "{} not exists in target DataMap", new Object[] { entry.getKey() });
        }
        else
        {
          copyDataList((DataList)dataElement, (DataList)targetDataElement);
        }
      }
    }
  }

  public static void copyDataMap(DataMap source, DataMap target, DataList paramsList)
    throws BaseException
  {
    if (null != paramsList)
      for (int i = 0; i < paramsList.size(); ) {
        try {
          DataElement dataElement = source.get(paramsList.get(i).getName());
          DataElement targetDataElement = target.get(paramsList.get(i).getName());
          if ((paramsList.get(i).getName() != null) && (dataElement != null))
          {
            if (targetDataElement instanceof DataField)
            {
              ((DataField)targetDataElement).setValue(((DataField)dataElement).getValue());
            } else if (targetDataElement instanceof DataList)
            {
              copyDataList((DataList)dataElement, (DataList)targetDataElement);
            }
          }
        } catch (Exception e) {
          Trace.logError("DATA", "copyDataMap Error --> field:{}", new Object[] { paramsList.get(i).getName(), e });
          throw new BaseException(e);
        }
        ++i;
      }
  }

  public static void copyDataMap(Map source, DataMap target, DataList paramsList)
    throws BaseException
  {
    if (null != paramsList)
      for (int i = 0; i < paramsList.size(); ) {
        try {
          DataElement targetDataElement = target.get(paramsList.get(i).getName());
          if ((paramsList.get(i).getName() != null) && (source.get(paramsList.get(i).getName()) != null))
          {
            if (targetDataElement instanceof DataField)
            {
              ((DataField)targetDataElement).setValue((String)source.get(paramsList.get(i).getName()));
            } else if (targetDataElement instanceof DataList)
            {
              DataList dataList = (DataList)targetDataElement;
              DataMap defineMap = dataList.getDefineMap();

              copyDataList(DataMapChangeUtil.listToDataList((List)source.get(paramsList.get(i).getName()), defineMap), dataList);
            }
          }
        } catch (BaseException e) {
          Trace.logError("DATA", "copyDataMap Error --> field:{}", new Object[] { paramsList.get(i).getName(), e });
          throw e;
        } catch (Exception e) {
          Trace.logError("DATA", "copyDataMap Error --> field:{}", new Object[] { paramsList.get(i).getName(), e });
          throw new BaseException(e);
        }
        ++i;
      }
  }

  public static void copyDataMap(Map source, DataMap target)
    throws BaseException
  {
    Iterator iterator = source.keySet().iterator();
    String paramName = null;
    DataElement targetDataElement = null;
    DataList dataList = null;
    DataMap defineMap = null;
    if (iterator.hasNext()) {
      paramName = (String)iterator.next();
      try {
        targetDataElement = target.get(paramName);
        if ((paramName != null) && (source.get(paramName) != null))
          if (targetDataElement instanceof DataField) {
            ((DataField)targetDataElement).setValue((String)source.get(paramName));
          } else if (targetDataElement instanceof DataList) {
            dataList = (DataList)targetDataElement;
            defineMap = dataList.getDefineMap();

            copyDataList(DataMapChangeUtil.listToDataList((List)source.get(paramName), defineMap), dataList);
          }
      }
      catch (BaseException e) {
        Trace.logError("DATA", "copyDataMap Error --> field:{}", new Object[] { paramName, e });
        throw e;
      } catch (Exception e) {
        Trace.logError("DATA", "copyDataMap Error --> field:{}", new Object[] { paramName, e });
        throw new BaseException(e);
      }
    }
  }

  public static void copyDataMap(Map source, Map target)
    throws BaseException
  {
    Iterator iterator = source.keySet().iterator();
    String paramName = null;
    Object targetDataElement = null;
    List dataList = null;
    if (iterator.hasNext()) {
      paramName = (String)iterator.next();
      try {
        targetDataElement = target.get(paramName);
        if ((paramName != null) && (source.get(paramName) != null))
          if (targetDataElement instanceof String) {
            target.put(paramName, (String)source.get(paramName));
          } else if (targetDataElement instanceof List) {
            dataList = (List)targetDataElement;
            if (dataList.size() > 0)
              dataList.clear();

            dataList.addAll((List)source.get(paramName));
          } else {
            target.put(paramName, source.get(paramName));
          }
      }
      catch (Exception e) {
        Trace.logError("DATA", "copyList Error --> field:{}", new Object[] { paramName, e });
        throw new BaseException(e);
      }
    }
  }

  public static Map<String, Object> clContext2MapForCLInput(IContext<Map<String, Object>> clogicContext, DataList inputParamsList)
    throws DataChangeException
  {
    Map clogicContextMap = new HashMap();

    if (null == inputParamsList) {
      throw new DataChangeException("SCPC0003", "入参列表为空：" + inputParamsList);
    }

    Map dataMap = (Map)clogicContext.getDataMap();
    Map clogicDataMap = clMap2MapForCLInput(dataMap, inputParamsList);
    clogicContextMap.put("dataMap", clogicDataMap);
    return clogicContextMap;
  }

  public static Map<String, Object> clContext2MapForCLOutput(IContext<Map<String, Object>> clogicContext, DataList outputParamsList)
    throws DataChangeException
  {
    Map clogicContextMap = new HashMap();

    if (null == outputParamsList) {
      throw new DataChangeException("SCPC0003", "出参列表为空：" + outputParamsList);
    }

    Map dataMap = (Map)clogicContext.getDataMap();
    Map clogicDataMap = clMap2MapForCLOutput(dataMap, outputParamsList);
    clogicContextMap.put("dataMap", clogicDataMap);

    String errorCode = (String)clogicDataMap.get("errorCode");
    if (!(StringUtil.hasText(errorCode)))
      errorCode = "0";

    String errorMsg = (String)clogicDataMap.get("errorMsg");
    if (!(StringUtil.hasText(errorMsg))) {
      errorMsg = "";
    }

    clogicContextMap.put("errorCode", errorCode);
    clogicContextMap.put("errorMsg", errorMsg);
    return clogicContextMap;
  }

  public static Map<String, Object> clMap2MapForCLInput(Map<String, Object> dataMap, DataList inputParamsList)
    throws DataChangeException
  {
    Map clogicDataMap = new HashMap();
    if ((null != dataMap) && 
      (null != inputParamsList)) {
      for (int i = 0; i < inputParamsList.size(); ++i) {
        String key;
        Object value;
        DataElement dataElement = inputParamsList.get(i);
        if (dataElement instanceof CLInputField) {
          CLInputField inField = (CLInputField)dataElement;
          key = inField.getName();
          value = dataMap.get(inField.getSourceName());
          if (null != value) {
            if (value instanceof String) {
              clogicDataMap.put(key, value); break label139:
            }
            throw new DataChangeException("SCPC0004", "参数转换错误：类型不是String=>" + key);
          }

          label139: label246: clogicDataMap.put(key, "");
        }
        else if (dataElement instanceof CLInputList) {
          CLInputList inputList = (CLInputList)dataElement;
          key = inputList.getName();
          value = dataMap.get(inputList.getSourceName());
          if (null != value) {
            if (value instanceof List) {
              clogicDataMap.put(key, value); break label246:
            }
            throw new DataChangeException("SCPC0004", "参数转换错误：类型不是List=>" + key);
          }

          clogicDataMap.put(key, "");
        }

      }

    }

    return clogicDataMap;
  }

  public static Map<String, Object> clMap2MapForCLOutput(Map<String, Object> dataMap, DataList outputParamsList)
    throws DataChangeException
  {
    Map clogicDataMap = new HashMap();
    if ((null != dataMap) && 
      (null != outputParamsList)) {
      for (int i = 0; i < outputParamsList.size(); ++i) {
        String key;
        String tkey;
        Object value;
        DataElement dataElement = outputParamsList.get(i);
        if (dataElement instanceof CLOutputField) {
          CLOutputField outField = (CLOutputField)dataElement;
          key = outField.getName();
          tkey = outField.getTargetName();
          value = dataMap.get(key);
          if (null != value) {
            if (value instanceof String) {
              clogicDataMap.put(tkey, value); break label143:
            }
            throw new DataChangeException("SCPC0004", "参数转换错误：类型不是String=>" + key);
          }

          label143: label254: clogicDataMap.put(tkey, "");
        }
        else if (dataElement instanceof CLOutputList) {
          CLOutputList outputList = (CLOutputList)dataElement;
          key = outputList.getName();
          tkey = outputList.getTargetName();
          value = dataMap.get(key);
          if (null != value) {
            if (value instanceof List) {
              clogicDataMap.put(tkey, value); break label254:
            }
            throw new DataChangeException("SCPC0004", "参数转换错误：类型不是List=>" + key);
          }

          clogicDataMap.put(tkey, "");
        }

      }

    }

    return clogicDataMap;
  }

  public static <T extends Map> Map<String, Object> contextMap2MapWithCLInputForClient(T dataMap, DataList inputParamsList)
    throws DataChangeException
  {
    Map transMap = new HashMap();

    for (int i = 0; i < inputParamsList.size(); ++i) {
      String key;
      Object value;
      DataElement dataElement = inputParamsList.get(i);
      if (dataElement instanceof CLInputField) {
        CLInputField inField = (CLInputField)dataElement;
        key = inField.getSourceName();
        value = dataMap.get(key);
        if (null != value) {
          if (value instanceof DataField) {
            transMap.put(key, ((DataField)value).getValue()); break label191: }
          if (value instanceof String) {
            transMap.put(key, value); break label191:
          }
          if (dataMap instanceof DataMap)
            throw new DataChangeException("SCPC0004", "参数转换失败，类型不是DataField=>" + key);

          throw new DataChangeException("SCPC0004", "参数转换失败，类型不是String=>" + key);
        }

        label191: label373: transMap.put(key, "");
      }
      else if (dataElement instanceof CLInputList) {
        CLInputList inputList = (CLInputList)dataElement;
        key = inputList.getSourceName();
        value = dataMap.get(key);
        if (null != value) {
          if (value instanceof DataList) {
            List list = new ArrayList();
            DataMapChangeUtil.dataListToList((DataList)value, list);
            transMap.put(key, list);
            break label373: } if (value instanceof List) {
            transMap.put(key, value); break label373:
          }
          if (dataMap instanceof DataMap)
            throw new DataChangeException("SCPC0004", "参数转换失败，类型不是DataList=>" + key);

          throw new DataChangeException("SCPC0004", "参数转换失败，类型不是List=>" + key);
        }

        transMap.put(key, "");
      }

    }

    return transMap;
  }

  public static <T extends Map> void contextMap4MapWithCLOutputForClient(T dataMap, Map<String, Object> transMap, DataList outputParamsList)
    throws DataChangeException
  {
    for (int i = 0; i < outputParamsList.size(); ++i) {
      String key;
      Object object;
      DataElement dataElement = outputParamsList.get(i);
      if (dataElement instanceof CLOutputField) {
        CLOutputField outField = (CLOutputField)dataElement;
        key = outField.getTargetName();
        String value = (String)transMap.get(key);
        if (null != value) {
          object = dataMap.get(key);
          if (dataMap instanceof DataMap) {
            if (object instanceof DataField) {
              dataMap.put(key, new DataField(key, value)); break label199: }
            if (object == null) break label199;
            throw new DataChangeException("SCPC0004", "参数转换失败，在dataMap中类型不是DataField=>" + key);
          }

          label423: label199: if ((null == object) || (object instanceof String))
            dataMap.put(key, value);
          else
            throw new DataChangeException("SCPC0004", "参数转换失败，在dataMap中类型不是String=>" + key);
        }
        else
        {
          throw new DataChangeException("SCPC0004", "参数转换失败，在transaMap中找不到数据=>" + key);
        }
      } else if (dataElement instanceof CLOutputList) {
        CLOutputList outputList = (CLOutputList)dataElement;
        key = outputList.getTargetName();
        List value = (List)dataMap.get(key);
        if (null != value) {
          object = dataMap.get(key);
          if (dataMap instanceof DataMap) {
            if (object instanceof DataList) {
              DataList dataList = (DataList)object;
              dataMap.put(key, DataMapChangeUtil.listToDataList(value, dataList.getDefineMap()));
              break label423: } if (object == null) break label423;
            throw new DataChangeException("SCPC0004", "参数转换失败，在dataMap中类型不是DataList=>" + key);
          }

          if ((null == object) || (object instanceof List))
            dataMap.put(key, value);
          else
            throw new DataChangeException("SCPC0004", "参数转换失败，在dataMap中类型不是List=>" + key);
        }
        else
        {
          throw new DataChangeException("SCPC0004", "参数转换失败，在transaMap中找不到数据=>" + key);
        }
      }
    }
  }

  public static <T extends Map> Map<String, Object> contextMap2MapWithBLInputForClient(T dataMap, DataMap dictMap, DataList inputParamsList)
    throws DataChangeException
  {
    Map transMap = new HashMap();

    for (int i = 0; i < inputParamsList.size(); ++i) {
      Object value;
      InputField inField = (InputField)inputParamsList.get(i);

      String key = inField.getSourceName();
      DataElement dataElement = dictMap.get(inField.getName());
      if (dataElement instanceof DataField) {
        value = dataMap.get(key);
        if (null != value) {
          if (value instanceof DataField) {
            transMap.put(key, ((DataField)value).getValue()); break label201: }
          if (value instanceof String) {
            transMap.put(key, value); break label201:
          }
          if (dataMap instanceof DataMap)
            throw new DataChangeException("SCPC0004", "参数转换失败，类型不是DataField=>" + key);

          throw new DataChangeException("SCPC0004", "参数转换失败，类型不是String=>" + key);
        }

        label201: label369: transMap.put(key, "");
      }
      else if (dataElement instanceof DataMap) {
        value = dataMap.get(key);
        if (null != value) {
          if (value instanceof DataList) {
            List list = new ArrayList();
            DataMapChangeUtil.dataListToList((DataList)value, list);
            transMap.put(key, list);
            break label369: } if (value instanceof List) {
            transMap.put(key, value); break label369:
          }
          if (dataMap instanceof DataMap)
            throw new DataChangeException("SCPC0004", "参数转换失败，类型不是DataList=>" + key);

          throw new DataChangeException("SCPC0004", "参数转换失败，类型不是List=>" + key);
        }

        transMap.put(key, "");
      }

    }

    return transMap;
  }

  public static <T extends Map> void contextMap4MapWithBLOutputForClient(T dataMap, Map<String, Object> transMap, DataMap dictMap, DataList outputParamsList)
    throws DataChangeException
  {
    for (int i = 0; i < outputParamsList.size(); ++i) {
      Object object;
      OutputField outputField = (OutputField)outputParamsList.get(i);
      String key = outputField.getTargetName();
      DataElement dataElement = dictMap.get(outputField.getName());
      if (dataElement instanceof DataField) {
        String value = (String)transMap.get(key);
        if (null != value) {
          object = dataMap.get(key);
          if (dataMap instanceof DataMap) {
            if (object instanceof DataField) {
              dataMap.put(key, new DataField(key, value)); break label209: }
            if (object == null) break label209;
            throw new DataChangeException("SCPC0004", "参数转换失败，在dataMap中类型不是DataField=>" + key);
          }

          label419: label209: if ((null == object) || (object instanceof String))
            dataMap.put(key, value);
          else
            throw new DataChangeException("SCPC0004", "参数转换失败，在dataMap中类型不是String=>" + key);
        }
        else
        {
          throw new DataChangeException("SCPC0004", "参数转换失败，在transaMap中找不到数据=>" + key);
        }
      } else if (dataElement instanceof DataMap) {
        List value = (List)transMap.get(key);
        if (null != value) {
          object = dataMap.get(key);
          if (dataMap instanceof DataMap) {
            if (object instanceof DataList) {
              DataList dataList = (DataList)object;
              dataMap.put(key, DataMapChangeUtil.listToDataList(value, dataList.getDefineMap()));
              break label419: } if (object == null) break label419;
            throw new DataChangeException("SCPC0004", "参数转换失败，在dataMap中类型不是DataList=>" + key);
          }

          if ((null == object) || (object instanceof List))
            dataMap.put(key, value);
          else
            throw new DataChangeException("SCPC0004", "参数转换失败，在dataMap中类型不是List=>" + key);
        }
        else
        {
          throw new DataChangeException("SCPC0004", "参数转换失败，在transaMap中找不到数据=>" + key);
        }
      }
    }
  }

  public static void doUpdateInputDataMap(Map<String, Object> cLogicDataMap, Context<DataMap> context, BusinessLogic businessLogic, boolean isProcessComm)
    throws DataChangeException
  {
    DataMap dataMap = changeMapCL2BL(cLogicDataMap, businessLogic, businessLogic.getInputParamsList(), false);

    if (isProcessComm) {
      DataList paramsList = businessLogic.getInputCommParamsList();
      if (null != paramsList) {
        DataMap dictMap = businessLogic.getDataDictionary();
        for (int i = 0; i < paramsList.size(); ++i) {
          DataElement dataElement = paramsList.get(i);
          InputField inField = (InputField)dataElement;
          String sourceKey = inField.getSourceName();

          if (StringUtil.hasText(sourceKey))
          {
            sourceKey = inField.getName();
          }
          String key = dataElement.getName();
          DataElement confElement = dictMap.get(key);
          Object sourceObj = cLogicDataMap.get(sourceKey);
          if (null != sourceObj) {
            if (null != confElement) {
              if (confElement instanceof DataField) {
                String value = String.valueOf(sourceObj);
                dataMap.put(key, DataMapChangeUtil.stringToDataField(value, (DataField)confElement));
                break label274: } if (confElement instanceof DataMap) {
                List value = new ArrayList();
                if (sourceObj instanceof List)
                  value = (List)sourceObj;
                dataMap.put(key, DataMapChangeUtil.listToDataList(value, (DataMap)confElement));
                break label274: }
              throw new DataChangeException("element type is not support: " + confElement.getClass().getSimpleName());
            }

            label274: throw new DataChangeException("element define is not found: " + key);
          }
        }
      }

    }

    context.setDataMap(dataMap);
  }

  public static void doUpdateOutputDataMap(Map<String, Object> cLogicDataMap, BusinessLogic businessLogic, BlogicContext blogicContext, boolean isProcessComm)
    throws ActionException, DataChangeException
  {
    if (null != blogicContext.getDataMap()) {
      int i;
      OutputField outField;
      DataElement dataElement;
      DataField dataField;
      DataList dataList;
      List list;
      DataMap dataMap = (DataMap)blogicContext.getDataMap();
      DataList outList = null;

      if (isProcessComm) {
        outList = businessLogic.outputCommParamsList;
        if (null != outList)
          for (i = 0; i < outList.size(); ++i) {
            outField = (OutputField)outList.get(i);
            dataElement = dataMap.get(outField.getName());
            if (null != dataElement)
              if (dataElement instanceof DataField) {
                dataField = (DataField)dataElement;
                cLogicDataMap.put(outField.getTargetName(), dataField.getValue());
              } else if (dataElement instanceof DataList) {
                dataList = (DataList)dataElement;
                list = new ArrayList();
                DataMapChangeUtil.dataListToList(dataList, list);
                cLogicDataMap.put(outField.getTargetName(), list);
              }
            else
              cLogicDataMap.put(outField.getTargetName(), "");
          }


      }

      outList = businessLogic.outputParamsList;
      if (null != outList)
        for (i = 0; i < outList.size(); ++i) {
          outField = (OutputField)outList.get(i);
          dataElement = dataMap.get(outField.getName());
          if (null != dataElement)
            if (dataElement instanceof DataField) {
              dataList = (DataField)dataElement;
              cLogicDataMap.put(outField.getTargetName(), dataList.getValue());
            } else if (dataElement instanceof DataList) {
              dataList = (DataList)dataElement;
              list = new ArrayList();
              DataMapChangeUtil.dataListToList(dataList, list);
              cLogicDataMap.put(outField.getTargetName(), list);
            }
          else
            cLogicDataMap.put(outField.getTargetName(), "");

        }


      cLogicDataMap.put("errorCode", ((DataField)dataMap.get("errorCode")).getValue());
      cLogicDataMap.put("errorMsg", ((DataField)dataMap.get("errorMsg")).getValue());
    }
  }

  private static void dataListToList(DataList dataList, List list)
    throws DataChangeException
  {
    if ((null != dataList) && (null != list))
      for (int j = 0; j < dataList.size(); ++j) {
        DataElement dataElement = dataList.get(j);
        if (null != dataElement) {
          if (dataElement instanceof DataMap) {
            Map map = new HashMap();
            dataMapToMap((DataMap)dataElement, map);
            list.add(map);
            break label156: } if (dataElement instanceof DataField) {
            DataField dataField = (DataField)dataElement;
            list.add(dataField.getValue());
            break label156: }
          throw new DataChangeException("element type is not support: " + dataElement.getClass().getSimpleName());
        }

        label156: throw new DataChangeException("dataElement is null in dataList, index: " + j);
      }

    else
      throw new DataChangeException("in param is null");
  }

  private static void dataMapToMap(DataMap dataMap, Map map)
    throws DataChangeException
  {
    if ((null != dataMap) && (null != map)) {
      Iterator iterator = dataMap.keySet().iterator();
      while (iterator.hasNext()) {
        String key = (String)iterator.next();
        DataElement dataElement = dataMap.get(key);
        if (null != dataElement) {
          if (dataElement instanceof DataField) {
            DataField dataField = (DataField)dataElement;
            map.put(key, dataField.getValue());
            continue; } if (dataElement instanceof DataList) {
            List list = new ArrayList();
            dataListToList((DataList)dataElement, list);
            map.put(key, list);
            continue; }
          throw new DataChangeException("element type is not support: " + dataElement.getClass().getSimpleName());
        }

        throw new DataChangeException("dataElement is null: " + key);
      }
    }
    else {
      throw new DataChangeException("in param is null");
    }
  }
}