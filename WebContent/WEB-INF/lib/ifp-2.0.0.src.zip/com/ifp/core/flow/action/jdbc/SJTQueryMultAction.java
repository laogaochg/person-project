package com.ifp.core.flow.action.jdbc;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.FillResultException;
import com.ifp.core.exception.JdbcException;
import com.ifp.core.log.Trace;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

public class SJTQueryMultAction extends AbstractJDBCAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    String dataSource = confMap.getElementValue("dataSource");
    int recordNum = 0;
    try
    {
      String querySql = confMap.getElementValue("querySql");

      if (querySql.startsWith("#"))
      {
        querySql = dataMap.getElementValue(querySql.substring(1));
      }

      String listName = confMap.getElementValue("listName");
      String outputFields = confMap.getElementValue("outputFields");

      Object[] rstObject = getSqlParamValueListAndSql(querySql, dataMap);
      querySql = (String)rstObject[0];
      Trace.log("JDBC", 1, "querySQL--->{}", new Object[] { querySql });
      List inputList = (List)rstObject[1];
      Trace.log("JDBC", 1, "inputList--->{}", new Object[] { inputList });

      List outputList = getFieldList(outputFields);
      Trace.log("JDBC", 0, "outputList--->{}", new Object[] { outputList });

      DataList dataList = (DataList)dataMap.get(listName);

      JdbcTemplate jdbcTemplate = getJdbcTemplate(dataSource);
      List countList = jdbcTemplate.query(querySql, inputList.toArray(), new ParameterizedRowMapper(this, dataList, outputList) {
        public String mapRow(, int rowNum) throws SQLException {
          try {
            this.this$0.fillResultIntoDataList(rs, this.val$dataList, this.val$outputList);
          } catch (Exception e) {
            throw new FillResultException(e);
          }

          return "0";
        }

      });
      recordNum = countList.size();
    } catch (Exception e) {
      throw new JdbcException(e);
    }

    return recordNum;
  }
}