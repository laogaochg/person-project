package com.ifp.core.flow.action.ftp;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.AbstractAction;
import com.ifp.core.ftp.client.FtpClientHandle;
import com.ifp.core.log.Trace;

public class FtpUploadAction extends AbstractAction
{
  private FtpClientHandle ftpClientHandle;
  private String localFilePath;

  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try {
      String sourcePath;
      String ftpServiceId = confMap.getElementValue("ftpServiceId");
      String pathType = getConfValue("pathType", dataMap, confMap);
      String sourceFilePath = getConfValue("sourceFilePath", dataMap, confMap);
      String targetFilePath = getConfValue("targetFilePath", dataMap, confMap);
      String targetFileName = getConfValue("targetFileName", dataMap, confMap);
      String createFlag = confMap.getElementValue("createFlag");

      if ("0".equals(pathType))
        sourcePath = getSystemConf().getWebRootPath() + sourceFilePath;
      else if ("1".equals(pathType))
        sourcePath = this.localFilePath + sourceFilePath;
      else if ("2".equals(pathType))
        sourcePath = sourceFilePath;
      else
        throw new ActionException("not expect value for pathType: " + pathType);

      Trace.log("FTP", 0, "ftpServiceId:{}, sourcePath:{}, targetFilePath:{}, targetFileName:{}, createFlag:{}", new Object[] { ftpServiceId, sourcePath, targetFilePath, targetFileName, createFlag });

      this.ftpClientHandle.upload(ftpServiceId, sourcePath, targetFilePath, targetFileName, Boolean.parseBoolean(createFlag));
    } catch (BaseException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }

  public FtpClientHandle getFtpClientHandle() {
    return this.ftpClientHandle;
  }

  public void setFtpClientHandle(FtpClientHandle ftpClientHandle) {
    this.ftpClientHandle = ftpClientHandle;
  }

  public String getLocalFilePath() {
    return this.localFilePath;
  }

  public void setLocalFilePath(String localFilePath) {
    this.localFilePath = localFilePath;
  }
}