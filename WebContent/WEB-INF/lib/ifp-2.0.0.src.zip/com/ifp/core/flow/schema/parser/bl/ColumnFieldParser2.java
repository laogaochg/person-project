package com.ifp.core.flow.schema.parser.bl;

import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.w3c.dom.Element;

public class ColumnFieldParser2 extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    builder.addConstructorArgValue(element.getAttribute("name"));
  }

  protected Class<String> getBeanClass(Element element)
  {
    return String.class;
  }
}