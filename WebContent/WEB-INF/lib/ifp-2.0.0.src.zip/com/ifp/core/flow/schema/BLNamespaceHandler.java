package com.ifp.core.flow.schema;

import com.ifp.core.flow.schema.parser.bl.ActionParser;
import com.ifp.core.flow.schema.parser.bl.BusinessLogicParser;
import com.ifp.core.flow.schema.parser.bl.ColumnFieldParser;
import com.ifp.core.flow.schema.parser.bl.DataFieldParser;
import com.ifp.core.flow.schema.parser.bl.DataListParser;
import com.ifp.core.flow.schema.parser.bl.DataMapParser;
import com.ifp.core.flow.schema.parser.bl.FlowParser;
import com.ifp.core.flow.schema.parser.bl.InFieldParser;
import com.ifp.core.flow.schema.parser.bl.InputParser;
import com.ifp.core.flow.schema.parser.bl.OutFieldParser;
import com.ifp.core.flow.schema.parser.bl.OutputParser;
import com.ifp.core.flow.schema.parser.bl.SubFlowParser;
import com.ifp.core.flow.schema.parser.bl.TargetParser;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

public class BLNamespaceHandler extends NamespaceHandlerSupport
{
  public void init()
  {
    registerBeanDefinitionParser("businessLogic", new BusinessLogicParser());

    registerBeanDefinitionParser("dataDictionary", new DataMapParser());
    registerBeanDefinitionParser("dataList", new DataListParser());
    registerBeanDefinitionParser("dataField", new DataFieldParser());
    registerBeanDefinitionParser("columnField", new ColumnFieldParser());

    registerBeanDefinitionParser("input", new InputParser());
    registerBeanDefinitionParser("inField", new InFieldParser());

    registerBeanDefinitionParser("output", new OutputParser());
    registerBeanDefinitionParser("outField", new OutFieldParser());

    registerBeanDefinitionParser("flow", new FlowParser());
    registerBeanDefinitionParser("subFlow", new SubFlowParser());
    registerBeanDefinitionParser("action", new ActionParser());
    registerBeanDefinitionParser("actionConfig", new DataMapParser());
    registerBeanDefinitionParser("property", new DataFieldParser());
    registerBeanDefinitionParser("target", new TargetParser());
    registerBeanDefinitionParser("asyncTarget", new TargetParser());
  }
}