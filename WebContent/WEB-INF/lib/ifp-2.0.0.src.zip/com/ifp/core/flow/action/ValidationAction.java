package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.util.List;

public class ValidationAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try
    {
      String fieldNames = confMap.getElementValue("fieldNames");
      String validateType = confMap.getElementValue("validateType");

      List fNameList = getFieldList(fieldNames);

      for (int i = 0; i < fNameList.size(); ++i)
      {
        String fieldName = (String)fNameList.get(i);
        if ("request".equals(validateType))
        {
          if (StringUtil.hasText(dataMap.getElementValue(fieldName)))
            break label391;
          throw new ActionException("fieldName:" + fieldName + "[" + ((DataField)dataMap.get(fieldName)).getDesc() + "]不能为空！");
        }
        if (validateType.startsWith("length")) {
          String lens = validateType.substring(validateType.indexOf("{"), validateType.lastIndexOf("}"));
          label391: if ((StringUtil.hasText(dataMap.getElementValue(fieldName))) && (dataMap.getElementValue(fieldName).length() > Integer.parseInt(lens)))
          {
            throw new ActionException("fieldName:" + fieldName + "[" + ((DataField)dataMap.get(fieldName)).getDesc() + "]长度不能超过(" + lens + ":)" + dataMap.getElementValue(fieldName));
          }
        } else if (validateType.startsWith("pattern")) {
          String pattern = validateType.substring(validateType.indexOf("{"), validateType.lastIndexOf("}"));
          if (!(dataMap.getElementValue(fieldName).matches(pattern)))
          {
            throw new ActionException("fieldName:" + fieldName + "[" + ((DataField)dataMap.get(fieldName)).getDesc() + "]格式有误:" + dataMap.getElementValue(fieldName));
          }
        } else {
          throw new ActionException("未知校验类型");
        }
      }
    }
    catch (ActionException e) {
      Trace.log("ACTION", 3, "数据校验组件异常：", e);
      throw e;
    } catch (Exception e) {
      Trace.log("ACTION", 3, "数据校验组件异常：", e);
      throw new ActionException(e);
    }

    return 0;
  }
}