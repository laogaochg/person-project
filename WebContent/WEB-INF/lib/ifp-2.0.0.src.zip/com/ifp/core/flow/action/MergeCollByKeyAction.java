package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.util.StringUtils;

public class MergeCollByKeyAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String mergeCollName = confMap.getElementValue("mergeCollName");
    if (!(StringUtils.hasText(mergeCollName))) {
      throw new ActionException("合并集合名称不能为空！");
    }

    String mergeKey = confMap.getElementValue("mergeKey");
    if (!(StringUtils.hasText(mergeKey))) {
      throw new ActionException("合并条件不能为空！");
    }

    String outCollName = confMap.getElementValue("outCollName");
    if (!(StringUtils.hasText(outCollName))) {
      throw new ActionException("输出集合名称不能为空！");
    }

    String outCollFields = confMap.getElementValue("outCollFields");
    if (!(StringUtils.hasText(outCollFields))) {
      throw new ActionException("输出集合字段不能为空！");
    }

    String[] collNames = mergeCollName.split(getFieldSeperatorRegex());
    String[] fieldNames = outCollFields.split(getFieldSeperatorRegex());
    if (collNames.length != 2) {
      throw new ActionException("合并集合名称字段需包含两个集合名称，中间用||分隔");
    }

    String[] fieldName1s = fieldNames[0].split("#");
    String[] fieldName2s = fieldNames[1].split("#");
    try
    {
      String collName1 = collNames[0];
      String collName2 = collNames[1];

      DataList datalist1 = (DataList)dataMap.get(collName1);
      DataList datalist2 = (DataList)dataMap.get(collName2);
      DataList outDataList = (DataList)dataMap.get(outCollName);
      List mergeList = new ArrayList();
      for (int i = 0; i < datalist1.size(); ++i)
      {
        DataMap dataMap1 = (DataMap)datalist1.get(i);
        String mergeValue1 = dataMap1.getElementValue(mergeKey);
        for (int j = 0; j < datalist2.size(); ++j)
        {
          if (!(mergeList.contains(Integer.valueOf(j))))
          {
            DataMap dataMap2 = (DataMap)datalist2.get(j);
            String mergeValue2 = dataMap2.getElementValue(mergeKey);
            if (mergeValue1.equals(mergeValue2))
            {
              DataMap outDataMap = outDataList.createSubDataMap();
              mergeList.add(Integer.valueOf(j));
              for (int k = 0; k < fieldName1s.length; ++k)
              {
                outDataMap.put(fieldName1s[k], dataMap1.get(fieldName1s[k]));
              }
              for (k = 0; k < fieldName2s.length; ++k)
              {
                outDataMap.put(fieldName2s[k], dataMap2.get(fieldName2s[k]));
              }
              outDataList.add(outDataMap);
            }
          }
        }
      }
    }
    catch (Exception e) {
      throw new ActionException(e);
    }
    return 0;
  }
}