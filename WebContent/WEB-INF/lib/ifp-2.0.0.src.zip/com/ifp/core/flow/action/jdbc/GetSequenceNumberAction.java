package com.ifp.core.flow.action.jdbc;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.JdbcException;
import com.ifp.core.jdbc.adapter.IJdbcAdapter;
import com.ifp.core.log.Trace;
import org.springframework.jdbc.core.JdbcTemplate;

public class GetSequenceNumberAction extends AbstractJDBCAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    String dataSource = confMap.getElementValue("dataSource");
    try
    {
      String sequence = confMap.getElementValue("sequence");

      if (sequence.startsWith("#")) {
        sequence = sequence.substring(1);
        sequence = dataMap.getElementValue(sequence);
      }

      String outputField = confMap.getElementValue("outputField");

      String sql = getJdbcAdapter(dataSource).getSequenceNumberSql(sequence);
      Trace.log("JDBC", 1, "querySQL--->{}", new Object[] { sql });
      JdbcTemplate jdbcTemplate = getJdbcTemplate(dataSource);
      dataMap.setElementValue(outputField, (String)jdbcTemplate.queryForObject(sql, String.class));
    } catch (Exception e) {
      throw new JdbcException("获取序列号失败!", e);
    }

    return 0;
  }
}