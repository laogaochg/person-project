package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;

public class TransitionAction extends AbstractAction
{
  public int execute(BlogicContext blogiccontext, DataMap datamap)
    throws BaseException
  {
    return 0;
  }
}