package com.ifp.core.flow.util;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FieldMapping4IFPUtil
{
  public static void format(String mappingId, DataMap dataMap, DataMap inputMap)
    throws Exception
  {
    Trace.logDebug("DATA", "字段映射前:{}", new Object[] { dataMap });

    MessageDefine requestMsgDefine = (MessageDefine)SpringContextsUtil.getBean(mappingId + "_send", MessageDefine.class);
    Iterator elementIter = requestMsgDefine.getElementMap().entrySet().iterator();
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof GroupMap)
        formatGroup(inputMap, dataMap, (GroupMap)defineElement);
      else
        formatElement(inputMap, dataMap, defineElement);

    }

    Trace.logDebug("DATA", "字段映射后:{}", new Object[] { inputMap });
  }

  public static void unformat(String mappingId, DataMap dataMap, DataMap resultMap)
    throws Exception
  {
    Trace.logDebug("DATA", "字段反映射前:{}", new Object[] { resultMap });

    MessageDefine requestMsgDefine = (MessageDefine)SpringContextsUtil.getBean(mappingId + "_receive", MessageDefine.class);
    Iterator elementIter = requestMsgDefine.getElementMap().entrySet().iterator();
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof GroupMap)
        unformatGroup(resultMap, dataMap, (GroupMap)defineElement);
      else
        unformatElement(resultMap, dataMap, defineElement);

    }

    Trace.logDebug("DATA", "字段反映射后:{}", new Object[] { dataMap });
  }

  public static void formatGroup(DataMap map, DataMap dataMap, GroupMap groupDefine) throws Exception {
    Iterator defineIterator = groupDefine.entrySet().iterator();
    String refName = groupDefine.getName();
    DataList listValue = new DataList();
    listValue.setDefineMap((DataMap)dataMap.getDefineMap().get(refName));
    while (defineIterator.hasNext()) {
      Map.Entry defineEntry = (Map.Entry)defineIterator.next();
      String key = (String)defineEntry.getKey();
      DataMap mapValue = listValue.createSubDataMap();
      DataElement defineElement = (DataElement)defineEntry.getValue();
      if (defineElement instanceof GroupMap)
        formatGroup(mapValue, dataMap, (GroupMap)defineElement);
      else
        formatElement(mapValue, dataMap, defineElement);

      listValue.add(mapValue);
    }
    map.put(refName, listValue);
  }

  public static void formatElement(DataMap map, DataMap dataMap, DataElement defineElement) throws Exception {
    if (defineElement instanceof MsgField) {
      formatField(map, dataMap, (MsgField)defineElement);
    } else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null != listDefine) {
        String key = listDefine.getName();
        String refName = listDefine.getRefName();
        if (StringUtil.hasText(refName))
          key = refName;

        DataElement listElement = dataMap.get(key);
        if (null == listElement) {
          if (listDefine.isNeed())
            throw new Exception(listDefine.getName() + " is need!");

          return;
        }

        if (!(listElement instanceof DataList))
          throw new Exception(key + " is undefine list, here expect of DataList!");

        formatList(map, (DataList)listElement, listDefine);
      }
    }
  }

  public static void formatField(DataMap map, DataMap dataMap, MsgField fieldDefine) throws Exception
  {
    String key = fieldDefine.getName();
    String value = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (!(StringUtil.hasText(refName))) {
      refName = fieldDefine.getName();
    }

    DataElement dataElement = dataMap.get(refName);
    if (null == dataElement) {
      if ((!(fieldDefine.isNeed())) || (StringUtil.hasText(value))) break label156;
      throw new Exception(fieldDefine.getName() + " is need!");
    }

    if (!(dataElement instanceof DataField)) {
      throw new Exception(key + " is define field, expect of DataField in context here!");
    }

    DataField dataField = (DataField)dataElement;
    if ((null != dataField) && (StringUtil.hasText(dataField.getValue()))) {
      value = dataField.getValue();
    }

    label156: value = (value == null) ? "" : value;
    map.put(key, value);
  }

  public static void formatList(DataMap map, DataList<DataElement> dataList, MsgList listDefine) throws Exception
  {
    Object[] fieldDefineArray = listDefine.values().toArray();
    String refName = listDefine.getRefName();
    DataList listValue = new DataList();

    if (!(StringUtil.hasText(refName)))
      refName = listDefine.getName();

    for (Iterator i$ = dataList.iterator(); i$.hasNext(); ) { DataElement rowElement = (DataElement)i$.next();
      DataMap mapValue = listValue.createSubDataMap();
      if (rowElement instanceof DataMap) {
        DataMap rowMap = (DataMap)rowElement;
        Object[] arr$ = fieldDefineArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object defineObject = arr$[i$];
          formatElement(mapValue, rowMap, (DataElement)defineObject);
        }
      } else {
        throw new Exception("DataList rows expect of DataMap");
      }
      listValue.add(mapValue);
    }
    map.put(listDefine.getName(), listValue);
  }

  public static void unformatGroup(DataMap resultMap, DataMap outDataMap, GroupMap defineMap) throws Exception {
    Iterator defineIterator = defineMap.values().iterator();
    while (defineIterator.hasNext()) {
      DataElement defineElement = (DataElement)defineIterator.next();
      if (defineElement instanceof GroupMap) { continue;
      }

      unformatElement(resultMap, outDataMap, defineElement);
    }
  }

  public static void unformatElement(DataMap resultMap, DataMap outDataMap, DataElement defineElement)
    throws Exception
  {
    if (defineElement instanceof MsgField) {
      MsgField msgField = (MsgField)defineElement;

      if (null == resultMap.get(msgField.getName())) {
        if (msgField.isNeed())
          throw new Exception(defineElement.getName() + " is need!");

        return;
      }

      unformatField(resultMap, outDataMap, msgField);
    } else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null != listDefine) {
        DataElement value = resultMap.get(listDefine.getName());
        if ((null == value) || (!(value instanceof DataList))) {
          if (listDefine.isNeed())
            throw new Exception(defineElement.getName() + " is need!");

          return;
        }

        DataList listValue = (DataList)value;
        int i = 0; for (int length = listValue.size(); i < length; ++i)
          unformatList((DataMap)listValue.get(i), outDataMap, listDefine);
      }
    }
  }

  public static void unformatField(DataMap resultMap, DataMap outDataMap, MsgField fieldDefine) throws Exception
  {
    String refName = fieldDefine.getRefName();
    if (!(StringUtil.hasText(refName)))
      refName = fieldDefine.getName();

    String name = fieldDefine.getName();
    String value = resultMap.getElementValue(name);

    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      throw new Exception(fieldDefine.getName() + " is empty!");
    }

    String defaultValue = fieldDefine.getValue();

    if ((null != defaultValue) && (!(StringUtil.hasText(value)))) {
      value = defaultValue;
    }

    value = (value == null) ? "" : value;
    if (outDataMap.containsKey(refName))
      outDataMap.setElementValue(refName, value);
    else
      outDataMap.put(refName, value);
  }

  public static void unformatList(DataMap resultMap, DataMap outDataMap, MsgList listDefine) throws Exception
  {
    DataList dList;
    Object[] fieldDefineArray = listDefine.values().toArray();
    String key = listDefine.getName();
    String refName = listDefine.getRefName();
    if (StringUtil.hasText(refName)) {
      key = refName;
    }

    if (outDataMap.containsKey(key)) {
      DataElement outElement = outDataMap.get(key);
      if (outElement instanceof DataList)
        dList = (DataList)outElement;
      else
        throw new Exception(key + " is define list, expect of DataList in context here!");
    }
    else {
      dList = new DataList();
      dList.setDefineMap((DataMap)outDataMap.getDefineMap().get(key));
    }

    DataMap dMap = dList.createSubDataMap();
    for (int i = 0; i < fieldDefineArray.length; ++i)
      unformatElement(resultMap, dMap, (DataElement)fieldDefineArray[i]);

    dList.add(dMap);

    outDataMap.put(key, dList);
  }
}