package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import java.util.Iterator;
import java.util.Set;
import org.springframework.util.StringUtils;

public class CopyFieldToCollValueAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws ActionException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String collName = confMap.getElementValue("collName");
    if (!(StringUtils.hasText(collName))) {
      throw new ActionException("数据集合名称为null");
    }

    String fieldName = confMap.getElementValue("fieldName");
    if (!(StringUtils.hasText(fieldName))) {
      throw new ActionException("字段名称为null");
    }

    String collValue = confMap.getElementValue("collValue");
    if (!(StringUtils.hasText(collValue))) {
      throw new ActionException("数据集合值为null");
    }

    if (!(dataMap.containsKey(collName))) {
      throw new ActionException("数据集合不存在: " + collName);
    }

    DataElement dataElement = dataMap.get(collName);
    if (!(dataElement instanceof DataList))
      throw new ActionException("非集合类型: " + collName);

    try
    {
      DataList dataList = (DataList)dataElement;

      String[] recoreds = collValue.split(getFieldSeperatorRegex());
      String[] fNames = fieldName.split(getFieldSeperatorRegex());

      String[] arr$ = recoreds; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String recored = arr$[i$];
        String[] fields = recored.split("#");
        DataMap dMap = dataList.createSubDataMap();

        DataMap defineMap = dMap.getDefineMap();
        Iterator iterator = defineMap.keySet().iterator();
        while (iterator.hasNext()) {
          String key = (String)iterator.next();
          int i = 0;
          while (true) { while (true) { if (i >= fNames.length) break label336;
              String fName = fNames[i];
              if (!(key.equalsIgnoreCase(fName))) break;
              dMap.put(fName, dataMap.get(fields[i]).clone());
            }
            ++i;
          }

          label336: dMap.put(key, new DataField(key, ""));
        }
        dataList.add(dMap);
      }
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}