package com.ifp.core.flow.logic;

import com.ifp.core.flow.step.IStep;
import java.util.Map;

public class Flow
{
  private String id;
  private Map<String, IStep> stepMap;

  public String getId()
  {
    return this.id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Map<String, IStep> getStepMap() {
    return this.stepMap;
  }

  public void setStepMap(Map<String, IStep> stepMap) {
    this.stepMap = stepMap;
  }
}