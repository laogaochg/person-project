package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import org.springframework.util.StringUtils;

public class SplicingStringAction extends FillFieldAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String sourceStr = confMap.getElementValue("sourceName");
    if (!(StringUtils.hasText(sourceStr))) {
      throw new ActionException("来源为null");
    }

    String outputField = confMap.getElementValue("outputField");
    if (!(StringUtils.hasText(outputField))) {
      throw new ActionException("被合并的目标数据集合列表为null");
    }

    dataMap.put(outputField, replaceString(dataMap, sourceStr, confMap.getElementValue("connector")));

    return 0;
  }
}