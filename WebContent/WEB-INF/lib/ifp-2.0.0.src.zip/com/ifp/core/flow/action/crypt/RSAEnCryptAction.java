package com.ifp.core.flow.action.crypt;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.encrypt.rsa.RSAUtils;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.AbstractAction;
import java.security.interfaces.RSAPublicKey;
import org.springframework.util.StringUtils;

public class RSAEnCryptAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try {
      String sourceName = confMap.getElementValue("sourceName");
      if (!(StringUtils.hasText(sourceName)))
        throw new ActionException("加密字段为null");

      String outputName = confMap.getElementValue("outputName");
      if (!(StringUtils.hasText(outputName)))
        throw new ActionException("输出字段为null");

      String publicKey = confMap.getElementValue("publicKey");
      if (!(StringUtils.hasText(publicKey)))
        throw new ActionException("公钥字段名称为null");

      String modulusName = confMap.getElementValue("modulusName");
      if (!(StringUtils.hasText(modulusName))) {
        throw new ActionException("模名称为null");
      }

      String publicExponent = (String)getSystemConf().getConfByKey(publicKey);
      String modulus = (String)getSystemConf().getConfByKey(modulusName);
      RSAPublicKey pubKey = RSAUtils.getPublicKey(modulus, publicExponent);

      String[] sourceFieldNames = sourceName.split(getFieldSeperatorRegex());
      String[] targetFieldNames = outputName.split(getFieldSeperatorRegex());

      for (int i = 0; i < sourceFieldNames.length; ++i)
        dataMap.setElementValue(targetFieldNames[i], RSAUtils.encryptByPublicKey(dataMap.getElementValue(sourceFieldNames[i]), pubKey));
    }
    catch (ActionException e)
    {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }
    return 0;
  }
}