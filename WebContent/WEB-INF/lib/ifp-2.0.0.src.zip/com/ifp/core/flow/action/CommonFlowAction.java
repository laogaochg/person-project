package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.context.Context;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.data.InputField;
import com.ifp.core.data.OutputField;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.ElementNotFoundException;
import com.ifp.core.flow.FlowHandle;
import com.ifp.core.flow.logic.BusinessLogic;
import com.ifp.core.log.Trace;
import com.ifp.core.util.DateUtil;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import java.util.HashMap;
import java.util.Map;

public class CommonFlowAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws ActionException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    if (null != confMap) {
      Trace.log("ACTION", 0, "{} context datamap: {}", new Object[] { context.getLogicCode(), ((DataMap)context.getDataMap()).toString() });
      FlowHandle blFlowHandle = (FlowHandle)SpringContextsUtil.getBean("blFlowHandle");
      String logicId = "";

      DataField flowKeyField = (DataField)confMap.get("commFlowId");
      if (null != flowKeyField)
        logicId = flowKeyField.getValue();
      else
        throw new ActionException("配置项中的公有逻辑为空，请检查流程配置文件！");

      BusinessLogic commLogic = (BusinessLogic)SpringContextsUtil.getBean(logicId);
      Map inConfMap = getKeyMap((DataField)confMap.get("input"));
      Map outConfMap = getKeyMap((DataField)confMap.get("output"));

      if (null != commLogic) {
        if (commLogic.commonFlag)
          try
          {
            DataElement dElement;
            Context commContext = new BlogicContext();
            commContext.setLogicCode(commLogic.getId());
            commContext.setCreateTime(DateUtil.getStringToday());
            commContext.setLogicPath(context.getLogicPath());

            DataMap commDataMap = commLogic.getDefaultDataMap().clone();
            DataList inList = commLogic.getInputParamsList();
            if (null != inList)
              for (int i = 0; i < inList.size(); ++i) {
                InputField inField = (InputField)inList.get(i);
                String key = getInKey(inConfMap, inField);
                dElement = dataMap.get(key);
                if (null != dElement)
                  commDataMap.put(inField.getName(), dElement.clone());
                else
                  throw new ElementNotFoundException("element not found in source: " + key);
              }


            commContext.setDataMap(commDataMap);
            commContext.setMonitorId(context.getMonitorId());
            Trace.log("ACTION", 0, "{} commContext datamap: {}", new Object[] { commContext.getLogicCode(), commContext.getDataMap().toString() });
            blFlowHandle.executeComm(commLogic, commContext);
            Trace.log("ACTION", 0, "{} commContext datamap: {}", new Object[] { commContext.getLogicCode(), commContext.getDataMap().toString() });

            DataList outList = commLogic.getOutputParamsList();
            if (null != outList)
              for (int i = 0; i < outList.size(); ++i) {
                OutputField outField = (OutputField)outList.get(i);
                dElement = commDataMap.get(outField.getName());
                if (null != dElement) {
                  String key = getOutKey(outConfMap, outField);
                  dataMap.put(key, dElement);
                } else {
                  throw new ElementNotFoundException("element not found in common context: " + outField.getName());
                }
              }
          }
          catch (BaseException e) {
            throw new ActionException("公有逻辑执行异常！logicId ：" + logicId, e);
          }

        throw new ActionException("非公有逻辑，不能执行！logicId ：" + logicId);
      }

      throw new ActionException("取得的公有逻辑为空，请检查流程配置文件！");

      Trace.log("ACTION", 0, "{} context datamap: {}", new Object[] { context.getLogicCode(), ((DataMap)context.getDataMap()).toString() });
    } else {
      throw new ActionException("配置项为空，请检查流程配置！");
    }
    return 0;
  }

  private Map<String, String> getKeyMap(DataField dataField)
  {
    Map keyMap = new HashMap();
    if (null != dataField) {
      String conf = dataField.getValue();
      if ((null != conf) && (!("".equals(conf.trim())))) {
        String[] confArr = conf.split("\\|");
        String[] arr$ = confArr; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String cm = arr$[i$];
          String[] c = cm.split("@");
          keyMap.put(c[1], c[0]);
        }
      }
    }
    return keyMap;
  }

  private String getInKey(Map<String, String> keyMap, InputField inField)
  {
    String key = inField.getName();
    if (StringUtil.hasText(inField.getSourceName())) {
      key = inField.getSourceName();
    }

    if (keyMap.containsKey(key))
      return ((String)keyMap.get(key));

    return key;
  }

  private String getOutKey(Map<String, String> keyMap, OutputField outField)
  {
    String key = outField.getName();
    if (StringUtil.hasText(outField.getTargetName())) {
      key = outField.getTargetName();
    }

    if (keyMap.containsKey(key))
      return ((String)keyMap.get(key));

    return key;
  }
}