package com.ifp.core.flow.action.operation;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.AbstractAction;

public class NumberIteratorAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try {
      String numberField = confMap.getElementValue("numberField");
      String direction = confMap.getElementValue("direction");
      String stepSize = confMap.getElementValue("stepSize");
      int number = Integer.parseInt(dataMap.getElementValue(numberField.trim()));
      if ("sub".equals(direction))
        number -= Integer.parseInt(stepSize.trim());
      else
        number += Integer.parseInt(stepSize.trim());

      dataMap.setElementValue(numberField, String.valueOf(number));
    } catch (BaseException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}