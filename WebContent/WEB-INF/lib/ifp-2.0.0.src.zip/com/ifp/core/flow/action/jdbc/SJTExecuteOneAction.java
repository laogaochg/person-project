package com.ifp.core.flow.action.jdbc;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.JdbcException;
import com.ifp.core.log.Trace;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;

public class SJTExecuteOneAction extends AbstractJDBCAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    String dataSource = confMap.getElementValue("dataSource");
    int changeRecord = 0;
    try
    {
      String execSql = confMap.getElementValue("execSql");

      if (execSql.startsWith("#"))
      {
        execSql = dataMap.getElementValue(execSql.substring(1));
      }

      Object[] rstObject = getSqlParamValueListAndSql(execSql, dataMap);
      execSql = (String)rstObject[0];
      Trace.log("ACTION", 1, "executeSQL--->{}", new Object[] { execSql });
      List inputList = (List)rstObject[1];
      Trace.log("JDBC", 1, "inputList--->{}", new Object[] { inputList });

      JdbcTemplate jdbcTemplate = getJdbcTemplate(dataSource);
      changeRecord = jdbcTemplate.update(execSql, inputList.toArray());
    } catch (Exception e) {
      throw new JdbcException(e);
    }

    return changeRecord;
  }
}