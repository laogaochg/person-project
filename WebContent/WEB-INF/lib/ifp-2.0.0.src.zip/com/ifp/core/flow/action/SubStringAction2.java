package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import org.springframework.util.StringUtils;

public class SubStringAction2 extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try
    {
      String sourceStr = confMap.getElementValue("sourceName");
      if (!(StringUtils.hasText(sourceStr))) {
        throw new ActionException("截取字段名称不能为空！");
      }

      String outputField = confMap.getElementValue("outputField");
      if (!(StringUtils.hasText(outputField))) {
        throw new ActionException("输出字段名称不能为空！");
      }

      String subType = confMap.getElementValue("subType");
      if (!(StringUtils.hasText(subType))) {
        throw new ActionException("截取方式不能为空！");
      }

      String subLength = confMap.getElementValue("subLength");
      if (!(StringUtils.hasText(subLength))) {
        throw new ActionException("截取长度不能为空！");
      }

      String value = dataMap.getElementValue(sourceStr);

      if (!(StringUtil.hasText(value)))
      {
        throw new ActionException("截取字段为空！");
      }

      int length = dataMap.getElementValue(sourceStr).length();

      if (length < Integer.parseInt(subLength))
      {
        throw new ActionException("截取字段长度超出字段内容长度！");
      }
      if ("left".equals(subType))
      {
        dataMap.put(outputField, value.substring(0, Integer.parseInt(subLength)));
      } else if ("right".equals(subType))
      {
        dataMap.put(outputField, value.substring(value.length() - Integer.parseInt(subLength), value.length()));
      }
      else throw new ActionException("截取方式配置有误！");
    }
    catch (BaseException e)
    {
      throw e;
    } catch (Exception e) {
      Trace.log("ACTION", 3, "执行字符截取组件异常！", e);
      throw new ActionException(e);
    }

    return 0;
  }
}