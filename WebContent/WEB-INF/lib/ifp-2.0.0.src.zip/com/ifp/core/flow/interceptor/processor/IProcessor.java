package com.ifp.core.flow.interceptor.processor;

import com.ifp.core.context.Context;
import com.ifp.core.exception.BaseException;

public abstract interface IProcessor
{
  public abstract void process(Context paramContext)
    throws BaseException;
}