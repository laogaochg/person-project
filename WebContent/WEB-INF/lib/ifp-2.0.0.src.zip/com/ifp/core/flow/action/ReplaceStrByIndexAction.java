package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import org.springframework.util.StringUtils;

public class ReplaceStrByIndexAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    String value;
    DataMap dataMap = (DataMap)context.getDataMap();

    String sourceStr = confMap.getElementValue("sourceName");
    if (!(StringUtils.hasText(sourceStr))) {
      throw new ActionException("截取字段名称不能为空！");
    }

    String outputField = confMap.getElementValue("outputField");
    if (!(StringUtils.hasText(outputField))) {
      throw new ActionException("输出字段名称不能为空！");
    }

    String replaceIndex = confMap.getElementValue("replaceIndex");
    if (!(StringUtils.hasText(replaceIndex))) {
      throw new ActionException("替换位置不能为空！");
    }

    String length = confMap.getElementValue("length");
    if (!(StringUtils.hasText(length))) {
      throw new ActionException("替换长度不能为空！");
    }

    String replaceKey = confMap.getElementValue("replaceKey");
    if (!(StringUtils.hasText(replaceKey))) {
      throw new ActionException("替换Key值不能为空！");
    }

    int len = dataMap.getElementValue(sourceStr).length();

    if (len < Integer.parseInt(replaceIndex) + Integer.parseInt(length))
    {
      throw new ActionException("替换字段长度超出字段内容长度！");
    }

    String sourceValue = dataMap.getElementValue(sourceStr);
    if (replaceKey.startsWith("#"))
    {
      value = sourceValue.substring(0, Integer.parseInt(replaceIndex) - 1) + dataMap.getElementValue(replaceKey.substring(1)) + sourceValue.substring(Integer.parseInt(replaceIndex) + Integer.parseInt(length) - 1);

      dataMap.put(outputField, value);
    } else {
      value = sourceValue.substring(0, Integer.parseInt(replaceIndex) - 1) + replaceKey + sourceValue.substring(Integer.parseInt(replaceIndex) + Integer.parseInt(length) - 1);

      dataMap.put(outputField, value);
    }

    return 0;
  }
}