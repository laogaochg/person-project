package com.ifp.core.flow.util;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.rpc.RPCHandle;
import java.util.Map;

public class DubboFlowUtil
{
  public static Map<String, Object> execute(Map<String, Object> blogicContextMap, String monitorId, String logicId)
    throws BaseException
  {
    Trace.log("FLOW", 0, "dubbo调远程flow组件，调用远程flow的logicId为{}", new Object[] { logicId });
    RPCHandle rpcHandle = (RPCHandle)SpringContextsUtil.getBean("rpcHandle");

    ClogicContext clogicContext = new ClogicContext();
    clogicContext.setLogicCode(logicId);
    clogicContext.setMonitorId(monitorId);
    clogicContext.setDataMap(blogicContextMap);

    rpcHandle.executeRemoteServiceForCL(clogicContext, logicId);
    return ((Map)clogicContext.getDataMap());
  }
}