package com.ifp.core.flow.action.crypt;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.AbstractAction;
import com.ifp.core.flow.util.MD5Util;
import org.springframework.util.StringUtils;

public class MD5EnCryptAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try {
      String sourceName = confMap.getElementValue("sourceName");
      if (!(StringUtils.hasText(sourceName)))
        throw new ActionException("加密字段为null");

      String outputName = confMap.getElementValue("outputName");
      if (!(StringUtils.hasText(outputName))) {
        throw new ActionException("输出字段为null");
      }

      String[] sourceFieldNames = sourceName.split(getFieldSeperatorRegex());
      String[] targetFieldNames = outputName.split(getFieldSeperatorRegex());

      for (int i = 0; i < sourceFieldNames.length; ++i)
        dataMap.setElementValue(targetFieldNames[i], MD5Util.md5Encode(dataMap.getElementValue(sourceFieldNames[i])));
    }
    catch (ActionException e)
    {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }
    return 0;
  }
}