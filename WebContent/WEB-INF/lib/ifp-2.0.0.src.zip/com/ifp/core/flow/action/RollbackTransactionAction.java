package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import java.util.List;

public class RollbackTransactionAction extends AbstractAction
{
  private final IAction action;

  public RollbackTransactionAction()
  {
    this.action = ((IAction)SpringContextsUtil.getBean("dubboFlowAction"));
  }

  public int execute(BlogicContext context, DataMap confMap) throws BaseException {
    DataMap dataMap = (DataMap)context.getDataMap();
    try {
      String serviceNames = confMap.getElementValue("serviceNames");
      if (!(StringUtil.hasText(serviceNames)))
      {
        throw new ActionException("服务列表不能为空！");
      }
      String rollbackServiceNames = confMap.getElementValue("rollbackServiceNames");
      if (!(StringUtil.hasText(rollbackServiceNames)))
      {
        throw new ActionException("回滚服务列表不能为空！");
      }
      String errorLogic = context.getLastExceLogic();

      List serviceList = getFieldList(serviceNames);
      List rollbackServiceList = getFieldList(rollbackServiceNames);

      if (serviceList.size() != rollbackServiceList.size())
      {
        throw new ActionException("服务列表与回滚服务列表不对应！");
      }

      if (StringUtil.hasText(errorLogic))
      {
        Trace.log("ACTION", 1, "[{}]服务异常，开始事务回滚！", new Object[] { errorLogic });
        int i = 0; for (int slength = serviceList.size(); i < slength; ++i)
        {
          String serviceName = (String)serviceList.get(i);
          if (serviceName.equals(errorLogic))
          {
            DataMap cMap = new DataMap(true);
            for (int j = i; j > 0; --j)
            {
              String rollbackServiceName = (String)rollbackServiceList.get(j);
              Trace.log("ACTION", 0, "开始事务回滚服务[{}]", new Object[] { rollbackServiceName });
              cMap.put("logicId", new DataField("logicId", rollbackServiceName));
              this.action.execute(context, cMap);
              Trace.log("ACTION", 0, "结束事务回滚服务[{}]", new Object[] { rollbackServiceName });
            }
            break;
          }
        }
        Trace.log("ACTION", 1, "事务回滚结束！");
      }
    }
    catch (BaseException e) {
      Trace.log("ACTION", 3, "执行事务回滚服务异常！", e);
      throw e;
    } catch (Exception e) {
      Trace.log("ACTION", 3, "执行事务回滚服务异常！", e);
      throw new ActionException(e);
    }
    return 0;
  }
}