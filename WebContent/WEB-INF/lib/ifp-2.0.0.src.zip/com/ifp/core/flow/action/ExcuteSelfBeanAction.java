package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.util.SpringContextsUtil;
import org.springframework.util.StringUtils;

public class ExcuteSelfBeanAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String fieldBeanName = confMap.getElementValue("fieldBeanName");
    if (!(StringUtils.hasText(fieldBeanName))) {
      throw new ActionException("执行bean名称为null");
    }

    IAction iAction = (IAction)SpringContextsUtil.getBean(fieldBeanName);
    iAction.execute(context, confMap);

    return 0;
  }
}