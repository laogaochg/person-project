package com.ifp.core.flow.action.ftp;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.AbstractAction;
import com.ifp.core.ftp.client.FtpClientHandle;
import com.ifp.core.log.Trace;

public class FtpDownloadAction extends AbstractAction
{
  private FtpClientHandle ftpClientHandle;
  private String localFilePath;

  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try {
      String tfilePath;
      String ftpServiceId = confMap.getElementValue("ftpServiceId");
      String pathType = getConfValue("pathType", dataMap, confMap);
      String sourceFilePath = getConfValue("sourceFilePath", dataMap, confMap);
      String sourceFileName = getConfValue("sourceFileName", dataMap, confMap);
      String targetFilePath = getConfValue("targetFilePath", dataMap, confMap);
      String targetFileName = getConfValue("targetFileName", dataMap, confMap);
      String createFlag = confMap.getElementValue("createFlag");

      if ("0".equals(pathType))
        tfilePath = getSystemConf().getWebRootPath() + targetFilePath;
      else if ("1".equals(pathType))
        tfilePath = this.localFilePath + targetFilePath;
      else if ("2".equals(pathType))
        tfilePath = targetFilePath;
      else {
        throw new ActionException("not expect value for pathType: " + pathType);
      }

      Trace.log("FTP", 0, "ftpServiceId:{}, tfilePath:{}, targetFileName:{}, sourceFilePath:{}, sourceFileName:{}, createFlag:{}", new Object[] { ftpServiceId, tfilePath, targetFileName, sourceFilePath, sourceFileName, createFlag });

      this.ftpClientHandle.download(ftpServiceId, tfilePath, targetFileName, sourceFilePath, sourceFileName, Boolean.parseBoolean(createFlag));
    } catch (BaseException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }

  public FtpClientHandle getFtpClientHandle() {
    return this.ftpClientHandle;
  }

  public void setFtpClientHandle(FtpClientHandle ftpClientHandle) {
    this.ftpClientHandle = ftpClientHandle;
  }

  public String getLocalFilePath() {
    return this.localFilePath;
  }

  public void setLocalFilePath(String localFilePath) {
    this.localFilePath = localFilePath;
  }
}