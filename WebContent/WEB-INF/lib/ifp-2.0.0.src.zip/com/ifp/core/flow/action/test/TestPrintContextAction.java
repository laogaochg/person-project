package com.ifp.core.flow.action.test;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.flow.action.AbstractAction;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.util.HashMap;
import java.util.Map;

public class TestPrintContextAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws ActionException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try {
      String fieldNames = confMap.getElementValue("fieldName");
      if (StringUtil.hasText(fieldNames)) {
        Map map = new HashMap();
        String[] fieldName = fieldNames.split(getFieldSeperatorRegex());
        String[] arr$ = fieldName; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String fName = arr$[i$];
          DataElement dataElement = dataMap.get(fName);
          map.put(fName, dataElement);
        }
        Trace.logDebug("ACTION", "dataMap part fields: {}", new Object[] { map });
      } else {
        Trace.logDebug("ACTION", "dataMap all fields: {}", new Object[] { dataMap });
      }
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}