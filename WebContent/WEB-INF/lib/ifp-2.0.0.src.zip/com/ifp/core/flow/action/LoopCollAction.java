package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.util.StringUtil;
import java.util.Iterator;
import java.util.Set;
import org.springframework.util.StringUtils;

public class LoopCollAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String collName = confMap.getElementValue("collName");
    String fieldMapping = "";
    if (confMap.containsKey("fieldMapping")) {
      fieldMapping = confMap.getElementValue("fieldMapping");
    }

    if (!(StringUtils.hasText(collName)))
      throw new ActionException("数据集合名称为null");
    try
    {
      DataList dataList = (DataList)dataMap.get(collName);
      if (null == dataList) {
        throw new ActionException("找不到数据集合:" + collName);
      }

      String tempKey = context.getLogicPath() + "_" + getId() + "_listIndex";
      Integer tempInteger = (Integer)context.getTemp(tempKey);
      int index = (null != tempInteger) ? tempInteger.intValue() : 0;

      if (index < dataList.size()) {
        DataMap dtMap = (DataMap)dataList.get(index++);
        if (!(StringUtil.hasText(fieldMapping)))
        {
          for (Iterator iterator = dtMap.keySet().iterator(); iterator.hasNext(); ) {
            String key = (String)iterator.next();
            DataElement dataElement = dtMap.get(key);
            dataMap.put(key, dataElement);
          }
        } else {
          String[] fMappings = fieldMapping.split(getFieldSeperatorRegex());
          String[] arr$ = fMappings; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String fMapping = arr$[i$];
            if (StringUtil.hasText(fMapping)) {
              String[] fm = fMapping.split("#");
              String key = fm[0];
              DataElement dataElement = dtMap.get(key);
              if (fm.length > 1)
                dataMap.put(fm[1], dataElement);
              else
                dataMap.put(key, dataElement);
            }
          }
        }

        context.setTemp(tempKey, Integer.valueOf(index));
      } else {
        context.removeTemp(tempKey);
        return 1;
      }
    } catch (BaseException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}