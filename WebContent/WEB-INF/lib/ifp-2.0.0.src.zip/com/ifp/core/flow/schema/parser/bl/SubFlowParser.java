package com.ifp.core.flow.schema.parser.bl;

import com.ifp.core.flow.logic.Flow;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedMap;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class SubFlowParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    try
    {
      builder.addPropertyValue("id", element.getAttribute("id"));

      builder.addPropertyValue("stepMap", parseMapElement("action", element, parserContext, builder));
    } catch (Exception e) {
      parserContext.getReaderContext().error("class " + SubFlowParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<Flow> getBeanClass(Element element)
  {
    return Flow.class;
  }

  private Map<String, BeanDefinition> parseMapElement(String tagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List actionList = DomUtils.getChildElementsByTagName(element, tagName);

    ManagedMap map = new ManagedMap(actionList.size());
    map.setMergeEnabled(true);
    map.setSource(parserContext.getReaderContext().extractSource(element));

    for (Iterator i$ = actionList.iterator(); i$.hasNext(); ) { Element actionElement = (Element)i$.next();
      String id = actionElement.getAttribute("id");
      map.put(id, parserContext.getDelegate().parseCustomElement(actionElement, builder.getRawBeanDefinition()));
    }

    return map;
  }
}