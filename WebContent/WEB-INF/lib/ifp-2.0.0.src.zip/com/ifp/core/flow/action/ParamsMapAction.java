package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.util.StringUtils;

public class ParamsMapAction extends AbstractAction
{
  private final String fieldSp = "->";

  public ParamsMapAction()
  {
    this.fieldSp = "->"; }

  public int execute(BlogicContext context, DataMap confMap) throws BaseException { DataMap dataMap;
    try { dataMap = (DataMap)context.getDataMap();
      String mapFiled = confMap.getElementValue("mapFiled");
      String srcParamFiled = confMap.getElementValue("srcParamFiled");
      String descParamFiled = confMap.getElementValue("descParamFiled");
      if (!(StringUtils.hasText(mapFiled)))
        throw new ActionException("转换集合域为null");

      if (!(StringUtils.hasText(srcParamFiled)))
        throw new ActionException("源数据域为null");

      if (!(StringUtils.hasText(descParamFiled)))
        throw new ActionException("目标数据域为null");

      Map paramMap = new HashMap();
      String mapStr = dataMap.getElementValue(mapFiled);
      List mapList = getFieldList(mapStr);
      for (Iterator i$ = mapList.iterator(); i$.hasNext(); ) { String str = (String)i$.next();
        paramMap.put(str.split("->")[0], str.split("->")[1]);
      }
      List srcList = getFieldList(srcParamFiled);
      List descList = getFieldList(descParamFiled);
      if (srcList.size() != descList.size()) {
        throw new ActionException("源数据和目标数据参数数目不一致");
      }

      for (int i = 0; i < srcList.size(); ++i) {
        String srcValue = dataMap.getElementValue((String)srcList.get(i));
        dataMap.put((String)descList.get(i), (String)paramMap.get(srcValue));
      }
    }
    catch (Exception ex) {
      Trace.log("MVC", 3, "获取交易流水号失败", ex);
      throw new BaseException("CPR000001", "获取交易流水号失败", ex);
    }
    return 0;
  }
}