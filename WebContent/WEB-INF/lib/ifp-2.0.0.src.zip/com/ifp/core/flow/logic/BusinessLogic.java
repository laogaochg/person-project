package com.ifp.core.flow.logic;

import java.io.Serializable;
import java.util.Map;

public class BusinessLogic extends AbstractLogic
  implements Serializable
{
  private static final long serialVersionUID = -1945527171320984638L;
  private transient Map<String, Flow> subFlow;

  public Map<String, Flow> getSubFlow()
  {
    return this.subFlow;
  }

  public void setSubFlow(Map<String, Flow> subFlow) {
    this.subFlow = subFlow;
  }
}