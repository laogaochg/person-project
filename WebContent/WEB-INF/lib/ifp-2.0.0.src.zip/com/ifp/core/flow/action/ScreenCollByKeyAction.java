package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.util.StringUtil;
import java.util.ArrayList;
import java.util.List;
import org.springframework.util.StringUtils;

public class ScreenCollByKeyAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String sourceCollName = confMap.getElementValue("sourceCollName");
    if (!(StringUtils.hasText(sourceCollName))) {
      throw new ActionException("源集合名称不能为空！");
    }

    String screenKey = confMap.getElementValue("screenKey");
    if (!(StringUtils.hasText(screenKey))) {
      throw new ActionException("筛选字段不能为空！");
    }

    String screenValue = confMap.getElementValue("screenValue");
    if (!(StringUtils.hasText(screenValue))) {
      throw new ActionException("筛选值不能为空！");
    }

    String outCollName = confMap.getElementValue("outCollName");
    if (!(StringUtils.hasText(outCollName))) {
      throw new ActionException("输出集合名称不能为空！");
    }

    String outCollFields = confMap.getElementValue("outCollFields");

    String[] fieldNames = null;
    try {
      DataList datalist = (DataList)dataMap.get(sourceCollName).clone();
      DataList outDataList = (DataList)dataMap.get(outCollName).clone();
      if (sourceCollName.equals(outCollName))
      {
        outDataList.clear();
      }
      if (screenValue.startsWith("#"))
      {
        screenValue = dataMap.getElementValue(screenValue.substring(1));
      }
      if (StringUtil.hasText(outCollFields))
      {
        fieldNames = outCollFields.split(getFieldSeperatorRegex());
      }
      List mergeList = new ArrayList();
      for (int i = 0; i < datalist.size(); ++i)
      {
        DataMap dataMap1 = (DataMap)datalist.get(i);
        String screenValue1 = dataMap1.getElementValue(screenKey);
        if (screenValue.equals(screenValue1))
        {
          DataMap outDataMap = outDataList.createSubDataMap();
          if (fieldNames == null)
          {
            outDataMap = dataMap1;
          }
          else for (int k = 0; k < fieldNames.length; ++k)
            {
              outDataMap.put(fieldNames[k], dataMap1.get(fieldNames[k]));
            }

          outDataList.add(outDataMap);
        }
      }
      dataMap.put(outCollName, outDataList);
    }
    catch (Exception e) {
      throw new ActionException(e);
    }
    return 0;
  }
}