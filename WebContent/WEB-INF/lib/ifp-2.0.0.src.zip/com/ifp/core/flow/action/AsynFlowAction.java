package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.FlowHandle;
import com.ifp.core.flow.logic.BusinessLogic;
import com.ifp.core.flow.logic.Flow;
import com.ifp.core.log.FlumeLogInf;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.LogThread;
import com.ifp.core.log.Trace;
import com.ifp.core.pool.IThreadPool;
import com.ifp.core.util.DateUtil;
import com.ifp.core.util.SpringContextsUtil;
import java.util.Date;
import java.util.Map;

public class AsynFlowAction extends AbstractAction
{
  private IThreadPool threadPool;
  private LogHandle logHandle;

  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    String asynLogicId = confMap.getElementValue("asynFlowId");
    int result = 0;
    try {
      if (null == this.logHandle)
        this.logHandle = ((LogHandle)SpringContextsUtil.getBean("logHandle"));

      LogThread parentLogThread = this.logHandle.getLogThread();
      BusinessLogic logic = (BusinessLogic)SpringContextsUtil.getBean(context.getLogicCode());
      FlowHandle blFlowHandle = (FlowHandle)SpringContextsUtil.getBean("blFlowHandle");

      Map subLogicMap = logic.getSubFlow();
      Flow asynLogic = (Flow)subLogicMap.get(asynLogicId);
      if (null != asynLogic) {
        BlogicContext asynContext = new BlogicContext();
        asynContext.setDataMap(((DataMap)context.getDataMap()).clone());
        asynContext.setLogicCode(context.getLogicCode());
        asynContext.setLogicPath(context.getLogicPath() + "." + asynLogicId);
        asynContext.setMonitorId(context.getMonitorId());
        asynContext.setTempMap(context.getTempMap());
        asynContext.setCreateTime(DateUtil.getStringToday());

        FlumeLogInf parentFlumeLogInf = this.logHandle.getFlumeLogInf();

        this.threadPool.execute(new Runnable(this, parentLogThread, parentFlumeLogInf, asynContext, asynLogicId, blFlowHandle, asynLogic) {
          public void run() {
            AsynFlowAction.access$000(this.this$0).init(this.val$parentLogThread);
            String flumeReqIp = this.val$parentFlumeLogInf.getFlumeReqIP();
            String flumeReqId = null;
            String flumePid = null;
            String flumeCid = AsynFlowAction.access$000(this.this$0).getFlumeLogCid();

            AsynFlowAction.access$000(this.this$0).setFlumeLogInf(this.val$parentFlumeLogInf.getFlumeSessionId(), this.val$asynContext.getLogicCode(), flumeReqId, flumeCid, flumePid, flumeReqIp, Long.valueOf(new Date().getTime()));
            Trace.logDebug("ACTION", "开始执行异步逻辑：{}", new Object[] { this.val$asynLogicId });
            try {
              this.val$blFlowHandle.execute(this.val$asynLogic, this.val$asynContext);
              Trace.logInfo("ACTION", "异步线程执行完毕：{}", new Object[] { this.val$asynLogicId });
            } catch (Exception e) {
              Trace.logInfo("ACTION", "异步线程执行异常：{}, exception: {}", new Object[] { this.val$asynLogicId, e });
            } finally {
              Trace.logDebug("ACTION", "结束执行异步逻辑：{}", new Object[] { this.val$asynLogicId });
              if (null != AsynFlowAction.access$000(this.this$0))
                AsynFlowAction.access$000(this.this$0).destroy();
            }
          }
        });
      }
      else {
        throw new ActionException("取得的异步逻辑为空，请检查流程配置文件和加载程序！");
      }
    } catch (ActionException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException("异步逻辑块执行异常！asynLogicId ：" + asynLogicId, e);
    }
    return result;
  }

  public IThreadPool getThreadPool() {
    return this.threadPool;
  }

  public void setThreadPool(IThreadPool threadPool) {
    this.threadPool = threadPool;
  }
}