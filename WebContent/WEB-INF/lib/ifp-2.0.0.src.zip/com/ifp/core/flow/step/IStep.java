package com.ifp.core.flow.step;

import com.ifp.core.data.DataMap;
import java.util.Map;

public abstract interface IStep
{
  public abstract String getStepId();

  public abstract void setStepId(String paramString);

  public abstract String getRefBeanId();

  public abstract void setRefBeanId(String paramString);

  public abstract DataMap getConfMap();

  public abstract void setConfMap(DataMap paramDataMap);

  public abstract Map<String, StepTarget> getTargetMap();

  public abstract void setTargetMap(Map<String, StepTarget> paramMap);
}