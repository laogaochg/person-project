package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import org.springframework.util.StringUtils;

public class CopyFieldValueAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws ActionException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String sourceFieldName = confMap.getElementValue("sourceFieldName");
    if (!(StringUtils.hasText(sourceFieldName))) {
      throw new ActionException("来源数据域列表为null");
    }

    String targetFieldName = confMap.getElementValue("targetFieldName");
    if (!(StringUtils.hasText(targetFieldName))) {
      throw new ActionException("目标数据域列表为null");
    }

    String[] sourceFieldNames = sourceFieldName.split(getFieldSeperatorRegex());
    String[] targetFieldNames = targetFieldName.split(getFieldSeperatorRegex());
    if (sourceFieldNames.length != targetFieldNames.length)
      throw new ActionException("来源与目标数据域列表个数对不上");

    try
    {
      for (int i = 0; i < sourceFieldNames.length; ++i)
        dataMap.setElementValue(targetFieldNames[i], dataMap.getElementValue(sourceFieldNames[i]));
    }
    catch (ActionException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}