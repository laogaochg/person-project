package com.ifp.core.flow.logic;

public class ControlLogic extends AbstractLogic
{
}