package com.ifp.core.flow.util;

import com.ifp.core.log.Trace;
import java.io.PrintStream;
import java.security.MessageDigest;

public class MD5Util
{
  public static String md5Encode(String inStr)
    throws Exception
  {
    MessageDigest md5 = null;
    try {
      md5 = MessageDigest.getInstance("MD5");
    } catch (Exception e) {
      Trace.logError("CORE", "MessageDigest.getInstance(\"MD5\") error: {}", e);
      e.printStackTrace();
      return "";
    }

    byte[] byteArray = inStr.getBytes("UTF-8");
    byte[] md5Bytes = md5.digest(byteArray);
    StringBuffer hexValue = new StringBuffer();
    for (int i = 0; i < md5Bytes.length; ++i) {
      int val = md5Bytes[i] & 0xFF;
      if (val < 16)
        hexValue.append("0");

      hexValue.append(Integer.toHexString(val));
    }
    return hexValue.toString();
  }

  public static void main(String[] args) throws Exception {
    System.out.println(System.currentTimeMillis());
    String str = new String("amigoxiexiexingxing");
    System.out.println("原始：" + str);
    System.out.println("MD5后：" + md5Encode(str));
  }
}