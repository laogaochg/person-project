package com.ifp.core.flow.service;

import java.util.Map;

public abstract interface Service
{
  public abstract Map<String, Object> execute(Map<String, Object> paramMap)
    throws Exception;
}