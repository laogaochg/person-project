package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.util.StringUtil;
import java.io.PrintStream;
import org.springframework.util.StringUtils;

public class SubCharAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String sourceName = confMap.getElementValue("sourceName");
    if (!(StringUtils.hasText(sourceName))) {
      throw new ActionException("截取字段名称不能为空！");
    }

    String outputField = confMap.getElementValue("outputField");
    if (!(StringUtils.hasText(outputField))) {
      throw new ActionException("输出字段名称不能为空！");
    }

    String subLenght = confMap.getElementValue("subLenght");

    String value = "";
    if (sourceName.startsWith("#"))
    {
      value = dataMap.getElementValue(sourceName.substring(1));
    }

    String[] valuesTemp = value.split("");
    String[] values = new String[valuesTemp.length - 1];
    System.arraycopy(valuesTemp, 1, values, 0, valuesTemp.length - 1);
    String[] targetFieldNames = outputField.split(getFieldSeperatorRegex());
    if (targetFieldNames.length > values.length)
    {
      throw new ActionException("输出字段数量超出[" + sourceName + "]的长度！");
    }
    if (StringUtil.hasText(subLenght))
    {
      String[] sourceFieldNames = subLenght.split(getFieldSeperatorRegex());
      if (sourceFieldNames.length > value.length())
      {
        throw new ActionException("输出字段数量超出[" + sourceName + "]的长度！");
      }
      int countLen = 0;
      for (int i = 0; i < sourceFieldNames.length; ++i)
      {
        if (Integer.parseInt(sourceFieldNames[i]) < 1)
        {
          throw new ActionException("输出字段[" + targetFieldNames[i] + "]长度不能小于1！");
        }
        if (countLen > value.length())
        {
          throw new ActionException("输出字段数量超出[" + sourceName + "]的长度！");
        }
        dataMap.put(targetFieldNames[i], value.substring(countLen, countLen + Integer.parseInt(sourceFieldNames[i])));
        countLen += Integer.parseInt(sourceFieldNames[i]);
      }
    } else {
      for (int i = 0; i < targetFieldNames.length; ++i)
      {
        dataMap.put(targetFieldNames[i], values[i]);
      }
    }

    return 0;
  }

  public static void main(String[] args)
  {
    System.out.println("0123".substring(1, 2));
  }
}