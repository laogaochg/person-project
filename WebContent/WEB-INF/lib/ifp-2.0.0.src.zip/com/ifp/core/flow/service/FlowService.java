package com.ifp.core.flow.service;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.flow.logic.BusinessLogic;

public abstract interface FlowService extends Service
{
  public abstract BlogicContext execute(BlogicContext paramBlogicContext)
    throws Exception;

  public abstract BusinessLogic getBusinessLogic();
}