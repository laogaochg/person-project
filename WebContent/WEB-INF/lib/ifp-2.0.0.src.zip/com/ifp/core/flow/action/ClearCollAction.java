package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import org.springframework.util.StringUtils;

public class ClearCollAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws ActionException
  {
    DataMap dataMap = (DataMap)context.getDataMap();

    String collName = confMap.getElementValue("collName");
    if (!(StringUtils.hasText(collName))) {
      throw new ActionException("数据集合列表为null");
    }

    String[] collNames = collName.split(getFieldSeperatorRegex());
    try
    {
      for (int i = 0; i < collNames.length; ++i) {
        DataList dataList = (DataList)dataMap.get(collNames[i]);
        if (null == dataList) {
          throw new ActionException("找不到数据集合:" + collNames[i]);
        }

        dataList.clear();
      }
    } catch (ActionException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}