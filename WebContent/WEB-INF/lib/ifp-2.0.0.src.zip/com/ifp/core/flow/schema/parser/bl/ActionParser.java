package com.ifp.core.flow.schema.parser.bl;

import com.ifp.core.flow.step.FlowStep;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedMap;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class ActionParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    try
    {
      builder.addPropertyValue("stepId", element.getAttribute("id"));
      builder.addPropertyValue("refBeanId", element.getAttribute("type"));

      BeanDefinition confMap = parseElement("actionConfig", element, parserContext, builder);
      if (null != confMap) {
        builder.addPropertyValue("confMap", confMap);
      }

      Map targetMap = parseDataMapElement("target", element, parserContext, builder);
      if ((null != targetMap) && (targetMap.size() > 0)) {
        builder.addPropertyValue("targetMap", targetMap);
      }

      Map asyncTargetMap = parseDataMapElement("asyncTarget", element, parserContext, builder);
      if ((null != asyncTargetMap) && (asyncTargetMap.size() > 0))
        builder.addPropertyValue("asyncTargetMap", asyncTargetMap);

    }
    catch (Exception e)
    {
      parserContext.getReaderContext().error("class " + ActionParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<FlowStep> getBeanClass(Element element)
  {
    return FlowStep.class;
  }

  private BeanDefinition parseElement(String tagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List list = DomUtils.getChildElementsByTagName(element, tagName);
    if ((null != list) && (list.size() > 0)) {
      Element ele = (Element)list.get(0);
      BeanDefinition beanDefinition = parserContext.getDelegate().parseCustomElement(ele, builder.getRawBeanDefinition());
      return beanDefinition;
    }
    return null;
  }

  private Map<String, BeanDefinition> parseDataMapElement(String tagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    List targetList = DomUtils.getChildElementsByTagName(element, tagName);
    if ((null != targetList) && (targetList.size() > 0)) {
      ManagedMap map = new ManagedMap(targetList.size());
      map.setMergeEnabled(true);
      map.setSource(parserContext.getReaderContext().extractSource(element));

      for (Iterator i$ = targetList.iterator(); i$.hasNext(); ) { Element propertyElement = (Element)i$.next();
        String id = propertyElement.getAttribute("id");
        map.put(id, parserContext.getDelegate().parseCustomElement(propertyElement, builder.getRawBeanDefinition()));
      }

      return map;
    }
    return null;
  }
}