package com.ifp.core.flow.action.jdbc;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.BaseRuntimeException;
import com.ifp.core.flow.action.IAction;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import com.ifp.core.util.TransactionTemplateUtils;
import java.util.Map;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

public class JDBCTransactionProxyAction extends AbstractJDBCAction
{
  private Map<String, PlatformTransactionManager> txManagerMap;
  private IAction proxyAction;

  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    int result = 0;
    String dataSource = confMap.getElementValue("dataSource");
    String transType = confMap.getElementValue("transType");
    int isolationLevel = -1;
    DataField isolationLevelField = (DataField)confMap.get("isolationLevel");
    if ((null != isolationLevelField) && (StringUtil.hasText(isolationLevelField.getValue()))) {
      isolationLevel = Integer.parseInt(isolationLevelField.getValue());
    }

    Trace.log("JDBC", 0, "getTransactionTemplate: {}|{}|{}", new Object[] { dataSource, transType, Integer.valueOf(isolationLevel) });
    if (!("5".equals(transType))) {
      TransactionTemplate transactionTemplate = TransactionTemplateUtils.getTransactionTemplate((PlatformTransactionManager)this.txManagerMap.get(dataSource), Integer.parseInt(transType), isolationLevel);

      result = ((Integer)transactionTemplate.execute(new TransactionCallback(this, context, confMap) {
        public Integer doInTransaction() {
          try {
            return Integer.valueOf(JDBCTransactionProxyAction.access$000(this.this$0).execute(this.val$context, this.val$confMap));
          } catch (RuntimeException e) {
            throw new BaseRuntimeException(e);
          } catch (BaseException e) {
            throw new BaseRuntimeException(e);
          } catch (Exception e) {
            throw new BaseRuntimeException(e);
          }
        }
      })).intValue();
    }
    else
    {
      result = this.proxyAction.execute(context, confMap);
    }

    return result;
  }

  public Map<String, PlatformTransactionManager> getTxManagerMap() {
    return this.txManagerMap;
  }

  public void setTxManagerMap(Map<String, PlatformTransactionManager> txManagerMap) {
    this.txManagerMap = txManagerMap;
  }

  public IAction getProxyAction() {
    return this.proxyAction;
  }

  public void setProxyAction(IAction proxyAction) {
    this.proxyAction = proxyAction;
  }
}