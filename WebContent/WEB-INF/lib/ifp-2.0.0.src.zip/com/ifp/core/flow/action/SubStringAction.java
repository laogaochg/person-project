package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import org.springframework.util.StringUtils;

public class SubStringAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try
    {
      String sourceStr = confMap.getElementValue("sourceName");
      if (!(StringUtils.hasText(sourceStr))) {
        throw new ActionException("截取字段名称不能为空！");
      }

      String outputField = confMap.getElementValue("outputField");
      if (!(StringUtils.hasText(outputField))) {
        throw new ActionException("输出字段名称不能为空！");
      }

      String startIndex = confMap.getElementValue("startIndex");
      if (!(StringUtils.hasText(startIndex))) {
        throw new ActionException("开始位置不能为空！");
      }

      String subLength = confMap.getElementValue("subLength");
      if (!(StringUtils.hasText(subLength))) {
        throw new ActionException("截取长度不能为空！");
      }

      if (!(StringUtil.hasText(dataMap.getElementValue(sourceStr))))
      {
        throw new ActionException("截取字段为空！");
      }

      int length = dataMap.getElementValue(sourceStr).length();

      if (length < Integer.parseInt(startIndex) + Integer.parseInt(subLength))
      {
        throw new ActionException("截取字段长度超出字段内容长度！");
      }
      dataMap.put(outputField, dataMap.getElementValue(sourceStr).substring(Integer.parseInt(startIndex) - 1, Integer.parseInt(startIndex) - 1 + Integer.parseInt(subLength)));
    }
    catch (BaseException e) {
      throw e;
    } catch (Exception e) {
      Trace.log("ACTION", 3, "执行字符截取组件异常！", e);
      throw new ActionException(e);
    }

    return 0;
  }
}