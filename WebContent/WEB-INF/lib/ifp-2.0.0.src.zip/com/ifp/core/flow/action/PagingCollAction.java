package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import org.springframework.util.StringUtils;

public class PagingCollAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try
    {
      String collName = confMap.getElementValue("collName");
      if (!(StringUtils.hasText(collName))) {
        throw new ActionException("集合名称不能为空！");
      }

      String outputCollName = confMap.getElementValue("outputCollName");
      if (!(StringUtils.hasText(outputCollName))) {
        throw new ActionException("输出集合名称不能为空！");
      }

      String pageNum = confMap.getElementValue("pageNum");
      if (!(StringUtils.hasText(pageNum))) {
        throw new ActionException("当前页数不能为空！");
      }

      String pageSize = confMap.getElementValue("pageSize");
      if (!(StringUtils.hasText(pageSize))) {
        throw new ActionException("每页记录不能为空！");
      }

      String screenKey = confMap.getElementValue("screenKey");
      String screenValue = confMap.getElementValue("screenValue");

      String[] fieldNames = screenKey.split(getFieldSeperatorRegex());
      String[] fieldValues = screenValue.split(getFieldSeperatorRegex());
      if (fieldNames.length != fieldValues.length)
        throw new ActionException("筛选条件的Key与值列表个数对不上");

      DataList list = (DataList)dataMap.get(collName);
      DataList dataList = list.clone();
      if ((StringUtil.hasText(screenKey)) && (StringUtil.hasText(screenValue)))
      {
        Trace.log("ACTION", 0, "筛选集合,筛选Key为{},筛选值为{}", new Object[] { screenKey, screenValue });
        for (int i = 0; i < dataList.size(); ++i) {
          DataMap tempDataMap = (DataMap)dataList.get(i);
          for (int j = 0; j < fieldNames.length; ++j)
          {
            if (fieldValues[j].startsWith("#"))
            {
              if ((StringUtil.hasText(dataMap.getElementValue(fieldValues[j].substring(1)))) && (!(dataMap.getElementValue(fieldValues[j].substring(1)).equals(tempDataMap.getElementValue(fieldNames[j])))))
              {
                dataList.remove(i);
                --i;
              }
            } else if (fieldValues[j].equals("*")) {
              if (!(StringUtil.hasText(tempDataMap.getElementValue(fieldNames[j]))))
              {
                dataList.remove(i);
                --i;
              }
            }
            else if (!(fieldValues[j].equals(tempDataMap.getElementValue(fieldNames[j]))))
            {
              dataList.remove(i);
              --i;
            }
          }
        }

      }

      int size = dataList.size();

      int startNum = (Integer.parseInt(dataMap.getElementValue(pageNum)) - 1) * Integer.parseInt(dataMap.getElementValue(pageSize));
      int endNum = startNum + Integer.parseInt(dataMap.getElementValue(pageSize));
      endNum = (endNum > size) ? size : endNum;
      DataList outDataList = new DataList();
      outDataList.setDefineMap(dataList.getDefineMap());
      for (int i = startNum; i < endNum; ++i)
      {
        outDataList.add(dataList.get(i));
      }

      dataMap.put(collName, outDataList);
    }
    catch (BaseException e) {
      Trace.log("ACTION", 3, "执行集合分页组件异常！", e);
      throw e;
    } catch (Exception e) {
      Trace.log("ACTION", 3, "执行集合分页组件异常！", e);
      throw new ActionException(e);
    }
    return 0;
  }
}