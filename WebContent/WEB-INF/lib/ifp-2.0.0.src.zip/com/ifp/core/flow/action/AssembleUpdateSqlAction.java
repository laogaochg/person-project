package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.jdbc.AbstractJDBCAction;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.util.List;

public class AssembleUpdateSqlAction extends AbstractJDBCAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try
    {
      String fieldNames = confMap.getElementValue("fieldNames");
      String fieldValues = confMap.getElementValue("fieldValues");
      String queryTables = confMap.getElementValue("queryTables");
      String queryCondition = confMap.getElementValue("queryCondition");
      String outputField = confMap.getElementValue("outputField");

      StringBuffer sql = new StringBuffer();
      sql.append("update ");
      sql.append(queryTables);
      sql.append(" set ");

      List fNameList = getFieldList(fieldNames);
      List fValueList = getFieldList(fieldValues);
      int count = 0;
      for (int i = 0; i < fNameList.size(); ++i)
      {
        String fieldName = (String)fNameList.get(i);
        String fieldValue = (String)fValueList.get(i);
        if (fieldValue.startsWith("#"))
        {
          Trace.log("ACTION", 0, "fieldName[{}]:{}", new Object[] { fieldValue, dataMap.getElementValue(fieldValue.substring(1)) });
          if (StringUtil.hasText(dataMap.getElementValue(fieldValue.substring(1))))
          {
            sql.append(fieldName);
            sql.append(" = ");
            sql.append(fieldValue);
            sql.append(",");
            ++count;
          }
        } else {
          sql.append(fieldName);
          sql.append(" = ");
          sql.append(fieldValue);
          sql.append(",");
          ++count;
        }
      }

      if (count == 0)
      {
        sql.append(" 1 = 1 ");
      }
      if (sql.toString().endsWith(","))
      {
        sql.deleteCharAt(sql.length() - 1);
      }
      sql.append(" where ");
      sql.append(queryCondition);

      dataMap.setElementValue(outputField, sql.toString());
    }
    catch (ActionException e) {
      Trace.log("ACTION", 3, "更新脚本语句拼装组件异常：", e);
      throw e;
    } catch (Exception e) {
      Trace.log("ACTION", 3, "更新脚本语句拼装组件异常：", e);
      throw new ActionException(e);
    }

    return 0;
  }
}