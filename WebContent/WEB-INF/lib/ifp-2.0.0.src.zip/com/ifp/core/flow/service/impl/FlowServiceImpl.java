package com.ifp.core.flow.service.impl;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.FlowHandle;
import com.ifp.core.flow.logic.BusinessLogic;
import com.ifp.core.flow.service.FlowService;
import com.ifp.core.flow.util.ContextMapChangeUtil;
import com.ifp.core.log.FlumeLogInf;
import com.ifp.core.log.IfpActionLoggerFactory;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.LogThread;
import com.ifp.core.log.RemoteCallInfo;
import com.ifp.core.log.Trace;
import com.ifp.core.monitor.Monitor;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.DateUtil;
import com.ifp.core.util.IpUtils;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class FlowServiceImpl
  implements FlowService
{
  private transient FlowHandle blFlowHandle;
  private BusinessLogic businessLogic;
  private transient MonitorManager monitorManager;

  public Map<String, Object> execute(Map<String, Object> dataMap)
    throws BaseException
  {
    long startTime = System.currentTimeMillis();
    Trace.log("RPC", 1, "start BL flow service, params：{}", new Object[] { dataMap });
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");

    Map blogicMap = new HashMap();
    setLogData(blogicMap, dataMap);

    String flumeReqIp = (String)dataMap.get("flumeReqIp");
    String flumeReqId = (String)dataMap.get("reqId");
    String flumePid = (String)dataMap.get("pcid");

    String flumeCid = IpUtils.getHostAddress() + logHandle.getAppName() + String.valueOf(System.currentTimeMillis()) + StringUtil.generateRandomString(7);
    String flumeSessionId = "";
    String flumeServiceId = this.businessLogic.getId();
    Monitor monitor = new Monitor();
    monitor.setLogicCode(flumeServiceId);
    monitor.setMonitorId(flumeCid);
    if (null == this.monitorManager)
      this.monitorManager = ((MonitorManager)SpringContextsUtil.getBean("monitorManager"));

    this.monitorManager.put(monitor);
    logHandle.setFlumeLogInf(flumeSessionId, flumeServiceId, flumeReqId, flumeCid, flumePid, flumeReqIp, Long.valueOf(startTime));
    logHandle.getFlumeLogInf().setType("DUBBO");
    RemoteCallInfo rc = new RemoteCallInfo(flumeReqId, flumeCid, flumePid, "RPCSERVER", Long.valueOf(startTime));
    logHandle.logFlumeRemote(rc);
    BlogicContext blogicContext = null;
    BaseException ex = null;
    try {
      Trace.log("RPC", 0, "远程调用，map转成blogicContext， map: {}", new Object[] { dataMap });
      blogicContext = new BlogicContext();

      ContextMapChangeUtil.doUpdateInputDataMap((Map)dataMap.get("dataMap"), blogicContext, this.businessLogic, false);

      blogicContext.setLogicCode(this.businessLogic.getId());
      blogicContext.setMonitorId(flumeCid);

      getBlFlowHandle().execute(this.businessLogic, blogicContext);

      dataMap = new HashMap();
      Map cLogicDataMap = new HashMap();
      ContextMapChangeUtil.doUpdateOutputDataMap(cLogicDataMap, this.businessLogic, blogicContext, false);
      dataMap.put("dataMap", cLogicDataMap);
      String errorCode = (String)cLogicDataMap.get("errorCode");
      if (!(StringUtil.hasText(errorCode)))
        errorCode = "0";

      String errorMsg = (String)cLogicDataMap.get("errorMsg");
      if (!(StringUtil.hasText(errorMsg)))
        errorMsg = "";

      dataMap.put("errorCode", errorCode);
      dataMap.put("errorMsg", errorMsg);

      Trace.log("RPC", 0, "远程调用完，blogicContext转成map，并返回 map: {}", new Object[] { dataMap });

      rc.setType("RPCCLIENT");
      rc.setMarkTime(Long.valueOf(System.currentTimeMillis()));
      logHandle.logFlumeRemote(rc);

      blogicMap.put("repText", dataMap.toString());
      blogicMap.put("cid", flumeCid);
      blogicMap.put("repTime", DateUtil.getStringToday());
      blogicContext.setTemp("blogicMap", blogicMap);

      IfpActionLoggerFactory.checkActionLogger(blogicContext, ex);
    }
    catch (BaseException e)
    {
    }
    catch (Exception e)
    {
    }
    finally
    {
      List flumeLogInfList;
      logHandle.logFlumeService();
      if (monitor != null)
        this.monitorManager.remove(monitor);

      List flumeLogInfList = logHandle.getLogThread().getFlumeLogInfList();
      if (flumeLogInfList.size() > 1) {
        flumeLogInfList.remove(flumeLogInfList.size() - 1);
        logHandle.getLogThread().setFlumeLogInfList(flumeLogInfList);
      }
      blogicMap.put("repText", dataMap.toString());
      blogicMap.put("cid", flumeCid);
      blogicMap.put("repTime", DateUtil.getStringToday());
      blogicContext.setTemp("blogicMap", blogicMap);

      IfpActionLoggerFactory.checkActionLogger(blogicContext, ex);
      Trace.log("RPC", 1, "complete BL flow service, time：{}ms", new Object[] { Long.valueOf(System.currentTimeMillis() - startTime) });
    }

    return dataMap;
  }

  public BlogicContext execute(BlogicContext blogicContext) throws BaseException {
    long startTime = System.currentTimeMillis();
    Trace.log("RPC", 1, "start BL flow service：{}", new Object[] { blogicContext.getLogicCode() });
    Trace.log("RPC", 0, "接收到的报文：{}", new Object[] { blogicContext.getDataMap() });
    try {
      blogicContext = (BlogicContext)blogicContext.clone();
      blogicContext.setLogicCode(this.businessLogic.getId());
    } catch (CloneNotSupportedException e1) {
      Trace.logInfo("RPC", "接收到远程调用的参数后，clone新的参数对像出错", e1);
    }

    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");

    DataMap dataMap = (DataMap)blogicContext.getDataMap();

    String flumeReqIp = dataMap.getElementValue("flumeReqIp");
    String flumeReqId = dataMap.getElementValue("reqId");
    String flumePid = dataMap.getElementValue("pcid");

    String flumeCid = IpUtils.getHostAddress() + logHandle.getAppName() + String.valueOf(System.currentTimeMillis()) + StringUtil.generateRandomString(7);
    String flumeSessionId = "";
    String flumeServiceId = this.businessLogic.getId();
    Monitor monitor = new Monitor();
    monitor.setLogicCode(flumeServiceId);
    monitor.setMonitorId(flumeCid);
    if (null == this.monitorManager)
      this.monitorManager = ((MonitorManager)SpringContextsUtil.getBean("monitorManager"));

    this.monitorManager.put(monitor);
    logHandle.setFlumeLogInf(flumeSessionId, flumeServiceId, flumeReqId, flumeCid, flumePid, flumeReqIp, Long.valueOf(startTime));
    logHandle.getFlumeLogInf().setType("DUBBO");
    RemoteCallInfo rc = new RemoteCallInfo(flumeReqId, flumeCid, flumePid, "RPCSERVER", Long.valueOf(startTime));
    logHandle.logFlumeRemote(rc);
    try
    {
      DataMap runDataMap = this.businessLogic.getDefaultDataMap().clone();
      ContextMapChangeUtil.copyDataMap((DataMap)blogicContext.getDataMap(), runDataMap, this.businessLogic.getInputParamsList());
      blogicContext.setDataMap(runDataMap);

      Trace.log("RPC", 0, "服务执行的dataMap：{}", new Object[] { runDataMap });
      getBlFlowHandle().execute(this.businessLogic, blogicContext);

      DataMap returnDataMap = this.businessLogic.getDefaultDataMap().clone();
      DataList outputParamsList = this.businessLogic.getOutputParamsList();
      List removeKeys = new ArrayList();
      for (Iterator i$ = returnDataMap.values().iterator(); i$.hasNext(); ) { DataElement returnElement = (DataElement)i$.next();
        boolean contains = false;
        for (Iterator i$ = outputParamsList.iterator(); i$.hasNext(); ) { DataElement optputElement = (DataElement)i$.next();
          if (returnElement.getName().equalsIgnoreCase(optputElement.getName())) {
            contains = true;
            break;
          }
        }
        if (!(contains))
          removeKeys.add(returnElement.getName());
      }
      for (i$ = removeKeys.iterator(); i$.hasNext(); ) { String removeKey = (String)i$.next();
        returnDataMap.remove(removeKey);
      }
      ContextMapChangeUtil.copyDataMap((DataMap)blogicContext.getDataMap(), returnDataMap, outputParamsList);
      blogicContext.setDataMap(returnDataMap);

      Trace.log("RPC", 0, "服务执行完的dataMap: {}", new Object[] { returnDataMap });

      rc.setType("RPCCLIENT");
      rc.setMarkTime(Long.valueOf(System.currentTimeMillis()));
      logHandle.logFlumeRemote(rc);
      logHandle.logFlumeService();
    }
    catch (BaseException e)
    {
    }
    catch (Exception e) {
    }
    finally {
      List flumeLogInfList;
      if (monitor != null)
        this.monitorManager.remove(monitor);

      List flumeLogInfList = logHandle.getLogThread().getFlumeLogInfList();
      if (flumeLogInfList.size() > 1) {
        flumeLogInfList.remove(flumeLogInfList.size() - 1);
        logHandle.getLogThread().setFlumeLogInfList(flumeLogInfList);
      }
      Trace.log("RPC", 1, "complete BL flow service, time：{}ms", new Object[] { Long.valueOf(System.currentTimeMillis() - startTime) });
    }
    return blogicContext;
  }

  private void setLogData(Map blogicMap, Map<String, Object> dataMap)
  {
    try
    {
      String flumeReqId = (dataMap.get("reqId") == null) ? "unDefine" : dataMap.get("reqId").toString();
      String flumePid = (dataMap.get("pcid") == null) ? "unDefine" : dataMap.get("pcid").toString();
      Object appId = this.businessLogic.getSystemConf().getConfByKey("appCode");
      appId = (appId == null) ? "unDefine" : appId.toString();
      Object channel = ((Map)dataMap.get("dataMap")).get("channel");
      channel = (channel == null) ? "unDefine" : channel.toString();
      Object transCode = ((Map)dataMap.get("dataMap")).get("transCode");
      transCode = (transCode == null) ? "unDefine" : transCode.toString();
      Object channelIP = ((Map)dataMap.get("dataMap")).get("channelIP");
      channelIP = (channelIP == null) ? "unDefine" : channelIP.toString();
      blogicMap.put("reqId", flumeReqId);
      blogicMap.put("pcid", flumePid);
      blogicMap.put("reqTime", DateUtil.getStringToday());
      blogicMap.put("svrTranscode", "");
      blogicMap.put("reqText", blogicMap.toString());
      blogicMap.put("appId", appId);
      blogicMap.put("channel", channel);
      blogicMap.put("transCode", transCode);
      blogicMap.put("channelIP", channelIP);
    } catch (Exception e) {
      Trace.log("RPC", 3, "初始化记录dubbo服务访问日志参数异常：", e);
    }
  }

  public BusinessLogic getBusinessLogic() {
    return this.businessLogic;
  }

  public void setBusinessLogic(BusinessLogic businessLogic) {
    this.businessLogic = businessLogic;
  }

  public FlowHandle getBlFlowHandle() {
    if (null == this.blFlowHandle)
      this.blFlowHandle = ((FlowHandle)SpringContextsUtil.getBean("blFlowHandle"));

    return this.blFlowHandle;
  }

  public void setBlFlowHandle(FlowHandle blFlowHandle) {
    this.blFlowHandle = blFlowHandle;
  }
}