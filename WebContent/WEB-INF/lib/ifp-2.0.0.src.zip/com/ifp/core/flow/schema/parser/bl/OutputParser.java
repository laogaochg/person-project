package com.ifp.core.flow.schema.parser.bl;

import com.ifp.core.data.DataList;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedList;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class OutputParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    List list;
    try
    {
      list = parseDataListElement(element, parserContext, builder);

      if (list.size() > 0)
      {
        builder.addConstructorArgValue(list);
      }
    } catch (Exception e) {
      parserContext.getReaderContext().error("class " + OutputParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<DataList> getBeanClass(Element element)
  {
    return DataList.class;
  }

  private List<BeanDefinition> parseDataListElement(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List propertyList = DomUtils.getChildElementsByTagName(element, "outField");
    ManagedList list = new ManagedList(propertyList.size());
    list.setMergeEnabled(true);
    list.setSource(parserContext.getReaderContext().extractSource(element));

    for (Iterator i$ = propertyList.iterator(); i$.hasNext(); ) { Element propertyElement = (Element)i$.next();
      list.add(parserContext.getDelegate().parseCustomElement(propertyElement, builder.getRawBeanDefinition()));
    }

    return list;
  }
}