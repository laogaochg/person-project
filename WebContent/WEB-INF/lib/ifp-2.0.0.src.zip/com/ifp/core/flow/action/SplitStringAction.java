package com.ifp.core.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import org.springframework.util.StringUtils;

public class SplitStringAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    String[] values;
    DataMap dataMap = (DataMap)context.getDataMap();

    String sourceStr = confMap.getElementValue("sourceName");
    if (!(StringUtils.hasText(sourceStr))) {
      throw new ActionException("来源字段名称不能为空！");
    }

    String outputList = confMap.getElementValue("outputList");
    String outputField = confMap.getElementValue("outputField");
    if (!(StringUtils.hasText(outputList)))
      throw new ActionException("目标数据集合列表名称不能为空！");

    if (!(StringUtils.hasText(outputField)))
      throw new ActionException("目标数据集合字段不能为空！");

    DataList dataList = (DataList)dataMap.get(outputList);
    String splitStr = confMap.getElementValue("splitStr");
    String value = "";
    if (sourceStr.startsWith("#"))
    {
      value = dataMap.getElementValue(sourceStr.substring(1));
    }

    if (StringUtils.hasText(splitStr)) {
      values = value.split(splitStr);
    } else {
      String[] valuesTemp = value.split("");
      values = new String[valuesTemp.length - 1];
      System.arraycopy(valuesTemp, 1, values, 0, valuesTemp.length - 1);
    }
    if ((values != null) && (values.length > 0))
    {
      String[] arr$ = values; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String str = arr$[i$];

        DataMap map = dataList.createSubDataMap();
        map.put(outputField, new DataField(outputField, str));
        dataList.add(map);
      }
    }
    return 0;
  }
}