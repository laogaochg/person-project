package com.ifp.core.flow.schema.parser.bl;

import com.ifp.core.flow.logic.BusinessLogic;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedMap;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class BusinessLogicParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    try
    {
      builder.addPropertyValue("id", element.getAttribute("id"));
      builder.addPropertyValue("commonFlag", Boolean.valueOf(element.getAttribute("common")));
      builder.addPropertyValue("name", element.getAttribute("name"));

      builder.addPropertyValue("dataDictionary", parseElement("dataDictionary", element, parserContext, builder));
      builder.addPropertyValue("inputParamsList", parseElement("input", element, parserContext, builder));
      builder.addPropertyValue("outputParamsList", parseElement("output", element, parserContext, builder));
      builder.addPropertyValue("flow", parseElement("flow", element, parserContext, builder));
      builder.addPropertyValue("subFlow", parseMapMulElement("subFlow", element, parserContext, builder));

      builder.addPropertyReference("systemConf", "systemConf");
      builder.setInitMethodName("init");
    } catch (Exception e) {
      parserContext.getReaderContext().error("class " + BusinessLogicParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<BusinessLogic> getBeanClass(Element element)
  {
    return BusinessLogic.class;
  }

  private BeanDefinition parseElement(String tagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List inputList = DomUtils.getChildElementsByTagName(element, tagName);
    Element inputElement = (Element)inputList.get(0);
    BeanDefinition beanDefinition = parserContext.getDelegate().parseCustomElement(inputElement, builder.getRawBeanDefinition());
    return beanDefinition;
  }

  private Map<String, BeanDefinition> parseMapMulElement(String tagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List flowList = DomUtils.getChildElementsByTagName(element, tagName);
    ManagedMap flowMap = new ManagedMap(flowList.size());
    flowMap.setMergeEnabled(true);
    flowMap.setSource(parserContext.getReaderContext().extractSource(element));
    for (Iterator i$ = flowList.iterator(); i$.hasNext(); ) { Element flowElement = (Element)i$.next();
      BeanDefinition beanDefinition = parserContext.getDelegate().parseCustomElement(flowElement, builder.getRawBeanDefinition());
      String id = flowElement.getAttribute("id");
      flowMap.put(id, beanDefinition);
    }

    return flowMap;
  }
}