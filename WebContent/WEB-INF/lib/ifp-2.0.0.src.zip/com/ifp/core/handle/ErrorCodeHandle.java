package com.ifp.core.handle;

import com.ifp.core.data.ErrorElement;
import com.ifp.core.errorcode.ErrorCodeFactory;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ErrorCodeHandle
{
  private Pattern pattern = Pattern.compile("\\{[A-Za-z0-9_.]+\\}");
  private ErrorCodeFactory errorCodeFactory;
  private boolean useDefaultMsg = true;
  private String defaultErrorCode = "0";
  private String defaultErrorMsg = "";

  public void init()
  {
    this.errorCodeFactory.init();
  }

  public void fillErrorCodeAndMsg(String errorCode, String errorMsg, Map<String, Object> dataMap, Map<String, Object> targetMap)
  {
    String showErrorCode = errorCode;
    String showErrorMsg = "";

    ErrorElement errorElement = this.errorCodeFactory.getErrorElement(errorCode, errorMsg);
    if (null != errorElement) {
      showErrorCode = errorElement.getShowErrorCode();
      showErrorMsg = errorElement.getErrorMsg();
    }

    if (this.useDefaultMsg) {
      if (StringUtil.hasText(errorMsg))
        showErrorMsg = errorMsg;

    }
    else if (!(StringUtil.hasText(showErrorMsg))) {
      showErrorMsg = errorMsg;
    }

    targetMap.put("errorCode", (!(StringUtil.hasText(showErrorCode))) ? this.defaultErrorCode : showErrorCode);
    showErrorMsg = changeErrorMsg(showErrorMsg, dataMap);
    targetMap.put("errorMsg", (!(StringUtil.hasText(showErrorMsg))) ? this.defaultErrorMsg : showErrorMsg);
  }

  public String changeErrorMsg(String errorMsg, Map<String, Object> dataMap)
  {
    if (StringUtil.hasText(errorMsg)) {
      if (errorMsg.indexOf("{") < 0)
        return errorMsg;

      StringBuffer errorMsgBuf = new StringBuffer();
      Matcher matcher = this.pattern.matcher(errorMsg);
      int c_idx = 0;
      while (matcher.find()) {
        int s_idx = matcher.start(0);
        int e_idx = matcher.end(0);
        String key = errorMsg.substring(s_idx + 1, e_idx - 1);
        Object value = null;
        int idx = key.indexOf(".");
        if (idx < 0)
          value = dataMap.get(key);
        else if (idx == 4) {
          if (key.toLowerCase().startsWith("head."))
            value = ((Map)dataMap.get("header")).get(key);
          else if (key.toLowerCase().startsWith("body."))
            value = ((Map)dataMap.get("body")).get(key);

        }

        errorMsgBuf.append(errorMsg.substring(c_idx, s_idx)).append((null == value) ? "" : value.toString());
        c_idx = e_idx;
      }

      if (c_idx < errorMsg.length() - 1) {
        errorMsgBuf.append(errorMsg.substring(c_idx));
      }

      return errorMsgBuf.toString();
    }

    return "";
  }

  public String getErrorMsg(String errorCode)
  {
    try
    {
      return this.errorCodeFactory.getErrorMsg(errorCode);
    } catch (Exception e) {
      Trace.log("CORE", 2, "getErrorMsg Error:{}", e); }
    return "";
  }

  public String getShowErrorCode(String errorCode)
  {
    try
    {
      return this.errorCodeFactory.getShowErrorCode(errorCode);
    } catch (Exception e) {
      Trace.log("CORE", 2, "getErrorMsg Error:{}", e); }
    return errorCode;
  }

  public ErrorCodeFactory getErrorCodeFactory()
  {
    return this.errorCodeFactory;
  }

  public void setErrorCodeFactory(ErrorCodeFactory errorCodeFactory) {
    this.errorCodeFactory = errorCodeFactory;
  }

  public boolean isUseDefaultMsg() {
    return this.useDefaultMsg;
  }

  public void setUseDefaultMsg(boolean useDefaultMsg) {
    this.useDefaultMsg = useDefaultMsg;
  }
}