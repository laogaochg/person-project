package com.ifp.core.handle;

import com.ifp.core.base.SystemConf;
import com.ifp.core.util.SpringContextsUtil;

public class SystemConfHandle
{
  private static SystemConf systemConf;

  public static SystemConf getSystemConf()
  {
    if (null == systemConf)
      systemConf = (SystemConf)SpringContextsUtil.getBean("systemConf");

    return systemConf;
  }

  public static Object getConfByKey(String key)
  {
    return getSystemConf().getConfByKey(key);
  }
}