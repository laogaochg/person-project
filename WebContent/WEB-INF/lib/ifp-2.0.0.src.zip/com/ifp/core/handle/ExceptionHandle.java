package com.ifp.core.handle;

import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.BaseRuntimeException;

public class ExceptionHandle
{
  public static BaseException handleBaseException(BaseException e)
  {
    BaseException ex = e;
    do {
      if ((ex.getCause() == null) || ((!(ex.getCause() instanceof BaseException)) && (!(ex.getCause() instanceof BaseRuntimeException))))
        break;
      if (ex.getCause() instanceof BaseRuntimeException)
      {
        ex = handleBaseRuntimeException((BaseRuntimeException)ex.getCause());
      }
      else ex = (BaseException)ex.getCause();

      if (!(ex.getCause() instanceof BaseException)) break;  }
    while (ex != ex.getCause());

    return ex;
  }

  public static BaseException handleBaseRuntimeException(BaseRuntimeException e)
  {
    BaseRuntimeException erx = e;
    do { if ((erx.getCause() == null) || (!(erx.getCause() instanceof BaseRuntimeException)))
        break;
      erx = (BaseRuntimeException)erx.getCause();
      if (!(erx.getCause() instanceof BaseRuntimeException)) break;  }
    while (erx != erx.getCause());

    if (erx.getCause() instanceof BaseException)
    {
      return ((BaseException)erx.getCause());
    }
    return new BaseException(erx.getCause());
  }
}