package com.ifp.core.encrypt.rsa;

import com.ifp.core.log.Trace;
import java.io.PrintStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.HashMap;
import javax.crypto.Cipher;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class RSAUtils
{
  public static HashMap<String, Object> getKeys()
    throws NoSuchAlgorithmException
  {
    HashMap map = new HashMap();
    KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
    keyPairGen.initialize(1024);
    KeyPair keyPair = keyPairGen.generateKeyPair();
    RSAPublicKey publicKey = (RSAPublicKey)keyPair.getPublic();
    RSAPrivateKey privateKey = (RSAPrivateKey)keyPair.getPrivate();
    map.put("public", publicKey);
    map.put("private", privateKey);
    return map;
  }

  public static RSAPublicKey getPublicKey(String modulus, String exponent)
  {
    BigInteger b1;
    try
    {
      b1 = new BigInteger(modulus);
      BigInteger b2 = new BigInteger(exponent);
      KeyFactory keyFactory = KeyFactory.getInstance("RSA");
      RSAPublicKeySpec keySpec = new RSAPublicKeySpec(b1, b2);
      return ((RSAPublicKey)keyFactory.generatePublic(keySpec));
    } catch (Exception e) {
      Trace.log("CORE", 3, "getPublicKey Error:", e); }
    return null;
  }

  public static RSAPrivateKey getPrivateKey(String modulus, String exponent)
  {
    BigInteger b1;
    try
    {
      b1 = new BigInteger(modulus);
      BigInteger b2 = new BigInteger(exponent);
      KeyFactory keyFactory = KeyFactory.getInstance("RSA");
      RSAPrivateKeySpec keySpec = new RSAPrivateKeySpec(b1, b2);
      return ((RSAPrivateKey)keyFactory.generatePrivate(keySpec));
    } catch (Exception e) {
      Trace.log("CORE", 3, "getPrivateKey Error:", e); }
    return null;
  }

  public static String encryptByPublicKey(String data, RSAPublicKey publicKey)
    throws Exception
  {
    Cipher cipher = Cipher.getInstance("RSA");
    cipher.init(1, publicKey);

    int key_len = publicKey.getModulus().bitLength() / 8;

    String[] datas = splitString(data, key_len - 11);
    String mi = "";

    String[] arr$ = datas; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String s = arr$[i$];
      mi = mi + bcd2Str(cipher.doFinal(s.getBytes()));
    }
    return mi;
  }

  public static String encryptByPublicKey(String data, String modulus, String public_exponent)
    throws Exception
  {
    RSAPublicKey publicKey = getPublicKey(modulus, public_exponent);
    Cipher cipher = Cipher.getInstance("RSA");
    cipher.init(1, publicKey);

    int key_len = publicKey.getModulus().bitLength() / 8;

    String[] datas = splitString(data, key_len - 11);
    String mi = "";

    String[] arr$ = datas; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String s = arr$[i$];
      mi = mi + bcd2Str(cipher.doFinal(s.getBytes()));
    }
    return mi;
  }

  public static String encryptByPublicKeyBASE64(String data, String modulus, String public_exponent) throws Exception
  {
    RSAPublicKey publicKey = getPublicKey(modulus, public_exponent);
    data = new String(encryptBASE64(data.getBytes()));
    Cipher cipher = Cipher.getInstance("RSA");
    cipher.init(1, publicKey);

    int key_len = publicKey.getModulus().bitLength() / 8;

    String[] datas = splitString(data, key_len - 11);
    String mi = "";

    String[] arr$ = datas; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String s = arr$[i$];
      mi = mi + bcd2Str(cipher.doFinal(s.getBytes()));
    }
    return mi;
  }

  public static String decryptByPrivateKey(String data, RSAPrivateKey privateKey)
    throws Exception
  {
    Cipher cipher = Cipher.getInstance("RSA");
    cipher.init(2, privateKey);

    int key_len = privateKey.getModulus().bitLength() / 8;
    byte[] bytes = data.getBytes();
    byte[] bcd = ASCII_To_BCD(bytes, bytes.length);

    String ming = "";
    byte[][] arrays = splitArray(bcd, key_len);
    byte[][] arr$ = arrays; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { byte[] arr = arr$[i$];
      ming = ming + new String(cipher.doFinal(arr));
    }
    return ming;
  }

  public static String decryptByPrivateKey(String data, String modulus, String private_exponent)
    throws Exception
  {
    RSAPrivateKey privateKey = getPrivateKey(modulus, private_exponent);
    Cipher cipher = Cipher.getInstance("RSA");
    cipher.init(2, privateKey);

    int key_len = privateKey.getModulus().bitLength() / 8;
    byte[] bytes = data.getBytes();
    byte[] bcd = ASCII_To_BCD(bytes, bytes.length);

    String ming = "";
    byte[][] arrays = splitArray(bcd, key_len);
    byte[][] arr$ = arrays; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { byte[] arr = arr$[i$];
      ming = ming + new String(cipher.doFinal(arr));
    }
    return ming;
  }

  public static String decryptByPrivateKeyBASE64(String data, String modulus, String private_exponent)
    throws Exception
  {
    RSAPrivateKey privateKey = getPrivateKey(modulus, private_exponent);
    Cipher cipher = Cipher.getInstance("RSA");
    cipher.init(2, privateKey);

    int key_len = privateKey.getModulus().bitLength() / 8;
    byte[] bytes = data.getBytes();
    byte[] bcd = ASCII_To_BCD(bytes, bytes.length);

    String ming = "";
    byte[][] arrays = splitArray(bcd, key_len);
    byte[][] arr$ = arrays; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { byte[] arr = arr$[i$];
      ming = ming + new String(cipher.doFinal(arr));
    }
    return new String(decryptBASE64(ming));
  }

  public static byte[] ASCII_To_BCD(byte[] ascii, int asc_len)
  {
    byte[] bcd = new byte[asc_len / 2];
    int j = 0;
    for (int i = 0; i < (asc_len + 1) / 2; ++i) {
      bcd[i] = asc_to_bcd(ascii[(j++)]);
      bcd[i] = (byte)(((j >= asc_len) ? 0 : asc_to_bcd(ascii[(j++)])) + (bcd[i] << 4));
    }
    return bcd;
  }

  public static byte asc_to_bcd(byte asc)
  {
    byte bcd;
    if ((asc >= 48) && (asc <= 57))
      bcd = (byte)(asc - 48);
    else if ((asc >= 65) && (asc <= 70))
      bcd = (byte)(asc - 65 + 10);
    else if ((asc >= 97) && (asc <= 102))
      bcd = (byte)(asc - 97 + 10);
    else
      bcd = (byte)(asc - 48);
    return bcd;
  }

  public static String bcd2Str(byte[] bytes)
  {
    char[] temp = new char[bytes.length * 2];

    for (int i = 0; i < bytes.length; ++i) {
      char val = (char)((bytes[i] & 0xF0) >> 4 & 0xF);
      temp[(i * 2)] = (char)((val > '\t') ? val + 'A' - 10 : val + '0');

      val = (char)(bytes[i] & 0xF);
      temp[(i * 2 + 1)] = (char)((val > '\t') ? val + 'A' - 10 : val + '0');
    }
    return new String(temp);
  }

  public static String[] splitString(String string, int len)
  {
    int x = string.length() / len;
    int y = string.length() % len;
    int z = 0;
    if (y != 0)
      z = 1;

    String[] strings = new String[x + z];
    String str = "";
    for (int i = 0; i < x + z; ++i) {
      if ((i == x + z - 1) && (y != 0))
        str = string.substring(i * len, i * len + y);
      else
        str = string.substring(i * len, i * len + len);

      strings[i] = str;
    }
    return strings;
  }

  public static byte[][] splitArray(byte[] data, int len)
  {
    int x = data.length / len;
    int y = data.length % len;
    int z = 0;
    if (y != 0)
      z = 1;

    byte[][] arrays = new byte[x + z][];

    for (int i = 0; i < x + z; ++i) {
      byte[] arr = new byte[len];
      if ((i == x + z - 1) && (y != 0))
        System.arraycopy(data, i * len, arr, 0, y);
      else
        System.arraycopy(data, i * len, arr, 0, len);

      arrays[i] = arr;
    }
    return arrays;
  }

  public static byte[] decryptBASE64(String key) throws Exception {
    return new BASE64Decoder().decodeBuffer(key);
  }

  public static String encryptBASE64(byte[] key) throws Exception {
    return new BASE64Encoder().encodeBuffer(key);
  }

  public static void main(String[] args) throws Exception
  {
    HashMap map = getKeys();

    RSAPublicKey publicKey = (RSAPublicKey)map.get("public");
    RSAPrivateKey privateKey = (RSAPrivateKey)map.get("private");

    String modulus = publicKey.getModulus().toString();

    String public_exponent = publicKey.getPublicExponent().toString();

    String private_exponent = privateKey.getPrivateExponent().toString();

    String ming = "main.html#financialService/appDownload/appDownload?openId:'testss',iCIFID:'111',eCIFID:'111111',timestamp:'1461060782173'";

    RSAPublicKey pubKey = getPublicKey("95270526752824812960962665766716618211541383853458282151556620829168454353494856363916027475810909692511406521859915826457758134769565144699289105667852604046212374064854054213476721749929577081951771804326543621821911516045793918842619153262400635412409149254130938331848407353454732061557372476029049466783", "65537");
    RSAPrivateKey priKey = getPrivateKey(modulus, private_exponent);
    System.out.println(pubKey);
    System.out.println(priKey);

    String mi = encryptByPublicKeyBASE64(ming, "95270526752824812960962665766716618211541383853458282151556620829168454353494856363916027475810909692511406521859915826457758134769565144699289105667852604046212374064854054213476721749929577081951771804326543621821911516045793918842619153262400635412409149254130938331848407353454732061557372476029049466783", "65537");
    System.err.println(mi);

    ming = decryptByPrivateKey(mi, priKey);
    System.err.println(ming);
  }
}