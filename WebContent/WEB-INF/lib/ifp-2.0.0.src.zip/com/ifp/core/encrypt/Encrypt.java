package com.ifp.core.encrypt;

public abstract interface Encrypt
{
  public abstract String getEncryptKey();

  public abstract String getEncryptString(String paramString1, String paramString2);
}