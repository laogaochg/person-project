package com.ifp.core.context;

import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SerializeUtils;
import java.io.Serializable;

public abstract class Context<T>
  implements IContext<T>, Serializable, Cloneable
{
  public String logicCode;
  public String logicPath;
  public String createTime;
  public String monitorId;
  public T dataMap;

  public String getLogicCode()
  {
    return this.logicCode;
  }

  public void setLogicCode(String logicCode) {
    this.logicCode = logicCode;
  }

  public String getLogicPath() {
    return this.logicPath;
  }

  public void setLogicPath(String logicPath) {
    this.logicPath = logicPath;
  }

  public String getCreateTime() {
    return this.createTime;
  }

  public void setCreateTime(String createTime) {
    this.createTime = createTime;
  }

  public T getDataMap() {
    return this.dataMap;
  }

  public void setDataMap(T dataMap) {
    this.dataMap = dataMap; }

  public String getMonitorId() {
    return this.monitorId;
  }

  public void setMonitorId(String monitorId) {
    this.monitorId = monitorId;
  }

  public Object clone() throws CloneNotSupportedException {
    String objStr;
    try {
      objStr = SerializeUtils.serialize(this);
      return SerializeUtils.unSerialize(objStr);
    } catch (BaseException e) {
      Trace.log("CORE", 3, "ClogicContext clone Error!", e);
    }
    return ((ClogicContext)super.clone());
  }
}