package com.ifp.core.context;

import com.ifp.core.data.DataMap;
import java.util.HashMap;
import java.util.Map;

public class BlogicContext extends Context<DataMap>
{
  public Map<String, Object> tempMap;
  private String lastExceLogic;

  public BlogicContext()
  {
    this.tempMap = new HashMap();
  }

  public Object getTemp(String key)
  {
    return this.tempMap.get(key);
  }

  public void setTemp(String key, Object object) {
    this.tempMap.put(key, object);
  }

  public void removeTemp(String key) {
    this.tempMap.remove(key);
  }

  public Map<String, Object> getTempMap() {
    return this.tempMap;
  }

  public void setTempMap(Map<String, Object> tempMap) {
    this.tempMap = tempMap;
  }

  public String getLastExceLogic() {
    return this.lastExceLogic;
  }

  public void setLastExceLogic(String lastExceLogic) {
    this.lastExceLogic = lastExceLogic;
  }
}