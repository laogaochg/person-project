package com.ifp.core.context;

public abstract interface IContext<T>
{
  public abstract String getLogicCode();

  public abstract void setLogicCode(String paramString);

  public abstract String getLogicPath();

  public abstract void setLogicPath(String paramString);

  public abstract String getCreateTime();

  public abstract void setCreateTime(String paramString);

  public abstract T getDataMap();

  public abstract void setDataMap(T paramT);

  public abstract String getMonitorId();

  public abstract void setMonitorId(String paramString);
}