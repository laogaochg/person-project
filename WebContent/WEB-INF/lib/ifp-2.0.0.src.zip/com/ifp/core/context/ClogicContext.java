package com.ifp.core.context;

import java.util.HashMap;
import java.util.Map;

public class ClogicContext extends Context<Map<String, Object>>
{
  public String transCode;
  public String securityType;
  public String sessionName;
  public String viewName;
  public String requestType;
  public Map<String, Object> tempMap;

  public ClogicContext()
  {
    this.tempMap = new HashMap(); }

  public String getTransCode() {
    return this.transCode;
  }

  public void setTransCode(String transCode) {
    this.transCode = transCode;
  }

  public String getSessionName() {
    return this.sessionName;
  }

  public void setSessionName(String sessionName) {
    this.sessionName = sessionName;
  }

  public String getViewName() {
    return this.viewName;
  }

  public void setViewName(String viewName) {
    this.viewName = viewName;
  }

  public String getRequestType() {
    return this.requestType;
  }

  public void setRequestType(String requestType) {
    this.requestType = requestType;
  }

  public void setValue(String key, Object value)
  {
    if (this.dataMap != null)
    {
      ((Map)this.dataMap).put(key, value);
    }
  }

  public Object getValue(String key)
  {
    if (this.dataMap != null)
    {
      return ((Map)this.dataMap).get(key);
    }
    return null;
  }

  public Map<String, Object> getTempMap() {
    return this.tempMap;
  }

  public void setTempMap(Map<String, Object> tempMap) {
    this.tempMap = tempMap;
  }

  public String getSecurityType() {
    return this.securityType;
  }

  public void setSecurityType(String securityType) {
    this.securityType = securityType;
  }
}