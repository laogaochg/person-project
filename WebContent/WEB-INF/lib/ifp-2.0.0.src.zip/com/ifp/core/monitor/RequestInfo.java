package com.ifp.core.monitor;

public class RequestInfo
{
  public String cId;
  public String sessionId;
  public long startTime;

  public RequestInfo(String cId)
  {
    this.cId = cId;
  }

  public RequestInfo(String cId, long startTime)
  {
    this.cId = cId;
    this.startTime = startTime;
  }

  public RequestInfo(String cId, long startTime, String sessionId) {
    this.cId = cId;
    this.startTime = startTime;
    this.sessionId = sessionId;
  }

  public String getCId() {
    return this.cId;
  }

  public void setCId(String cId) {
    this.cId = cId;
  }

  public long getStartTime() {
    return this.startTime;
  }

  public void setStartTime(long startTime) {
    this.startTime = startTime;
  }

  public String getSessionId() {
    return this.sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }
}