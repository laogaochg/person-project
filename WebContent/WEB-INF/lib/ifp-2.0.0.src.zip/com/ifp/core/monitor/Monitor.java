package com.ifp.core.monitor;

public class Monitor
{
  public String monitorId;
  public long createTime;
  public String currentMonitorStep;
  public long startStepTime;
  public String currentOperationName;
  public long startOperationTime;
  public String logicCode;
  public String sessionId;

  public Monitor()
  {
    this.createTime = System.currentTimeMillis();
    this.startStepTime = this.createTime;
  }

  public Monitor(String monitorId, String currentMonitorStep)
  {
    this.monitorId = monitorId;
    this.createTime = System.currentTimeMillis();
    this.startStepTime = this.createTime;
    this.currentMonitorStep = currentMonitorStep;
  }

  public String getMonitorId() {
    return this.monitorId; }

  public void setMonitorId(String monitorId) {
    this.monitorId = monitorId; }

  public long getCreateTime() {
    return this.createTime; }

  public void setCreateTime(long createTime) {
    this.createTime = createTime; }

  public String getCurrentMonitorStep() {
    return this.currentMonitorStep; }

  public void setCurrentMonitorStep(String currentMonitorStep) {
    if (!(currentMonitorStep.equals(this.currentMonitorStep)))
      setStartStepTime(System.currentTimeMillis());
    this.currentMonitorStep = currentMonitorStep; }

  public long getStartStepTime() {
    return this.startStepTime; }

  public void setStartStepTime(long startStepTime) {
    this.startStepTime = startStepTime;
  }

  public String getCurrentOperationName() {
    return this.currentOperationName;
  }

  public void setCurrentOperationName(String currentOperationName) {
    setStartOperationTime(System.currentTimeMillis());
    this.currentOperationName = currentOperationName;
  }

  public long getStartOperationTime() {
    return this.startOperationTime;
  }

  public void setStartOperationTime(long startOperationTime) {
    this.startOperationTime = startOperationTime;
  }

  public String getLogicCode() {
    return this.logicCode;
  }

  public void setLogicCode(String logicCode) {
    this.logicCode = logicCode;
  }

  public String getSessionId() {
    return this.sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  public String toString()
  {
    return "MonitorId:" + getMonitorId() + ",createTime:" + getCreateTime() + ",LogicCode:" + getLogicCode();
  }
}