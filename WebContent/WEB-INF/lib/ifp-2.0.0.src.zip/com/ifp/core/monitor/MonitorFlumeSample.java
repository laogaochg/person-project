package com.ifp.core.monitor;

public class MonitorFlumeSample
{
  private Long maxDuration;
  private String formattedStr;

  public MonitorFlumeSample()
  {
    this.maxDuration = Long.valueOf(-3763399874041610240L);

    this.formattedStr = "|0|0|0|0||0||0##"; }

  public Long getMaxDuration() { return this.maxDuration; }

  public void setMaxDuration(Long maxDuration) {
    this.maxDuration = maxDuration; }

  public String getFormattedStr() {
    return this.formattedStr; }

  public void setFormattedStr(String formattedStr) {
    this.formattedStr = formattedStr;
  }
}