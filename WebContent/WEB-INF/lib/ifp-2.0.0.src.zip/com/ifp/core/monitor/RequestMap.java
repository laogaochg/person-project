package com.ifp.core.monitor;

import java.util.HashMap;
import java.util.Map;

public class RequestMap
{
  public Map<String, RequestInfo> startTimeMap;

  public RequestMap()
  {
    this.startTimeMap = new HashMap();
  }

  public RequestMap(RequestInfo requestInfo)
  {
    this.startTimeMap = new HashMap();
    add(requestInfo);
  }

  public Map<String, RequestInfo> getStartTimeMap() {
    return this.startTimeMap;
  }

  public void setStartTimeMap(Map<String, RequestInfo> startTimeMap) {
    this.startTimeMap = startTimeMap;
  }

  public void add(RequestInfo requestInfo)
  {
    if ((requestInfo != null) && (this.startTimeMap != null))
      this.startTimeMap.put(requestInfo.getCId(), requestInfo);
  }

  public int size()
  {
    if (this.startTimeMap != null)
      return this.startTimeMap.size();
    return 0;
  }
}