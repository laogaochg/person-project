package com.ifp.core.monitor;

import java.util.List;

public class ChildMonitorList<Monitor>
{
  public List<Monitor> childMonitorList;
}