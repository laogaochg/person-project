package com.ifp.core.monitor;

import com.ifp.core.log.Trace;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

public class MonitorManager
{
  private int totalRequest;
  private List<RequestInfo> totalRequestList;
  private Map<String, RequestMap> sessionRequestMap;
  private Map<String, RequestMap> totalServiceRequestMap;
  private Map<String, RequestMap> totalActionRequestMap;
  private Map<String, Monitor> monitorMap;
  private AtomicReference atomicReference;
  private long timeOut;

  public MonitorManager()
  {
    this.monitorMap = new ConcurrentHashMap();

    this.atomicReference = new AtomicReference();

    this.timeOut = 5000L; }

  public Map<String, Monitor> getMonitorMap() {
    return this.monitorMap;
  }

  public Monitor getMonitor(String monitorId)
  {
    if (null == monitorId) {
      Trace.log("MONITOR", 2, "the monitorId can not be null when getMonitor, so return null.");
      return null;
    }
    Trace.log("MONITOR", 2, "the monitorId {} was exist.", new Object[] { monitorId });
    return ((Monitor)getMonitorMap().get(monitorId));
  }

  public void setMonitorMap(Map<String, Monitor> monitorMap) {
    this.monitorMap = monitorMap;
  }

  public void put(Monitor monitor)
  {
    if (monitor.getMonitorId() != null)
      this.monitorMap.put(monitor.getMonitorId(), monitor);
  }

  public void remove(Monitor monitor)
  {
    if ((monitor != null) && (monitor.getMonitorId() != null) && (this.monitorMap.get(monitor.getMonitorId()) != null))
    {
      this.monitorMap.remove(monitor.getMonitorId());
      if (this.monitorMap.get(monitor.getMonitorId()) != null)
      {
        Trace.log("MONITOR", 2, "monitor can't be remove: {}", new Object[] { monitor.toString() });
      }
    } else {
      Trace.log("MONITOR", 2, "request'monitor is null: {}", new Object[] { monitor.toString() });
    }
  }

  public void clearAll()
  {
    if (this.monitorMap != null)
      this.monitorMap.clear();
    if (this.totalRequestList != null)
      this.totalRequestList.clear();
    if (this.totalActionRequestMap != null)
      this.totalActionRequestMap.clear();
    if (this.totalActionRequestMap != null)
      this.totalActionRequestMap.clear();
    if (this.sessionRequestMap != null)
      this.sessionRequestMap.clear();
  }

  public void checkRequest()
  {
    if (this.monitorMap != null)
    {
      long currentTime = System.currentTimeMillis();
      for (Iterator i$ = this.monitorMap.values().iterator(); i$.hasNext(); ) { Monitor monitor = (Monitor)i$.next();

        if (currentTime - this.timeOut > monitor.getCreateTime())
        {
          Trace.log("MONITOR", 2, "the request[service:{},CID:{}] is timeOut,release the Context now...", new Object[] { monitor.getLogicCode(), monitor.getMonitorId() });
          remove(monitor);
        }
      }
    }
  }

  public long countRequest()
  {
    Trace.log("MONITOR", 1, "monitor监控器开始获取切面数据");
    this.totalServiceRequestMap = new HashMap();
    this.totalActionRequestMap = new HashMap();
    this.sessionRequestMap = new HashMap();
    this.totalRequestList = new ArrayList();
    this.totalRequest = 0;
    long currentTime = System.currentTimeMillis();
    if (this.monitorMap != null)
    {
      Map map = new Hashtable();

      map.putAll(this.monitorMap);
      for (Iterator i$ = map.values().iterator(); i$.hasNext(); ) { Monitor monitor = (Monitor)i$.next();

        String serviceName = monitor.getLogicCode();
        String operationName = monitor.getCurrentMonitorStep();
        String sessionId = monitor.getSessionId();
        this.totalRequestList.add(new RequestInfo(monitor.getMonitorId(), monitor.createTime));
        if (this.totalServiceRequestMap.get(serviceName) == null)
        {
          this.totalServiceRequestMap.put(serviceName, new RequestMap(new RequestInfo(monitor.getMonitorId(), monitor.getCreateTime())));
        }
        else ((RequestMap)this.totalServiceRequestMap.get(serviceName)).add(new RequestInfo(monitor.getMonitorId(), monitor.getCreateTime()));

        if ("BL00".equals(monitor.getCurrentMonitorStep()))
        {
          if (this.totalActionRequestMap.get(operationName) == null)
          {
            if (operationName != null)
              this.totalActionRequestMap.put(operationName, new RequestMap(new RequestInfo(monitor.getMonitorId(), monitor.getStartOperationTime())));
          }
          else if (operationName != null)
            ((RequestMap)this.totalActionRequestMap.get(operationName)).add(new RequestInfo(monitor.getMonitorId(), monitor.getStartOperationTime()));
        }

        if (sessionId != null)
        {
          if (this.sessionRequestMap.get(sessionId) == null)
          {
            if (operationName != null)
              this.sessionRequestMap.put(sessionId, new RequestMap(new RequestInfo(monitor.getMonitorId(), monitor.getCreateTime(), sessionId)));
          }
          else if (operationName != null)
            ((RequestMap)this.sessionRequestMap.get(sessionId)).add(new RequestInfo(monitor.getMonitorId(), monitor.getCreateTime(), sessionId));
        }
      }

      this.totalRequest = this.totalRequestList.size();
      map.clear();
    }
    Trace.log("MONITOR", 1, "monitor监控器获取切面数据结束");
    return currentTime;
  }

  public void setCurrentMonitorStep(String monitorId, String step)
  {
    if (this.monitorMap.get(monitorId) != null)
      ((Monitor)this.monitorMap.get(monitorId)).setCurrentMonitorStep(step);
  }

  public void setCurrentOperationName(String monitorId, String step)
  {
    if (this.monitorMap.get(monitorId) != null)
      ((Monitor)this.monitorMap.get(monitorId)).setCurrentOperationName(step);
  }

  public int getTotalRequest() {
    return this.totalRequest;
  }

  public void setTotalRequest(int totalRequest) {
    this.totalRequest = totalRequest;
  }

  public List<RequestInfo> getTotalRequestList() {
    return this.totalRequestList;
  }

  public void setTotalRequestList(List<RequestInfo> totalRequestList) {
    this.totalRequestList = totalRequestList;
  }

  public Map<String, RequestMap> getSessionRequestMap() {
    return this.sessionRequestMap;
  }

  public void setSessionRequestMap(Map<String, RequestMap> sessionRequestMap) {
    this.sessionRequestMap = sessionRequestMap;
  }

  public Map<String, RequestMap> getTotalServiceRequestMap() {
    return this.totalServiceRequestMap;
  }

  public void setTotalServiceRequestMap(Map<String, RequestMap> totalServiceRequestMap)
  {
    this.totalServiceRequestMap = totalServiceRequestMap;
  }

  public Map<String, RequestMap> getTotalActionRequestMap() {
    return this.totalActionRequestMap;
  }

  public void setTotalActionRequestMap(Map<String, RequestMap> totalActionRequestMap)
  {
    this.totalActionRequestMap = totalActionRequestMap;
  }
}