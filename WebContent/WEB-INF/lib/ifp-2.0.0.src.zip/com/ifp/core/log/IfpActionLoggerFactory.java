package com.ifp.core.log;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.BlogicContext;
import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;

public class IfpActionLoggerFactory
{
  private static IfpActionLoggerInterface logger;
  private static String loggerClassName;

  public static void initialize(IfpActionLoggerInterface loggerImp)
  {
    logger = loggerImp;
  }

  public static IfpActionLoggerInterface getLog() {
    return logger;
  }

  public static boolean checkActionLogger(IContext context, Throwable throwable)
    throws BaseException
  {
    try
    {
      if (context != null) {
        IfpActionLogInfo logInfo = null;
        String logFieldDefine = "";
        String loggerClassName = "";
        IfpActionLoggerInterface logger = null;
        try {
          if (context instanceof BlogicContext)
            logInfo = (IfpActionLogInfo)((BlogicContext)context).getTemp("logFieldDefine");
          else
            logInfo = (IfpActionLogInfo)((ClogicContext)context).getValue("logFieldDefine");

          logFieldDefine = logInfo.getLogFormat();
          loggerClassName = logInfo.getLoggerClassName();
        }
        catch (Exception ex) {
        }
        if ((((logFieldDefine == null) || (logFieldDefine.length() == 0))) && (!(StringUtil.hasText(getLoggerClassName()))))
        {
          return false;
        }
        if ((loggerClassName == null) || (loggerClassName.length() == 0)) {
          if (StringUtil.hasText(getLoggerClassName()))
            try
            {
              logger = (IfpActionLoggerInterface)SpringContextsUtil.getBean(getLoggerClassName());
            } catch (Exception e) {
              Trace.log("FACTORY", 2, "can't find bean:{};maybe is class,try to new logger", new Object[] { getLoggerClassName() });
              Class c = Class.forName(getLoggerClassName());
              logger = (IfpActionLoggerInterface)c.newInstance();
            }

          else
            logger = getLog();
        }
        else
        {
          Class c = Class.forName(loggerClassName);
          logger = (IfpActionLoggerInterface)c.newInstance();
        }
        logger.log(context, logInfo, throwable);
      }
      else {
        Trace.log("MVC", 0, "记录自定义日志异常：IfpActionLoggerFactory.checkActionLogger context为null");
      }
    } catch (Exception ex) {
      Trace.log("MVC", 0, "记录自定义日志异常", ex);
    }
    return true;
  }

  public static void checkActionLogger(ClogicContext context)
    throws BaseException
  {
    try
    {
      if (context != null) {
        IfpActionLogInfo logInfo = null;
        String logFieldDefine = "";
        String loggerClassName = "";
        IfpActionLoggerInterface logger = null;
        try {
          logInfo = (IfpActionLogInfo)context.getValue("logFieldDefine");
          logFieldDefine = logInfo.getLogFormat();
          loggerClassName = logInfo.getLoggerClassName();
        }
        catch (Exception ex) {
        }
        if ((logFieldDefine == null) || (logFieldDefine.length() == 0))
        {
          return;
        }
        if ((loggerClassName == null) || (loggerClassName.length() == 0))
        {
          logger = getLog();
        }
        else {
          Class c = Class.forName(loggerClassName);
          logger = (IfpActionLoggerInterface)c.newInstance();
        }
        logger.log(context, logInfo); }
    } catch (Exception ex) {
    }
  }

  public static String getLoggerClassName() {
    if (loggerClassName == null)
    {
      loggerClassName = (String)((SystemConf)SpringContextsUtil.getBean("systemConf")).getConfByKey("loggerClassName");
    }
    return loggerClassName;
  }

  public static void checkActionLogger(IContext context, IfpActionLogInfo logInfo)
    throws BaseException
  {
    try
    {
      if (context != null) {
        String logFieldDefine = logInfo.getLogFormat();
        String loggerClassName = logInfo.getLoggerClassName();
        IfpActionLoggerInterface logger = null;
        if ((logFieldDefine == null) || (logFieldDefine.length() == 0))
        {
          return;
        }
        if ((loggerClassName == null) || (loggerClassName.length() == 0))
        {
          logger = getLog();
        }
        else {
          Class c = Class.forName(loggerClassName);
          logger = (IfpActionLoggerInterface)c.newInstance();
        }
        logger.log(context, logInfo);
      } else {
        Trace.log("MVC", 0, "记录自定义日志异常：IfpActionLoggerFactory.checkActionLogger context为null");
      }
    } catch (Exception ex) {
      Trace.log("MVC", 0, "记录自定义日志异常", ex);
    }
  }
}