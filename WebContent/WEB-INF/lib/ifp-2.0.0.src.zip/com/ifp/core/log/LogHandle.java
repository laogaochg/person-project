package com.ifp.core.log;

import com.ifp.core.base.SystemConf;
import com.ifp.core.data.DataMap;
import com.ifp.core.data.SessionElement;
import com.ifp.core.generator.IKeyGenerator;
import com.ifp.core.monitor.MonitorFlumeSample;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.monitor.RequestInfo;
import com.ifp.core.monitor.RequestMap;
import com.ifp.core.session.IFPSession;
import com.ifp.core.session.IFPSessionManager;
import com.ifp.core.session.SessionManager;
import com.ifp.core.util.IpUtils;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.beans.factory.BeanFactoryUtils;

public class LogHandle
  implements ILogHandle
{
  private ThreadLocal<LogThread> tl;
  private ThreadLocal<Map<String, Object>> tlTemp;
  private SystemConf systemConf;
  private String appName;
  private String idcId;
  private int stainQPS;
  private int samplePeriod;
  private int sampleNum;
  private AtomicInteger sampleCount;
  private MonitorFlumeSample maxRequestSample;
  private Map<String, MonitorFlumeSample> maxSvcSamples;
  private Map<String, MonitorFlumeSample> maxCompSamples;
  private boolean compress;
  private boolean printRemote;
  private boolean simplifiedSvcInfo;
  private boolean printDBSvcInfo;
  private boolean printSISvcInfo;
  private boolean printRPCSvcInfo;
  private boolean printCacheSvcInfo;
  private boolean disable;
  private boolean printInitSessionInfo;
  private String sessionGroup;
  private final Comparator<IFPSession> sessionComparator;
  private IKeyGenerator reqIdGenerator;
  private Map<String, String> serviceNameMap;
  private Map<String, String> actionNameMap;
  private Map<String, String> serviceDescMap;
  private Map<String, String> actionDescMap;

  public LogHandle()
  {
    this.tl = new ThreadLocal();

    this.tlTemp = new ThreadLocal();

    this.samplePeriod = 100;
    this.sampleNum = 0;
    this.sampleCount = new AtomicInteger(0);

    this.disable = true;
    this.printInitSessionInfo = true;
    this.sessionGroup = "";

    this.sessionComparator = new Comparator(this)
    {
      public int compare(, IFPSession o2) {
        Long rt = Long.valueOf(o1.getLastAccessTime() - o1.getCreateTime() - o2.getLastAccessTime() - o2.getCreateTime());
        if (rt.longValue() > -3763407845500911616L)
          return 1;

        if (rt.longValue() < -3763407845500911616L) {
          return -1;
        }

        return 0;
      }
    };
  }

  public LogThread init()
  {
    LogThread logThread = new LogThread();
    logThread.setRootId(generateLogThreadId());
    logThread.setCurrentId(logThread.getRootId());
    this.tl.set(logThread);
    this.tlTemp.set(new HashMap());
    return logThread;
  }

  public LogThread init(LogThread parentLogThread)
  {
    this.tlTemp.set(new HashMap());
    if (null != parentLogThread) {
      LogThread logThread = new LogThread();
      String currentNumber = parentLogThread.getNextNumber();
      logThread.setCurrentId(new StringBuilder().append(parentLogThread.getCurrentId()).append(".").append(currentNumber).toString());
      logThread.setRootId(parentLogThread.getRootId());
      this.tl.set(logThread);
      return logThread;
    }

    return null;
  }

  public void destroy()
  {
    this.tl.set(null);
    this.tlTemp.set(null);
  }

  public void putTempData(String key, Object value)
  {
    ((Map)this.tlTemp.get()).put(key, value);
  }

  public Object getTempData(String key)
  {
    return ((Map)this.tlTemp.get()).get(key);
  }

  public String getLogHead(String module, String message)
  {
    StringBuffer headString = new StringBuffer(module);
    LogThread logThread = getLogThread();
    if (null != logThread) {
      headString.append(" ").append(logThread.getCurrentId());
      if (getFlumeLogInf() != null) {
        headString.append(" ").append(getFlumeLogInf().getFlumeReqid());
      }

      if (null != logThread.getInfo())
        headString.append("[").append(logThread.getInfo()).append("]");

    }

    headString.append(" - ").append(message);
    return headString.toString();
  }

  public void setFieldInfo(Map<String, String> map)
  {
    if (null != map) {
      StringBuffer info = new StringBuffer();
      String logFields = (String)this.systemConf.getConfMap().get("logField");
      if ((null != logFields) && (!("".equals(logFields)))) {
        String[] logFieldArr = logFields.split("\\|");
        String[] arr$ = logFieldArr; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String logField = arr$[i$];
          if (map.containsKey(logField))
            info.append("|").append((String)map.get(logField));
          else
            info.append("|NA");

        }

        getLogThread().setFieldInfo(info.toString());
      }
    }
  }

  public String getFieldInfo()
  {
    return getLogThread().getFieldInfo();
  }

  public void setInfo(String info)
  {
    getLogThread().setInfo(info);
  }

  public String getInfo()
  {
    return getLogThread().getInfo();
  }

  public LogThread getLogThread(LogThread parentLogThread)
  {
    if (null != parentLogThread) {
      LogThread logThread = (LogThread)this.tl.get();
      if (null == logThread) {
        logThread = init(parentLogThread);
      }

      return logThread;
    }

    return null;
  }

  public LogThread getLogThread()
  {
    LogThread logThread = (LogThread)this.tl.get();
    if (null == logThread) {
      logThread = init();
    }

    return logThread;
  }

  private String generateLogThreadId()
  {
    Map confMap = this.systemConf.getConfMap();
    if (null != confMap)
    {
      String appCode = (String)confMap.get("appCode");
      if (null != appCode)
        return new StringBuilder().append(appCode).append(String.valueOf(System.currentTimeMillis())).append(StringUtil.generateRandomString(7)).toString();
    }

    return new StringBuilder().append(String.valueOf(System.currentTimeMillis())).append(StringUtil.generateRandomString(7)).toString();
  }

  public void setFlumeLogInf(String flumeSessionId, String flumeServiceId, String flumeReqId, String flumeCid, String flumePid, String flumeReqIp, Long startTime)
  {
    if (!(StringUtil.hasText(flumeReqId)))
      flumeReqId = getFlumeLogReqId();

    if (!(StringUtil.hasText(flumeCid)))
      flumeCid = getFlumeLogCid();

    FlumeLogInf flumeLogInf = new FlumeLogInf();
    flumeLogInf.setFlumeSessionId(flumeSessionId);
    flumeLogInf.setFlumeServiceId(flumeServiceId);
    flumeLogInf.setFlumeReqid(flumeReqId);
    flumeLogInf.setFlumePid(flumePid);
    flumeLogInf.setFlumeCid(flumeCid);
    flumeLogInf.setFlumeSerStTime(startTime);
    flumeLogInf.setFlumeReqIP(flumeReqIp);

    setFlumeLogInf(flumeLogInf);
  }

  public void setFlumeLogInf(FlumeLogInf flumeLogInf)
  {
    List flumeLogInfList = getLogThread().getFlumeLogInfList();
    if (flumeLogInfList == null)
      flumeLogInfList = new ArrayList();

    flumeLogInfList.add(flumeLogInf);
    getLogThread().setFlumeLogInfList(flumeLogInfList);
  }

  public void logFlumeService()
  {
    if (!(isDisable()))
    {
      Long serviceEndTime = Long.valueOf(System.currentTimeMillis());
      LogThread logThread = getLogThread();
      List flumeLogInfList = logThread.getFlumeLogInfList();
      if (flumeLogInfList.size() > 0) {
        FlumeLogInf flumeLogInf = (FlumeLogInf)flumeLogInfList.get(flumeLogInfList.size() - 1);

        StringBuffer sb = new StringBuffer();
        if (this.simplifiedSvcInfo)
        {
          sb.append(flumeLogInf.getFlumeReqIP()).append("|").append("").append("|").append((null == flumeLogInf.getFlumeSessionId()) ? "" : flumeLogInf.getFlumeSessionId()).append("|").append(getAppName()).append("|").append(IpUtils.getHostAddress()).append("|").append(this.idcId).append("|").append(flumeLogInf.getFlumeReqid()).append("|").append(flumeLogInf.getFlumeCid()).append("|").append((null == flumeLogInf.getFlumePid()) ? "" : flumeLogInf.getFlumePid()).append("|").append((null == this.serviceNameMap.get(flumeLogInf.getFlumeServiceId())) ? flumeLogInf.getFlumeServiceId() : (String)this.serviceNameMap.get(flumeLogInf.getFlumeServiceId())).append("|").append(flumeLogInf.getFlumeSerStTime()).append("|").append(serviceEndTime.longValue() - flumeLogInf.getFlumeSerStTime().longValue()).append("|").append(flumeLogInf.getType()).append("##");

          logFlume("FLUME_NORMAL", 7, "4", sb.toString());
        }
        else {
          sb.append(flumeLogInf.getFlumeReqIP()).append("|").append("|").append((null == flumeLogInf.getFlumeSessionId()) ? "" : flumeLogInf.getFlumeSessionId()).append("|").append(getAppName()).append("|").append(flumeLogInf.getFlumeReqid()).append("|").append(flumeLogInf.getFlumeCid()).append("|").append((null == flumeLogInf.getFlumePid()) ? "" : flumeLogInf.getFlumePid()).append("|").append((null == this.serviceNameMap.get(flumeLogInf.getFlumeServiceId())) ? flumeLogInf.getFlumeServiceId() : (String)this.serviceNameMap.get(flumeLogInf.getFlumeServiceId())).append("|").append(flumeLogInf.getFlumeSerStTime()).append("|").append(serviceEndTime).append("|").append(flumeLogInf.getType()).append("###").append(flumeLogInf.getFlumeComInf());

          logFlume("FLUME_NORMAL", 4, "0", sb.toString());
        }
      }
    }
  }

  public void logFlumeDBService(String tables, String db, String ip, String idc, Long startTime)
  {
    if (this.printDBSvcInfo)
      logFlumeExtService("DB", tables, db, ip, idc, startTime, null);
  }

  public void logFlumeDBSvcEx(String tables, String db, String ip, String idc, Long startTime, Throwable t)
  {
    if (this.printDBSvcInfo)
      logFlumeExtSvcEx("DB", tables, db, ip, idc, startTime, null, t);
  }

  public void logFlumeSIService(String tranCode, String chanId, String ip, String client, Long startTime, String cid)
  {
    if (this.printSISvcInfo)
      logFlumeExtService("SI", tranCode, chanId, ip, client, startTime, cid);
  }

  public void logFlumeSISvcEx(String tranCode, String chanId, String ip, String client, Long startTime, String cid, Throwable t)
  {
    if (this.printSISvcInfo)
      logFlumeExtSvcEx("SI", tranCode, chanId, ip, client, startTime, cid, t);
  }

  public void logFlumeRPCService(String compId, String appId, String ip, String idc, Long startTime, String cid)
  {
    if (this.printRPCSvcInfo)
      logFlumeExtService("RPC", compId, appId, ip, idc, startTime, cid);
  }

  public void logFlumeRPCSvcEx(String compId, String appId, String ip, String idc, Long startTime, String cid, Throwable t)
  {
    if (this.printRPCSvcInfo)
      logFlumeExtSvcEx("RPC", compId, appId, ip, idc, startTime, cid, t);
  }

  public void logFlumeCacheSvc(String method, String appId, String ip, String idc, Long startTime)
  {
    if (this.printCacheSvcInfo)
      logFlumeExtService("CACHE", method, appId, ip, idc, startTime, null);
  }

  public void logFlumeCacheSvcEx(String tables, String db, String ip, String idc, Long startTime, Throwable t)
  {
    if (this.printCacheSvcInfo)
      logFlumeExtSvcEx("CACHE", tables, db, ip, idc, startTime, null, t);
  }

  private String logFlumeExtService(String type, String svcId, String appId, String ip, String idc, Long startTime, String cid)
  {
    if (this.disable)
      return "";

    if (!(StringUtil.hasText(appId)))
      appId = getAppName();

    if (!(StringUtil.hasText(ip)))
      ip = IpUtils.getHostAddress();

    if (!(StringUtil.hasText(idc)))
      idc = this.idcId;

    String newCid = cid;
    if (!(StringUtil.hasText(newCid)))
      newCid = new StringBuilder().append(ip).append(appId).append(String.valueOf(System.currentTimeMillis())).append(StringUtil.generateRandomString(7)).toString();

    Long serviceEndTime = Long.valueOf(System.currentTimeMillis());
    LogThread logThread = getLogThread();
    List flumeLogInfList = logThread.getFlumeLogInfList();
    if (flumeLogInfList.size() > 0) {
      FlumeLogInf flumeLogInf = (FlumeLogInf)flumeLogInfList.get(flumeLogInfList.size() - 1);

      StringBuffer sb = new StringBuffer();
      sb.append(IpUtils.getHostAddress()).append("|").append("").append("|").append((null == flumeLogInf.getFlumeSessionId()) ? "" : flumeLogInf.getFlumeSessionId()).append("|").append(appId).append("|").append(ip).append("|").append(idc).append("|").append(flumeLogInf.getFlumeReqid()).append("|").append(newCid).append("|").append(flumeLogInf.getFlumeCid()).append("|").append(svcId).append("|").append(startTime).append("|").append(serviceEndTime.longValue() - startTime.longValue()).append("|").append(type).append("##");

      logFlume("FLUME_NORMAL", 7, "4", sb.toString());
    }
    return newCid;
  }

  private void logFlumeExtSvcEx(String type, String svcId, String appId, String ip, String idc, Long startTime, String cid, Throwable t)
  {
    if (this.disable)
      return;

    if (!(StringUtil.hasText(appId)))
      appId = getAppName();

    if (!(StringUtil.hasText(ip)))
      ip = IpUtils.getHostAddress();

    if (!(StringUtil.hasText(idc)))
      idc = this.idcId;

    String newCid = cid;
    if (!(StringUtil.hasText(newCid)))
      newCid = new StringBuilder().append(ip).append(appId).append(String.valueOf(System.currentTimeMillis())).append(StringUtil.generateRandomString(7)).toString();

    Long serviceEndTime = Long.valueOf(System.currentTimeMillis());
    LogThread logThread = getLogThread();
    List flumeLogInfList = logThread.getFlumeLogInfList();
    if (flumeLogInfList.size() > 0) {
      FlumeLogInf flumeLogInf = (FlumeLogInf)flumeLogInfList.get(flumeLogInfList.size() - 1);

      StringBuffer sb = new StringBuffer();
      if (this.printDBSvcInfo) {
        sb.append(IpUtils.getHostAddress()).append("|").append("").append("|").append((null == flumeLogInf.getFlumeSessionId()) ? "" : flumeLogInf.getFlumeSessionId()).append("|").append(appId).append("|").append(ip).append("|").append(idc).append("|").append(flumeLogInf.getFlumeReqid()).append("|").append(newCid).append("|").append(flumeLogInf.getFlumeCid()).append("|").append(svcId).append("|").append(startTime).append("|").append(serviceEndTime.longValue() - startTime.longValue()).append("|").append(type).append("##");

        logFlume("FLUME_NORMAL", 7, "4", sb.toString());

        String errMSg = t.toString();
        StackTraceElement[] stackTrace = t.getStackTrace();
        for (int i = 0; i < stackTrace.length; ++i)
          errMSg = new StringBuilder().append(errMSg).append("\n").append(stackTrace[i].toString()).toString();

        sb.delete(0, sb.length());
        sb.append(flumeLogInf.getFlumeReqid()).append("|").append(newCid).append("|").append(flumeLogInf.getFlumeCid()).append("|").append(svcId).append("|").append(errMSg).append("##");

        logFlume(6, null, sb.toString());
      }
    }
  }

  public void logFlumeInitData()
  {
    if (!(isDisable())) {
      if ((!(StringUtil.hasText(this.appName))) || (this.serviceNameMap == null) || (this.actionNameMap == null))
      {
        return;
      }
      StringBuffer sb = new StringBuffer();

      sb.append(getAppName()).append("|").append(getAppDesc()).append("|").append(IpUtils.getHostAddress()).append("|").append(getIdcId()).append("##").append("##");

      for (Iterator i$ = this.serviceNameMap.keySet().iterator(); i$.hasNext(); ) { String svcName = (String)i$.next();
        sb.append(svcName).append("|").append((String)this.serviceNameMap.get(svcName)).append("|").append((StringUtil.hasText((String)this.serviceDescMap.get(svcName))) ? (String)this.serviceDescMap.get(svcName) : "").append("#");
      }

      if ((this.serviceNameMap != null) && (this.serviceNameMap.size() > 0)) {
        sb.deleteCharAt(sb.length() - 1);
      }
      else if (this.actionNameMap.size() == 0) {
        sb.delete(sb.length() - 2, sb.length());
        logFlume("FLUME_STAT", 8, "1", sb.toString());
        return;
      }

      sb.append("##");
      for (i$ = this.actionNameMap.keySet().iterator(); i$.hasNext(); ) { String actName = (String)i$.next();
        sb.append(actName).append("|").append((String)this.actionNameMap.get(actName)).append("|").append((StringUtil.hasText((String)this.actionDescMap.get(actName))) ? (String)this.actionDescMap.get(actName) : "").append("#");
      }

      if ((this.actionNameMap != null) && (this.actionNameMap.size() > 0))
        sb.deleteCharAt(sb.length() - 1);

      logFlume("FLUME_STAT", 8, "1", sb.toString()); }
  }

  private String getAppDesc() {
    String desc = (String)this.systemConf.getConfMap().get("appDesc");
    return ((StringUtil.hasText(desc)) ? desc : "");
  }

  public void logFlumeAppHost()
  {
    if (!(isDisable())) {
      if (!(StringUtil.hasText(this.appName)))
        return;

      StringBuffer sb = new StringBuffer();

      sb.append(getAppName()).append("|").append("").append("|").append(IpUtils.getHostAddress()).append("|").append(getIdcId()).append("##");

      logFlume("FLUME_STAT", 8, "2", sb.toString());
    }
  }

  public void logFlumeRemote(RemoteCallInfo rc)
  {
    if (!(isDisable())) {
      if ((!(this.printRemote)) || (null == rc) || (getLogThread() == null) || (getLogThread().getFlumeLogInfList().size() == 0))
      {
        return;
      }
      String reqId = ""; String cid = ""; String pcid = "";
      if (StringUtil.hasText(rc.getReqId())) {
        reqId = rc.getReqId();
        cid = rc.getCid();
        pcid = rc.getPcid();
      } else {
        logInfo = (FlumeLogInf)getLogThread().getFlumeLogInfList().get(getLogThread().getFlumeLogInfList().size() - 1);

        reqId = logInfo.getFlumeReqid();
        cid = logInfo.getFlumeCid();
        pcid = logInfo.getFlumePid();
      }
      FlumeLogInf logInfo = (FlumeLogInf)getLogThread().getFlumeLogInfList().get(getLogThread().getFlumeLogInfList().size() - 1);

      Long duration = Long.valueOf(-3763408395256725504L);
      if (logInfo.getPreMarkTime().longValue() != -3763400183279255552L)
        duration = Long.valueOf(rc.getMarkTime().longValue() - logInfo.getPreMarkTime().longValue());

      StringBuffer sb = new StringBuffer();
      if (!(StringUtil.hasText(rc.getComponentId())))
      {
        if (rc.getType().contains("CLIENT"))
          duration = Long.valueOf(rc.getMarkTime().longValue() - logInfo.getFlumeSerStTime().longValue());

        sb.append(reqId).append("|").append(cid).append("|").append((null == pcid) ? "" : pcid).append("|").append(logInfo.getFlumeServiceId()).append("|").append(rc.getMarkTime()).append("|").append(rc.getType()).append("|").append(duration).append("##");

        logFlume("FLUME_NORMAL", 4, "2", sb.toString());
      }
      else
      {
        sb.append(reqId).append("|").append(cid).append("|").append((null == pcid) ? "" : pcid).append("|").append(rc.getComponentId()).append("|").append(rc.getMarkTime()).append("|").append(rc.getType()).append("|").append(duration).append("|").append(rc.getTargetSvcId()).append("|").append(rc.getTargetAppId()).append("|").append(rc.getTargetIp()).append("|").append(rc.getTargetIdc()).append("|").append(rc.getTargetPort()).append("|").append(rc.getTargetUrl()).append("##");

        logFlume("FLUME_NORMAL", 4, "1", sb.toString());
      }

      logInfo.setPreMarkTime(rc.getMarkTime());
    }
  }

  public void logFlumeSessionCreate(IFPSession session) {
    if (isDisable()) {
      return;
    }

    if (!(isPrintInitSessionInfo())) {
      return;
    }

    StringBuilder sb = new StringBuilder();
    sb.append(session.getAttribute("CLIENT_IP")).append("|").append("").append("|").append(session.getId()).append("|").append(session.getAttribute("CLIENT_MAC")).append("|").append(session.getAttribute("DEVICE_ID")).append("|").append(session.getAttribute("DEVICE_NAME")).append("|").append(getSessionGroup()).append("|").append(session.getCreateTime()).append("|").append(session.getLastAccessTime() - session.getCreateTime()).append("##");

    logFlume("FLUME_STAT", 8, "3", sb.toString());
  }

  public void logFlume(int level, String flag, String message)
  {
    if (!(isDisable()))
    {
      if (StringUtil.hasText(flag)) {
        message = new StringBuilder().append(flag).append("|").append((this.compress) ? StringUtil.compress(message) : message).toString();
      }

      Trace.log("FLUME_NORMAL", level, message);
    }
  }

  public void logFlume(String loggerName, int level, String flag, String message)
  {
    if (!(isDisable()))
    {
      if (StringUtil.hasText(flag)) {
        message = new StringBuilder().append(flag).append("|").append((this.compress) ? StringUtil.compress(message) : message).toString();
      }

      Trace.log(loggerName, level, message);
    }
  }

  public void logFlumeQPSInit()
  {
    if (this.stainQPS % this.samplePeriod == 0) {
      this.sampleNum = (this.stainQPS / this.samplePeriod);
    }
    else
      this.sampleNum = (this.stainQPS / this.samplePeriod + 1);

    this.maxRequestSample = new MonitorFlumeSample();
    this.maxSvcSamples = new HashMap();
    this.maxCompSamples = new HashMap();
    Timer timer = new Timer();
    Calendar calendar = Calendar.getInstance();
    Long time1 = Long.valueOf(calendar.getTimeInMillis());
    calendar.add(12, 1);
    calendar.set(calendar.get(1), calendar.get(2), calendar.get(5), calendar.get(11), calendar.get(12), 0);

    Long time2 = Long.valueOf(calendar.getTimeInMillis());
    timer.schedule(new TimerTask(this)
    {
      public void run() {
        try {
          LogHandle.access$000(this.this$0);
        } catch (Exception e) {
          Trace.log("MONITOR", 3, "flumeQPS() Exception", e);
        }
      }
    }
    , time2.longValue() - time1.longValue(), this.samplePeriod);
  }

  private void logFlumeQPSMorePrecisely()
  {
    if (!(isDisable())) {
      MonitorManager monitorManager = (MonitorManager)SpringContextsUtil.getBean("monitorManager");

      Long nowTime = Long.valueOf(monitorManager.countRequest());
      if (this.sampleCount.incrementAndGet() == this.sampleNum) {
        MonitorFlumeSample sample;
        updateMaxDurationSample(nowTime, monitorManager);
        StringBuilder sb = new StringBuilder();

        sb.append(getAppName()).append("|");
        sb.append(IpUtils.getHostAddress()).append("|").append(this.idcId).append("|").append(nowTime).append(this.maxRequestSample.getFormattedStr());

        logFlume("FLUME_STAT", 7, "0", sb.toString());

        if (StringUtil.hasText(getSessionGroup())) {
          SessionManager sessionMgr = (SessionManager)SpringContextsUtil.getBean("sessionManager");
          if (sessionMgr instanceof IFPSessionManager) {
            Map sessionMap = BeanFactoryUtils.beansOfTypeIncludingAncestors(SpringContextsUtil.getApplicationContext(), SessionElement.class, true, false);
            List allSessions = new ArrayList();
            for (Iterator i$ = sessionMap.values().iterator(); i$.hasNext(); ) { SessionElement se = (SessionElement)i$.next();
              List sessLs = ((IFPSessionManager)sessionMgr).getAllSessionFromCache(se.getCacheName());
              if (null != sessLs)
                allSessions.addAll(sessLs);
            }

            if (allSessions.isEmpty()) {
              logFlumeBlankSessionStat(nowTime);
            }
            else {
              Collections.sort(allSessions, this.sessionComparator);
              Long totalDuration = Long.valueOf(-3763405938535432192L);
              for (Iterator i$ = allSessions.iterator(); i$.hasNext(); ) { IFPSession s = (IFPSession)i$.next();
                totalDuration = Long.valueOf(totalDuration.longValue() + s.getLastAccessTime() - s.getCreateTime());
              }
              Long avgDuration = Long.valueOf(totalDuration.longValue() / allSessions.size());
              IFPSession maxSession = (IFPSession)allSessions.get(allSessions.size() - 1);
              IFPSession minSession = (IFPSession)allSessions.get(0);
              sb.delete(0, sb.length());
              sb.append(getAppName()).append("|").append(IpUtils.getHostAddress()).append("|").append(this.idcId).append("|").append(getSessionGroup()).append("|").append(maxSession.getLastAccessTime() - maxSession.getCreateTime()).append("|").append(maxSession.getId()).append("|").append(minSession.getLastAccessTime() - minSession.getCreateTime()).append("|").append(minSession.getId()).append("|").append(avgDuration).append("|").append(nowTime).append("|").append(allSessions.size()).append("####");

              boolean firstElement = true;
              for (Iterator i$ = allSessions.iterator(); i$.hasNext(); ) { IFPSession s = (IFPSession)i$.next();
                if (!(firstElement)) {
                  sb.append("#");
                }
                else
                  firstElement = false;

                sb.append(s.getId()).append("|").append(s.getLastAccessTime() - s.getCreateTime());
              }

              logFlume("FLUME_STAT", 7, "1", sb.toString());
            }
          }
          else
          {
            logFlumeBlankSessionStat(nowTime);
          }

        }

        sb.delete(0, sb.length());
        sb.append(getAppName()).append("|");
        sb.append(IpUtils.getHostAddress()).append("|").append(this.idcId).append("|").append(nowTime).append("#");

        for (Iterator i$ = this.maxSvcSamples.values().iterator(); i$.hasNext(); ) { sample = (MonitorFlumeSample)i$.next();
          sb.append(sample.getFormattedStr());
        }
        if ((this.maxSvcSamples == null) || (this.maxSvcSamples.size() == 0))
        {
          sb.append("#").append("|").append("0|").append("0|").append("|").append("0|").append("|").append("0");
        }

        logFlume("FLUME_STAT", 7, "2", sb.toString());

        sb.delete(0, sb.length());
        sb.append(getAppName()).append("|");
        sb.append(IpUtils.getHostAddress()).append("|").append(this.idcId).append("|").append(nowTime).append("#");

        for (i$ = this.maxCompSamples.values().iterator(); i$.hasNext(); ) { sample = (MonitorFlumeSample)i$.next();
          sb.append(sample.getFormattedStr());
        }
        if ((this.maxCompSamples == null) || (this.maxCompSamples.size() == 0))
        {
          sb.append("#").append("|").append("0|").append("0|").append("|").append("0|").append("|").append("0");
        }

        logFlume("FLUME_STAT", 7, "3", sb.toString());

        this.sampleCount.compareAndSet(this.sampleNum, 0);
        this.maxRequestSample.setMaxDuration(Long.valueOf(-3763406900608106496L));
        this.maxRequestSample.setFormattedStr("|0|0|0|0||0||0##");
        this.maxSvcSamples.clear();
        this.maxCompSamples.clear();
      }
      else {
        updateMaxDurationSample(nowTime, monitorManager);
      }
    }
  }

  private void updateMaxDurationSample(Long nowTime, MonitorManager monitorManager)
  {
    RequestMap requestMap;
    Map startTimeMap;
    Iterator i$;
    MonitorFlumeSample sample;
    String key;
    RequestInfo ri;
    List totalRequestList = monitorManager.getTotalRequestList();

    Map totalServiceRequestMap = monitorManager.getTotalServiceRequestMap();

    Map totalActionRequestMap = monitorManager.getTotalActionRequestMap();

    StringBuilder sb = new StringBuilder();

    Long totalTime = Long.valueOf(-3763399959940956160L);

    Long timeTemp = null;
    RequestInfo requestInfoMin = new RequestInfo(null);
    RequestInfo requestInfoMax = new RequestInfo(null);

    for (Iterator i$ = totalRequestList.iterator(); i$.hasNext(); ) { RequestInfo ri = (RequestInfo)i$.next();
      if (timeTemp == null) {
        requestInfoMin = ri;
        requestInfoMax = ri;
      }
      timeTemp = Long.valueOf(nowTime.longValue() - ri.getStartTime());
      totalTime = Long.valueOf(totalTime.longValue() + timeTemp.longValue());
      if (timeTemp.longValue() < nowTime.longValue() - requestInfoMin.getStartTime())
        requestInfoMin = ri;
      else if (timeTemp.longValue() > nowTime.longValue() - requestInfoMax.getStartTime())
        requestInfoMax = ri;
    }

    if ((totalRequestList != null) && (totalRequestList.size() > 0) && 
      (nowTime.longValue() - requestInfoMax.getStartTime() > this.maxRequestSample.getMaxDuration().longValue())) {
      this.maxRequestSample.setMaxDuration(Long.valueOf(nowTime.longValue() - requestInfoMax.getStartTime()));
      sb.append("|").append(totalRequestList.size()).append("|").append(totalServiceRequestMap.size()).append("|").append(totalActionRequestMap.size()).append("|").append(totalTime.longValue() / totalRequestList.size()).append("|").append(requestInfoMax.getCId()).append("|").append(nowTime.longValue() - requestInfoMax.getStartTime()).append("|").append(requestInfoMin.getCId()).append("|").append(nowTime.longValue() - requestInfoMin.getStartTime()).append("##");

      this.maxRequestSample.setFormattedStr(sb.toString());
    }

    totalTime = Long.valueOf(-3763400080200040448L);
    timeTemp = null;
    for (i$ = totalServiceRequestMap.keySet().iterator(); i$.hasNext(); ) { String serviceId = (String)i$.next();
      requestMap = (RequestMap)totalServiceRequestMap.get(serviceId);
      startTimeMap = requestMap.getStartTimeMap();
      for (i$ = startTimeMap.keySet().iterator(); i$.hasNext(); ) { key = (String)i$.next();
        ri = (RequestInfo)startTimeMap.get(key);
        if (timeTemp == null) {
          requestInfoMin = ri;
          requestInfoMax = ri;
        }
        timeTemp = Long.valueOf(nowTime.longValue() - ri.getStartTime());
        totalTime = Long.valueOf(totalTime.longValue() + timeTemp.longValue());
        if (timeTemp.longValue() < nowTime.longValue() - requestInfoMin.getStartTime())
          requestInfoMin = ri;
        else if (timeTemp.longValue() > nowTime.longValue() - requestInfoMax.getStartTime())
        {
          requestInfoMax = ri;
        }
      }

      if ((startTimeMap != null) && (startTimeMap.size() > 0)) {
        if (this.maxSvcSamples.containsKey(serviceId)) {
          if (nowTime.longValue() - requestInfoMax.getStartTime() > ((MonitorFlumeSample)this.maxSvcSamples.get(serviceId)).getMaxDuration().longValue()) {
            ((MonitorFlumeSample)this.maxSvcSamples.get(serviceId)).setMaxDuration(Long.valueOf(nowTime.longValue() - requestInfoMax.getStartTime()));
            sb.delete(0, sb.length());
            sb.append("#").append((null == this.serviceNameMap.get(serviceId)) ? serviceId : (String)this.serviceNameMap.get(serviceId)).append("|").append(startTimeMap.size()).append("|").append(totalTime.longValue() / startTimeMap.size()).append("|").append(requestInfoMax.getCId()).append("|").append(nowTime.longValue() - requestInfoMax.getStartTime()).append("|").append(requestInfoMin.getCId()).append("|").append(nowTime.longValue() - requestInfoMin.getStartTime());

            ((MonitorFlumeSample)this.maxSvcSamples.get(serviceId)).setFormattedStr(sb.toString());
          }
        }
        else {
          sample = new MonitorFlumeSample();
          sample.setMaxDuration(Long.valueOf(nowTime.longValue() - requestInfoMax.getStartTime()));
          sb.delete(0, sb.length());
          sb.append("#").append((null == this.serviceNameMap.get(serviceId)) ? serviceId : (String)this.serviceNameMap.get(serviceId)).append("|").append(startTimeMap.size()).append("|").append(totalTime.longValue() / startTimeMap.size()).append("|").append(requestInfoMax.getCId()).append("|").append(nowTime.longValue() - requestInfoMax.getStartTime()).append("|").append(requestInfoMin.getCId()).append("|").append(nowTime.longValue() - requestInfoMin.getStartTime());

          sample.setFormattedStr(sb.toString());
          this.maxSvcSamples.put(serviceId, sample);
        }

      }

    }

    totalTime = Long.valueOf(-3763400080200040448L);
    timeTemp = null;
    for (i$ = totalActionRequestMap.keySet().iterator(); i$.hasNext(); ) { String componentId = (String)i$.next();
      requestMap = (RequestMap)totalActionRequestMap.get(componentId);
      startTimeMap = requestMap.getStartTimeMap();
      for (sample = startTimeMap.keySet().iterator(); sample.hasNext(); ) { key = (String)sample.next();
        ri = (RequestInfo)startTimeMap.get(key);
        if (timeTemp == null) {
          requestInfoMin = ri;
          requestInfoMax = ri;
        }
        timeTemp = Long.valueOf(nowTime.longValue() - ri.getStartTime());
        totalTime = Long.valueOf(totalTime.longValue() + timeTemp.longValue());
        if (timeTemp.longValue() < nowTime.longValue() - requestInfoMin.getStartTime())
          requestInfoMin = ri;
        else if (timeTemp.longValue() > nowTime.longValue() - requestInfoMax.getStartTime())
        {
          requestInfoMax = ri;
        }
      }
      if ((startTimeMap != null) && (startTimeMap.size() > 0))
        if (this.maxCompSamples.containsKey(componentId)) {
          if (nowTime.longValue() - requestInfoMax.getStartTime() > ((MonitorFlumeSample)this.maxCompSamples.get(componentId)).getMaxDuration().longValue()) {
            ((MonitorFlumeSample)this.maxCompSamples.get(componentId)).setMaxDuration(Long.valueOf(nowTime.longValue() - requestInfoMax.getStartTime()));
            sb.delete(0, sb.length());
            sb.append("#").append((null == this.actionNameMap.get(componentId)) ? componentId : (String)this.actionNameMap.get(componentId)).append("|").append(startTimeMap.size()).append("|").append(totalTime.longValue() / startTimeMap.size()).append("|").append(requestInfoMax.getCId()).append("|").append(nowTime.longValue() - requestInfoMax.getStartTime()).append("|").append(requestInfoMin.getCId()).append("|").append(nowTime.longValue() - requestInfoMin.getStartTime());

            ((MonitorFlumeSample)this.maxCompSamples.get(componentId)).setFormattedStr(sb.toString());
          }
        }
        else {
          sample = new MonitorFlumeSample();
          sample.setMaxDuration(Long.valueOf(nowTime.longValue() - requestInfoMax.getStartTime()));
          sb.delete(0, sb.length());
          sb.append("#").append((null == this.actionNameMap.get(componentId)) ? componentId : (String)this.actionNameMap.get(componentId)).append("|").append(startTimeMap.size()).append("|").append(totalTime.longValue() / startTimeMap.size()).append("|").append(requestInfoMax.getCId()).append("|").append(nowTime.longValue() - requestInfoMax.getStartTime()).append("|").append(requestInfoMin.getCId()).append("|").append(nowTime.longValue() - requestInfoMin.getStartTime());

          sample.setFormattedStr(sb.toString());
          this.maxCompSamples.put(componentId, sample);
        }
    }
  }

  @Deprecated
  public void logFlumeQPS()
    throws Exception
  {
    if (!(isDisable())) {
      RequestMap requestMap;
      Map startTimeMap;
      Iterator i$;
      String key;
      RequestInfo ri;
      MonitorManager monitorManager = (MonitorManager)SpringContextsUtil.getBean("monitorManager");

      Trace.log("MONITOR", 0, "Get monitorManager");

      Long nowTime = Long.valueOf(monitorManager.countRequest());
      Trace.log("MONITOR", 0, new StringBuilder().append("Get CurTime: ").append(nowTime).toString());

      List totalRequestList = monitorManager.getTotalRequestList();

      Trace.log("MONITOR", 0, "Get request list");

      Map sessionRequestMap = monitorManager.getSessionRequestMap();

      Trace.log("MONITOR", 0, "Get session list");

      Map totalServiceRequestMap = monitorManager.getTotalServiceRequestMap();

      Trace.log("MONITOR", 0, "Get service list");

      Map totalActionRequestMap = monitorManager.getTotalActionRequestMap();

      Trace.log("MONITOR", 0, "Get action list");

      StringBuffer sb = new StringBuffer();

      Long totalTime = Long.valueOf(-3763408395256725504L);

      Long timeTemp = null;
      RequestInfo requestInfoMin = new RequestInfo(null);
      RequestInfo requestInfoMax = new RequestInfo(null);

      for (Iterator i$ = totalRequestList.iterator(); i$.hasNext(); ) { RequestInfo ri = (RequestInfo)i$.next();
        if (timeTemp == null) {
          requestInfoMin = ri;
          requestInfoMax = ri;
        }
        timeTemp = Long.valueOf(nowTime.longValue() - ri.getStartTime());
        totalTime = Long.valueOf(totalTime.longValue() + timeTemp.longValue());
        if (timeTemp.longValue() < nowTime.longValue() - requestInfoMin.getStartTime())
          requestInfoMin = ri;
        else if (timeTemp.longValue() > nowTime.longValue() - requestInfoMax.getStartTime())
          requestInfoMax = ri;
      }

      sb.append(getAppName()).append("|");
      sb.append(IpUtils.getHostAddress()).append("|").append(this.idcId).append("|").append(nowTime);

      if ((totalRequestList != null) && (totalRequestList.size() > 0)) {
        sb.append("|").append(totalRequestList.size()).append("|").append(totalServiceRequestMap.size()).append("|").append(totalActionRequestMap.size()).append("|").append(totalTime.longValue() / totalRequestList.size()).append("|").append(requestInfoMax.getCId()).append("|").append(nowTime.longValue() - requestInfoMax.getStartTime()).append("|").append(requestInfoMin.getCId()).append("|").append(nowTime.longValue() - requestInfoMin.getStartTime()).append("##");
      }
      else
      {
        sb.append("|").append("0|").append("0|").append("0|").append("0|").append("|").append("0|").append("|").append("0##");
      }

      logFlume("FLUME_STAT", 7, "0", sb.toString());

      if (StringUtil.hasText(getSessionGroup())) {
        SessionManager sessionMgr = (SessionManager)SpringContextsUtil.getBean("sessionManager");
        if (sessionMgr instanceof IFPSessionManager) {
          Map sessionMap = BeanFactoryUtils.beansOfTypeIncludingAncestors(SpringContextsUtil.getApplicationContext(), SessionElement.class, true, false);
          List allSessions = new ArrayList();
          for (Iterator i$ = sessionMap.values().iterator(); i$.hasNext(); ) { SessionElement se = (SessionElement)i$.next();
            List sessLs = ((IFPSessionManager)sessionMgr).getAllSessionFromCache(se.getCacheName());
            if (null != sessLs)
              allSessions.addAll(sessLs);
          }

          if (allSessions.isEmpty()) {
            logFlumeBlankSessionStat(nowTime);
          }
          else {
            Collections.sort(allSessions, this.sessionComparator);
            Long totalDuration = Long.valueOf(-3763406728809414656L);
            for (Iterator i$ = allSessions.iterator(); i$.hasNext(); ) { IFPSession s = (IFPSession)i$.next();
              totalDuration = Long.valueOf(totalDuration.longValue() + s.getLastAccessTime() - s.getCreateTime());
            }
            Long avgDuration = Long.valueOf(totalDuration.longValue() / allSessions.size());
            IFPSession maxSession = (IFPSession)allSessions.get(allSessions.size() - 1);
            IFPSession minSession = (IFPSession)allSessions.get(0);
            sb.delete(0, sb.length());
            sb.append(getAppName()).append("|").append(IpUtils.getHostAddress()).append("|").append(this.idcId).append("|").append(getSessionGroup()).append("|").append(maxSession.getLastAccessTime() - maxSession.getCreateTime()).append("|").append(maxSession.getId()).append("|").append(minSession.getLastAccessTime() - minSession.getCreateTime()).append("|").append(minSession.getId()).append("|").append(avgDuration).append("|").append(nowTime).append("|").append(allSessions.size()).append("####");

            boolean firstElement = true;
            for (Iterator i$ = allSessions.iterator(); i$.hasNext(); ) { IFPSession s = (IFPSession)i$.next();
              if (!(firstElement)) {
                sb.append("#");
              }
              else
                firstElement = false;

              sb.append(s.getId()).append("|").append(s.getLastAccessTime() - s.getCreateTime());
            }

            logFlume("FLUME_STAT", 7, "1", sb.toString());
          }
        }
        else
        {
          logFlumeBlankSessionStat(nowTime);
        }

      }

      totalTime = Long.valueOf(-3763407965759995904L);
      timeTemp = null;
      sb.delete(0, sb.length());
      sb.append(getAppName()).append("|");
      sb.append(IpUtils.getHostAddress()).append("|").append(this.idcId).append("|").append(nowTime).append("#");

      for (i$ = totalServiceRequestMap.keySet().iterator(); i$.hasNext(); ) { String serviceId = (String)i$.next();
        requestMap = (RequestMap)totalServiceRequestMap.get(serviceId);
        startTimeMap = requestMap.getStartTimeMap();
        for (i$ = startTimeMap.keySet().iterator(); i$.hasNext(); ) { key = (String)i$.next();
          ri = (RequestInfo)startTimeMap.get(key);
          if (timeTemp == null) {
            requestInfoMin = ri;
            requestInfoMax = ri;
          }
          timeTemp = Long.valueOf(nowTime.longValue() - ri.getStartTime());
          totalTime = Long.valueOf(totalTime.longValue() + timeTemp.longValue());
          if (timeTemp.longValue() < nowTime.longValue() - requestInfoMin.getStartTime())
            requestInfoMin = ri;
          else if (timeTemp.longValue() > nowTime.longValue() - requestInfoMax.getStartTime())
          {
            requestInfoMax = ri;
          }
        }

        if ((startTimeMap != null) && (startTimeMap.size() > 0)) {
          Trace.log("MONITOR", 1, new StringBuilder().append("svcID:").append(serviceId).toString());

          sb.append("#").append((null == this.serviceNameMap.get(serviceId)) ? serviceId : (String)this.serviceNameMap.get(serviceId)).append("|").append(startTimeMap.size()).append("|").append(totalTime.longValue() / startTimeMap.size()).append("|").append(requestInfoMax.getCId()).append("|").append(nowTime.longValue() - requestInfoMax.getStartTime()).append("|").append(requestInfoMin.getCId()).append("|").append(nowTime.longValue() - requestInfoMin.getStartTime());
        }

      }

      if ((totalServiceRequestMap == null) || (totalServiceRequestMap.size() == 0))
      {
        sb.append("#").append("|").append("0|").append("0|").append("|").append("0|").append("|").append("0");
      }

      logFlume("FLUME_STAT", 7, "2", sb.toString());

      totalTime = Long.valueOf(-3763407965759995904L);
      timeTemp = null;
      sb.delete(0, sb.length());
      sb.append(getAppName()).append("|");
      sb.append(IpUtils.getHostAddress()).append("|").append(this.idcId).append("|").append(nowTime).append("#");

      for (i$ = totalActionRequestMap.keySet().iterator(); i$.hasNext(); ) { String componentId = (String)i$.next();
        requestMap = (RequestMap)totalActionRequestMap.get(componentId);
        startTimeMap = requestMap.getStartTimeMap();
        for (i$ = startTimeMap.keySet().iterator(); i$.hasNext(); ) { key = (String)i$.next();
          ri = (RequestInfo)startTimeMap.get(key);
          if (timeTemp == null) {
            requestInfoMin = ri;
            requestInfoMax = ri;
          }
          timeTemp = Long.valueOf(nowTime.longValue() - ri.getStartTime());
          totalTime = Long.valueOf(totalTime.longValue() + timeTemp.longValue());
          if (timeTemp.longValue() < nowTime.longValue() - requestInfoMin.getStartTime())
            requestInfoMin = ri;
          else if (timeTemp.longValue() > nowTime.longValue() - requestInfoMax.getStartTime())
          {
            requestInfoMax = ri;
          }
        }
        if ((startTimeMap != null) && (startTimeMap.size() > 0)) {
          Trace.log("MONITOR", 1, new StringBuilder().append("compID:").append(componentId).toString());

          sb.append("#").append((null == this.actionNameMap.get(componentId)) ? componentId : (String)this.actionNameMap.get(componentId)).append("|").append(startTimeMap.size()).append("|").append(totalTime.longValue() / startTimeMap.size()).append("|").append(requestInfoMax.getCId()).append("|").append(nowTime.longValue() - requestInfoMax.getStartTime()).append("|").append(requestInfoMin.getCId()).append("|").append(nowTime.longValue() - requestInfoMin.getStartTime());
        }

      }

      if ((totalActionRequestMap == null) || (totalActionRequestMap.size() == 0))
      {
        sb.append("#").append("|").append("0|").append("0|").append("|").append("0|").append("|").append("0");
      }

      logFlume("FLUME_STAT", 7, "3", sb.toString());
    }
  }

  private void logFlumeBlankSessionStat(Long nowTime) {
    StringBuilder sb = new StringBuilder();
    sb.append(getAppName()).append("|").append(IpUtils.getHostAddress()).append("|").append(this.idcId).append("|").append(getSessionGroup()).append("|").append(0).append("|").append("").append("|").append(0).append("|").append("").append("|").append(0).append("|").append(nowTime).append("|").append(0).append("####").append("").append("|").append(0);

    logFlume("FLUME_STAT", 7, "1", sb.toString());
  }

  public String getFlumeLogCid()
  {
    return new StringBuilder().append(IpUtils.getHostAddress()).append(getLogThread().getCurrentId()).toString();
  }

  public String getFlumeLogReqId()
  {
    if (null != this.reqIdGenerator)
      return this.reqIdGenerator.generatId();

    return new StringBuilder().append(this.idcId).append("-").append(IpUtils.getHostAddress()).append("-").append(getLogThread().getRootId()).toString();
  }

  public String getServiceMapping(String serName)
  {
    return ((String)this.serviceNameMap.get(serName));
  }

  public String getActionMapping(String actionName)
  {
    if (this.actionNameMap != null)
      return ((String)this.actionNameMap.get(actionName));

    return null;
  }

  public FlumeLogInf getFlumeLogInf()
  {
    if (getLogThread().getFlumeLogInfList().size() > 0)
      return ((FlumeLogInf)getLogThread().getFlumeLogInfList().get(getLogThread().getFlumeLogInfList().size() - 1));
    return null;
  }

  public void getFlumeLogInfToMap(Map<String, Object> map) {
    LogThread logThread = getLogThread();
    if (logThread.getFlumeLogInfList().size() > 0) {
      FlumeLogInf logInfo = (FlumeLogInf)logThread.getFlumeLogInfList().get(logThread.getFlumeLogInfList().size() - 1);
      map.put("flumeReqIp", logInfo.getFlumeReqIP());
      map.put("reqId", logInfo.getFlumeReqid());
      map.put("pcid", logInfo.getFlumeCid());
    }
  }

  public void getFlumeLogInfToDataMap(DataMap dataMap) {
    LogThread logThread = getLogThread();
    if (logThread.getFlumeLogInfList().size() > 0) {
      FlumeLogInf logInfo = (FlumeLogInf)logThread.getFlumeLogInfList().get(logThread.getFlumeLogInfList().size() - 1);
      dataMap.put("flumeReqIp", logInfo.getFlumeReqIP());
      dataMap.put("reqId", logInfo.getFlumeReqid());
      dataMap.put("pcid", logInfo.getFlumeCid());
    }
  }

  public SystemConf getSystemConf() {
    return this.systemConf;
  }

  public void setSystemConf(SystemConf systemConf) {
    this.systemConf = systemConf;
  }

  public String getIdcId() {
    return this.idcId;
  }

  public String getAppName() {
    return this.appName;
  }

  public void setAppName(String appName) {
    this.appName = appName;
  }

  public void setIdcId(String idcId) {
    this.idcId = idcId;
  }

  public int getStainQPS() {
    return this.stainQPS; }

  public void setStainQPS(int stainQPS) {
    this.stainQPS = stainQPS;
  }

  public boolean getCompress() {
    return this.compress;
  }

  public void setCompress(boolean compress) {
    this.compress = compress;
  }

  public void setServiceNameMap(Map<String, String> serviceNameMap) {
    this.serviceNameMap = serviceNameMap;
  }

  public void setActionNameMap(Map<String, String> actionNameMap) {
    this.actionNameMap = actionNameMap;
  }

  public boolean isPrintRemote() {
    return this.printRemote;
  }

  public void setPrintRemote(boolean printRemote) {
    this.printRemote = printRemote;
  }

  public boolean isSimplifiedSvcInfo() {
    return this.simplifiedSvcInfo;
  }

  public void setSimplifiedSvcInfo(boolean simplifiedSvcInfo) {
    this.simplifiedSvcInfo = simplifiedSvcInfo;
  }

  public boolean isDisable() {
    return this.disable;
  }

  public void setDisable(boolean disable) {
    this.disable = disable;
  }

  public IKeyGenerator getReqIdGenerator() {
    return this.reqIdGenerator;
  }

  public void setReqIdGenerator(IKeyGenerator reqIdGenerator) {
    this.reqIdGenerator = reqIdGenerator;
  }

  public boolean isPrintDBSvcInfo() {
    return this.printDBSvcInfo;
  }

  public void setPrintDBSvcInfo(boolean printDBSvcInfo) {
    this.printDBSvcInfo = printDBSvcInfo;
  }

  public boolean isPrintSISvcInfo() {
    return this.printSISvcInfo;
  }

  public void setPrintSISvcInfo(boolean printSISvcInfo) {
    this.printSISvcInfo = printSISvcInfo;
  }

  public boolean isPrintRPCSvcInfo() {
    return this.printRPCSvcInfo;
  }

  public void setPrintRPCSvcInfo(boolean printRPCSvcInfo) {
    this.printRPCSvcInfo = printRPCSvcInfo;
  }

  public boolean isPrintCacheSvcInfo() {
    return this.printCacheSvcInfo;
  }

  public void setPrintCacheSvcInfo(boolean printCacheSvcInfo) {
    this.printCacheSvcInfo = printCacheSvcInfo;
  }

  public String getSessionGroup() {
    return this.sessionGroup;
  }

  public void setSessionGroup(String sessionGroup) {
    this.sessionGroup = sessionGroup;
  }

  public int getSamplePeriod() {
    return this.samplePeriod;
  }

  public void setSamplePeriod(int samplePeriod) {
    this.samplePeriod = samplePeriod;
  }

  public void setServiceDescMap(Map<String, String> serviceDescMap) {
    this.serviceDescMap = serviceDescMap;
  }

  public void setActionDescMap(Map<String, String> actionDescMap) {
    this.actionDescMap = actionDescMap;
  }

  public boolean isPrintInitSessionInfo() {
    return this.printInitSessionInfo;
  }

  public void setPrintInitSessionInfo(boolean printInitSessionInfo) {
    this.printInitSessionInfo = printInitSessionInfo;
  }
}