package com.ifp.core.log;

import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;

public abstract interface IfpActionLoggerInterface
{
  public abstract void log(IContext paramIContext, IfpActionLogInfo paramIfpActionLogInfo)
    throws BaseException;

  public abstract void log(IContext paramIContext, IfpActionLogInfo paramIfpActionLogInfo, Throwable paramThrowable)
    throws BaseException;
}