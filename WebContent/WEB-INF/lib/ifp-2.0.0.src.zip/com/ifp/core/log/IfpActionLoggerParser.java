package com.ifp.core.log;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.util.DataMapChangeUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class IfpActionLoggerParser
{
  private static final String FIELD_VAR_PREFIX = "#[";
  private static final String FIELD_VAR_SUFFIX = "]";
  private static final String FIELD_VAR_ICOLL = ".";
  private static final String FIELD_VAR_ICOLL_RET = "|";
  private static final String FIELD_FUN_PREFIX = "@";
  private static final String FIELD_FUN_SUFFIX = ")";
  private static final String FIELD_FUN_ARGFIX = "(";
  private static final String FIELD_EXP_NOTAG = "NOTAG";

  public static String parser(IContext context, String logStr)
  {
    String logVar = variableAnalyzer(context, logStr);

    return logVar;
  }

  public static String getDataValue(IContext context, String fieldName)
  {
    String fieldValue = null;
    try {
      if (context instanceof BlogicContext)
      {
        fieldValue = ((DataMap)((BlogicContext)context).getDataMap()).getElementValue(fieldName);
      }
      else fieldValue = (String)((Map)context.getDataMap()).get(fieldName);
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    if (fieldValue == null) {
      fieldValue = "";
    }

    return fieldValue;
  }

  public static String getICollValue(IContext context, String iCollName, String key)
  {
    StringBuffer values = new StringBuffer();
    try {
      List list = new ArrayList();
      if (context instanceof BlogicContext)
      {
        DataList dataList = (DataList)((DataMap)((BlogicContext)context).getDataMap()).get(iCollName);
        DataMapChangeUtil.dataListToList(dataList, list);
      } else {
        list = (List)((Map)((ClogicContext)context).getDataMap()).get(iCollName);
      }
      for (int i = 0; i < list.size(); ++i) {
        Map dtMap = (Map)list.get(i);
        values.append((String)dtMap.get(key));
        if (i != list.size() - 1)
          values.append("|");
      }
    }
    catch (Exception e)
    {
    }
    return values.toString();
  }

  private static String variableAnalyzer(IContext context, String logStr)
  {
    int index = 0;
    String tag = "";
    String fieldName = "";
    StringBuffer subContent = new StringBuffer();

    tag = searchTag(logStr, index, "#[", "]");
    while (true) {
      if (tag.equals("NOTAG"))
        break;

      fieldName = trimTag(tag, "#[", "]");
      subContent.append(logStr.substring(index, logStr.indexOf(tag, index)));
      subContent.append(getVariableValue(context, fieldName));
      index = logStr.indexOf(tag, index) + tag.length();
      tag = searchTag(logStr, index, "#[", "]");
    }
    subContent.append(logStr.substring(index, logStr.length()));
    return subContent.toString();
  }

  private static String getVariableValue(IContext context, String fieldName) {
    int index1 = fieldName.indexOf(".", 0);
    if (index1 == -1) {
      return getDataValue(context, fieldName);
    }

    String iCollName = fieldName.substring(0, index1).trim();
    String key = fieldName.substring(index1 + 1).trim();
    return getICollValue(context, iCollName, key);
  }

  private static String searchTag(String str, int index, String startWith, String endWith)
  {
    int index1 = str.indexOf(startWith, index);
    if (index1 == -1)
      return "NOTAG";

    int index2 = str.indexOf(endWith, index);
    if (index2 == -1)
      return "NOTAG";

    if (index2 == index1 + 2)
      return "";

    String tagString = str.substring(index1, index2 + endWith.length());
    return tagString;
  }

  private static String trimTag(String tag, String startWith, String endWith)
  {
    int index1 = tag.indexOf(startWith);
    int index2 = tag.indexOf(endWith);
    String s = tag.substring(index1 + startWith.length(), index2);
    return s.trim();
  }

  public static String getDataValue(BlogicContext blogicContext, String fieldName)
  {
    String fieldValue = null;
    try {
      fieldValue = ((DataMap)blogicContext.getDataMap()).getElementValue(fieldName);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    if (fieldValue == null) {
      fieldValue = "";
    }

    return fieldValue;
  }

  public static String getICollValue(BlogicContext blogicContext, String iCollName, String key)
  {
    StringBuffer values = new StringBuffer();
    try {
      DataList list = (DataList)((DataMap)blogicContext.getDataMap()).get(iCollName);
      for (int i = 0; i < list.size(); ++i) {
        DataMap dtMap = (DataMap)list.get(i);
        DataElement dataElement = dtMap.get(key);
        values.append(dataElement);
        if (i != list.size() - 1)
          values.append("|");
      }
    }
    catch (Exception e)
    {
    }
    return values.toString();
  }

  private static String variableAnalyzer(BlogicContext blogicContext, String logStr)
  {
    int index = 0;
    String tag = "";
    String fieldName = "";
    StringBuffer subContent = new StringBuffer();

    tag = searchTag(logStr, index, "#[", "]");
    while (true) {
      if (tag.equals("NOTAG"))
        break;

      fieldName = trimTag(tag, "#[", "]");
      subContent.append(logStr.substring(index, logStr.indexOf(tag, index)));
      subContent.append(getVariableValue(blogicContext, fieldName));
      index = logStr.indexOf(tag, index) + tag.length();
      tag = searchTag(logStr, index, "#[", "]");
    }
    subContent.append(logStr.substring(index, logStr.length()));
    return subContent.toString();
  }

  private static String getVariableValue(BlogicContext blogicContext, String fieldName) {
    int index1 = fieldName.indexOf(".", 0);
    if (index1 == -1) {
      return getDataValue(blogicContext, fieldName);
    }

    String iCollName = fieldName.substring(0, index1).trim();
    String key = fieldName.substring(index1 + 1).trim();
    return getICollValue(blogicContext, iCollName, key);
  }
}