package com.ifp.core.log;

import java.util.ArrayList;
import java.util.List;

public class LogThread
{
  private String rootId;
  private String currentId;
  private int number;
  private String fieldInfo;
  private String info;
  private List<FlumeLogInf> flumeLogInfList;

  public LogThread()
  {
    this.number = 0;

    this.flumeLogInfList = new ArrayList(); }

  public String getRootId() {
    return this.rootId;
  }

  public void setRootId(String rootId) {
    this.rootId = rootId;
  }

  public String getCurrentId() {
    return this.currentId;
  }

  public void setCurrentId(String currentId) {
    this.currentId = currentId;
  }

  public int getNumber() {
    return this.number;
  }

  public void setNumber(int number) {
    this.number = number;
  }

  public String getFieldInfo() {
    return this.fieldInfo;
  }

  public void setFieldInfo(String fieldInfo) {
    this.fieldInfo = fieldInfo;
  }

  public String getInfo() {
    return this.info;
  }

  public void setInfo(String info) {
    this.info = info;
  }

  public synchronized String getNextNumber() {
    this.number += 1;
    if (this.number < 10)
      return "0" + this.number;

    return String.valueOf(this.number);
  }

  public List<FlumeLogInf> getFlumeLogInfList()
  {
    return this.flumeLogInfList;
  }

  public void setFlumeLogInfList(List<FlumeLogInf> flumeLogInfList) {
    this.flumeLogInfList = flumeLogInfList;
  }
}