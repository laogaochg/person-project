package com.ifp.core.log;

import java.util.HashMap;
import java.util.Map;

public class IfpActionLogInfo
{
  private String logFormat;
  private String loggerClassName;
  private String businessCode;
  public Map<String, Object> dataMap;

  public IfpActionLogInfo()
  {
    this.dataMap = new HashMap(); }

  public String getLogFormat() { return this.logFormat; }

  public void setLogFormat(String logFormat) {
    this.logFormat = logFormat; }

  public String getLoggerClassName() {
    return this.loggerClassName; }

  public void setLoggerClassName(String loggerClassName) {
    this.loggerClassName = loggerClassName; }

  public String getBusinessCode() {
    return this.businessCode; }

  public void setBusinessCode(String businessCode) {
    this.businessCode = businessCode;
  }

  public Object getData(String key) {
    return this.dataMap.get(key); }

  public void setData(String key, Object object) {
    this.dataMap.put(key, object);
  }
}