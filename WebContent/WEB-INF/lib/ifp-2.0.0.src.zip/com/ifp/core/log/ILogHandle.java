package com.ifp.core.log;

import java.util.Map;

public abstract interface ILogHandle
{
  public abstract LogThread init();

  public abstract LogThread init(LogThread paramLogThread);

  public abstract String getLogHead(String paramString1, String paramString2);

  public abstract void setFieldInfo(Map<String, String> paramMap);

  public abstract String getFieldInfo();

  public abstract void setInfo(String paramString);

  public abstract String getInfo();

  public abstract LogThread getLogThread(LogThread paramLogThread);

  public abstract LogThread getLogThread();

  public abstract void destroy();
}