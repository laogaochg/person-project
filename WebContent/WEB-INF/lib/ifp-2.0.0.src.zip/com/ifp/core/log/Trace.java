package com.ifp.core.log;

import com.ifp.core.util.SpringContextsUtil;
import java.util.List;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Trace
{
  public static final int LEVEL_DEBUG = 0;
  public static final int LEVEL_INFO = 1;
  public static final int LEVEL_WARN = 2;
  public static final int LEVEL_ERROR = 3;
  public static final int LEVEL_F_NORMAL = 4;
  public static final int LEVEL_F_WARN = 5;
  public static final int LEVEL_F_ERROR = 6;
  public static final int LEVEL_F_STAT = 7;
  public static final int LEVEL_F_INIT = 8;
  public static final Level F_NORMAL = Level.forName("F_NORMAL", 99);
  public static final Level F_WARN = Level.forName("F_WARN", 98);
  public static final Level F_ERROR = Level.forName("F_ERROR", 97);
  public static final Level F_STAT = Level.forName("F_STAT", 96);
  public static final Level F_INIT = Level.forName("F_INIT", 95);
  public static final String MODULE_CORE = "CORE";
  public static final String MODULE_DATA = "DATA";
  public static final String MODULE_ADAPTER = "ADAPTER";
  public static final String MODULE_CTRL = "CTRL";
  public static final String MODULE_FLOW = "FLOW";
  public static final String MODULE_ACTION = "ACTION";
  public static final String MODULE_JDBC = "JDBC";
  public static final String MODULE_CONNECT = "CONNECT";
  public static final String MODULE_FTP = "FTP";
  public static final String MODULE_COMMON = "COMMON";
  public static final String MODULE_MVC = "MVC";
  public static final String MODULE_FORMAT = "FORMAT";
  public static final String MODULE_FACTORY = "FACTORY";
  public static final String MODULE_TRANSACTION = "TRANSACTION";
  public static final String MODULE_SESSION = "SESSION";
  public static final String MODULE_SCHEDULE = "SCHEDULE";
  public static final String MODULE_WEB = "WEB";
  public static final String MODULE_MONITOR = "MONITOR";
  public static final String MODULE_TRACE = "TRACE";
  public static final String MODULE_THREAD = "THREAD";
  public static final String MODULE_INTERCEPTOR = "INTERCEPTOR";
  public static final String MODULE_MESSAGE = "MESSAGE";
  public static final String MODULE_VALIDATION = "VALIDATION";
  public static final String MODULE_WORKFLOW = "WORKFLOW";
  public static final String MODULE_FLUME_STAT = "FLUME_STAT";
  public static final String MODULE_FLUME_NORMAL = "FLUME_NORMAL";
  public static final String MODULE_DUBBOV = "DUBBOV";
  public static final String MODULE_CACHE = "CACHE";
  public static final String MODULE_ACCESS = "ACCESS";
  public static final String MODULE_FILTER = "FILTER";
  public static final String MODULE_TEST = "TEST";
  public static final String MODULE_MANAGE = "MANAGE";
  public static final String MODULE_RPC = "RPC";
  private static LogHandle logHandle = null;

  public static void log(String module, int level, String message)
  {
    Logger logger = LogManager.getLogger(module);
    switch (level)
    {
    case 0:
      logger.debug(logHandle.getLogHead(module, message));
      break;
    case 1:
      logger.info(logHandle.getLogHead(module, message));
      break;
    case 2:
      logger.warn(logHandle.getLogHead(module, message));
      break;
    case 3:
      LogThread logThread = logHandle.getLogThread();

      StringBuffer sb = new StringBuffer();
      List flumeLogInfList = logThread.getFlumeLogInfList();
      if (flumeLogInfList.size() > 0)
      {
        FlumeLogInf flumeLogInf = (FlumeLogInf)flumeLogInfList.get(flumeLogInfList.size() - 1);
        sb.append(flumeLogInf.getFlumeReqid()).append("|").append(flumeLogInf.getFlumeCid()).append("|").append(flumeLogInf.getFlumePid()).append("|").append(flumeLogInf.getFlumeServiceId()).append("|").append(message).append("##");
      }

      logHandle.logFlume(6, null, sb.toString());
      logger.error(logHandle.getLogHead(module, message));
      break;
    case 4:
      logger.log(F_NORMAL, message);
      break;
    case 5:
      logger.log(F_WARN, message);
      break;
    case 6:
      logger.log(F_ERROR, message);
      break;
    case 7:
      logger.log(F_STAT, message);
      break;
    case 8:
      logger.log(F_INIT, message);
    }
  }

  public static void log(String module, int level, String message, Object[] object)
  {
    Logger logger = LogManager.getLogger(module);

    switch (level)
    {
    case 0:
      logger.debug(logHandle.getLogHead(module, message), object);
      break;
    case 1:
      logger.info(logHandle.getLogHead(module, message), object);
      break;
    case 2:
      logger.warn(logHandle.getLogHead(module, message), object);
      break;
    case 3:
      LogThread logThread = logHandle.getLogThread();

      StringBuffer sb = new StringBuffer();
      List flumeLogInfList = logThread.getFlumeLogInfList();
      if (flumeLogInfList.size() > 0)
      {
        FlumeLogInf flumeLogInf = (FlumeLogInf)flumeLogInfList.get(flumeLogInfList.size() - 1);
        sb.append(flumeLogInf.getFlumeReqid()).append("|").append(flumeLogInf.getFlumeCid()).append("|").append(flumeLogInf.getFlumePid()).append("|").append(flumeLogInf.getFlumeServiceId()).append("|").append(message).append("##");
      }

      logHandle.logFlume(6, null, sb.toString());
      logger.error(logHandle.getLogHead(module, message), object);
      break;
    case 4:
      logger.log(F_NORMAL, message);
      break;
    case 5:
      logger.log(F_WARN, message);
      break;
    case 6:
      logger.log(F_ERROR, message);
      break;
    case 7:
      logger.log(F_STAT, message);
      break;
    case 8:
      logger.log(F_INIT, message);
    }
  }

  public static void log(String module, int level, String message, Throwable t)
  {
    Logger logger = LogManager.getLogger(module);

    switch (level)
    {
    case 0:
      logger.debug(logHandle.getLogHead(module, message), t);
      break;
    case 1:
      logger.info(logHandle.getLogHead(module, message), t);
      break;
    case 2:
      logger.warn(logHandle.getLogHead(module, message), t);
      break;
    case 3:
      String errMSg = t.toString();
      StackTraceElement[] stackTrace = t.getStackTrace();
      for (int i = 0; i < stackTrace.length; ++i) {
        errMSg = errMSg + "\n" + stackTrace[i].toString();
      }

      LogThread logThread = logHandle.getLogThread();

      StringBuffer sb = new StringBuffer();
      List flumeLogInfList = logThread.getFlumeLogInfList();
      if (flumeLogInfList.size() > 0)
      {
        FlumeLogInf flumeLogInf = (FlumeLogInf)flumeLogInfList.get(flumeLogInfList.size() - 1);
        sb.append(flumeLogInf.getFlumeReqid()).append("|").append(flumeLogInf.getFlumeCid()).append("|").append(flumeLogInf.getFlumePid()).append("|").append(flumeLogInf.getFlumeServiceId()).append("|").append(errMSg).append("##");
      }

      logHandle.logFlume(6, null, sb.toString());
      logger.error(logHandle.getLogHead(module, message), t);
      break;
    case 4:
      logger.log(F_NORMAL, message);
      break;
    case 5:
      logger.log(F_WARN, message);
      break;
    case 6:
      logger.log(F_ERROR, message);
      break;
    case 7:
      logger.log(F_STAT, message);
      break;
    case 8:
      logger.log(F_INIT, message);
    }
  }

  public static void logDebug(String module, String message)
  {
    log(module, 0, message);
  }

  public static void logDebug(String module, String message, Object[] object)
  {
    log(module, 0, message, object);
  }

  public static void logDebug(String module, String message, Throwable t)
  {
    log(module, 0, message, t);
  }

  public static void logInfo(String module, String message)
  {
    log(module, 1, message);
  }

  public static void logInfo(String module, String message, Object[] object)
  {
    log(module, 1, message, object);
  }

  public static void logInfo(String module, String message, Throwable t)
  {
    log(module, 1, message, t);
  }

  public static void logWarn(String module, String message)
  {
    log(module, 2, message);
  }

  public static void logWarn(String module, String message, Object[] object)
  {
    log(module, 2, message, object);
  }

  public static void logWarn(String module, String message, Throwable t)
  {
    log(module, 2, message, t);
  }

  public static void logError(String module, String message)
  {
    log(module, 3, message);
  }

  public static void logError(String module, String message, Object[] object)
  {
    log(module, 3, message, object);
  }

  public static void logError(String module, String message, Throwable t)
  {
    log(module, 3, message, t);
  }

  static
  {
    logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
  }
}