package com.ifp.core.log;

public class RemoteCallInfo
{
  private String componentId;
  private String targetSvcId;
  private String targetAppId = "";
  private String targetIp = "";
  private String targetIdc = "";
  private String reqId;
  private String cid;
  private String pcid;
  private String type;
  private Long markTime;
  private String targetUrl = "";
  private String targetPort = "";

  public RemoteCallInfo()
  {
  }

  public RemoteCallInfo(String componentId, String targetSvcId, String type, Long markTime)
  {
    this.componentId = componentId;
    this.targetSvcId = targetSvcId;
    this.type = type;
    if (null == markTime) {
      this.markTime = Long.valueOf(System.currentTimeMillis());
    }
    else
      this.markTime = markTime;
  }

  public RemoteCallInfo(String reqId, String cid, String pcid, String type, Long markTime)
  {
    this.reqId = reqId;
    this.cid = cid;
    this.pcid = pcid;
    this.type = type;
    this.markTime = markTime;
  }

  public RemoteCallInfo(String type, Long markTime)
  {
    this.type = type;
    this.markTime = markTime;
  }

  public String getComponentId() {
    return this.componentId;
  }

  public void setComponentId(String componentId)
  {
    this.componentId = componentId;
  }

  public String getTargetSvcId()
  {
    return this.targetSvcId;
  }

  public void setTargetSvcId(String targetSvcId)
  {
    this.targetSvcId = targetSvcId;
  }

  public String getTargetAppId()
  {
    return this.targetAppId;
  }

  public void setTargetAppId(String targetAppId)
  {
    this.targetAppId = targetAppId;
  }

  public String getTargetIp()
  {
    return this.targetIp;
  }

  public void setTargetIp(String targetIp)
  {
    this.targetIp = targetIp;
  }

  public String getTargetIdc()
  {
    return this.targetIdc;
  }

  public void setTargetIdc(String targetIdc)
  {
    this.targetIdc = targetIdc;
  }

  public String getReqId()
  {
    return this.reqId;
  }

  public void setReqId(String reqId)
  {
    this.reqId = reqId;
  }

  public String getCid()
  {
    return this.cid;
  }

  public void setCid(String cid)
  {
    this.cid = cid;
  }

  public String getPcid()
  {
    return this.pcid;
  }

  public void setPcid(String pcid)
  {
    this.pcid = pcid;
  }

  public String getType()
  {
    return this.type;
  }

  public void setType(String type)
  {
    this.type = type;
  }

  public Long getMarkTime()
  {
    return this.markTime;
  }

  public void setMarkTime(Long markTime)
  {
    this.markTime = markTime;
  }

  public String getTargetUrl() {
    return this.targetUrl;
  }

  public void setTargetUrl(String targetUrl) {
    this.targetUrl = targetUrl;
  }

  public String getTargetPort() {
    return this.targetPort;
  }

  public void setTargetPort(String targetPort) {
    this.targetPort = targetPort;
  }
}