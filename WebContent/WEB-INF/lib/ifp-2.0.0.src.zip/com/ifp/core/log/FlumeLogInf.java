package com.ifp.core.log;

import java.util.HashMap;
import java.util.Map;

public class FlumeLogInf
{
  private String flumeReqid;
  private String flumeReqIP;
  private String flumePid;
  private String flumeCid;
  private Long flumeSerStTime;
  private String flumeServiceId;
  private String flumeSessionId;
  private Long preMarkTime;
  private String flumeComInf;
  private String type;
  public Map<String, Object> dataMap;

  public FlumeLogInf()
  {
    this.flumeReqid = "null";

    this.flumeReqIP = "null";

    this.flumePid = "null";

    this.flumeCid = "null";

    this.flumeServiceId = "null";

    this.flumeSessionId = "null";

    this.preMarkTime = Long.valueOf(-3763399736602656768L);

    this.dataMap = new HashMap(); }

  public String getFlumeReqid() {
    return this.flumeReqid;
  }

  public void setFlumeReqid(String flumeReqid) {
    this.flumeReqid = flumeReqid;
  }

  public String getFlumeReqIP() {
    return this.flumeReqIP;
  }

  public void setFlumeReqIP(String flumeReqIP) {
    this.flumeReqIP = flumeReqIP;
  }

  public String getFlumePid() {
    return this.flumePid;
  }

  public void setFlumePid(String flumePid) {
    this.flumePid = flumePid;
  }

  public String getFlumeCid() {
    return this.flumeCid;
  }

  public void setFlumeCid(String flumeCid) {
    this.flumeCid = flumeCid;
  }

  public String getFlumeServiceId() {
    return this.flumeServiceId;
  }

  public void setFlumeServiceId(String flumeServiceId) {
    this.flumeServiceId = flumeServiceId;
  }

  public Long getFlumeSerStTime() {
    return this.flumeSerStTime;
  }

  public void setFlumeSerStTime(Long flumeSerStTime) {
    this.flumeSerStTime = flumeSerStTime;
  }

  public String getFlumeComInf() {
    return this.flumeComInf;
  }

  public void setFlumeComInf(String flumeComInf) {
    this.flumeComInf = flumeComInf;
  }

  public String getFlumeSessionId() {
    return this.flumeSessionId;
  }

  public void setFlumeSessionId(String flumeSessionId) {
    this.flumeSessionId = flumeSessionId;
  }

  public Long getPreMarkTime() {
    return this.preMarkTime;
  }

  public void setPreMarkTime(Long preMarkTime) {
    this.preMarkTime = preMarkTime; }

  public Object getData(String key) {
    return this.dataMap.get(key);
  }

  public void setData(String key, Object object) {
    this.dataMap.put(key, object); }

  public void setDataMap(Map<String, Object> dataMap) {
    this.dataMap = dataMap;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }
}