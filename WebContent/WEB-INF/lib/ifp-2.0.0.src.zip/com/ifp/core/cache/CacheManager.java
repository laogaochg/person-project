package com.ifp.core.cache;

import com.ifp.core.exception.BaseException;
import java.util.List;

public abstract interface CacheManager
{
  public abstract void put(String paramString1, String paramString2, Object paramObject)
    throws BaseException;

  public abstract void put(String paramString1, String paramString2, Object paramObject, long paramLong)
    throws BaseException;

  public abstract void remove(String paramString1, String paramString2)
    throws BaseException;

  public abstract void removeAll(String paramString)
    throws BaseException;

  public abstract Object get(String paramString1, String paramString2)
    throws BaseException;

  public abstract Object get(String paramString1, String paramString2, int paramInt)
    throws BaseException;

  public abstract String[] getCacheNames();

  public abstract List<Object> query(String paramString1, String paramString2)
    throws BaseException;

  public abstract List<Object> query(String paramString1, String paramString2, int paramInt1, int paramInt2)
    throws BaseException;

  public abstract int queryCount(String paramString1, String paramString2)
    throws BaseException;

  public abstract List<String> getKeys(String paramString);

  public abstract Object getCache(String paramString);

  public abstract int removeAll(String paramString1, String paramString2)
    throws BaseException;
}