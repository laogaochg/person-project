package com.ifp.core.jdbc.adapter;

import java.sql.CallableStatement;
import java.sql.SQLException;

public abstract interface IJdbcAdapter
{
  public abstract String getSequenceNumberSql(String paramString);

  public abstract String getExecuteProcedureSql(String paramString, int paramInt, String[] paramArrayOfString1, String[] paramArrayOfString2);

  public abstract String parseQuerySql(String paramString);

  public abstract String getCountSql(String paramString);

  public abstract String getCountSql(String paramString1, String paramString2);

  public abstract void setInField(CallableStatement paramCallableStatement, Object[] paramArrayOfObject)
    throws SQLException;

  public abstract void setOutField(CallableStatement paramCallableStatement, int paramInt1, int paramInt2, String[] paramArrayOfString)
    throws SQLException;

  public abstract String getPageQuerySql(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, int paramInt2);
}