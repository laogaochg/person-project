package com.ifp.core.jdbc;

import com.ifp.core.base.SystemConf;
import com.ifp.core.cache.CacheManager;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.FillResultException;
import com.ifp.core.jdbc.adapter.IJdbcAdapter;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import com.ifp.core.util.TransactionTemplateUtils;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

public class DataSourceHandle
{
  private Map<String, PlatformTransactionManager> txManagerMap;
  private Map<String, Object> jdbcTemplateMap;
  private SystemConf systemConf;
  private Map<String, String> tableMappingMap;
  private Map<String, String> sequenceMappingMap;
  private Pattern pattern;
  private String cacheName;
  private CacheManager ifpCacheManager;

  public DataSourceHandle()
  {
    this.tableMappingMap = new HashMap();

    this.sequenceMappingMap = new HashMap();

    this.pattern = Pattern.compile("(^INSERT INTO +[A-Za-z0-9_]+|^UPDATE +[A-Za-z0-9_]+|JOIN +[A-Za-z0-9_]+|FROM +[A-Za-z0-9_]+|\\([, A-Za-z0-9_]+\\)|=[?, A-Za-z0-9_']+|, +[A-Za-z0-9_]+)");

    this.cacheName = "sqlCache";
  }

  public void init()
  {
    if (null != this.systemConf) {
      Map tempTableMappingMap = (Map)this.systemConf.getConfByKey("database.mapping.table");
      if (null != tempTableMappingMap) {
        this.tableMappingMap = tempTableMappingMap;
      }

      Map tempSequenceMappingMap = (Map)this.systemConf.getConfByKey("database.mapping.sequence");
      if (null != tempSequenceMappingMap)
        this.sequenceMappingMap = tempSequenceMappingMap;
    }
  }

  public List<Object> querySQL(String key, String sql, RowMapper<Object> rowMapper)
  {
    Trace.log("JDBC", 0, "querySQL:{}|{}", new Object[] { key, sql });
    return getJdbcTemplate(key).query(sql, rowMapper);
  }

  public List<Object> querySQL(String key, String sql, RowMapper<Object> rowMapper, String postfix)
  {
    sql = getRealSql(sql, postfix);
    return querySQL(key, sql, rowMapper);
  }

  public List<Object> querySQL(String key, String sql, Object[] inputArray, RowMapper<Object> rowMapper)
  {
    Trace.log("JDBC", 0, "querySQL:{}|{}|{}", new Object[] { key, sql, inputArray });
    return getJdbcTemplate(key).query(sql, inputArray, rowMapper);
  }

  public List<Object> querySQL(String key, String sql, Object[] inputArray, RowMapper<Object> rowMapper, String postfix)
  {
    sql = getRealSql(sql, postfix);
    return querySQL(key, sql, inputArray, rowMapper);
  }

  public List<String[]> querySQL(String key, String sql)
  {
    Trace.log("JDBC", 0, "querySQL:{}|{}", new Object[] { key, sql });
    List list = getJdbcTemplate(key).query(sql, new ParameterizedRowMapper(this) {
      public String[] mapRow(, int rowNum) throws SQLException {
        String[] data = new String[rs.getMetaData().getColumnCount()];
        for (int i = 0; i < data.length; ++i) {
          data[i] = rs.getString(i + 1);
        }

        return data;
      }

    });
    return list;
  }

  public List<String[]> querySQL(String key, String sql, String postfix)
  {
    sql = getRealSql(sql, postfix);
    return querySQL(key, sql);
  }

  public List<String[]> querySQL(String key, String sql, Object[] inputArray)
  {
    Trace.log("JDBC", 0, "querySQL:{}|{}|{}", new Object[] { key, sql, inputArray });
    List list = getJdbcTemplate(key).query(sql, inputArray, new ParameterizedRowMapper(this) {
      public String[] mapRow(, int rowNum) throws SQLException {
        String[] data = new String[rs.getMetaData().getColumnCount()];
        for (int i = 0; i < data.length; ++i) {
          data[i] = rs.getString(i + 1);
        }

        return data;
      }

    });
    return list;
  }

  public List<String[]> querySQL(String key, String sql, Object[] inputArray, String postfix)
  {
    sql = getRealSql(sql, postfix);
    return querySQL(key, sql, inputArray);
  }

  public int excuteSQL(String key, String sql, Object[] inputArray)
    throws SQLException
  {
    Trace.log("JDBC", 0, "excuteSQL:{}|{}|{}", new Object[] { key, sql, inputArray });
    return getJdbcTemplate(key).update(sql, inputArray);
  }

  public int excuteSQL(String key, String sql, Object[] inputArray, String postfix)
    throws SQLException
  {
    sql = getRealSql(sql, postfix);
    return excuteSQL(key, sql, inputArray);
  }

  public int excuteSQL(String key, String sql)
    throws SQLException
  {
    Trace.log("JDBC", 0, "excuteSQL:{}|{}", new Object[] { key, sql });
    return getJdbcTemplate(key).update(sql);
  }

  public int excuteSQL(String key, String sql, String postfix)
    throws SQLException
  {
    sql = getRealSql(sql, postfix);
    return excuteSQL(key, sql);
  }

  public void executeProcedure(String key, String sql, Object[] inFieldArray)
    throws SQLException
  {
    Trace.log("JDBC", 0, "executeProcedure:{}|{}|{}", new Object[] { key, sql, inFieldArray });
    excuteSQL(key, sql, inFieldArray);
  }

  public List<Map<String, String>>[] executeProcedureOutList(String key, String sql, Object[] inFieldArray, String[] outFieldArray)
    throws SQLException
  {
    Trace.log("JDBC", 0, "executeProcedureOutList:{}|{}|{}|{}", new Object[] { key, sql, inFieldArray, outFieldArray });
    return ((List[])getJdbcTemplate(key).execute(new CallableStatementCreator(this, sql, key, inFieldArray, outFieldArray) {
      public CallableStatement createCallableStatement() throws SQLException {
        CallableStatement cs = conn.prepareCall(this.val$sql);

        this.this$0.getJdbcAdapter(this.val$key).setInField(cs, this.val$inFieldArray);

        this.this$0.getJdbcAdapter(this.val$key).setOutField(cs, 2, this.val$inFieldArray.length + 1, this.val$outFieldArray);

        return cs;
      }
    }
    , new CallableStatementCallback(this, outFieldArray)
    {
      public List<Map<String, String>>[] doInCallableStatement()
        throws SQLException, DataAccessException
      {
        List[] outLists = new List[this.val$outFieldArray.length];

        boolean hadResults = cs.execute();
        try {
          int k = 0;
          String[] arr$ = this.val$outFieldArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String oFields = arr$[i$];
            ResultSet rs = cs.getResultSet();
            int index = oFields.indexOf("(");
            List list = new ArrayList();
            String listName = oFields.substring(0, index);
            String[] oFieldsArray = oFields.substring(index + 1, oFields.length() - 1).split(",");
            while ((rs != null) && (rs.next())) {
              Map map = new HashMap();
              for (int i = 0; i < oFieldsArray.length; ++i)
                map.put(oFieldsArray[i], rs.getString(i + 1));

              list.add(map);
            }
            outLists[(k++)] = list;
            hadResults = cs.getMoreResults();
          }
        } catch (FillResultException e) {
          throw e;
        } catch (Exception e) {
          throw new FillResultException(e);
        }

        return outLists;
      }
    }));
  }

  public Map<String, String> executeProcedureOutMap(String key, String sql, Object[] inFieldArray, String[] outFieldArray)
    throws SQLException
  {
    Trace.log("JDBC", 0, "executeProcedureOutMap:{}|{}|{}|{}", new Object[] { key, sql, inFieldArray, outFieldArray });
    return ((Map)getJdbcTemplate(key).execute(new CallableStatementCreator(this, sql, key, inFieldArray, outFieldArray) {
      public CallableStatement createCallableStatement() throws SQLException {
        CallableStatement cs = conn.prepareCall(this.val$sql);

        this.this$0.getJdbcAdapter(this.val$key).setInField(cs, this.val$inFieldArray);

        this.this$0.getJdbcAdapter(this.val$key).setOutField(cs, 1, this.val$inFieldArray.length + 1, this.val$outFieldArray);

        return cs;
      }
    }
    , new CallableStatementCallback(this, inFieldArray, outFieldArray)
    {
      public Map<String, String> doInCallableStatement()
        throws SQLException, DataAccessException
      {
        boolean hadResults = cs.execute();
        try {
          Map map = new HashMap();
          int i = this.val$inFieldArray.length;
          for (int j = 0; j < this.val$outFieldArray.length; ++j)
            map.put(this.val$outFieldArray[j], cs.getString(++i));
        }
        catch (FillResultException e) {
          throw e;
        } catch (Exception e) {
          throw new FillResultException(e);
        }

        return null;
      }
    }));
  }

  public String getRealTableName(String tableName, String postfix)
  {
    String realName = (String)this.tableMappingMap.get((StringUtil.hasText(postfix)) ? tableName + "." + postfix : tableName);
    if (null != realName)
      return realName;

    return tableName;
  }

  public String getRealSequenceName(String sequenceName, String postfix)
  {
    String realName = (String)this.sequenceMappingMap.get((StringUtil.hasText(postfix)) ? sequenceName + "." + postfix : sequenceName);
    if (null != realName)
      return realName;

    return sequenceName;
  }

  public String getRealSql(String sql, String postfix)
  {
    String tempSql = sql.toUpperCase();
    if (null != this.ifpCacheManager)
      try {
        returnSql = (String)this.ifpCacheManager.get(this.cacheName, postfix + "_" + tempSql);
        if (null != returnSql)
          return returnSql;
      }
      catch (BaseException e) {
        Trace.logError("JDBC", "get cache error:", e);
      }


    StringBuffer sqlBuffer = new StringBuffer();
    Matcher matcher = this.pattern.matcher(tempSql);
    int c_idx = 0;
    Map tempTableMapping = new HashMap();
    while (true) { int s_idx;
      int e_idx;
      while (true) { do { if (!(matcher.find())) break label305;
          s_idx = matcher.start(0);
          e_idx = matcher.end(0);
          tableName = sql.substring(s_idx, e_idx); }
        while (tableName.startsWith("(")); if (!(tableName.startsWith("=")))
          break;
      }
      int m_idx = tableName.lastIndexOf(" ");
      sqlBuffer.append(sql.substring(c_idx, s_idx + m_idx + 1));

      String tableName = tableName.substring(tableName.lastIndexOf(" ") + 1);
      String realTableName = (String)this.tableMappingMap.get((StringUtil.hasText(postfix)) ? tableName + "." + postfix : tableName);
      if (StringUtil.hasText(realTableName)) {
        sqlBuffer.append(realTableName);
        tempTableMapping.put(tableName, realTableName);
      } else {
        sqlBuffer.append(tableName);
      }

      c_idx = e_idx;
    }
    if (c_idx < sql.length() - 1) {
      label305: sqlBuffer.append(sql.substring(c_idx));
    }

    String returnSql = sqlBuffer.toString();

    Iterator mappingIterator = tempTableMapping.entrySet().iterator();
    while (mappingIterator.hasNext()) {
      Map.Entry mappingEntry = (Map.Entry)mappingIterator.next();
      returnSql = returnSql.replaceAll(((String)mappingEntry.getKey()) + "\\.", ((String)mappingEntry.getValue()) + ".");
    }

    if (null != this.ifpCacheManager)
      try {
        this.ifpCacheManager.put(this.cacheName, postfix + "_" + tempSql, returnSql);
      } catch (BaseException e) {
        Trace.logError("JDBC", "get cache error:", e);
      }


    return returnSql;
  }

  public TransactionTemplate getTransactionTemplate(String key, int transType, int level)
  {
    return TransactionTemplateUtils.getTransactionTemplate((PlatformTransactionManager)this.txManagerMap.get(key), transType, level);
  }

  public TransactionTemplate getTransactionTemplate(String key)
  {
    return TransactionTemplateUtils.getDefaultTransactionTemplate((PlatformTransactionManager)this.txManagerMap.get(key));
  }

  public JdbcTemplate getJdbcTemplate(String key)
  {
    return ((JdbcTemplate)this.jdbcTemplateMap.get(key));
  }

  public IJdbcAdapter getJdbcAdapter(String key)
  {
    return ((IJdbcAdapter)this.jdbcTemplateMap.get(key + "_Adapter"));
  }

  public Map<String, PlatformTransactionManager> getTxManagerMap() {
    return this.txManagerMap;
  }

  public void setTxManagerMap(Map<String, PlatformTransactionManager> txManagerMap) {
    this.txManagerMap = txManagerMap;
  }

  public Map<String, Object> getJdbcTemplateMap() {
    return this.jdbcTemplateMap;
  }

  public void setJdbcTemplateMap(Map<String, Object> jdbcTemplateMap) {
    this.jdbcTemplateMap = jdbcTemplateMap;
  }

  public SystemConf getSystemConf() {
    return this.systemConf;
  }

  public void setSystemConf(SystemConf systemConf) {
    this.systemConf = systemConf;
  }

  public String getCacheName() {
    return this.cacheName;
  }

  public void setCacheName(String cacheName) {
    this.cacheName = cacheName;
  }

  public CacheManager getIfpCacheManager() {
    return this.ifpCacheManager;
  }

  public void setIfpCacheManager(CacheManager ifpCacheManager) {
    this.ifpCacheManager = ifpCacheManager;
  }
}