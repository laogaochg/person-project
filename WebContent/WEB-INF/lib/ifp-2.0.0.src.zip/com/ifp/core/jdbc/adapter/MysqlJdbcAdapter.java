package com.ifp.core.jdbc.adapter;

import com.ifp.core.util.StringUtil;

public class MysqlJdbcAdapter extends AbstractJdbcAdapter
{
  public String getSequenceNumberSql(String sequenceName)
  {
    return "SELECT NEXTVAL('" + sequenceName + "')";
  }

  public String getExecuteProcedureSql(String procedureName, int outType, String[] inFields, String[] outFields) {
    if (null == inFields)
      inFields = new String[0];

    if (null == outFields) {
      outFields = new String[0];
    }

    StringBuffer sql = new StringBuffer("{CALL ");
    sql.append(procedureName).append("(");
    int i = 0;
    for (int j = 0; j < inFields.length; ++j) {
      if (i == 0)
        sql.append("?");
      else
        sql.append(",?");

      ++i;
    }
    for (j = 0; j < outFields.length; ++j) {
      if (i == 0)
        sql.append("?");
      else
        sql.append(",?");

      ++i;
    }
    sql.append(")}");

    return sql.toString();
  }

  public String getPageQuerySql(String queryFields, String queryTables, String queryCondition, String queryOrder, int startIndex, int endIndex)
  {
    int size = endIndex - startIndex + 1;
    startIndex -= 1;
    StringBuffer querySql = new StringBuffer();
    querySql.append("SELECT ").append(queryFields).append(" FROM ").append(queryTables);

    if (StringUtil.hasText(queryCondition)) {
      querySql.append(" WHERE ").append(queryCondition);
    }

    if (StringUtil.hasText(queryOrder))
      querySql.append(" ORDER BY ").append(queryOrder);

    querySql.append(" LIMIT ").append(startIndex).append(", ").append(size);

    return querySql.toString();
  }
}