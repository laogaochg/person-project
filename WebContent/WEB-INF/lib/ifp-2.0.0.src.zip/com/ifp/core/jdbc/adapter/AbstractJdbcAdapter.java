package com.ifp.core.jdbc.adapter;

import com.ifp.core.util.StringUtil;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.regex.Pattern;

public abstract class AbstractJdbcAdapter
  implements IJdbcAdapter
{
  private String regex;
  private Pattern pattern;

  public AbstractJdbcAdapter()
  {
    this.regex = "#[A-Za-z0-9_.]+";

    this.pattern = Pattern.compile(this.regex); }

  public String parseQuerySql(String querySql) {
    return querySql.replaceAll(getRegex(), "?");
  }

  public String getCountSql(String querySql) {
    return "SELECT COUNT(1) FROM (" + querySql + ") SUM";
  }

  public String getCountSql(String queryTables, String queryCondition) {
    StringBuffer querySql = new StringBuffer("SELECT COUNT(1) FROM ").append(queryTables);
    if (StringUtil.hasText(queryCondition))
      querySql.append(" WHERE ").append(queryCondition);

    return querySql.toString();
  }

  public String getRegex() {
    return this.regex;
  }

  public void setRegex(String regex) {
    this.regex = regex;
  }

  public Pattern getPattern() {
    return this.pattern;
  }

  public void setPattern(Pattern pattern) {
    this.pattern = pattern;
  }

  public void setInField(CallableStatement cs, Object[] inFieldArray)
    throws SQLException
  {
    int i = 1;
    Object[] arr$ = inFieldArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object inField = arr$[i$];
      if (inField instanceof Integer)
        cs.setInt(i++, Integer.parseInt((String)inField));
      else
        cs.setString(i++, (String)inField);
    }
  }

  public void setOutField(CallableStatement cs, int outType, int startIndex, String[] outFieldArray)
    throws SQLException
  {
    for (int j = 0; j < outFieldArray.length; ++j)
      cs.registerOutParameter(startIndex++, 12);
  }
}