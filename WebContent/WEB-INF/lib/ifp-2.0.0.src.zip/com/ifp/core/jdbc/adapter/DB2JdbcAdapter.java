package com.ifp.core.jdbc.adapter;

import com.ifp.core.util.StringUtil;
import java.sql.CallableStatement;
import java.sql.SQLException;

public class DB2JdbcAdapter extends AbstractJdbcAdapter
{
  public String getSequenceNumberSql(String sequenceName)
  {
    return "SELECT NEXTVAL FOR " + sequenceName + " FROM SYSIBM.SYSDUMMY1";
  }

  public String getExecuteProcedureSql(String procedureName, int outType, String[] inFields, String[] outFields) {
    if (null == inFields)
      inFields = new String[0];

    if (null == outFields) {
      outFields = new String[0];
    }

    StringBuffer sql = new StringBuffer("{CALL ");
    sql.append(procedureName).append("(");
    int i = 0;
    for (int j = 0; j < inFields.length; ++j) {
      if (i == 0)
        sql.append("?");
      else
        sql.append(",?");

      ++i;
    }

    if (outType == 2)
      for (j = 0; j < outFields.length; ++j) {
        if (i == 0)
          sql.append("?");
        else
          sql.append(",?");

        ++i;
      }

    sql.append(")}");

    return sql.toString();
  }

  public String getCountSql(String querySql)
  {
    return "SELECT COUNT(1) FROM (" + querySql + ") SUM WITH UR";
  }

  public void setOutField(CallableStatement cs, String outType, int startIndex, String[] outFieldArray) throws SQLException {
    if ((null != outType) && (!(outType.equals("2"))))
      for (int j = 0; j < outFieldArray.length; ++j)
        cs.registerOutParameter(startIndex++, 12);
  }

  public String getPageQuerySql(String queryFields, String queryTables, String queryCondition, String queryOrder, int startIndex, int endIndex)
  {
    StringBuffer querySql = new StringBuffer();
    querySql.append("SELECT ").append(queryFields).append(" FROM (SELECT ").append(queryFields).append(",ROW_NUMBER()");
    if (StringUtil.hasText(queryOrder))
      querySql.append(" OVER(ORDER BY ").append(queryOrder).append(") ROWNUM");
    else {
      querySql.append(" OVER() ROWNUM");
    }

    querySql.append(" FROM ").append(queryTables);
    if (StringUtil.hasText(queryCondition)) {
      querySql.append(" WHERE ").append(queryCondition);
    }

    querySql.append(") AS TEMP1 WHERE ROWNUM BETWEEN ").append(startIndex).append(" AND ").append(endIndex).append(" WITH UR");

    return querySql.toString();
  }
}