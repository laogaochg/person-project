package com.ifp.core.errorcode;

public class IFPSyncErrorCodeFactory extends AbstractErrorCodeFactory
{
  public void init()
  {
  }
}