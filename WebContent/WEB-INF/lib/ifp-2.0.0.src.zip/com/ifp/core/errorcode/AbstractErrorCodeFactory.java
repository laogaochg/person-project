package com.ifp.core.errorcode;

import com.ifp.core.data.ErrorElement;
import com.ifp.core.util.StringUtil;
import java.util.HashMap;
import java.util.Map;

public class AbstractErrorCodeFactory
  implements ErrorCodeFactory
{
  public Map<String, ErrorElement> errorMap;

  public AbstractErrorCodeFactory()
  {
    this.errorMap = new HashMap();
  }

  public void init()
  {
  }

  public String getErrorMsg(String errorCode)
  {
    if (StringUtil.hasText(errorCode)) {
      ErrorElement errorElement = (ErrorElement)this.errorMap.get(errorCode);
      if (null != errorElement)
        return errorElement.getErrorMsg();

      return "";
    }

    return "";
  }

  public void setErrorElement(ErrorElement errorElement)
  {
    this.errorMap.put(errorElement.getErrorCode(), errorElement);
  }

  public ErrorElement getErrorElement(String errorCode, String errorMsg) {
    if ((StringUtil.hasText(errorCode)) && 
      (null != this.errorMap.get(errorCode))) {
      return ((ErrorElement)this.errorMap.get(errorCode));
    }

    return null;
  }

  public Map<String, ErrorElement> getErrorMap() {
    return this.errorMap;
  }

  public void setErrorMap(Map<String, ErrorElement> errorMap) {
    this.errorMap = errorMap;
  }

  public String getShowErrorCode(String errorCode)
  {
    ErrorElement errorElement = (ErrorElement)this.errorMap.get(errorCode);
    if (null != errorElement)
      return errorElement.getShowErrorCode();

    return errorCode;
  }
}