package com.ifp.core.errorcode;

import com.ifp.core.data.ErrorElement;
import com.ifp.core.jdbc.DataSourceHandle;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class IFPErrorCodeFactory extends AbstractErrorCodeFactory
{
  private DataSourceHandle dataSourceHandle;
  private String dataSource;
  public String initSql;

  public void init()
  {
    try
    {
      initErrorCodeBySql();
    } catch (SQLException e) {
      Trace.log("CORE", 3, "init errorCode Error ...{}", e);
    }
  }

  public String getInitSql() {
    return this.initSql;
  }

  public void setInitSql(String sql) {
    this.initSql = sql;
  }

  public DataSourceHandle getDataSourceHandle() {
    return this.dataSourceHandle;
  }

  public void setDataSourceHandle(DataSourceHandle dataSourceHandle) {
    this.dataSourceHandle = dataSourceHandle;
  }

  public String getDataSource() {
    return this.dataSource;
  }

  public void setDataSource(String dataSource) {
    this.dataSource = dataSource;
  }

  public void initErrorCodeBySql()
    throws SQLException
  {
    if ((this.dataSourceHandle != null) && (this.dataSource != null) && (StringUtil.hasText(this.initSql)))
    {
      List rstList = this.dataSourceHandle.querySQL(this.dataSource, this.initSql);
      for (Iterator i$ = rstList.iterator(); i$.hasNext(); ) { String[] rsts = (String[])i$.next();
        ErrorElement errorElement = new ErrorElement();
        errorElement.setErrorCode(rsts[0]);
        errorElement.setErrorMsg(rsts[1]);
        errorElement.setLanguage(rsts[2]);
        errorElement.setLevel(rsts[3]);
        errorElement.setChannel(rsts[4]);
        errorElement.setSyscode(rsts[5]);
        if (rsts.length > 6)
          errorElement.setShowErrorCode(rsts[6]);
        else
          errorElement.setShowErrorCode(rsts[0]);

        this.errorMap.put(errorElement.getErrorCode(), errorElement);
      }
    }
  }
}