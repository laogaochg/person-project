package com.ifp.core.errorcode;

import com.ifp.core.data.ErrorElement;

public abstract interface ErrorCodeFactory
{
  public abstract void init();

  public abstract String getErrorMsg(String paramString);

  public abstract String getShowErrorCode(String paramString);

  public abstract void setErrorElement(ErrorElement paramErrorElement);

  public abstract ErrorElement getErrorElement(String paramString1, String paramString2);
}