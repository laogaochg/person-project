package com.ifp.core.ftp.client;

import com.ifp.core.exception.FtpException;
import java.io.File;

public abstract interface IFtpClientService
{
  public abstract boolean upload(File paramFile, String paramString1, String paramString2, boolean paramBoolean)
    throws FtpException;

  public abstract boolean upload(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
    throws FtpException;

  public abstract boolean download(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean)
    throws FtpException;
}