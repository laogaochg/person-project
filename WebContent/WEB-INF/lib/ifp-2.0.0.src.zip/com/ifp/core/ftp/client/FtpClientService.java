package com.ifp.core.ftp.client;

import com.ifp.core.exception.FtpCloseException;
import com.ifp.core.exception.FtpConnectException;
import com.ifp.core.exception.FtpException;
import com.ifp.core.exception.FtpTransferException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.FolderUtil;
import com.ifp.core.util.StringUtil;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

public class FtpClientService
  implements IFtpClientService
{
  private String ip;
  private int port;
  private String userName;
  private String password;
  private int timeOut;
  private String localEncoding;
  private String serverEncoding;
  private int fileType;
  private String targetFileNameRegex;
  private String sourceFileNameRegex;

  public FtpClientService()
  {
    this.timeOut = 60000;

    this.localEncoding = "GBK";

    this.serverEncoding = "ISO-8859-1";

    this.fileType = 2;

    this.targetFileNameRegex = ".*[/*:?\"<>|\\\\]+.*";

    this.sourceFileNameRegex = ".*[/:?\"<>|\\\\]+.*";
  }

  public boolean upload(File srcFile, String targetFilePath, String targetFileName, boolean createFlag)
    throws FtpException
  {
    Trace.logInfo("FTP", "upload file==>srcFilePath:{},targetFilePath:{},targetFileName:{}", new Object[] { srcFile.getAbsolutePath(), targetFilePath, targetFileName });

    if (!(srcFile.exists()))
      throw new FtpException("srcFile is not exists:" + srcFile.getAbsolutePath());

    if (!(checkFileName(targetFileName, this.targetFileNameRegex))) {
      throw new FtpException("targetFileName included illegal character");
    }

    boolean flag = false;
    FTPClient ftpClient = connect();
    try {
      if ((srcFile.isFile()) && 
        (!(ftpClient.changeWorkingDirectory(changeEncoding(targetFilePath, this.localEncoding, this.serverEncoding))))) {
        if (createFlag)
          createDirectory(ftpClient, targetFilePath);
        else
          throw new FtpException("targetFilePath is not exists:" + targetFilePath);

      }

      if (!(StringUtil.hasText(targetFileName)))
        targetFileName = srcFile.getName();

      uploadFile(ftpClient, srcFile, targetFilePath, targetFileName, createFlag);
      Trace.logInfo("FTP", "upload {}{} successful!", new Object[] { targetFilePath, targetFileName });
      try
      {
        ftpClient.disconnect();
      } catch (IOException e1) {
        throw new FtpException("disconnect ftpServer error!" + this.ip + ":" + this.port);
      }
    }
    catch (FtpException e)
    {
    }
    catch (Exception e)
    {
    }
    finally
    {
      try
      {
        ftpClient.disconnect();
      } catch (IOException e1) {
        throw new FtpException("disconnect ftpServer error!" + this.ip + ":" + this.port);
      }
    }

    return flag;
  }

  public boolean upload(String sourceFilePath, String targetFilePath, String targetFileName, boolean createFlag)
    throws FtpException
  {
    return upload(new File(sourceFilePath), targetFilePath, targetFileName, createFlag);
  }

  private void uploadFile(FTPClient ftpClient, File file, String targetFilePath, String targetFileName, boolean createFlag)
    throws FtpTransferException
  {
    try
    {
      if (file.isDirectory()) {
        String dirName = changeEncoding(targetFilePath, this.localEncoding, this.serverEncoding);
        if (!(ftpClient.changeWorkingDirectory(dirName)))
          if (createFlag)
            createDirectory(ftpClient, dirName);
          else
            throw new FtpException("targetFilePath is not exists:" + targetFilePath);


        File[] files = file.listFiles();
        File[] arr$ = files; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { File f = arr$[i$];
          uploadFile(ftpClient, f, f.getName(), f.getName(), true);
        }
        ftpClient.changeToParentDirectory();
      } else {
        String fileName = changeEncoding(targetFileName, this.localEncoding, this.serverEncoding);
        FileInputStream fis = null;
        try {
          fis = new FileInputStream(file);
          ftpClient.storeFile(fileName, fis);
          Trace.logDebug("FTP", "upload file complete: {}", new Object[] { file.getAbsolutePath() });
        } finally {
          IOUtils.closeQuietly(fis);
        }
      }
    } catch (FtpTransferException e) {
      throw e;
    } catch (Exception e) {
      throw new FtpTransferException(e);
    }
  }

  private void createDirectory(FTPClient ftpClient, String path)
    throws Exception
  {
    if (path.indexOf("/") == 0)
      path = path.substring(1);

    String[] paths = path.split("/");
    int index = 0;
    while (index < paths.length) {
      String dirPath = paths[index];
      if (StringUtil.hasText(dirPath)) {
        String dPath = changeEncoding(dirPath, this.localEncoding, this.serverEncoding);
        if (!(ftpClient.changeWorkingDirectory(dPath)))
          if (ftpClient.makeDirectory(dPath))
            ftpClient.changeWorkingDirectory(dPath);
          else
            throw new Exception("create directory fail: " + dirPath);
      }
      else
      {
        throw new Exception("directory path error: " + path);
      }
      ++index;
    }
  }

  public boolean download(String targetFilePath, String targetFileName, String sourceFilePath, String sourceFileName, boolean createFlag)
    throws FtpException
  {
    Trace.logInfo("FTP", "download file==>targetFilePath:{},targetFileName:{},sourceFilePath:{},sourceFileName:{}", new Object[] { targetFilePath, targetFileName, sourceFilePath, sourceFileName });

    if (!(checkFileName(targetFileName, this.targetFileNameRegex)))
      throw new FtpException("targetFileName included illegal character");

    if (!(checkFileName(sourceFileName, this.sourceFileNameRegex))) {
      throw new FtpException("sourceFileName included illegal character");
    }

    FTPClient ftpClient = connect();
    boolean flag = false;
    try {
      if (!(ftpClient.changeWorkingDirectory(changeEncoding(sourceFilePath, this.localEncoding, this.serverEncoding))))
        throw new FtpException("sourceFilePath is not exists:" + sourceFilePath);

      if ((StringUtil.hasText(sourceFileName)) && (sourceFileName.indexOf("*") < 0)) {
        File file = new File(targetFilePath);
        if ((!(file.exists())) || (!(file.isDirectory()))) {
          if (createFlag)
            FolderUtil.creatDirectory(targetFilePath);
          else
            throw new FtpException("targetFilePath is not exists:" + targetFilePath);

        }

        if (StringUtil.hasText(targetFileName))
          targetFilePath = targetFilePath + targetFileName;
        else {
          targetFilePath = targetFilePath + sourceFileName;
        }

        FileOutputStream fos = null;
        try {
          fos = new FileOutputStream(targetFilePath);
          String filePath = sourceFilePath + sourceFileName;
          ftpClient.retrieveFile(filePath, fos);
          Trace.logDebug("FTP", "download file complete: {}", new Object[] { filePath });
        } catch (IOException e) {
        }
        finally {
          IOUtils.closeQuietly(fos);
        }
      } else {
        if (!(StringUtil.hasText(sourceFileName)))
          sourceFileName = "";

        if (StringUtil.hasText(targetFileName))
          targetFilePath = targetFilePath + targetFileName;

        FolderUtil.creatDirectory(targetFilePath);
        downloadDirectory(ftpClient, sourceFilePath, targetFilePath, sourceFileName);
      }

      try
      {
        ftpClient.disconnect();
      } catch (IOException e1) {
        throw new FtpCloseException("disconnect ftpServer error!" + this.ip + ":" + this.port);
      }
    }
    catch (FtpException e)
    {
    }
    catch (Exception e)
    {
    }
    finally
    {
      try
      {
        ftpClient.disconnect();
      } catch (IOException e1) {
        throw new FtpCloseException("disconnect ftpServer error!" + this.ip + ":" + this.port);
      }
    }

    return flag;
  }

  private FTPClient connect()
    throws FtpConnectException
  {
    FTPClient ftpClient = new FTPClient();
    try {
      ftpClient.connect(this.ip, this.port);
      if (FTPReply.isPositiveCompletion(ftpClient.getReplyCode()))
        if (ftpClient.login(this.userName, this.password)) {
          if (FTPReply.isPositiveCompletion(ftpClient.sendCommand("OPTS UTF8", "ON")))
          {
            this.localEncoding = "UTF-8";
          }
          ftpClient.setControlEncoding(this.localEncoding);
          ftpClient.enterLocalPassiveMode();

          ftpClient.setFileType(this.fileType);
        } else {
          throw new FtpConnectException("Connet ftpServer error! Please check user or password" + this.ip + ":" + this.port);
        }

      ftpClient.setSoTimeout(this.timeOut);
    } catch (IOException e) {
      try {
        if (ftpClient.isConnected())
          ftpClient.disconnect();
      }
      catch (IOException e1) {
        throw new FtpConnectException("disconnect ftpServer error!" + this.ip + ":" + this.port);
      }
      throw new FtpConnectException("Connet ftpServer error! Please check the Configuration" + this.ip + ":" + this.port);
    }
    Trace.logDebug("FTP", "connect successful==>ip:{}, port:{}", new Object[] { this.ip, Integer.valueOf(this.port) });
    return ftpClient;
  }

  private void downloadDirectory(FTPClient ftpClient, String sourceFilePath, String targetFilePath, String sourceFileNameRegex)
    throws FtpTransferException
  {
    FTPFile[] files;
    try
    {
      files = ftpClient.listFiles();
      FTPFile[] arr$ = files; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { FTPFile file = arr$[i$];
        String fileName = file.getName();
        if (file.isDirectory()) {
          if (!(StringUtil.hasText(sourceFileNameRegex))) {
            String srcPath = sourceFilePath + fileName;
            if (!(ftpClient.changeWorkingDirectory(changeEncoding(srcPath, this.localEncoding, this.serverEncoding))))
              throw new FtpTransferException("not found file path:" + sourceFilePath);

            String targetPath = targetFilePath + fileName;
            File fileDir = new File(targetPath);
            if ((!(fileDir.isDirectory())) && (!(fileDir.mkdir())))
              throw new FtpTransferException("create directory error: " + targetPath);

            downloadDirectory(ftpClient, srcPath + "/", targetPath + "/", sourceFileNameRegex);
            ftpClient.changeToParentDirectory();
          }
        }
        else if ((!(StringUtil.hasText(sourceFileNameRegex))) || (matches(fileName, sourceFileNameRegex))) {
          FileOutputStream fos = null;
          try {
            fos = new FileOutputStream(targetFilePath + fileName);
            String filePath = sourceFilePath + fileName;
            ftpClient.retrieveFile(filePath, fos);
            Trace.logDebug("FTP", "download file complete: {}", new Object[] { filePath });
          } finally {
            IOUtils.closeQuietly(fos);
          }
        }
      }
    }
    catch (FtpTransferException e) {
      throw e;
    } catch (Exception e) {
      throw new FtpTransferException(e);
    }
  }

  protected boolean matches(String name, String regex)
  {
    regex = regex.trim() + " ";
    name = name + " ";
    String[] regexs = regex.split("\\*");
    for (int i = 0; i < regexs.length; ++i) {
      String s = regexs[i];
      if (i == 0) {
        if (!(s.equals(""))) {
          if (!(name.startsWith(s))) {
            return false;
          }

          name = name.substring(s.length()); }
      } else {
        if (i == regexs.length - 1) {
          if ((s.equals(" ")) || 
            (name.endsWith(s))) break label166;
          return false;
        }

        int index = name.indexOf(s);
        label166: if (index >= 0)
          name = name.substring(index + s.length());
        else
          return false;
      }

    }

    return true;
  }

  private String changeEncoding(String name, String sEncoding, String tEncoding) throws UnsupportedEncodingException {
    return new String(name.getBytes(sEncoding), tEncoding);
  }

  protected boolean checkFileName(String fileName, String fileNameRegex)
  {
    if (StringUtil.hasText(fileName))
    {
      return (!(fileName.matches(fileNameRegex)));
    }

    return true;
  }

  public String getIp()
  {
    return this.ip;
  }

  public void setIp(String ip) {
    this.ip = ip;
  }

  public int getPort() {
    return this.port;
  }

  public void setPort(int port) {
    this.port = port;
  }

  public String getUserName() {
    return this.userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getPassword() {
    return this.password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public int getFileType() {
    return this.fileType;
  }

  public void setFileType(int fileType) {
    this.fileType = fileType;
  }

  public String getLocalEncoding() {
    return this.localEncoding;
  }

  public void setLocalEncoding(String localEncoding) {
    this.localEncoding = localEncoding;
  }

  public String getServerEncoding() {
    return this.serverEncoding;
  }

  public void setServerEncoding(String serverEncoding) {
    this.serverEncoding = serverEncoding;
  }

  public String getTargetFileNameRegex() {
    return this.targetFileNameRegex;
  }

  public void setTargetFileNameRegex(String targetFileNameRegex) {
    this.targetFileNameRegex = targetFileNameRegex;
  }

  public String getSourceFileNameRegex() {
    return this.sourceFileNameRegex;
  }

  public void setSourceFileNameRegex(String sourceFileNameRegex) {
    this.sourceFileNameRegex = sourceFileNameRegex;
  }

  public int getTimeOut() {
    return this.timeOut;
  }

  public void setTimeOut(int timeOut) {
    this.timeOut = timeOut;
  }
}