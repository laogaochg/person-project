package com.ifp.core.ftp.client;

import com.ifp.core.exception.FtpException;
import java.io.File;
import java.util.Map;

public class FtpClientHandle
{
  private Map<String, IFtpClientService> ftpServiceMap;

  public void upload(String ftpId, String sourceFilePath, String targetFilePath, String targetFileName, boolean createFlag)
    throws FtpException
  {
    IFtpClientService fcService = (IFtpClientService)this.ftpServiceMap.get(ftpId);
    fcService.upload(sourceFilePath, targetFilePath, targetFileName, createFlag);
  }

  public void upload(String ftpId, File sourceFile, String targetFilePath, String targetFileName, boolean createFlag)
    throws FtpException
  {
    IFtpClientService fcService = (IFtpClientService)this.ftpServiceMap.get(ftpId);
    fcService.upload(sourceFile, targetFilePath, targetFileName, createFlag);
  }

  public void download(String ftpId, String targetFilePath, String targetFileName, String sourceFilePath, String sourceFileName, boolean createFlag)
    throws FtpException
  {
    IFtpClientService fcService = (IFtpClientService)this.ftpServiceMap.get(ftpId);
    fcService.download(targetFilePath, targetFileName, sourceFilePath, sourceFileName, createFlag);
  }

  public Map<String, IFtpClientService> getFtpServiceMap() {
    return this.ftpServiceMap;
  }

  public void setFtpServiceMap(Map<String, IFtpClientService> ftpServiceMap) {
    this.ftpServiceMap = ftpServiceMap;
  }
}