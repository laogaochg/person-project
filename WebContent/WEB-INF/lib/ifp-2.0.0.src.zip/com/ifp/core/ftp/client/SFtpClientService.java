package com.ifp.core.ftp.client;

import com.ifp.core.exception.FtpConnectException;
import com.ifp.core.exception.FtpException;
import com.ifp.core.exception.FtpTransferException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.FolderUtil;
import com.ifp.core.util.StringUtil;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;

public class SFtpClientService
  implements IFtpClientService
{
  private String ip;
  private int port;
  private String userName;
  private String password;
  private int timeOut;
  private String encoding;
  private String targetFileNameRegex;
  private String sourceFileNameRegex;

  public SFtpClientService()
  {
    this.timeOut = 60000;

    this.encoding = "UTF-8";

    this.targetFileNameRegex = ".*[/*:?\"<>|\\\\]+.*";

    this.sourceFileNameRegex = ".*[/:?\"<>|\\\\]+.*";
  }

  public boolean upload(File srcFile, String targetFilePath, String targetFileName, boolean createFlag)
    throws FtpException
  {
    Trace.logInfo("FTP", "upload file==>srcFilePath:{},targetFilePath:{},targetFileName:{}", new Object[] { srcFile.getAbsolutePath(), targetFilePath, targetFileName });

    if (!(srcFile.exists()))
      throw new FtpException("srcFile is not exists:" + srcFile.getAbsolutePath());

    if (!(checkFileName(targetFileName, this.targetFileNameRegex))) {
      throw new FtpException("targetFileName included illegal character");
    }

    boolean flag = false;
    ChannelSftp sftpClient = connect();
    try {
      if (!(openAndMakeDir(sftpClient, targetFilePath))) {
        throw new FtpException("targetFilePath is not exists:" + targetFilePath);
      }

      if (!(StringUtil.hasText(targetFileName)))
        targetFileName = srcFile.getName();

      uploadFile(sftpClient, srcFile, targetFilePath, targetFileName, createFlag);
      Trace.logInfo("FTP", "upload {}{} successful!", new Object[] { targetFilePath, targetFileName });
      try
      {
        disconnect(sftpClient);
      } catch (Exception e) {
        throw new FtpException("disconnect ftpServer error!" + this.ip + ":" + this.port);
      }
    }
    catch (FtpException e)
    {
    }
    catch (Exception e)
    {
    }
    finally
    {
      try
      {
        disconnect(sftpClient);
      } catch (Exception e) {
        throw new FtpException("disconnect ftpServer error!" + this.ip + ":" + this.port);
      }
    }

    return flag;
  }

  public boolean upload(String sourceFilePath, String targetFilePath, String targetFileName, boolean createFlag)
    throws FtpException
  {
    return upload(new File(sourceFilePath), targetFilePath, targetFileName, createFlag);
  }

  private void uploadFile(ChannelSftp sftpClient, File file, String targetFilePath, String targetFileName, boolean createFlag)
    throws FtpTransferException
  {
    try
    {
      if (file.isDirectory()) {
        if (createFlag)
          mkDir(sftpClient, targetFilePath);
        else {
          throw new FtpException("targetFilePath is not exists:" + targetFilePath);
        }

        sftpClient.cd(targetFilePath);
        String nowPath = sftpClient.pwd();
        File[] files = file.listFiles();
        File[] arr$ = files; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { File f = arr$[i$];
          uploadFile(sftpClient, f, f.getName(), f.getName(), true);
          sftpClient.cd(nowPath);
        }
      } else {
        FileInputStream fis = null;
        try {
          fis = new FileInputStream(file);
          sftpClient.put(fis, targetFileName);
          Trace.logDebug("FTP", "upload file complete: {}", new Object[] { file.getAbsolutePath() });
        } finally {
          IOUtils.closeQuietly(fis);
        }
      }
    } catch (FtpTransferException e) {
      throw e;
    } catch (Exception e) {
      throw new FtpTransferException(e);
    }
  }

  public boolean download(String targetFilePath, String targetFileName, String sourceFilePath, String sourceFileName, boolean createFlag)
    throws FtpException
  {
    Trace.logInfo("FTP", "download file==>targetFilePath:{},targetFileName:{},sourceFilePath:{},sourceFileName:{}", new Object[] { targetFilePath, targetFileName, sourceFilePath, sourceFileName });

    if (!(checkFileName(targetFileName, this.targetFileNameRegex)))
      throw new FtpException("targetFileName included illegal character");

    if (!(checkFileName(sourceFileName, this.sourceFileNameRegex))) {
      throw new FtpException("sourceFileName included illegal character");
    }

    ChannelSftp sftpClient = connect();
    boolean flag = false;
    try {
      if (!(openAndMakeDir(sftpClient, sourceFilePath)))
        throw new FtpException("sourceFilePath is not exists:" + sourceFilePath);

      if ((StringUtil.hasText(sourceFileName)) && (sourceFileName.indexOf("*") < 0)) {
        File file = new File(targetFilePath);
        if ((!(file.exists())) || (!(file.isDirectory()))) {
          if (createFlag)
            FolderUtil.creatDirectory(targetFilePath);
          else
            throw new FtpException("targetFilePath is not exists:" + targetFilePath);

        }

        if (StringUtil.hasText(targetFileName))
          targetFilePath = targetFilePath + targetFileName;
        else {
          targetFilePath = targetFilePath + sourceFileName;
        }

        FileOutputStream fos = null;
        try {
          fos = new FileOutputStream(targetFilePath);
          sftpClient.cd(sourceFilePath);
          String filePath = sourceFilePath + sourceFileName;
          sftpClient.get(filePath, fos);
          Trace.logDebug("FTP", "download file complete: {}", new Object[] { filePath });
        } catch (Exception e) {
        }
        finally {
          IOUtils.closeQuietly(fos);
        }
      } else {
        if (!(StringUtil.hasText(sourceFileName)))
          sourceFileName = "";

        if (StringUtil.hasText(targetFileName))
          targetFilePath = targetFilePath + targetFileName;

        FolderUtil.creatDirectory(targetFilePath);
        downloadDirectory(sftpClient, sourceFilePath, targetFilePath, sourceFileName);
      }

      try
      {
        disconnect(sftpClient);
      } catch (Exception e) {
        throw new FtpException("disconnect ftpServer error!" + this.ip + ":" + this.port);
      }
    }
    catch (FtpException e)
    {
    }
    catch (Exception e)
    {
    }
    finally
    {
      try
      {
        disconnect(sftpClient);
      } catch (Exception e) {
        throw new FtpException("disconnect ftpServer error!" + this.ip + ":" + this.port);
      }
    }

    return flag;
  }

  private void downloadDirectory(ChannelSftp sftpClient, String sourceFilePath, String targetFilePath, String sourceFileNameRegex)
    throws FtpTransferException
  {
    Vector sftpFile;
    try
    {
      sftpFile = sftpClient.ls(sourceFilePath);
      Iterator sftpFileIterator = sftpFile.iterator();
      while (true) { String fileName;
        while (true) { do { if (!(sftpFileIterator.hasNext())) break label351;
            ChannelSftp.LsEntry isEntity = (ChannelSftp.LsEntry)sftpFileIterator.next();
            fileName = isEntity.getFilename(); }
          while (fileName.equals(".")); if (!(fileName.equals("..")))
            break;
        }

        sftpClient.cd(sourceFilePath);
        String srcPath = sourceFilePath + fileName;
        label351: if (isDir(sftpClient, srcPath)) {
          if (!(StringUtil.hasText(sourceFileNameRegex))) {
            String targetPath = targetFilePath + fileName;
            File fileDir = new File(targetPath);
            if ((!(fileDir.isDirectory())) && (!(fileDir.mkdir())))
              throw new FtpTransferException("create directory error: " + targetPath);

            downloadDirectory(sftpClient, srcPath + "/", targetPath + "/", sourceFileNameRegex);
          }

        }
        else if ((!(StringUtil.hasText(sourceFileNameRegex))) || (matches(fileName, sourceFileNameRegex))) {
          FileOutputStream fos = null;
          try {
            fos = new FileOutputStream(targetFilePath + fileName);
            String filePath = sourceFilePath + fileName;
            sftpClient.get(filePath, fos);
            Trace.logDebug("FTP", "download file complete: {}", new Object[] { filePath });
          } finally {
            IOUtils.closeQuietly(fos);
          }
        }
      }
    }
    catch (FtpTransferException e) {
      throw e;
    } catch (Exception e) {
      throw new FtpTransferException(e);
    }
  }

  protected boolean matches(String name, String regex)
  {
    regex = regex.trim() + " ";
    name = name + " ";
    String[] regexs = regex.split("\\*");
    for (int i = 0; i < regexs.length; ++i) {
      String s = regexs[i];
      if (i == 0) {
        if (!(s.equals(""))) {
          if (!(name.startsWith(s))) {
            return false;
          }

          name = name.substring(s.length()); }
      } else {
        if (i == regexs.length - 1) {
          if ((s.equals(" ")) || 
            (name.endsWith(s))) break label166;
          return false;
        }

        int index = name.indexOf(s);
        label166: if (index >= 0)
          name = name.substring(index + s.length());
        else
          return false;
      }

    }

    return true;
  }

  protected boolean checkFileName(String fileName, String fileNameRegex)
  {
    if (StringUtil.hasText(fileName))
    {
      return (!(fileName.matches(fileNameRegex)));
    }

    return true;
  }

  public ChannelSftp connect()
    throws FtpConnectException
  {
    ChannelSftp sftp = new ChannelSftp();
    try {
      JSch jsch = new JSch();
      Session sshSession = jsch.getSession(this.userName, this.ip, this.port);
      sshSession.setPassword(this.password);
      Properties sshConfig = new Properties();
      sshConfig.put("StrictHostKeyChecking", "no");
      sshSession.setConfig(sshConfig);

      sshSession.setTimeout(this.timeOut);
      sshSession.connect();
      Channel channel = sshSession.openChannel("sftp");
      channel.connect();
      sftp = (ChannelSftp)channel;
      sftp.setFilenameEncoding(this.encoding);
    } catch (Exception e) {
      throw new FtpConnectException("Connet ftpServer error! Please check the Configuration" + this.ip + ":" + this.port, e);
    }
    return sftp;
  }

  public boolean openAndMakeDir(ChannelSftp sftp, String directory)
  {
    String now;
    try
    {
      now = sftp.pwd();
      if (now.equals(directory))
        return true;
      try
      {
        sftp.cd(directory);
        return true;
      } catch (SftpException e) {
        if (directory.startsWith(now))
          directory = directory.replaceFirst(now, "");

        String[] dirList = directory.split("/");
        dirList = (String[])(String[])ArrayUtils.removeElement(dirList, "");
        String[] arr$ = dirList; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ) { String dir = arr$[i$];
          try {
            sftp.cd(dir);
          } catch (SftpException e1) {
            sftp.mkdir(dir);
            sftp.cd(dir);
          }
          ++i$;
        }

        return true;
      }
    }
    catch (SftpException e) {
      Trace.logError("FTP", "openDir Exception : " + directory, e); }
    return false;
  }

  public void mkDir(ChannelSftp sftp, String dirName)
  {
    String[] dirs = dirName.split("/");
    try {
      String now = sftp.pwd();
      for (int i = 0; i < dirs.length; ) {
        try {
          sftp.cd(dirs[i]);
        } catch (SftpException e) {
          sftp.mkdir(dirs[i]);
          sftp.cd(dirs[i]);
        }
        ++i;
      }

      sftp.cd(now);
    } catch (SftpException e) {
      Trace.logError("FTP", "mkDir Exception : " + e);
    }
  }

  public static boolean isDir(ChannelSftp sftp, String directory)
  {
    try
    {
      sftp.cd(directory);
      return true; } catch (SftpException e) {
    }
    return false;
  }

  public static void disconnect(ChannelSftp sftp)
    throws JSchException
  {
    if (null != sftp) {
      sftp.disconnect();

      if (null != sftp.getSession())
        sftp.getSession().disconnect();
    }
  }

  public String getIp()
  {
    return this.ip;
  }

  public void setIp(String ip) {
    this.ip = ip;
  }

  public int getPort() {
    return this.port;
  }

  public void setPort(int port) {
    this.port = port;
  }

  public String getUserName() {
    return this.userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getPassword() {
    return this.password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getTargetFileNameRegex() {
    return this.targetFileNameRegex;
  }

  public void setTargetFileNameRegex(String targetFileNameRegex) {
    this.targetFileNameRegex = targetFileNameRegex;
  }

  public String getSourceFileNameRegex() {
    return this.sourceFileNameRegex;
  }

  public void setSourceFileNameRegex(String sourceFileNameRegex) {
    this.sourceFileNameRegex = sourceFileNameRegex;
  }

  public int getTimeOut() {
    return this.timeOut;
  }

  public void setTimeOut(int timeOut) {
    this.timeOut = timeOut;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }
}