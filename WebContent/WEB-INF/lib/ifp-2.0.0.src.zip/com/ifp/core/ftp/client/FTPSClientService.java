package com.ifp.core.ftp.client;

import com.ifp.core.exception.FtpConnectException;
import com.ifp.core.exception.FtpException;
import com.ifp.core.exception.FtpTransferException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.FolderUtil;
import com.ifp.core.util.StringUtil;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;
import org.apache.commons.io.IOUtils;

@Deprecated
public class FTPSClientService
  implements IFtpClientService
{
  private String ip;
  private int port;
  private String userName;
  private String password;
  private String localEncoding;
  private String serverEncoding;
  private String targetFileNameRegex;
  private String sourceFileNameRegex;
  private int fileType;
  private ChannelSftp sftp;
  private Channel channel;
  private Session sshSession;

  public FTPSClientService()
  {
    this.localEncoding = "GBK";

    this.serverEncoding = "ISO-8859-1";

    this.targetFileNameRegex = ".*[/*:?\"<>|\\\\]+.*";

    this.sourceFileNameRegex = ".*[/:?\"<>|\\\\]+.*";

    this.fileType = 0;
    this.sftp = null;
    this.channel = null;
    this.sshSession = null;
  }

  private ChannelSftp connect()
    throws FtpConnectException
  {
    JSch jsch;
    try
    {
      jsch = new JSch();
      jsch.getSession(this.userName, this.ip, this.port);
      this.sshSession = jsch.getSession(this.userName, this.ip, this.port);
      this.sshSession.setPassword(this.password);
      Properties sshConfig = new Properties();
      sshConfig.put("StrictHostKeyChecking", "no");
      this.sshSession.setConfig(sshConfig);
      this.sshSession.connect();
      this.channel = this.sshSession.openChannel("sftp");
      this.channel.connect();
      this.sftp = ((ChannelSftp)this.channel);
    } catch (Exception e) {
      throw new FtpConnectException("Connet ftpServer error! Please check the Configuration" + this.ip + ":" + this.port, e);
    }
    return this.sftp;
  }

  private static void closeChannel(Channel channel) {
    if ((channel != null) && 
      (channel.isConnected()))
      channel.disconnect();
  }

  private static void closeSession(Session session)
  {
    if ((session != null) && 
      (session.isConnected()))
      session.disconnect();
  }

  public boolean upload(File srcFile, String targetFilePath, String targetFileName, boolean createFlag)
    throws FtpException
  {
    Trace.logInfo("FTP", "upload file==>srcFilePath:{},targetFilePath:{},targetFileName:{}", new Object[] { srcFile.getAbsolutePath(), targetFilePath, targetFileName });
    if (!(srcFile.exists())) {
      throw new FtpException("srcFile is not exists:" + srcFile.getAbsolutePath());
    }

    if (!(checkFileName(targetFileName, this.targetFileNameRegex))) {
      throw new FtpException("targetFileName included illegal character");
    }

    boolean flag = false;
    this.sftp = connect();
    try
    {
      if (!(StringUtil.hasText(targetFileName)))
        targetFileName = srcFile.getName();

      uploadFile(this.sftp, srcFile, targetFilePath, targetFileName, createFlag);
      Trace.logInfo("FTP", "upload {}{} successful!", new Object[] { targetFilePath, targetFileName });
      flag = true;
    } catch (FtpException e) {
    }
    catch (Exception e) {
    }
    finally {
      this.sftp.quit();
      closeChannel(this.channel);
      closeSession(this.sshSession);
    }
    return flag;
  }

  public boolean upload(String sourceFilePath, String targetFilePath, String targetFileName, boolean createFlag)
    throws FtpException
  {
    if (!(targetFilePath.endsWith("/")))
      targetFilePath = targetFilePath + "/";

    if (!(sourceFilePath.endsWith("/")))
      sourceFilePath = sourceFilePath + "/";

    return upload(new File(sourceFilePath), targetFilePath, targetFileName, createFlag);
  }

  private void uploadFile(ChannelSftp sftp, File file, String targetFilePath, String targetFileName, boolean createFlag)
    throws FtpTransferException
  {
    try
    {
      if (file.isDirectory()) {
        File[] files = file.listFiles();
        File[] arr$ = files; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { File f = arr$[i$];
          if (f.isDirectory()) {
            String targetFilePath2 = targetFilePath + f.getName() + "/";
            try {
              sftp.cd(targetFilePath2);
            } catch (Exception e) {
              if (createFlag)
                sftp.mkdir(targetFilePath2);
              else
                throw new FtpException("targetFilePath is not exists:" + targetFilePath);
            }

            uploadFile(sftp, f, targetFilePath2, f.getName(), createFlag);
          } else {
            uploadFile(sftp, f, targetFilePath, f.getName(), createFlag);
          }
        }
      } else {
        FileInputStream fis = new FileInputStream(file);
        try {
          sftp.put(fis, targetFilePath + targetFileName);
          Trace.logDebug("FTP", "upload file complete: {}", new Object[] { file.getAbsolutePath() });
        } finally {
          IOUtils.closeQuietly(fis);
        }
      }
    } catch (FtpTransferException e) {
      throw e;
    } catch (Exception e) {
      throw new FtpTransferException(e);
    }
  }

  public boolean download(String targetFilePath, String targetFileName, String sourceFilePath, String sourceFileName, boolean createFlag)
    throws FtpException
  {
    Trace.logInfo("FTP", "download file==>targetFilePath:{},targetFileName:{},sourceFilePath:{},sourceFileName:{}", new Object[] { targetFilePath, targetFileName, sourceFilePath, sourceFileName });
    if (!(checkFileName(targetFileName, this.targetFileNameRegex)))
      throw new FtpException("targetFileName included illegal character");

    if (!(checkFileName(sourceFileName, this.sourceFileNameRegex))) {
      throw new FtpException("sourceFileName included illegal character");
    }

    this.sftp = connect();
    boolean flag = false;
    FileOutputStream fos = null;
    if (!(targetFilePath.endsWith("/")))
      targetFilePath = targetFilePath + "/";

    if (!(sourceFilePath.endsWith("/")))
      sourceFilePath = sourceFilePath + "/";
    try
    {
      if (StringUtil.hasText(sourceFileName)) {
        File file = new File(targetFilePath);
        if ((!(file.exists())) || (!(file.isDirectory()))) {
          if (createFlag)
            FolderUtil.creatDirectory(targetFilePath);
          else
            throw new FtpException("targetFilePath is not exists:" + targetFilePath);

        }

        if (StringUtil.hasText(targetFileName))
          targetFilePath = targetFilePath + targetFileName;
        else {
          targetFilePath = targetFilePath + sourceFileName;
        }

        fos = new FileOutputStream(targetFilePath);
        String filePath = sourceFilePath + sourceFileName;
        this.sftp.get(filePath, fos);
        Trace.logDebug("FTP", "download file complete: {}", new Object[] { filePath });
      } else {
        if (StringUtil.hasText(targetFileName))
          targetFilePath = targetFilePath + targetFileName;

        FolderUtil.creatDirectory(targetFilePath);
        downloadDirectory(this.sftp, sourceFilePath, targetFilePath);
      }
      Trace.logInfo("FTP", "download {}{} successful!", new Object[] { sourceFilePath, sourceFileName });
    } catch (FtpException e) {
    }
    catch (Exception e) {
    }
    finally {
      IOUtils.closeQuietly(fos);
      this.sftp.quit();
      closeChannel(this.channel);
      closeSession(this.sshSession);
    }

    return flag;
  }

  private void downloadDirectory(ChannelSftp sftp, String sourceFilePath, String targetFilePath)
    throws FtpTransferException
  {
    FileOutputStream fos = null;
    try {
      Vector vector = sftp.ls(sourceFilePath);
      for (Iterator i$ = vector.iterator(); i$.hasNext(); ) { Object item = i$.next();
        ChannelSftp.LsEntry entry = (ChannelSftp.LsEntry)item;
        if (!(entry.getFilename().endsWith("."))) {
          fos = new FileOutputStream(targetFilePath + entry.getFilename());
          sftp.get(sourceFilePath + entry.getFilename(), fos);
        }
      }
    } catch (Exception e) {
    }
    finally {
      closeChannel(sftp);
      closeChannel(this.channel);
      closeSession(this.sshSession);
      IOUtils.closeQuietly(fos);
    }
  }

  private String changeEncoding(String name, String sEncoding, String tEncoding) throws UnsupportedEncodingException {
    return new String(name.getBytes(sEncoding), tEncoding);
  }

  protected boolean checkFileName(String fileName, String fileNameRegex)
  {
    if (StringUtil.hasText(fileName))
    {
      return (!(fileName.matches(fileNameRegex)));
    }

    return true;
  }

  public String getIp()
  {
    return this.ip;
  }

  public void setIp(String ip) {
    this.ip = ip;
  }

  public int getPort() {
    return this.port;
  }

  public void setPort(int port) {
    this.port = port;
  }

  public String getUserName() {
    return this.userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getPassword() {
    return this.password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public int getFileType() {
    return this.fileType;
  }

  public void setFileType(int fileType) {
    this.fileType = fileType;
  }

  public String getLocalEncoding() {
    return this.localEncoding;
  }

  public void setLocalEncoding(String localEncoding) {
    this.localEncoding = localEncoding;
  }

  public String getServerEncoding() {
    return this.serverEncoding;
  }

  public void setServerEncoding(String serverEncoding) {
    this.serverEncoding = serverEncoding;
  }

  public String getTargetFileNameRegex() {
    return this.targetFileNameRegex;
  }

  public void setTargetFileNameRegex(String targetFileNameRegex) {
    this.targetFileNameRegex = targetFileNameRegex;
  }

  public String getSourceFileNameRegex() {
    return this.sourceFileNameRegex;
  }

  public void setSourceFileNameRegex(String sourceFileNameRegex) {
    this.sourceFileNameRegex = sourceFileNameRegex;
  }
}