package com.ifp.core.transaction;

import com.ifp.core.util.SpringContextsUtil;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

public class BLTransactionAdvice
{
  public Object doTransaction(ProceedingJoinPoint joinPoint)
    throws Throwable
  {
    DataSourceTransactionManager transactionManager = (DataSourceTransactionManager)SpringContextsUtil.getBean("transactionManager");

    DefaultTransactionDefinition def = new DefaultTransactionDefinition();
    def.setPropagationBehavior(3);
    TransactionStatus status = transactionManager.getTransaction(def);
    Object object = null;
    try {
      object = joinPoint.proceed();
      transactionManager.commit(status);
    } catch (Exception e) {
      transactionManager.rollback(status);
      throw e;
    }

    return object;
  }
}