package com.ifp.core.generator;

import java.util.Map;

public abstract interface IKeyGenerator
{
  public abstract String generatId();

  public abstract String generatId(Map<String, String> paramMap);
}