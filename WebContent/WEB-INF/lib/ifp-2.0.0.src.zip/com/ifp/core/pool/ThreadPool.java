package com.ifp.core.pool;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ThreadPool extends AbstractThreadPool
{
  private int corePoolSize = 500;
  private int maximumPoolSize = 500;
  private long keepAliveTime = -3763402244863557632L;
  private BlockingQueue<Runnable> workQueue;

  public ThreadPool()
  {
    setThreadPool(new ThreadPoolExecutor(this.corePoolSize, this.maximumPoolSize, this.keepAliveTime, TimeUnit.MILLISECONDS, new LinkedBlockingQueue()));
  }

  public int getCorePoolSize()
  {
    return this.corePoolSize;
  }

  public void setCorePoolSize(int corePoolSize) {
    this.corePoolSize = corePoolSize;
  }

  public int getMaximumPoolSize() {
    return this.maximumPoolSize;
  }

  public void setMaximumPoolSize(int maximumPoolSize) {
    this.maximumPoolSize = maximumPoolSize;
  }

  public long getKeepAliveTime() {
    return this.keepAliveTime;
  }

  public void setKeepAliveTime(long keepAliveTime) {
    this.keepAliveTime = keepAliveTime;
  }

  public BlockingQueue<Runnable> getWorkQueue() {
    return this.workQueue;
  }

  public void setWorkQueue(BlockingQueue<Runnable> workQueue) {
    this.workQueue = workQueue;
  }
}