package com.ifp.core.pool;

import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class CachedThreadPool extends AbstractThreadPool
{
  private int maximumPoolSize = 2147483647;
  long keepAliveTime = 60000L;

  public CachedThreadPool()
  {
    setThreadPool(new ThreadPoolExecutor(0, this.maximumPoolSize, this.keepAliveTime, TimeUnit.MILLISECONDS, new SynchronousQueue()));
  }

  public int getMaximumPoolSize()
  {
    return this.maximumPoolSize;
  }

  public void setMaximumPoolSize(int maximumPoolSize) {
    this.maximumPoolSize = maximumPoolSize;
  }

  public long getKeepAliveTime() {
    return this.keepAliveTime;
  }

  public void setKeepAliveTime(long keepAliveTime) {
    this.keepAliveTime = keepAliveTime;
  }
}