package com.ifp.core.pool;

import java.util.List;

public abstract interface IThreadPool
{
  public abstract void execute(Runnable paramRunnable);

  public abstract <T> T submit(Runnable paramRunnable);

  public abstract void shutdown();

  public abstract List<Runnable> shutdownNow();
}