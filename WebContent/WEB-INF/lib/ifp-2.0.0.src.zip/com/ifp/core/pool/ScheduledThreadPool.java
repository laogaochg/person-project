package com.ifp.core.pool;

import java.util.concurrent.Executors;

public class ScheduledThreadPool extends AbstractThreadPool
{
  public ScheduledThreadPool(int num)
  {
    setThreadPool(Executors.newScheduledThreadPool(num));
  }
}