package com.ifp.core.pool;

import java.util.concurrent.Executors;

public class SingleThreadPool extends AbstractThreadPool
{
  public SingleThreadPool()
  {
    setThreadPool(Executors.newSingleThreadExecutor());
  }
}