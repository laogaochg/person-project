package com.ifp.core.spel;

import com.ifp.core.util.DateUtil;
import java.math.BigDecimal;
import java.text.ParseException;

public class SpELFunction
{
  public boolean isNull(Object obj)
  {
    return (null == obj);
  }

  public int toInt(String name)
  {
    return Integer.parseInt(name);
  }

  public double toDouble(String name)
  {
    return Double.parseDouble(name);
  }

  public String add(String value1, String value2)
  {
    return new BigDecimal(value1.trim()).add(new BigDecimal(value2.trim())).toPlainString();
  }

  public String subtract(String value1, String value2)
  {
    return new BigDecimal(value1.trim()).subtract(new BigDecimal(value2.trim())).toPlainString();
  }

  public String multiply(String value1, String value2)
  {
    return new BigDecimal(value1.trim()).multiply(new BigDecimal(value2.trim())).toPlainString();
  }

  public String divide(String value1, String value2)
  {
    return new BigDecimal(value1.trim()).divide(new BigDecimal(value2.trim()), 4, 4).toPlainString();
  }

  public String remainder(String value1, String value2)
  {
    return new BigDecimal(value1.trim()).remainder(new BigDecimal(value2.trim())).toPlainString();
  }

  public String scale2(String value)
  {
    return new BigDecimal(value.trim()).setScale(2, 4).toPlainString();
  }

  public String scale(String value, int scale)
  {
    return new BigDecimal(value.trim()).setScale(scale, 4).toPlainString();
  }

  public String abs(String value)
  {
    return new BigDecimal(value.trim()).abs().toPlainString();
  }

  public String sum(String values)
  {
    BigDecimal sum = new BigDecimal("0");
    String[] valueArray = values.split("\\|");
    String[] arr$ = valueArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String value = arr$[i$];
      sum = sum.add(new BigDecimal(value.trim()));
    }

    return sum.toPlainString();
  }

  public boolean hasText(Object obj)
  {
    return ((null != obj) && (obj.toString().length() > 0));
  }

  public int compareDateTime(String date1, String date2, String formatString)
    throws ParseException
  {
    return DateUtil.compareTwoDateString(date1, date2, formatString);
  }

  public long getIntervalTime(String date1, String date2, String formatString, String type)
    throws ParseException
  {
    return DateUtil.getIntervalTime(date1, date2, formatString, type);
  }
}