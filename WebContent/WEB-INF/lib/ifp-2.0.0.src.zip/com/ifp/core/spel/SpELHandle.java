package com.ifp.core.spel;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

public class SpELHandle
{
  private ExpressionParser parser;
  private SpELFunction spelFunction;
  private Pattern p;

  public SpELHandle()
  {
    this.parser = new SpelExpressionParser();

    this.p = Pattern.compile("#[A-Za-z0-9_]+");
  }

  public boolean parseExpression(String expression, DataMap dataMap)
  {
    EvaluationContext spelContext = new StandardEvaluationContext(this.spelFunction);

    Matcher matcher = this.p.matcher(expression);
    while (matcher.find()) {
      String key = expression.substring(matcher.start(0) + 1, matcher.end(0));
      DataElement dataElement = dataMap.get(key);
      if (dataElement instanceof DataField)
        spelContext.setVariable(key, ((DataField)dataElement).getValue());
      else
        spelContext.setVariable(key, dataElement);

    }

    return ((Boolean)this.parser.parseExpression(expression).getValue(spelContext, Boolean.class)).booleanValue();
  }

  public boolean parseExpression(String expression, Map dataMap)
  {
    EvaluationContext spelContext = new StandardEvaluationContext(new SpELFunction());

    Matcher matcher = this.p.matcher(expression);
    while (matcher.find()) {
      String key = expression.substring(matcher.start(0) + 1, matcher.end(0));
      spelContext.setVariable(key, dataMap.get(key));
    }

    return ((Boolean)this.parser.parseExpression(expression).getValue(spelContext, Boolean.class)).booleanValue();
  }

  public SpELFunction getSpelFunction() {
    return this.spelFunction;
  }

  public void setSpelFunction(SpELFunction spelFunction) {
    this.spelFunction = spelFunction;
  }
}