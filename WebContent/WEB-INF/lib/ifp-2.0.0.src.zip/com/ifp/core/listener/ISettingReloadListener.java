package com.ifp.core.listener;

public abstract interface ISettingReloadListener
{
  public abstract void reload();
}