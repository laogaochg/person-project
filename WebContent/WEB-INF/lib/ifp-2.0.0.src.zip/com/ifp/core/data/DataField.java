package com.ifp.core.data;

import com.ifp.core.exception.ElementChangeFailedException;
import com.ifp.core.util.StringUtil;

public class DataField extends DataElement<DataField>
{
  private String value;
  private String defaultValue;
  private String desc;

  public DataField()
  {
  }

  public DataField(String name)
  {
    setName(name);
  }

  public DataField(String name, String value) {
    setName(name);
    this.value = value;
  }

  public DataField(String name, String value, String desc) {
    setName(name);
    this.value = value;
    this.desc = desc;
  }

  public void check() {
    if (!(isChange()))
      throw new ElementChangeFailedException("DataField can not be changed:" + getName());
  }

  public DataField clone()
  {
    DataField field = new DataField(getName(), this.value, this.desc);
    field.setChange(isChange());
    field.setDefaultValue(this.defaultValue);
    return field;
  }

  public DataField cloneWithOutData() {
    DataField field = new DataField(getName());
    field.setChange(isChange());
    return field;
  }

  public void copy(DataField dataField) {
    this.value = dataField.getValue();
    this.defaultValue = dataField.getDefaultValue();
    this.desc = dataField.getDesc();
  }

  public String getValue() {
    if (null == this.value)
      return this.defaultValue;

    return this.value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public String getDefaultValue() {
    return this.defaultValue;
  }

  public void setDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  public boolean equals(DataField dataField)
  {
    if (null == dataField) {
      return false;
    }

    return ((((getName() == dataField.getName()) || (getName().equals(dataField.getName())))) && (isChange() == dataField.isChange()) && (((this.value == dataField.getValue()) || ((null != this.value) && (this.value.equals(dataField.getValue()))))) && (((this.defaultValue == dataField.getDefaultValue()) || ((null != this.defaultValue) && (this.defaultValue.equals(dataField.getDefaultValue()))))));
  }

  public String toString()
  {
    return "{name:" + getName() + ",value:" + this.value + ",defaultValue:" + this.defaultValue + ",desc:" + this.desc + "}";
  }

  public String toJSON()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("{\"name\":\"").append(StringUtil.formatJSONText(getName()));
    strBuff.append("\",\"value\":\"").append(StringUtil.formatJSONText(this.value));
    strBuff.append("\",\"defaultValue\":\"").append(StringUtil.formatJSONText(this.defaultValue));
    strBuff.append("\"}");

    return strBuff.toString();
  }

  public String toXML()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("<field name=\"").append(StringUtil.formatXMLText(getName()));
    strBuff.append("\" value=\"").append(StringUtil.formatXMLText(this.value));
    strBuff.append("\" defaultValue=\"").append(StringUtil.formatXMLText(this.defaultValue));
    strBuff.append("\" />");

    return strBuff.toString();
  }
}