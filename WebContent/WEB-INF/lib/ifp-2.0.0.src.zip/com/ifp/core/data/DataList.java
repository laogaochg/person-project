package com.ifp.core.data;

import com.ifp.core.base.SystemConf;
import com.ifp.core.exception.ElementChangeFailedException;
import com.ifp.core.exception.ElementNotFoundException;
import com.ifp.core.exception.ElementNotSupportException;
import com.ifp.core.util.StringUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map.Entry;
import java.util.Set;

public class DataList<V extends DataElement> extends DataElement<DataList<V>>
  implements List<V>
{
  private List<V> dataList = new ArrayList();
  private DataMap defineMap;
  private int limit = 1000;
  private String desc;

  public DataList()
  {
  }

  public DataList(String name)
  {
    setName(name);
  }

  public DataList(boolean isChange) {
    setChange(isChange);
  }

  public DataList(String name, List<V> dataList) {
    setName(name);
    this.dataList = dataList;
  }

  public DataList(List<V> dataList)
  {
    this.dataList = dataList;
  }

  public void check()
  {
    if (!(isChange()))
      throw new ElementChangeFailedException("DataList can not be changed:" + getName());
  }

  public int size()
  {
    return this.dataList.size();
  }

  public boolean add(V element) {
    check();
    if ((null != this.defineMap) && (this.defineMap.size() > 0)) {
      if (element instanceof DataMap) {
        DataMap dMap = (DataMap)element;
        if (this.defineMap.equals(dMap.getDefineMap()))
          return this.dataList.add(element);

        throw new ElementNotFoundException("DataMap's define is not match: " + getName());
      }
      if (element instanceof DataField) {
        DataField dataField = (DataField)element;
        if (this.defineMap.containsKey(dataField.getName()))
          return this.dataList.add(element);

        throw new ElementNotSupportException("DataField is not define: " + dataField.getName());
      }

      throw new ElementNotSupportException("element type not support:" + element.getClass().getSimpleName());
    }

    return this.dataList.add(element);
  }

  public void add(int index, V element)
  {
    check();
    if ((null != this.defineMap) && (this.defineMap.size() > 0)) {
      if (element instanceof DataMap) {
        DataMap dMap = (DataMap)element;
        if (this.defineMap.equals(dMap.getDefineMap()))
          this.dataList.add(index, element);
        else
          throw new ElementNotFoundException("DataMap's define is not match: " + getName());

        return; } if (element instanceof DataField) {
        DataField dataField = (DataField)element;
        if (this.defineMap.containsKey(dataField.getName()))
          this.dataList.add(index, element);
        else
          throw new ElementNotSupportException("DataField is not define: " + dataField.getName());

        return; }
      throw new ElementNotSupportException("element type not support:" + element.getClass().getSimpleName());
    }

    this.dataList.add(index, element);
  }

  public V get(int index)
  {
    return ((DataElement)this.dataList.get(index));
  }

  public boolean isEmpty() {
    return this.dataList.isEmpty();
  }

  public boolean contains(Object element) {
    return this.dataList.contains(element);
  }

  public void clear() {
    check();
    this.dataList.clear();
  }

  public Iterator<V> iterator() {
    return this.dataList.iterator();
  }

  public Object[] toArray() {
    return this.dataList.toArray();
  }

  public <T> T[] toArray(T[] a) {
    return this.dataList.toArray(a);
  }

  public boolean remove(Object o) {
    check();
    return this.dataList.remove(o);
  }

  public boolean containsAll(Collection<?> c) {
    return this.dataList.containsAll(c);
  }

  public boolean addAll(Collection<? extends V> c) {
    check();
    boolean flag = true;
    for (Iterator i$ = c.iterator(); i$.hasNext(); ) { DataElement dElement = (DataElement)i$.next();
      flag = (flag) && (add(dElement));
    }
    return flag;
  }

  public boolean addAll(int index, Collection<? extends V> c) {
    check();
    for (Iterator i$ = c.iterator(); i$.hasNext(); ) { DataElement dElement = (DataElement)i$.next();
      add(index, dElement);
    }
    return true;
  }

  public boolean removeAll(Collection<?> c) {
    check();
    return this.dataList.removeAll(c);
  }

  public boolean retainAll(Collection<?> c) {
    check();
    return this.dataList.retainAll(c);
  }

  public V set(int index, V element) {
    if ((null != this.defineMap) && (this.defineMap.size() > 0)) {
      if (element instanceof DataMap) {
        DataMap dMap = (DataMap)element;
        if (this.defineMap.equals(dMap.getDefineMap()))
          return ((DataElement)this.dataList.set(index, element));

        throw new ElementNotFoundException("DataMap's define is not match: " + getName());
      }
      if (element instanceof DataField) {
        DataField dataField = (DataField)element;
        if (this.defineMap.containsKey(dataField.getName()))
          return ((DataElement)this.dataList.set(index, element));

        throw new ElementNotSupportException("DataField is not define: " + dataField.getName());
      }

      throw new ElementNotSupportException("element type not support:" + element.getClass().getSimpleName());
    }

    return ((DataElement)this.dataList.set(index, element));
  }

  public V remove(int index)
  {
    check();
    return ((DataElement)this.dataList.remove(index));
  }

  public int indexOf(Object o) {
    return this.dataList.indexOf(o);
  }

  public int lastIndexOf(Object o) {
    return this.dataList.lastIndexOf(o);
  }

  public ListIterator<V> listIterator() {
    return this.dataList.listIterator();
  }

  public ListIterator<V> listIterator(int index) {
    return this.dataList.listIterator(index);
  }

  public List<V> subList(int fromIndex, int toIndex) {
    return this.dataList.subList(fromIndex, toIndex);
  }

  public String getElementValue(int index) {
    DataElement dataElement = (DataElement)this.dataList.get(index);
    if (null != dataElement) {
      if (dataElement instanceof DataField)
        return ((DataField)dataElement).getValue();

      throw new ElementNotFoundException("DataElement of index[" + index + "] type is not DataField");
    }

    throw new ElementNotFoundException("DataElement of index[" + index + "] not found in DataList[" + getName() + "]");
  }

  public void setElementValue(int index, String value)
  {
    DataElement dataElement = (DataElement)this.dataList.get(index);
    if (null != dataElement) {
      if (dataElement instanceof DataField) {
        ((DataField)dataElement).setValue(value); return;
      }
      throw new ElementNotFoundException("DataElement of index[" + index + "] type is not DataField");
    }

    throw new ElementNotFoundException("DataElement of index[" + index + "] not found in DataList[" + getName() + "]");
  }

  public DataMap<V> createSubDataMap()
  {
    return createSubDataMap(null);
  }

  public DataMap<V> createSubDataMap(String name)
  {
    DataMap dMap = null;
    if (null != name)
      dMap = new DataMap(name);
    else
      dMap = new DataMap();

    dMap.setDefineMap(this.defineMap);

    boolean fillFlag = SystemConf.conf.getBooleanConfByKey("dataMapFillAllFlag", false);
    if (fillFlag) {
      Iterator iter = this.defineMap.entrySet().iterator();
      while (iter.hasNext()) {
        Map.Entry entry = (Map.Entry)iter.next();
        String key = (String)entry.getKey();
        DataElement dataElement = (DataElement)entry.getValue();
        if (dataElement instanceof DataField) {
          dMap.put(key, dataElement);
        } else if (dataElement instanceof DataList) {
          DataList dList = (DataList)dataElement;
          DataList list = new DataList();
          list.setDefineMap(dList.getDefineMap());
          dMap.put(key, list);
        }
      }
    }

    return dMap;
  }

  public DataList<V> clone()
  {
    DataList list = new DataList();
    list.setName(getName());
    list.setDefineMap(this.defineMap);
    list.setDesc(this.desc);

    for (int i = 0; i < this.dataList.size(); ++i) {
      DataElement dataElement = (DataElement)this.dataList.get(i);
      list.add(dataElement.clone());
    }

    list.setChange(isChange());
    return list;
  }

  public DataList<V> cloneWithOutData()
  {
    DataList list = new DataList();
    list.setName(getName());
    list.setDefineMap(this.defineMap);
    list.setDesc(this.desc);
    list.setChange(isChange());
    return list;
  }

  public void copy(DataList<V> list)
  {
    for (int i = 0; i < list.size(); ++i)
      add(list.get(i));
  }

  public boolean equals(DataList<V> dataList)
  {
    if (this.dataList == dataList) {
      return true;
    }

    if (null == dataList) {
      return false;
    }

    if ((this.dataList.size() == 0) && (dataList.size() == 0)) {
      return true;
    }

    if (this.dataList.size() != dataList.size()) {
      return false;
    }

    for (int i = 0; i < this.dataList.size(); ++i) {
      DataElement dataElement = (DataElement)this.dataList.get(i);
      if (!(dataElement.equals(dataList.get(i))))
        return false;
    }

    return true;
  }

  public String toString()
  {
    StringBuffer str = new StringBuffer("[");
    int i = 0;
    for (Iterator i$ = this.dataList.iterator(); i$.hasNext(); ) { DataElement element = (DataElement)i$.next();
      if (i > 0)
        str.append(",");

      str.append(element.toString());

      ++i;
    }

    return str.append("]").toString();
  }

  public String toJSON()
  {
    StringBuffer str = new StringBuffer("[");
    int i = 0;
    for (Iterator i$ = this.dataList.iterator(); i$.hasNext(); ) { DataElement element = (DataElement)i$.next();
      if (i > 0)
        str.append(",");

      str.append(element.toJSON());

      ++i;
    }

    return str.append("]").toString();
  }

  public String toXML()
  {
    StringBuffer str = new StringBuffer("<list");
    if (StringUtil.hasText(getName()))
      str.append(" name=\"").append(getName()).append("\"");

    str.append(">");
    for (Iterator i$ = this.dataList.iterator(); i$.hasNext(); ) { DataElement element = (DataElement)i$.next();
      str.append(element.toXML());
    }

    return str.append("</list>").toString();
  }

  public int getLimit()
  {
    return this.limit;
  }

  public void setLimit(int limit) {
    this.limit = limit;
  }

  public DataMap getDefineMap() {
    return this.defineMap;
  }

  public void setDefineMap(DataMap defineMap) {
    this.defineMap = defineMap;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }
}