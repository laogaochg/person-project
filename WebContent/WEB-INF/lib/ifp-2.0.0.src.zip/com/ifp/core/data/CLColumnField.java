package com.ifp.core.data;

import com.ifp.core.util.StringUtil;

public class CLColumnField extends DataElement<CLColumnField>
{
  private String regex;
  private String sourceName;
  private String targetName;
  private String checkType;
  private String desc;

  public CLColumnField()
  {
  }

  public CLColumnField(String name)
  {
  }

  public CLColumnField(String name, String regex)
  {
    setName(name);
    this.sourceName = name;
    this.regex = regex;
  }

  public CLColumnField(String name, String sourceName, String regex) {
    setName(name);
    this.sourceName = sourceName;
    this.regex = regex;
  }

  public CLColumnField(String name, String sourceName, String regex, String desc) {
    setName(name);
    this.sourceName = sourceName;
    this.regex = regex;
    this.desc = desc;
  }

  public CLColumnField clone()
  {
    CLColumnField inputField = new CLColumnField(getName(), this.regex);
    inputField.setChange(isChange());
    inputField.setSourceName(this.sourceName);
    return inputField;
  }

  public CLColumnField cloneWithOutData()
  {
    CLColumnField inputField = new CLColumnField(getName());
    inputField.setChange(isChange());
    return inputField;
  }

  public void copy(CLColumnField dataElement)
  {
    this.sourceName = dataElement.getSourceName();
    this.regex = dataElement.getRegex();
  }

  public String getRegex() {
    return this.regex;
  }

  public void setRegex(String regex) {
    this.regex = regex;
  }

  public String getSourceName() {
    return this.sourceName;
  }

  public void setSourceName(String sourceName) {
    this.sourceName = sourceName;
  }

  public boolean equals(CLColumnField inputField)
  {
    return ((((getName() == inputField.getName()) || (getName().equals(inputField.getName())))) && (isChange() == inputField.isChange()) && (((this.regex == inputField.getRegex()) || ((null != this.regex) && (this.regex.equals(inputField.getRegex()))))) && (((this.sourceName == inputField.getSourceName()) || ((null != this.sourceName) && (this.sourceName.equals(inputField.getSourceName()))))));
  }

  public String toString()
  {
    return "{name:" + getName() + ",sourceName:" + this.sourceName + ",regex:" + this.regex + "}";
  }

  public String toJSON()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("{\"name\":\"").append(StringUtil.formatJSONText(getName()));
    strBuff.append("\",\"sourceName\":\"").append(StringUtil.formatJSONText(this.sourceName));
    strBuff.append("\",\"regex\":\"").append(StringUtil.formatJSONText(this.regex));
    strBuff.append("\"}");

    return strBuff.toString();
  }

  public String toXML()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("<field name=\"").append(StringUtil.formatXMLText(getName()));
    strBuff.append("\" sourceName=\"").append(StringUtil.formatXMLText(this.sourceName));
    strBuff.append("\" regex=\"").append(StringUtil.formatXMLText(this.regex));
    strBuff.append("\" />");

    return strBuff.toString();
  }

  public String getCheckType() {
    return this.checkType;
  }

  public void setCheckType(String checkType) {
    this.checkType = checkType;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  public String getTargetName() {
    return this.targetName;
  }

  public void setTargetName(String targetName) {
    this.targetName = targetName;
  }
}