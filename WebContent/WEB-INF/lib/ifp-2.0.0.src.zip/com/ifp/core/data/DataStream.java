package com.ifp.core.data;

import com.ifp.core.exception.ElementChangeFailedException;
import com.ifp.core.util.StringUtil;

public class DataStream extends DataElement<DataStream>
{
  private String contextTempKey;
  private String path;
  private String size;
  private String type = "i";

  public DataStream()
  {
  }

  public DataStream(String name)
  {
    setName(name);
  }

  public void check() {
    if (!(isChange()))
      throw new ElementChangeFailedException("DataField can not be changed:" + getName());
  }

  public DataStream clone()
  {
    DataStream stream = new DataStream(getName());
    stream.setChange(isChange());
    stream.setContextTempKey(this.contextTempKey);
    stream.setPath(this.path);
    stream.setSize(this.size);
    stream.setType(this.type);

    return stream;
  }

  public DataStream cloneWithOutData()
  {
    DataStream stream = new DataStream(getName());
    stream.setChange(isChange());
    return stream;
  }

  public void copy(DataStream dataStream)
  {
    this.contextTempKey = dataStream.getContextTempKey();
    this.path = dataStream.getPath();
    this.size = dataStream.getSize();
    this.type = dataStream.getType();
  }

  public boolean equals(DataStream dataStream)
  {
    return ((((getName() == dataStream.getName()) || (getName().equals(dataStream.getName())))) && (isChange() == dataStream.isChange()) && (((this.contextTempKey == dataStream.getContextTempKey()) || ((null != this.contextTempKey) && (this.contextTempKey.equals(dataStream.getContextTempKey()))))) && (((this.path == dataStream.getPath()) || ((null != this.path) && (this.path.equals(dataStream.getPath()))))) && (((this.size == dataStream.getSize()) || ((null != this.size) && (this.size.equals(dataStream.getSize()))))) && (((this.type == dataStream.getType()) || ((null != this.type) && (this.type.equals(dataStream.getType()))))));
  }

  public String toString()
  {
    return "{name:" + getName() + ",contextTempKey:" + this.contextTempKey + ",path:" + this.path + ",size:" + this.size + ",type:" + this.type + "}";
  }

  public String toJSON()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("{\"name\":\"").append(StringUtil.formatJSONText(getName()));
    strBuff.append("\",\"contextTempKey\":\"").append(StringUtil.formatJSONText(this.contextTempKey));
    strBuff.append("\",\"path\":\"").append(StringUtil.formatJSONText(this.path));
    strBuff.append("\",\"size\":\"").append(StringUtil.formatJSONText(this.size));
    strBuff.append("\",\"type\":\"").append(StringUtil.formatJSONText(this.type));
    strBuff.append("\"}");

    return strBuff.toString();
  }

  public String toXML()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("<field name=\"").append(StringUtil.formatXMLText(getName()));
    strBuff.append("\" contextTempKey=\"").append(StringUtil.formatXMLText(this.contextTempKey));
    strBuff.append("\" path=\"").append(StringUtil.formatXMLText(this.path));
    strBuff.append("\" size=\"").append(StringUtil.formatXMLText(this.size));
    strBuff.append("\" type=\"").append(StringUtil.formatXMLText(this.type));
    strBuff.append("\" />");

    return strBuff.toString();
  }

  public String getContextTempKey() {
    return this.contextTempKey;
  }

  public void setContextTempKey(String contextTempKey) {
    this.contextTempKey = contextTempKey;
  }

  public String getPath() {
    return this.path;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public String getSize() {
    return this.size;
  }

  public void setSize(String size) {
    this.size = size;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }
}