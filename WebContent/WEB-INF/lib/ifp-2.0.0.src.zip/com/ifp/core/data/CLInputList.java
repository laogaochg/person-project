package com.ifp.core.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class CLInputList<V extends DataElement> extends DataElement<CLInputList<V>>
  implements List<V>
{
  private List<V> dataList = new ArrayList();
  private String sourceName;
  private String checkType;
  private String desc;

  public CLInputList()
  {
  }

  public CLInputList(String name)
  {
    setName(name);
  }

  public CLInputList(boolean isChange) {
    setChange(isChange);
  }

  public CLInputList(String name, List<V> dataList) {
    setName(name);
    this.dataList = dataList;
  }

  public CLInputList(List<V> dataList) {
    this.dataList = dataList;
  }

  public int size() {
    return this.dataList.size();
  }

  public V get(int index)
  {
    return ((DataElement)this.dataList.get(index));
  }

  public boolean isEmpty() {
    return this.dataList.isEmpty();
  }

  public boolean contains(Object element) {
    return this.dataList.contains(element);
  }

  public void clear() {
    check();
    this.dataList.clear();
  }

  public Iterator<V> iterator() {
    return this.dataList.iterator();
  }

  public Object[] toArray() {
    return this.dataList.toArray();
  }

  public <T> T[] toArray(T[] a) {
    return this.dataList.toArray(a);
  }

  public boolean remove(Object o) {
    check();
    return this.dataList.remove(o);
  }

  public boolean containsAll(Collection<?> c) {
    return this.dataList.containsAll(c);
  }

  public boolean addAll(Collection<? extends V> c) {
    check();
    boolean flag = true;
    for (Iterator i$ = c.iterator(); i$.hasNext(); ) { DataElement dElement = (DataElement)i$.next();
      flag = (flag) && (add(dElement));
    }
    return flag;
  }

  public boolean addAll(int index, Collection<? extends V> c) {
    check();
    for (Iterator i$ = c.iterator(); i$.hasNext(); ) { DataElement dElement = (DataElement)i$.next();
      add(index, dElement);
    }
    return true;
  }

  public boolean removeAll(Collection<?> c) {
    check();
    return this.dataList.removeAll(c);
  }

  public boolean retainAll(Collection<?> c) {
    check();
    return this.dataList.retainAll(c);
  }

  public V remove(int index)
  {
    check();
    return ((DataElement)this.dataList.remove(index));
  }

  public int indexOf(Object o) {
    return this.dataList.indexOf(o);
  }

  public int lastIndexOf(Object o) {
    return this.dataList.lastIndexOf(o);
  }

  public ListIterator<V> listIterator() {
    return this.dataList.listIterator();
  }

  public ListIterator<V> listIterator(int index) {
    return this.dataList.listIterator(index);
  }

  public List<V> subList(int fromIndex, int toIndex) {
    return this.dataList.subList(fromIndex, toIndex);
  }

  public String getSourceName()
  {
    return this.sourceName;
  }

  public void setSourceName(String sourceName) {
    this.sourceName = sourceName;
  }

  public List<V> getDataList() {
    return this.dataList;
  }

  public void setDataList(List<V> dataList) {
    this.dataList = dataList;
  }

  public String getCheckType() {
    return this.checkType;
  }

  public void setCheckType(String checkType) {
    this.checkType = checkType;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  public CLInputList<V> clone()
  {
    return null;
  }

  public CLInputList<V> cloneWithOutData()
  {
    return null;
  }

  public boolean add(V element) {
    return this.dataList.add(element);
  }

  public void add(int index, V element) {
    this.dataList.add(index, element);
  }

  public V set(int index, V element) {
    return ((DataElement)this.dataList.set(index, element));
  }

  public void copy(CLInputList<V> dataElement)
  {
  }

  public boolean equals(CLInputList<V> dataElement)
  {
    return false;
  }

  public String toString() {
    StringBuffer str = new StringBuffer("[");
    int i = 0;
    for (Iterator i$ = this.dataList.iterator(); i$.hasNext(); ) { DataElement element = (DataElement)i$.next();
      if (i > 0)
        str.append(",");

      str.append(element.toString());

      ++i;
    }

    return str.append("]").toString();
  }

  public String toJSON()
  {
    return null;
  }

  public String toXML()
  {
    return null;
  }
}