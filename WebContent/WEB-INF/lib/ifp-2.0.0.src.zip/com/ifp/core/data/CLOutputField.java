package com.ifp.core.data;

import com.ifp.core.util.StringUtil;

public class CLOutputField extends DataElement<OutputField>
{
  private String targetName;
  private String desc;

  public CLOutputField()
  {
  }

  public CLOutputField(String name)
  {
    setName(name);
  }

  public CLOutputField(String name, String targetName) {
    setName(name);
    this.targetName = targetName;
  }

  public CLOutputField(String name, String targetName, String desc) {
    setName(name);
    this.targetName = targetName;
    this.desc = desc;
  }

  public void copy(CLOutputField dataElement) {
    this.targetName = dataElement.getTargetName();
    this.desc = dataElement.getDesc();
  }

  public String getTargetName() {
    return this.targetName;
  }

  public void setTargetName(String targetName) {
    this.targetName = targetName;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  public boolean equals(CLOutputField outputField)
  {
    return ((((getName() == outputField.getName()) || (getName().equals(outputField.getName())))) && (isChange() == outputField.isChange()) && (((this.targetName == outputField.getTargetName()) || ((null != this.targetName) && (this.targetName.equals(outputField.getTargetName()))))));
  }

  public String toString()
  {
    return "{name:" + getName() + ",targetName:" + this.targetName + "}";
  }

  public String toJSON()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("{\"name\":\"").append(StringUtil.formatJSONText(getName()));
    strBuff.append("\",\"targetName\":\"").append(StringUtil.formatJSONText(this.targetName));
    strBuff.append("\"}");

    return strBuff.toString();
  }

  public String toXML()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("<field name=\"").append(StringUtil.formatXMLText(getName()));
    strBuff.append("\" targetName=\"").append(StringUtil.formatXMLText(this.targetName));
    strBuff.append("\" />");

    return strBuff.toString();
  }

  public void copy(OutputField dataElement)
  {
  }

  public boolean equals(OutputField dataElement)
  {
    return false;
  }

  public OutputField clone()
  {
    return null;
  }

  public OutputField cloneWithOutData()
  {
    return null;
  }
}