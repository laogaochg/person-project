package com.ifp.core.data;

import com.ifp.core.util.StringUtil;

public class OutputField extends DataElement<OutputField>
{
  private String targetName;
  private String desc;

  public OutputField()
  {
  }

  public OutputField(String name)
  {
    setName(name);
  }

  public OutputField(String name, String targetName) {
    setName(name);
    this.targetName = targetName;
  }

  public OutputField(String name, String targetName, String desc) {
    setName(name);
    this.targetName = targetName;
    this.desc = desc;
  }

  public OutputField clone()
  {
    OutputField field = new OutputField(getName(), this.targetName, this.desc);
    field.setChange(isChange());
    return field;
  }

  public OutputField cloneWithOutData()
  {
    OutputField field = new OutputField(getName());
    field.setChange(isChange());
    return field;
  }

  public void copy(OutputField dataElement)
  {
    this.targetName = dataElement.getTargetName();
    this.desc = dataElement.getDesc();
  }

  public String getTargetName() {
    return this.targetName;
  }

  public void setTargetName(String targetName) {
    this.targetName = targetName;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  public boolean equals(OutputField outputField)
  {
    return ((((getName() == outputField.getName()) || (getName().equals(outputField.getName())))) && (isChange() == outputField.isChange()) && (((this.targetName == outputField.getTargetName()) || ((null != this.targetName) && (this.targetName.equals(outputField.getTargetName()))))));
  }

  public String toString()
  {
    return "{name:" + getName() + ",targetName:" + this.targetName + "}";
  }

  public String toJSON()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("{\"name\":\"").append(StringUtil.formatJSONText(getName()));
    strBuff.append("\",\"targetName\":\"").append(StringUtil.formatJSONText(this.targetName));
    strBuff.append("\"}");

    return strBuff.toString();
  }

  public String toXML()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("<field name=\"").append(StringUtil.formatXMLText(getName()));
    strBuff.append("\" targetName=\"").append(StringUtil.formatXMLText(this.targetName));
    strBuff.append("\" />");

    return strBuff.toString();
  }
}