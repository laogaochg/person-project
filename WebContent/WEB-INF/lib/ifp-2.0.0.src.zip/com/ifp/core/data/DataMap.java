package com.ifp.core.data;

import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.ElementChangeFailedException;
import com.ifp.core.exception.ElementNotFoundException;
import com.ifp.core.exception.ElementNotSupportException;
import com.ifp.core.util.StringUtil;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DataMap<V extends DataElement> extends DataElement<DataMap<V>>
  implements Map<String, V>
{
  private Map<String, V> dataMap = new LinkedHashMap();
  private DataMap defineMap;
  private String desc;

  public DataMap()
  {
    setChange(false);
  }

  public DataMap(String name) {
    setName(name);
    setChange(false);
  }

  public DataMap(String name, boolean isChange) {
    setName(name);
    setChange(isChange);
  }

  public DataMap(boolean isChange) {
    setChange(isChange);
  }

  public DataMap(Map<String, V> dataMap) {
    this.dataMap = dataMap;
  }

  public DataMap(String name, Map<String, V> dataMap)
  {
    setName(name);
    this.dataMap = dataMap;
  }

  public void check()
  {
    if (!(isChange()))
      throw new ElementChangeFailedException("DataMap can not be changed:" + getName());
  }

  public boolean isChange()
  {
    return ((super.isChange()) || (null == this.defineMap) || (this.defineMap.size() == 0));
  }

  public int size() {
    return this.dataMap.size();
  }

  public boolean isEmpty() {
    return this.dataMap.isEmpty();
  }

  public boolean containsKey(Object key) {
    return this.dataMap.containsKey(key);
  }

  public boolean containsValue(Object value) {
    return this.dataMap.containsValue(value);
  }

  public void clear() {
    check();
    this.dataMap.clear();
  }

  public Set<String> keySet() {
    return this.dataMap.keySet();
  }

  public V get(Object key) {
    return ((DataElement)this.dataMap.get(key));
  }

  public V put(String key, V value)
  {
    if (isChange())
      return ((DataElement)this.dataMap.put(key, value));

    if ((null != this.defineMap) && (this.defineMap.containsKey(key))) {
      DataElement dataElement = this.defineMap.get(key);
      if ((value instanceof DataList) && (dataElement instanceof DataMap)) {
        DataList dataList = (DataList)value;
        DataMap dfMap = dataList.getDefineMap();
        if ((null != dfMap) && (dfMap.equals((DataMap)dataElement)))
          return ((DataElement)this.dataMap.put(key, value));

        throw new ElementNotSupportException("element's define is not match");
      }
      if ((value instanceof DataField) && (dataElement instanceof DataField))
        return ((DataElement)this.dataMap.put(key, value));

      throw new ElementNotSupportException("element type not support:" + value.getClass().getSimpleName());
    }

    throw new ElementNotFoundException(key + " not defined in DataMap[" + getName() + "]");
  }

  public DataElement put(String key, String value)
  {
    if (isChange())
      return ((DataElement)this.dataMap.put(key, new DataField(key, value)));

    if ((null != this.defineMap) && (this.defineMap.containsKey(key))) {
      DataElement dataElement = this.defineMap.get(key);
      if (dataElement instanceof DataField)
        return ((DataElement)this.dataMap.put(key, new DataField(key, value)));

      throw new ElementNotFoundException(key + " type is not DataField");
    }

    throw new ElementNotFoundException(key + " not defined in DataMap[" + getName() + "]");
  }

  public V remove(Object key)
  {
    check();
    return ((DataElement)this.dataMap.remove(key));
  }

  public void putAll(Map<? extends String, ? extends V> map) {
    if (isChange()) {
      Iterator iterator = map.keySet().iterator();
      while (iterator.hasNext()) {
        String key = (String)iterator.next();
        this.dataMap.put(key, map.get(key));
      }
    } else {
      if (!(map instanceof DataMap)) {
        throw new ElementNotSupportException("expect of element type DataMap");
      }

      DataMap dataMap = (DataMap)map;
      DataMap dfMap = dataMap.getDefineMap();
      if ((null != this.defineMap) && (null != dfMap) && (this.defineMap.equals(dfMap))) {
        Iterator iterator = map.keySet().iterator();
        while (iterator.hasNext()) {
          String key = (String)iterator.next();
          dataMap.put(key, (DataElement)map.get(key));
        }
      } else {
        throw new ElementNotSupportException("element's define is not match");
      }
    }
  }

  public Collection<V> values() {
    return this.dataMap.values();
  }

  public Set<Map.Entry<String, V>> entrySet() {
    return this.dataMap.entrySet();
  }

  public String getElementValue(String key) {
    DataElement dataElement = (DataElement)this.dataMap.get(key);
    if (null != dataElement) {
      if (dataElement instanceof DataField)
        return ((DataField)dataElement).getValue();

      throw new ElementNotFoundException(key + " type is not DataField");
    }

    throw new ElementNotFoundException(key + " not found in DataMap[" + getName() + "]");
  }

  public String getElementDefaultValue(String key)
  {
    DataElement dataElement = (DataElement)this.dataMap.get(key);
    if (null != dataElement) {
      if (dataElement instanceof DataField)
        return ((DataField)dataElement).getDefaultValue();

      throw new ElementNotFoundException(key + " type is not DataField");
    }

    throw new ElementNotFoundException(key + " not found in DataMap[" + getName() + "]");
  }

  public void setElementValue(String key, String value) throws BaseException
  {
    DataElement dataElement = (DataElement)this.dataMap.get(key);
    if (null != dataElement) {
      if (dataElement instanceof DataField) {
        ((DataField)dataElement).setValue(value); return;
      }
      throw new ElementNotFoundException(key + " type is not DataField");
    }

    throw new ElementNotFoundException(key + " not found in DataMap[" + getName() + "]");
  }

  public DataMap<V> clone()
  {
    DataMap map = new DataMap();
    map.setName(getName());
    map.setDefineMap(getDefineMap());
    map.setDesc(getDesc());

    Iterator iterator = this.dataMap.keySet().iterator();
    while (iterator.hasNext()) {
      String key = (String)iterator.next();
      DataElement dataElement = (DataElement)this.dataMap.get(key);
      map.put(key, dataElement.clone());
    }

    map.setChange(isChange());
    return map;
  }

  public DataMap<V> cloneWithOutData()
  {
    DataMap map = new DataMap();
    map.setName(getName());
    map.setDefineMap(getDefineMap());
    map.setDesc(getDesc());
    map.setChange(isChange());
    return map;
  }

  public void copy(DataMap<V> map)
  {
    Iterator iterator = map.keySet().iterator();
    while (iterator.hasNext()) {
      String key = (String)iterator.next();
      put(key, map.get(key).clone());
    }
  }

  public boolean equals(DataMap<V> dataMap)
  {
    if (this.dataMap == dataMap) {
      return true;
    }

    if (null == dataMap) {
      return false;
    }

    if ((this.dataMap.size() == 0) && (dataMap.size() == 0)) {
      return true;
    }

    if (this.dataMap.size() != dataMap.size()) {
      return false;
    }

    Iterator iterator = this.dataMap.keySet().iterator();
    while (iterator.hasNext()) {
      String key = (String)iterator.next();
      DataElement dataElement = (DataElement)this.dataMap.get(key);
      if (!(dataElement.equals(dataMap.get(key)))) {
        return false;
      }

    }

    return true;
  }

  public String toString()
  {
    StringBuffer str = new StringBuffer("{");
    Iterator keyIterator = this.dataMap.keySet().iterator();
    int i = 0;
    while (keyIterator.hasNext()) {
      String key = (String)keyIterator.next();
      DataElement element = (DataElement)this.dataMap.get(key);
      if (i > 0)
        str.append(",");

      str.append(key).append(":").append(element.toString());

      ++i;
    }
    return str.append("}").toString();
  }

  public String toJSON()
  {
    StringBuffer str = new StringBuffer("{");
    Iterator keyIterator = this.dataMap.keySet().iterator();
    int i = 0;
    while (keyIterator.hasNext()) {
      String key = (String)keyIterator.next();
      DataElement element = (DataElement)this.dataMap.get(key);
      if (i > 0)
        str.append(",");

      str.append("\"").append(key).append("\":").append(element.toJSON());

      ++i;
    }
    return str.append("}").toString();
  }

  public String toXML()
  {
    StringBuffer str = new StringBuffer("<map");
    if (StringUtil.hasText(getName()))
      str.append(" name=\"").append(getName()).append("\"");

    str.append(">");
    Iterator keyIterator = this.dataMap.keySet().iterator();
    while (keyIterator.hasNext()) {
      String key = (String)keyIterator.next();
      DataElement element = (DataElement)this.dataMap.get(key);
      str.append(element.toXML());
    }
    return str.append("</map>").toString();
  }

  public DataMap getDefineMap()
  {
    return this.defineMap;
  }

  public void setDefineMap(DataMap defineMap) {
    this.defineMap = defineMap;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }
}