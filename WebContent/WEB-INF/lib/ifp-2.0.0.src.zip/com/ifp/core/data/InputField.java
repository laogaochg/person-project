package com.ifp.core.data;

import com.ifp.core.util.StringUtil;

public class InputField extends DataElement<InputField>
{
  private String regex;
  private String sourceName;
  private String desc;

  public InputField()
  {
  }

  public InputField(String name)
  {
  }

  public InputField(String name, String regex)
  {
    setName(name);
    this.sourceName = name;
    this.regex = regex;
  }

  public InputField(String name, String sourceName, String regex) {
    setName(name);
    this.sourceName = sourceName;
    this.regex = regex;
  }

  public InputField(String name, String sourceName, String regex, String desc) {
    setName(name);
    this.sourceName = sourceName;
    this.regex = regex;
    this.desc = desc;
  }

  public InputField clone()
  {
    InputField inputField = new InputField(getName(), this.regex);
    inputField.setChange(isChange());
    inputField.setSourceName(this.sourceName);
    inputField.setDesc(this.desc);
    return inputField;
  }

  public InputField cloneWithOutData()
  {
    InputField inputField = new InputField(getName());
    inputField.setChange(isChange());
    return inputField;
  }

  public void copy(InputField dataElement)
  {
    this.sourceName = dataElement.getSourceName();
    this.regex = dataElement.getRegex();
    this.desc = dataElement.getDesc();
  }

  public String getRegex() {
    return this.regex;
  }

  public void setRegex(String regex) {
    this.regex = regex;
  }

  public String getSourceName() {
    return this.sourceName;
  }

  public void setSourceName(String sourceName) {
    this.sourceName = sourceName;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  public boolean equals(InputField inputField)
  {
    return ((((getName() == inputField.getName()) || (getName().equals(inputField.getName())))) && (isChange() == inputField.isChange()) && (((this.regex == inputField.getRegex()) || ((null != this.regex) && (this.regex.equals(inputField.getRegex()))))) && (((this.sourceName == inputField.getSourceName()) || ((null != this.sourceName) && (this.sourceName.equals(inputField.getSourceName()))))));
  }

  public String toString()
  {
    return "{name:" + getName() + ",sourceName:" + this.sourceName + ",regex:" + this.regex + "}";
  }

  public String toJSON()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("{\"name\":\"").append(StringUtil.formatJSONText(getName()));
    strBuff.append("\",\"sourceName\":\"").append(StringUtil.formatJSONText(this.sourceName));
    strBuff.append("\",\"regex\":\"").append(StringUtil.formatJSONText(this.regex));
    strBuff.append("\"}");

    return strBuff.toString();
  }

  public String toXML()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("<field name=\"").append(StringUtil.formatXMLText(getName()));
    strBuff.append("\" sourceName=\"").append(StringUtil.formatXMLText(this.sourceName));
    strBuff.append("\" regex=\"").append(StringUtil.formatXMLText(this.regex));
    strBuff.append("\" />");

    return strBuff.toString();
  }
}