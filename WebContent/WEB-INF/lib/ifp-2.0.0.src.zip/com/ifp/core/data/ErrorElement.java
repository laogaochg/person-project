package com.ifp.core.data;

public class ErrorElement
{
  public String errorCode;
  public String showErrorCode;
  public String language;
  public String errorMsg;
  public String level;
  public String channel;
  public String syscode;

  public String getErrorCode()
  {
    return this.errorCode; }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode; }

  public String getLanguage() {
    return this.language; }

  public void setLanguage(String language) {
    this.language = language; }

  public String getErrorMsg() {
    return ((this.errorMsg != null) ? this.errorMsg : ""); }

  public void setErrorMsg(String errorMsg) {
    this.errorMsg = errorMsg; }

  public String getLevel() {
    return this.level; }

  public void setLevel(String level) {
    this.level = level; }

  public String getChannel() {
    return this.channel; }

  public void setChannel(String channel) {
    this.channel = channel; }

  public String getSyscode() {
    return this.syscode; }

  public void setSyscode(String syscode) {
    this.syscode = syscode; }

  public String getShowErrorCode() {
    return ((com.ifp.core.util.StringUtil.hasText(this.showErrorCode)) ? this.showErrorCode : this.errorCode); }

  public void setShowErrorCode(String showErrorCode) {
    this.showErrorCode = showErrorCode;
  }
}