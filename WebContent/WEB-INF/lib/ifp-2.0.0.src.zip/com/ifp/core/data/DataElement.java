package com.ifp.core.data;

import com.ifp.core.exception.ElementChangeFailedException;
import java.io.Serializable;

public abstract class DataElement<T extends DataElement>
  implements Serializable
{
  private static final long serialVersionUID = -2100971168317640367L;
  private String name;
  private boolean isChange = true;

  public DataElement()
  {
  }

  public DataElement(String name)
  {
    this.name = name;
  }

  public DataElement(String name, boolean isChange) {
    this.name = name;
    this.isChange = isChange;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public boolean isChange() {
    return this.isChange;
  }

  public void setChange(boolean isChange) {
    this.isChange = isChange;
  }

  public void check() {
    if (!(isChange()))
      throw new ElementChangeFailedException(super.getClass().getSimpleName() + " can not be changed:" + getName());
  }

  public abstract T clone();

  public abstract T cloneWithOutData();

  public abstract void copy(T paramT);

  public abstract boolean equals(T paramT);

  public abstract String toString();

  public abstract String toJSON();

  public abstract String toXML();
}