package com.ifp.core.session.schema.parser;

import com.ifp.core.data.SessionNameElement;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

public class SessionInfoNameParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    try
    {
      builder.addPropertyValue("name", element.getAttribute("name"));

      String saveCookie = element.getAttribute("saveCookie");
      boolean ifSaveCookie = false;
      if (StringUtils.hasText(saveCookie)) {
        if ("true".equals(saveCookie.toLowerCase())) ifSaveCookie = true;
        builder.addPropertyValue("saveCookie", Boolean.valueOf(ifSaveCookie));
      }

      boolean isHttpOnly = Boolean.parseBoolean(element.getAttribute("httpOnly"));
      builder.addPropertyValue("httpOnly", Boolean.valueOf(isHttpOnly));

      String maxInactiveInterval = element.getAttribute("maxInactiveInterval");
      if (StringUtils.hasText(maxInactiveInterval)) {
        builder.addPropertyValue("maxInactiveInterval", maxInactiveInterval);
      }

      String forceExpirationPeriod = element.getAttribute("forceExpirationPeriod");
      if (StringUtils.hasText(forceExpirationPeriod)) {
        builder.addPropertyValue("forceExpirationPeriod", forceExpirationPeriod);
      }

      String dataSourceName = element.getAttribute("dataSourceName");
      if (StringUtils.hasText(dataSourceName)) {
        builder.addPropertyValue("dataSourceName", dataSourceName);
      }

      String cacheName = element.getAttribute("cacheName");
      if (StringUtils.hasText(cacheName))
        builder.addPropertyValue("cacheName", cacheName);
    }
    catch (Exception e)
    {
      parserContext.getReaderContext().error("class " + SessionInfoNameParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<SessionNameElement> getBeanClass(Element element)
  {
    return SessionNameElement.class;
  }
}