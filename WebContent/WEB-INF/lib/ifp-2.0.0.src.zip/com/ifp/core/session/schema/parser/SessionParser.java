package com.ifp.core.session.schema.parser;

import com.ifp.core.data.SessionElement;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedMap;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.StringUtils;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class SessionParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String id = element.getAttribute("id");

    if (StringUtils.hasText(id)) {
      builder.addPropertyValue("id", element.getAttribute("id"));
    }

    String saveCookie = element.getAttribute("saveCookie");
    if (StringUtils.hasText(saveCookie)) {
      builder.addPropertyValue("saveCookie", saveCookie);
    }

    boolean isHttpOnly = Boolean.parseBoolean(element.getAttribute("httpOnly"));
    builder.addPropertyValue("httpOnly", Boolean.valueOf(isHttpOnly));

    String maxInactiveInterval = element.getAttribute("maxInactiveInterval");
    if (StringUtils.hasText(maxInactiveInterval)) {
      builder.addPropertyValue("maxInactiveInterval", maxInactiveInterval);
    }

    String keepInTouch = element.getAttribute("keepInTouch");
    if (StringUtils.hasText(keepInTouch)) {
      builder.addPropertyValue("keepInTouch", keepInTouch);
    }

    String forceExpirationPeriod = element.getAttribute("forceExpirationPeriod");
    if (StringUtils.hasText(forceExpirationPeriod)) {
      builder.addPropertyValue("forceExpirationPeriod", forceExpirationPeriod);
    }

    String supportType = element.getAttribute("supportType");
    if (StringUtils.hasText(supportType)) {
      builder.addPropertyValue("supportType", supportType);
    }

    String algorithm = element.getAttribute("algorithm");
    if (StringUtils.hasText(algorithm)) {
      builder.addPropertyValue("algorithm", algorithm);
    }

    String algorithmField = element.getAttribute("algorithmField");
    if (StringUtils.hasText(algorithmField)) {
      builder.addPropertyValue("algorithmField", algorithmField);
    }

    builder.addPropertyValue("sessionNameMap", parseElement(element, parserContext, builder));
  }

  protected Class<SessionElement> getBeanClass(Element element)
  {
    return SessionElement.class;
  }

  private Map<String, BeanDefinition> parseElement(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List elist = DomUtils.getChildElements(element);
    ManagedMap map = new ManagedMap(elist.size());
    map.setMergeEnabled(true);
    map.setSource(parserContext.getReaderContext().extractSource(element));
    for (Iterator i$ = elist.iterator(); i$.hasNext(); ) { Element propertyElement = (Element)i$.next();
      String name = propertyElement.getAttribute("name");
      map.put(name, parserContext.getDelegate().parseCustomElement(propertyElement, builder.getRawBeanDefinition()));
    }
    return map;
  }
}