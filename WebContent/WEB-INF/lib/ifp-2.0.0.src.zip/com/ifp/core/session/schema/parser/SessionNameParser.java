package com.ifp.core.session.schema.parser;

import com.ifp.core.data.SessionElement;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedMap;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.StringUtils;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class SessionNameParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String id = element.getAttribute("id");

    if (StringUtils.hasText(id)) {
      builder.addPropertyValue("id", element.getAttribute("id"));
    }

    String saveCookie = element.getAttribute("saveCookie");
    boolean ifSaveCookie = false;
    if (StringUtils.hasText(saveCookie)) {
      if ("true".equals(saveCookie.toLowerCase())) ifSaveCookie = true;
      builder.addPropertyValue("saveCookie", Boolean.valueOf(ifSaveCookie));
    }

    boolean isHttpOnly = Boolean.parseBoolean(element.getAttribute("httpOnly"));
    builder.addPropertyValue("httpOnly", Boolean.valueOf(isHttpOnly));

    String maxInactiveInterval = element.getAttribute("maxInactiveInterval");
    if (StringUtils.hasText(maxInactiveInterval)) {
      builder.addPropertyValue("maxInactiveInterval", Long.valueOf(Long.parseLong(maxInactiveInterval)));
    }

    String keepInTouch = element.getAttribute("keepInTouch");
    if (StringUtils.hasText(keepInTouch)) {
      builder.addPropertyValue("keepInTouch", Boolean.valueOf(Boolean.parseBoolean(keepInTouch)));
    }

    String forceExpirationPeriod = element.getAttribute("forceExpirationPeriod");
    if (StringUtils.hasText(forceExpirationPeriod)) {
      builder.addPropertyValue("forceExpirationPeriod", Long.valueOf(Long.parseLong(forceExpirationPeriod)));
    }

    String dataSourceName = element.getAttribute("dataSourceName");
    if (StringUtils.hasText(dataSourceName)) {
      builder.addPropertyValue("dataSourceName", dataSourceName);
    }

    String cacheName = element.getAttribute("cacheName");
    if (StringUtils.hasText(cacheName)) {
      builder.addPropertyValue("cacheName", cacheName);
    }

    String algorithm = element.getAttribute("algorithm");
    if (StringUtils.hasText(algorithm))
      builder.addPropertyValue("algorithm", algorithm);

    String clazz = element.getAttribute("clazz");
    if (StringUtils.hasText(clazz)) {
      builder.addPropertyValue("clazz", clazz);
    }

    builder.addPropertyValue("sessionNameMap", parseElement(element, parserContext, builder));
  }

  protected Class<SessionElement> getBeanClass(Element element)
  {
    return SessionElement.class;
  }

  private Map<String, BeanDefinition> parseElement(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List elist = DomUtils.getChildElements(element);
    ManagedMap map = new ManagedMap(elist.size());
    map.setMergeEnabled(true);
    map.setSource(parserContext.getReaderContext().extractSource(element));
    for (Iterator i$ = elist.iterator(); i$.hasNext(); ) { Element propertyElement = (Element)i$.next();
      String name = propertyElement.getAttribute("name");
      map.put(name, parserContext.getDelegate().parseCustomElement(propertyElement, builder.getRawBeanDefinition()));
    }
    return map;
  }
}