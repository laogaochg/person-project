package com.ifp.core.session;

import com.ifp.cache.handle.CacheHandler;
import com.ifp.cache.redis.manager.IFPRedisManager;
import com.ifp.core.cache.CacheManager;
import com.ifp.core.context.ClogicContext;
import com.ifp.core.data.SessionElement;
import com.ifp.core.data.SessionNameElement;
import com.ifp.core.encrypt.EncryptHandle;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.SessionException;
import com.ifp.core.jdbc.DataSourceHandle;
import com.ifp.core.log.FlumeLogInf;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.Trace;
import com.ifp.core.util.CookieUtil;
import com.ifp.core.util.DateUtil;
import com.ifp.core.util.IpUtils;
import com.ifp.core.util.SerializeUtils;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.BeanFactoryUtils;
import org.springframework.util.StringUtils;

public class IFPSessionManager
  implements SessionManager
{
  public static final String CLIENT_IP = "CLIENT_IP";
  public static final String CLIENT_MAC = "CLIENT_MAC";
  public static final String DEVICE_ID = "DEVICE_ID";
  public static final String DEVICE_NAME = "DEVICE_NAME";
  private static final String SESSION_PREFIX = "sessionId:";
  private int cookieMaxAge;
  private int sessionTimeOut;
  private Timer timer;
  private int sessionCheckInterval;
  private boolean createWhenNotCreate;
  private long limit;
  private long count;
  private Map<String, Object> sessions;
  public CacheManager ifpCacheManager;
  private Map<String, SessionElement> sessionElementMap;
  private String getSessionSQL;
  private String createSessionSQL;
  private String updateSessionSQL;
  private String deleteSessionSQL;
  private String getSessionInfoSQL;
  private String updateSessionInfoSQL;
  private String saveSessionInfoSQL;
  private String sessionCache;
  private String cacheManager;
  private String algorithm;
  private EncryptHandle encrypt;
  private Map<String, Map<String, Field>> fieldMap;
  private DataSourceHandle dataSourceHandle;
  private String clientMacFieldName;
  private String deviceIdFieldName;
  private String deviceNameFieldName;

  public IFPSessionManager()
  {
    this.cookieMaxAge = -1;

    this.sessionTimeOut = 900;

    this.sessionCheckInterval = 300000;

    this.createWhenNotCreate = true;

    this.limit = 100000L;

    this.count = -3763401214071406592L;

    this.sessions = new ConcurrentHashMap();

    this.sessionElementMap = new HashMap();

    this.getSessionSQL = "SELECT ifp_sessionObj FROM ifp_session WHERE ifp_sessionId=?";

    this.createSessionSQL = "INSERT INTO ifp_session(ifp_sessionId,ifp_sessionName,ifp_sessionObj,ifp_maxInactiveInterval,ifp_keepInTouch,ifp_forceExpirationPeriod,ifp_createTime,ifp_updateTime) VALUES(?,?,?,?,?,?,?,?)";

    this.updateSessionSQL = "UPDATE ifp_session SET ifp_sessionObj=?,ifp_updateTime=? WHERE ifp_sessionId=?";

    this.deleteSessionSQL = "DELETE FROM ifp_session WHERE ifp_sessionId=?";

    this.getSessionInfoSQL = "SELECT ifp_inf_infoobj FROM ifp_session_info WHERE ifp_inf_sessionId = ?";

    this.updateSessionInfoSQL = "UPDATE ifp_session_info SET ifp_inf_infoobj=?,ifp_inf_updateTime=? WHERE ifp_inf_sessionId = ?";

    this.saveSessionInfoSQL = "INSERT INTO ifp_session_info(ifp_inf_sessionId,ifp_inf_infoobj,ifp_inf_createTime,ifp_inf_updateTime) VALUES(?,?,?,?)";

    this.sessionCache = "sessionCache";

    this.cacheManager = "cacheManager";

    this.algorithm = "MD5";

    this.encrypt = new EncryptHandle();

    this.fieldMap = new HashMap();

    this.clientMacFieldName = "macCode";

    this.deviceIdFieldName = "deviceID";

    this.deviceNameFieldName = "deviceName";
  }

  public void removeSession(Session session)
  {
    if (session == null) {
      return;
    }

    removeSession(session.getSessionName(), session.getId());
  }

  public void removeSessionInfo(SessionInfo sessionInfo, String sessionName, String sessionInfoName)
  {
    if (sessionInfo == null) {
      return;
    }

    removeSessionInfo(sessionName, sessionInfoName, sessionInfo.getSessionId());
  }

  public void sessionRequestEnd(Session session)
  {
  }

  public String encodeURL(HttpServletRequest request, HttpServletResponse response, String url, String method) {
    return null;
  }

  public int getSessionCount() {
    int count = 0;
    Object[] keys = null;
    try {
      keys = this.sessions.keySet().toArray();
    }
    catch (Exception e) {
      Trace.log("CORE", 3, "Failed to getSessionCount: ", e);
      return 0;
    }
    for (int i = 0; i < keys.length; )
    {
      try {
        if (this.sessions.get(keys[i]) instanceof Session)
        {
          IFPSession session = (IFPSession)this.sessions.get(keys[i]);
          if (session == null)
            break label105:
          ++count;
        }
      }
      catch (Exception e) {
        Trace.log("CORE", 3, "Failed to getSessionCount", e);
        return 0;
      }
      label105: ++i;
    }

    return count;
  }

  public void terminate() {
    if (this.timer == null)
      return;

    Trace.log("CORE", 0, "Terminate the IFPSessionManager");
    try
    {
      this.timer.cancel();
      this.timer = null;
      this.sessions.clear();
      synchronized (this) {
        this.count = -3763399839681871872L;
      }
    }
    catch (Exception e) {
      Trace.log("CORE", 3, "failed to Terminate the IFPSessionManager", e);
    }
  }

  public void removeSession(String sessionName, String sessionId)
  {
    if (useDb(sessionName, null))
    {
      try {
        this.dataSourceHandle.excuteSQL(getDataSourceName(sessionName, null), this.deleteSessionSQL, new Object[] { sessionId });
      }
      catch (SQLException e) {
        Trace.log("CORE", 3, "delete session SQL ERROR...", e);
      } catch (Exception e) {
        Trace.log("CORE", 3, "delete session ERROR...", e);
      }
    } else if (useCache(sessionName, null))
    {
      try {
        this.ifpCacheManager.remove(getCacheName(sessionName, null), sessionId);
      } catch (BaseException e) {
        Trace.log("CORE", 3, "delete session ERROR...", ???);
      }
    }
    else {
      this.sessions.remove(sessionId);
      synchronized (this) {
        this.count -= -3763400080200040447L;
      }
    }
  }

  public void removeSessionInfo(String sessionName, String sessionInfoName, String sessionId) {
    if (useDb(sessionName, sessionInfoName))
    {
      try {
        this.dataSourceHandle.excuteSQL(getDataSourceName(sessionName, sessionInfoName), this.deleteSessionSQL, new Object[] { sessionId });
      }
      catch (SQLException e) {
        Trace.log("CORE", 3, "delete session SQL ERROR...", e);
      } catch (Exception e) {
        Trace.log("CORE", 3, "delete session ERROR...", e);
      }
    } else if (useCache(sessionName, sessionInfoName))
    {
      try {
        this.ifpCacheManager.remove(getCacheName(sessionName, sessionInfoName), sessionName + "." + sessionInfoName + "." + sessionId);
      } catch (BaseException e) {
        Trace.log("CORE", 3, "delete session ERROR...", ???);
      }
    }
    else {
      this.sessions.remove(sessionName + "." + sessionInfoName + "." + sessionId);
      synchronized (this) {
        this.count -= -3763400080200040447L;
      }
    }
  }

  public String getSessionId(Object requestObj, Object responseObj, String sessionName)
    throws BaseException
  {
    IFPSession session;
    try
    {
      session = getSession(requestObj, sessionName);
      if ((session == null) && (this.createWhenNotCreate))
      {
        session = createSession(responseObj, requestObj, sessionName);
      }
      if (session != null) return session.getId();
    } catch (BaseException e) {
      Trace.log("CORE", 3, "get sessionID ERROR...", e);
    }
    return null;
  }

  private String generateSessionId(String sessionName, String keyValue)
  {
    String encryptionAlgorithm;
    try
    {
      encryptionAlgorithm = getAlgorithm(sessionName);

      return this.encrypt.getEncryptString(encryptionAlgorithm, keyValue);
    }
    catch (Exception _ex)
    {
    }

    return null;
  }

  protected boolean checkTimeout(Session session, String sessionName)
  {
    if (session == null) return true;
    if (getMaxInactiveInterval(sessionName) > 0) {
      long currentTime = System.currentTimeMillis();
      boolean currentTimeCompareLastAccessTime = currentTime - session.getLastAccessTime() > getMaxInactiveInterval(sessionName);
      boolean currentTimeCompareCreateTime = false;
      if (getforceExpirationPeriod(sessionName) > 0)
        currentTimeCompareCreateTime = currentTime - session.getCreateTime() > getforceExpirationPeriod(sessionName);

      if ((currentTimeCompareLastAccessTime) || (currentTimeCompareCreateTime))
        removeSession(session);

      return ((currentTimeCompareLastAccessTime) || (currentTimeCompareCreateTime));
    }
    return false;
  }

  protected boolean checkTimeout(SessionInfo sessionInfo, String sessionName, String sessionInfoName)
  {
    if (getMaxInactiveInterval(sessionName, sessionInfoName) > 0)
    {
      long currentTime = System.currentTimeMillis();
      boolean currentTimeCompareLastAccessTime = currentTime - sessionInfo.getLastAccessTime() > getMaxInactiveInterval(sessionName, sessionInfoName);
      boolean currentTimeCompareCreateTime = false;
      if (getforceExpirationPeriod(sessionName) > 0)
      {
        currentTimeCompareCreateTime = currentTime - sessionInfo.getCreateTime() > getforceExpirationPeriod(sessionName, sessionInfoName);
      }
      if ((currentTimeCompareLastAccessTime) || (currentTimeCompareCreateTime))
      {
        removeSessionInfo(sessionInfo, sessionName, sessionInfoName);
      }
      return ((currentTimeCompareLastAccessTime) || (currentTimeCompareCreateTime));
    }
    return false;
  }

  private IFPSession getSession(Object requestObj, String sessionName)
    throws BaseException
  {
    HttpServletRequest request;
    try
    {
      request = (HttpServletRequest)requestObj;
      IFPSession session = null;
      if (ifSaveCookie(sessionName))
      {
        session = checkSessionByCookie(request, sessionName);
      }

      if ((session == null) && (useDb(sessionName, null)))
      {
        session = checkSessionByDB(request, sessionName);
      }

      if ((session == null) && (useCache(sessionName, null)))
      {
        session = checkSessionByCache(request, sessionName);
      }

      checkSession(session, request, sessionName);
      return session;
    } catch (BaseException e) {
      throw e;
    } catch (Exception e) {
      throw new BaseException(e);
    }
  }

  private IFPSession checkSessionByCookie(HttpServletRequest request, String sessionName)
  {
    String sessionId = null;
    IFPSession session = null;
    Cookie[] cookies = request.getCookies();
    if (cookies != null)
      for (int i = 0; i < cookies.length; ++i)
        if (sessionName.equals(cookies[i].getName())) {
          sessionId = cookies[i].getValue();
          break;
        }



    if (sessionId != null) {
      String rSId = (String)request.getAttribute(sessionName);
      if (rSId == null)
        rSId = request.getParameter(sessionName);

      if ((rSId != null) && (!(rSId.equals(sessionId)))) {
        Trace.log("CORE", 3, "Invalid Session sessionName " + rSId + " not equal to cookie SID " + sessionId);
        sessionId = null;
      }
    }

    if (sessionId != null)
      session = (IFPSession)this.sessions.get(sessionId);
    else {
      return null;
    }

    if (session != null)
    {
      return checkSession(session, request, sessionName);
    }

    return session;
  }

  private IFPSession checkSessionByDB(HttpServletRequest request, String sessionName)
    throws SQLException, IOException, ClassNotFoundException
  {
    String sessionId = null;
    IFPSession session = null;
    if (sessionId == null) {
      Object rSId = request.getAttribute(sessionName);
      if (rSId == null)
        rSId = request.getParameter(sessionName);

      if (rSId != null)
        sessionId = (String)rSId;

    }

    if (sessionId == null) return null;

    if (session == null)
    {
      Session sessionTemp = getSesseionFromDB(sessionName, new String[] { sessionId });
      session = (sessionTemp == null) ? null : (IFPSession)sessionTemp;
    }

    if (session != null)
    {
      return checkSession(session, request, sessionName);
    }

    return session;
  }

  private IFPSession checkSessionByCache(HttpServletRequest request, String sessionName)
    throws BaseException
  {
    String sessionId = null;
    IFPSession session = null;
    if (sessionId == null) {
      Object rSId = request.getAttribute(sessionName);
      if (rSId == null)
        rSId = request.getParameter(sessionName);

      if (rSId != null)
        sessionId = (String)rSId;

    }

    if (sessionId == null) return null;

    if (session == null)
    {
      Session sessionTemp = getSesseionFromCache(sessionName, sessionId);
      session = (sessionTemp == null) ? null : (IFPSession)sessionTemp;
    }

    if (session != null)
    {
      return checkSession(session, request, sessionName);
    }
    return session;
  }

  private IFPSession checkSession(IFPSession session, HttpServletRequest request, String sessionName)
  {
    if ((session != null) && 
      (checkTimeout(session, sessionName))) {
      Trace.log("CORE", 3, "Session time out:" + session.getSessionId());

      return null;
    }

    if (session != null) {
      String saveIP = (String)session.getAttribute("CLIENT_IP");
      String reqIP = request.getRemoteAddr();

      if (!(reqIP.equals(saveIP))) {
        Trace.log("CORE", 3, "Invalid Session from IP " + saveIP + " to " + reqIP);
      }

    }

    if ((session != null) && (isKeepInTouch(sessionName)))
    {
      updateSessionLastAccessTime(session);
    }
    return session;
  }

  public IFPSession createSession(Object responseObj, Object requestObj, String sessionName)
    throws BaseException
  {
    if (this.count <= this.limit)
      try
      {
        LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
        String sessionId = generateSessionId(sessionName, null);
        IFPSession session = new IFPSession(sessionId, sessionName);
        if (StringUtil.hasText(getClazz(sessionName)))
        {
          Class c = Class.forName(getClazz(sessionName));
          session = (IFPSession)c.newInstance();
          session.setSessionId(sessionId);
          session.setSessionName(sessionName);
        }
        String reqIP = IpUtils.getIpAddr((HttpServletRequest)requestObj);
        String uri = ((HttpServletRequest)requestObj).getRequestURI();
        session.setAttribute("CLIENT_IP", reqIP);

        if (ifSaveCookie(sessionName))
          saveSessionToCookie(uri, responseObj, session, sessionId, sessionName);
        if (useDb(sessionName, null))
        {
          saveSessionToDB(session, sessionId, sessionName);
        }
        else if (useCache(sessionName, null))
        {
          saveSessionToCache(session, sessionId);
        }
        else {
          this.sessions.put(sessionId, session);
          synchronized (this) {
            this.count += -3763407398824312831L;
          }
        }
        return session;
      } catch (Exception e) {
        throw new SessionException(e);
      }

    throw new SessionException("系统繁忙，请稍后再试！");
  }

  private IFPSession setSessionFromRequest(Map<String, Object> paramsMap, IFPSession session)
  {
    String str = (String)paramsMap.get(this.clientMacFieldName);
    session.setAttribute("CLIENT_MAC", (null == str) ? "" : str);
    str = (String)paramsMap.get(this.deviceIdFieldName);
    session.setAttribute("DEVICE_ID", (null == str) ? "" : str);
    str = (String)paramsMap.get(this.deviceNameFieldName);
    session.setAttribute("DEVICE_NAME", (null == str) ? "" : str);
    return session;
  }

  private void saveSessionToCookie(String uri, Object responseObj, Session session, String sessionId, String sessionName)
  {
    if ((responseObj != null) && (responseObj instanceof HttpServletResponse)) {
      HttpServletResponse response = (HttpServletResponse)responseObj;

      Cookie cookie = new Cookie(sessionName, sessionId);
      cookie.setMaxAge((getMaxInactiveInterval(sessionName) == 0) ? this.cookieMaxAge : getMaxInactiveInterval(sessionName));

      CookieUtil.addCookie(response, cookie, getHttpOnly(sessionName));
    }
  }

  private void saveSessionToDB(Session session, String sessionId, String sessionName)
    throws SQLException, IOException
  {
    String currentTime = DateUtil.getStringToday();
    this.dataSourceHandle.excuteSQL(getDataSourceName(sessionName, null), this.createSessionSQL, new Object[] { sessionId, sessionName, session, String.valueOf(getMaxInactiveInterval(sessionName)), String.valueOf(isKeepInTouch(sessionName)), String.valueOf(getforceExpirationPeriod(sessionName)), currentTime, currentTime });
  }

  private void saveSessionToCache(Session session, String sessionId)
    throws BaseException
  {
    if (this.ifpCacheManager != null)
      this.ifpCacheManager.put(getCacheName(session.getSessionName(), null), "sessionId:" + sessionId, session, getMaxInactiveInterval(session.getSessionName()));
  }

  public void updateSession(Session session)
  {
    if (session == null) return;
    try {
      if (useDb(session.getSessionName(), null))
      {
        this.dataSourceHandle.excuteSQL(getDataSourceName(session.getSessionName(), null), this.updateSessionSQL, new Object[] { session, DateUtil.getStringToday(), session.getId() });

        return;
      }
    }
    catch (SQLException e) {
      Trace.log("CORE", 3, "update session ERROR...", e);
    } catch (Exception e) {
      Trace.log("CORE", 3, "update session ERROR...", e);
    }
    if (useCache(session.getSessionName(), null))
    {
      try {
        updateSessionToCache(session);
      } catch (BaseException e) {
        Trace.log("CORE", 3, "update session ERROR...", e);
      }
      return;
    }
    this.sessions.put(session.getId(), session);
  }

  public void updateSessionLastAccessTime(Session session)
  {
    if (session == null) return;
    session.setLastAccessTime(System.currentTimeMillis());
    try {
      if (useDb(session.getSessionName(), null))
      {
        this.dataSourceHandle.excuteSQL(getDataSourceName(session.getSessionName(), null), this.updateSessionSQL, new Object[] { session, DateUtil.getStringToday(), session.getId() });

        return;
      }
    }
    catch (SQLException e) {
      Trace.log("CORE", 3, "update session ERROR...", e);
    } catch (Exception e) {
      Trace.log("CORE", 3, "update session ERROR...", e);
    }
    if (useCache(session.getSessionName(), null))
    {
      try {
        updateSessionToCache(session);
      } catch (BaseException e) {
        Trace.log("CORE", 3, "update session ERROR...", e);
      }
      return;
    }
    this.sessions.put(session.getId(), session);
  }

  private void updateSessionToCache(Session session)
    throws BaseException
  {
    if (this.ifpCacheManager != null)
      this.ifpCacheManager.put(getCacheName(session.getSessionName(), null), "sessionId:" + session.getId(), session, getRestTime(session.getSessionName(), session.getLastAccessTime(), session.getCreateTime()));
  }

  private int getRestTime(String sessionName, long lastAccessTime, long createTime)
  {
    long currentTime = System.currentTimeMillis();
    if (getforceExpirationPeriod(sessionName) == 0)
    {
      return getMaxInactiveInterval(sessionName);
    }

    long lastTimeOut = createTime + getforceExpirationPeriod(sessionName);
    if (lastTimeOut - lastAccessTime > getMaxInactiveInterval(sessionName))
    {
      return getMaxInactiveInterval(sessionName);
    }
    return (int)(lastTimeOut - lastAccessTime);
  }

  public Session getSession(String sessionName, String key)
  {
    Session session = (Session)this.sessions.get(key);
    if ((session == null) && (useDb(sessionName, null)))
      try
      {
        session = getSesseionFromDB(sessionName, new String[] { key });
      }
      catch (Exception e) {
      }
    if ((session == null) && (useCache(sessionName, null)))
      try
      {
        session = getSesseionFromCache(sessionName, key);
      }
      catch (BaseException e) {
      }
    if (checkTimeout(session, sessionName))
    {
      session = null;
    }
    if ((session != null) && (isKeepInTouch(sessionName)))
    {
      updateSessionLastAccessTime(session);
    }
    return session;
  }

  public Session getSesseionFromDB(String sessionName, String[] args)
    throws SQLException, IOException, ClassNotFoundException
  {
    Session session = null;
    Object obj = byteToObject(getObjectFromDB(getDataSourceName(sessionName, null), this.getSessionSQL, args));
    if (obj != null) session = (IFPSession)obj;
    return session;
  }

  public Session getSesseionFromCache(String sessionName, String key)
    throws BaseException
  {
    Session session = null;
    Object obj = null;
    obj = this.ifpCacheManager.get(getCacheName(sessionName, null), "sessionId:" + key, 3);

    if (obj != null) session = (IFPSession)obj;
    return session;
  }

  public Map<String, SessionElement> getSessionElementMap() {
    return this.sessionElementMap;
  }

  public void setSessionElementMap(Map<String, SessionElement> sessionElementMap) {
    this.sessionElementMap = sessionElementMap;
  }

  public int getMaxInactiveInterval(String sessionName)
  {
    if (this.sessionElementMap != null)
    {
      SessionElement sessionelement = (SessionElement)this.sessionElementMap.get(sessionName);
      if (sessionelement.getMaxInactiveInterval() >= 0)
      {
        return sessionelement.getMaxInactiveInterval();
      }
    }
    return (this.sessionTimeOut * 1000);
  }

  public int getMaxInactiveInterval(String sessionName, String sessionInfoName)
  {
    SessionNameElement sessionNameElement = getSessionNameElement(sessionName, sessionInfoName);
    if ((sessionNameElement != null) && (sessionNameElement.getMaxInactiveInterval() >= 0) && (!("".equals(Integer.valueOf(sessionNameElement.getMaxInactiveInterval())))) && (sessionNameElement.getMaxInactiveInterval() <= getMaxInactiveInterval(sessionName)) && (getMaxInactiveInterval(sessionName) > 0) && (sessionNameElement.getMaxInactiveInterval() > 0))
    {
      return sessionNameElement.getMaxInactiveInterval();
    }
    return getMaxInactiveInterval(sessionName);
  }

  public boolean getHttpOnly(String sessionName) {
    if (this.sessionElementMap != null) {
      SessionElement sessionelement = (SessionElement)this.sessionElementMap.get(sessionName);
      if (null != sessionelement)
        return sessionelement.isHttpOnly();

      return false;
    }

    return false;
  }

  public boolean getHttpOnly(String sessionName, String sessionInfoName) {
    SessionNameElement sessionNameElement = getSessionNameElement(sessionName, sessionInfoName);
    if ((sessionNameElement != null) && (sessionNameElement.getMaxInactiveInterval() >= 0) && (!("".equals(Integer.valueOf(sessionNameElement.getMaxInactiveInterval())))) && (sessionNameElement.getMaxInactiveInterval() <= getMaxInactiveInterval(sessionName)) && (getMaxInactiveInterval(sessionName) > 0) && (sessionNameElement.getMaxInactiveInterval() > 0))
    {
      return sessionNameElement.isHttpOnly();
    }

    return getHttpOnly(sessionName);
  }

  public boolean isKeepInTouch(String sessionName)
  {
    if (this.sessionElementMap != null)
    {
      SessionElement sessionelement = (SessionElement)this.sessionElementMap.get(sessionName);
      return sessionelement.isKeepInTouch();
    }
    return true;
  }

  public int getforceExpirationPeriod(String sessionName)
  {
    if (this.sessionElementMap != null)
    {
      SessionElement sessionelement = (SessionElement)this.sessionElementMap.get(sessionName);
      if (sessionelement.getForceExpirationPeriod() >= 0)
      {
        return sessionelement.getForceExpirationPeriod();
      }
    }
    return (this.sessionTimeOut * 1000);
  }

  public int getforceExpirationPeriod(String sessionName, String sessionInfoName)
  {
    SessionNameElement sessionNameElement = getSessionNameElement(sessionName, sessionInfoName);
    if ((sessionNameElement != null) && (sessionNameElement.getForceExpirationPeriod() >= 0) && (!("".equals(Integer.valueOf(sessionNameElement.getForceExpirationPeriod())))) && (sessionNameElement.getForceExpirationPeriod() <= getforceExpirationPeriod(sessionName)) && (getforceExpirationPeriod(sessionName) > 0) && (sessionNameElement.getForceExpirationPeriod() > 0))
    {
      return sessionNameElement.getForceExpirationPeriod();
    }
    return getforceExpirationPeriod(sessionName);
  }

  public boolean ifSaveCookie(String sessionName)
  {
    if (this.sessionElementMap != null)
    {
      SessionElement sessionelement = (SessionElement)this.sessionElementMap.get(sessionName);
      return sessionelement.isSaveCookie();
    }
    return false;
  }

  public Object getObjectFromDB(String dataSource, String sql, String[] args)
    throws SQLException
  {
    List list = this.dataSourceHandle.querySQL(dataSource, sql, args);
    if (list.size() > 0) {
      String[] datas = (String[])list.get(list.size() - 1);
      if ((null != datas) && (datas.length > 0))
        return datas[0];

    }

    return null;
  }

  private Object byteToObject(Object byteObj)
    throws IOException, ClassNotFoundException
  {
    Object obj = null;
    if ((byteObj != null) && (byteObj instanceof byte[]))
    {
      byte[] b = (byte[])(byte[])byteObj;
      ByteArrayInputStream bais = new ByteArrayInputStream(b);
      ObjectInputStream ois = new ObjectInputStream(bais);
      obj = ois.readObject();

      ois.close();
      bais.close();
    }
    return obj;
  }

  public void initialize()
  {
    Map sessionInfoMap = BeanFactoryUtils.beansOfTypeIncludingAncestors(SpringContextsUtil.getApplicationContext(), SessionInfo.class, true, false);
    if ((sessionInfoMap != null) && (!(sessionInfoMap.isEmpty())))
    {
      for (Iterator i$ = sessionInfoMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entity = (Map.Entry)i$.next();
        Map map = new HashMap();
        Field[] fields = ((SessionInfo)entity.getValue()).getClass().getFields();
        Field[] arr$ = fields; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Field field = arr$[i$];

          map.put(field.getName(), field);
        }
        this.fieldMap.put(entity.getKey(), map);
      }
    }

    if (this.sessionCheckInterval > 0)
    {
      Trace.log("CORE", 1, "Start up session checker for IFPSessionManager sessionTimeOut=" + this.sessionTimeOut + " check interval=" + this.sessionCheckInterval);
      this.timer = new Timer();
      this.timer.schedule(new SessionCheckTask(this, null), this.sessionTimeOut, this.sessionCheckInterval);
      Trace.log("CORE", 1, "Start up session checker for IFPSessionManager  ok!");
    }
  }

  public void clearSessionOfTimeout()
  {
    Trace.log("CORE", 0, "Do the session check for IFPSessionManager");
    Object[] keys = null;
    try {
      keys = this.sessions.keySet().toArray();
    }
    catch (Exception e) {
      Trace.log("CORE", 3, "Failed to do session time out check: ", e);
      return;
    }
    for (int i = 0; i < keys.length; )
    {
      try {
        if (this.sessions.get(keys[i]) instanceof Session)
        {
          IFPSession session = (IFPSession)this.sessions.get(keys[i]);
          if (session == null)
            break label263:

          if (checkTimeout(session, session.getSessionName()))
          {
            Trace.log("CORE", 0, "Session time out: " + session.getSessionId());
          }
        }
        else if (this.sessions.get(keys[i]) instanceof SessionInfo)
        {
          String key = (String)keys[i];
          SessionInfo sessionInfo = (SessionInfo)this.sessions.get(keys[i]);
          String[] keyName = key.split(".");
          if (keyName.length == 3)
          {
            String sessionName = keyName[0];
            String sessionInfoName = keyName[1];
            if (sessionInfo == null)
              break label263:

            if (checkTimeout(sessionInfo, sessionName, sessionInfoName))
            {
              Trace.log("CORE", 0, "Session time out: " + sessionInfo.getSessionId());
            }
          }
        }
      }
      catch (Exception e) {
        Trace.log("CORE", 3, "Failed to do session time out check", e);
      }
      label263: ++i;
    }
  }

  public int getSessionCheckInterval()
  {
    return this.sessionCheckInterval; }

  public void setSessionCheckInterval(int sessionCheckInterval) {
    this.sessionCheckInterval = sessionCheckInterval;
  }

  public void setAttribute(Session session, String key, Object value)
  {
    session.setAttribute(key, value);
    updateSession(session);
  }

  public String getAlgorithm(String sessionName)
  {
    if (this.sessionElementMap != null)
    {
      SessionElement sessionelement = (SessionElement)this.sessionElementMap.get(sessionName);
      if ((sessionelement.getAlgorithm() != null) && (!("".equals(sessionelement.getAlgorithm()))))
        return sessionelement.getAlgorithm();
    }
    return this.algorithm;
  }

  public void saveSessionInfo(String sessionName, String sessionInfoName, SessionInfo sessionInfo, Object handle)
    throws BaseException
  {
    if (this.count <= this.limit)
      try
      {
        long currentTimeMillis = System.currentTimeMillis();
        sessionInfo.setCreateTime(currentTimeMillis);
        sessionInfo.setLastAccessTime(currentTimeMillis);
        SessionNameElement sessionNameElement = getSessionNameElement(sessionName, sessionInfoName);

        if (sessionNameElement.isSaveCookie())
        {
          HttpServletResponse response = null;
          if (handle instanceof HttpServletResponse)
          {
            response = (HttpServletResponse)handle;
            addResponseCookie(sessionName, sessionInfoName, sessionInfo, response);
          }
        }
        if (useDb(sessionName, sessionInfoName))
        {
          ??? = DateUtil.getStringToday();
          this.dataSourceHandle.excuteSQL(getDataSourceName(sessionName, sessionInfoName), this.saveSessionInfoSQL, new Object[] { sessionInfo.getSessionId(), sessionInfo, ???, ??? });
        }
        else if (useCache(sessionName, sessionInfoName))
        {
          this.ifpCacheManager.put(getCacheName(sessionName, sessionInfoName), sessionName + "." + sessionInfoName + "." + sessionInfo.getSessionId(), sessionInfo, getMaxInactiveInterval(sessionName, sessionInfoName));
        }
        else
        {
          this.sessions.put(sessionName + "." + sessionInfoName + "." + sessionInfo.getSessionId(), sessionInfo);
          synchronized (this) {
            this.count += -3763407398824312831L;
          }
        }
      } catch (Exception e) {
        throw new SessionException(e);
      }

    throw new SessionException("系统繁忙，请稍后再试！");
  }

  public void updateSessionInfo(String sessionName, String sessionInfoName, SessionInfo sessionInfo, Object handle)
    throws BaseException
  {
    try
    {
      if (sessionInfo == null) return;
      sessionInfo.setLastAccessTime(System.currentTimeMillis());
      SessionNameElement sessionNameElement = getSessionNameElement(sessionName, sessionInfoName);
      if (sessionNameElement.isSaveCookie())
      {
        HttpServletResponse response = null;
        if (handle instanceof HttpServletResponse)
        {
          response = (HttpServletResponse)handle;
          addResponseCookie(sessionName, sessionInfoName, sessionInfo, response);
        }
      }
      if (useDb(sessionName, sessionInfoName))
      {
        String currentTime = DateUtil.getStringToday();
        this.dataSourceHandle.excuteSQL(getDataSourceName(sessionName, sessionInfoName), this.updateSessionInfoSQL, new Object[] { sessionInfo, currentTime, sessionInfo.getSessionId() });
        return;
      }

      if (useCache(sessionName, sessionInfoName))
      {
        this.ifpCacheManager.put(getCacheName(sessionName, sessionInfoName), sessionName + "." + sessionInfoName + "." + sessionInfo.getSessionId(), sessionInfo, getMaxInactiveInterval(sessionName, sessionInfoName));

        return;
      }
      this.sessions.put(sessionName + "." + sessionInfoName + "." + sessionInfo.getSessionId(), sessionInfo);
    } catch (Exception e) {
      throw new SessionException(e);
    }
  }

  public SessionInfo getSessionInfo(String sessionName, String sessionInfoName, String sessionId, Object handle)
    throws BaseException
  {
    if (getSession(sessionName, sessionId) == null) return null;
    SessionNameElement sessionNameElement = getSessionNameElement(sessionName, sessionInfoName);

    SessionInfo obj = null;
    try {
      if ((this.sessions.get(sessionName + "." + sessionInfoName + "." + sessionId) != null) && (this.sessions.get(sessionName + "." + sessionInfoName + "." + sessionId) instanceof SessionInfo))
        obj = (SessionInfo)this.sessions.get(sessionName + "." + sessionInfoName + "." + sessionId);
      if (sessionNameElement.isSaveCookie())
      {
        HttpServletRequest request = null;
        if (handle instanceof HttpServletRequest)
        {
          request = (HttpServletRequest)handle;
          Cookie[] cookies = request.getCookies();
          if (cookies != null)
          {
            Object bean = getSessionInfoBean(sessionInfoName);

            if ((bean != null) && (bean instanceof SessionInfo))
            {
              obj = (SessionInfo)bean;
            }
            SessionInfo sessionInfoObj = obj.deepClone();

            Map attiMap = new HashMap();
            Cookie[] arr$ = cookies; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Cookie c = arr$[i$];

              String cookieKey = c.getName();
              String cookieValue = this.encrypt.getDecodeStr(c.getValue());
              if (cookieKey.startsWith(sessionName + "." + sessionInfoName + "."))
              {
                int index = sessionName + "." + sessionInfoName + ".".length();
                String fieldName = cookieKey.substring(index);
                if (fieldName.indexOf(".") != -1)
                {
                  int i = fieldName.indexOf(".");
                  String fieldNameTemp = fieldName.substring(i + 1);
                  fieldName = fieldName.substring(0, i);
                  if (fieldNameTemp.startsWith("ListValue$"))
                  {
                    List list;
                    if (attiMap.get(fieldName) == null)
                    {
                      list = new ArrayList();
                      list.add(cookieValue);
                      attiMap.put(fieldName, list);
                    } else {
                      list = new ArrayList();
                      list.add(cookieValue);
                      attiMap.put(fieldName, list);
                    }
                  } else {
                    Map map;
                    if (attiMap.get(fieldName) == null)
                    {
                      map = new HashMap();
                      map.put(fieldNameTemp.substring(1), cookieValue);
                      attiMap.put(fieldName, map);
                    } else {
                      map = (Map)attiMap.get(fieldName);
                      map.put(fieldNameTemp.substring(1), cookieValue);
                      attiMap.put(fieldName, map);
                    }
                  }
                }
                else if ((cookieKey != null) && (!("null".equals(cookieKey)))) {
                  attiMap.put(fieldName, cookieValue);
                }
              }
            }
            Iterator it = attiMap.keySet().iterator();
            Map fMap = (Map)this.fieldMap.get(sessionInfoName);
            while (it.hasNext())
            {
              String fieldName = (String)it.next();
              Object valueObj = attiMap.get(fieldName);
              Field field = (Field)fMap.get(fieldName);
              if (field != null)
                setSessionInfoObjVaue(sessionInfoObj, fieldName, valueObj, field.getType());
            }
            if ((sessionInfoObj != null) && (checkTimeout(sessionInfoObj, sessionName, sessionInfoName))) return sessionInfoObj;
          }
        }
      }
      if (useDb(sessionName, sessionInfoName))
      {
        obj = (SessionInfo)byteToObject(getObjectFromDB(getDataSourceName(sessionName, sessionInfoName), this.getSessionInfoSQL, new String[] { sessionId }));
        if ((obj != null) && (checkTimeout(obj, sessionName, sessionInfoName))) return obj;
      }

      if (useCache(sessionName, sessionInfoName))
      {
        obj = (SessionInfo)this.ifpCacheManager.get(getCacheName(sessionName, sessionInfoName), sessionName + "." + sessionInfoName + "." + sessionId, 3);
        if ((obj != null) && (checkTimeout(obj, sessionName, sessionInfoName))) return obj;
      }
    } catch (Exception e) {
      throw new SessionException(e);
    }

    return obj;
  }

  public SessionNameElement getSessionNameElement(String sessionId, String sessionName)
  {
    SessionNameElement sessionNameElement = null;
    if (this.sessionElementMap != null)
    {
      SessionElement sessionelement = (SessionElement)this.sessionElementMap.get(sessionId);
      if ((sessionelement.getSessionNameMap() != null) && (sessionelement.getSessionNameMap().get(sessionName) != null))
        return ((SessionNameElement)sessionelement.getSessionNameMap().get(sessionName));
    }
    return sessionNameElement;
  }

  public boolean useCache(String sessionName, String sessionInfoName)
  {
    String supportType;
    String[] cacheNames;
    int i;
    boolean result = false;
    if ((sessionName != null) && (sessionInfoName != null))
    {
      SessionNameElement sessionNameElement = getSessionNameElement(sessionName, sessionInfoName);
      if (sessionNameElement == null) return false;
      supportType = sessionNameElement.getCacheName();
      if ((supportType != null) && (!("".equals(supportType))))
      {
        cacheNames = this.ifpCacheManager.getCacheNames();
        for (i = 0; i < cacheNames.length; ++i)
        {
          if (supportType.equals(cacheNames[i])) return true;
        }
      }
    } else if (sessionName != null)
    {
      SessionElement sessionElement = (SessionElement)this.sessionElementMap.get(sessionName);
      if (sessionElement == null) return false;
      supportType = sessionElement.getCacheName();
      if ((supportType != null) && (!("".equals(supportType))))
      {
        cacheNames = this.ifpCacheManager.getCacheNames();
        for (i = 0; i < cacheNames.length; ++i)
        {
          if (supportType.equals(cacheNames[i])) return true;
        }
      }
    }
    return result;
  }

  public boolean useDb(String sessionName, String sessionInfoName)
  {
    String supportType;
    boolean result = false;
    if ((sessionName != null) && (sessionInfoName != null))
    {
      SessionNameElement sessionNameElement = getSessionNameElement(sessionName, sessionInfoName);
      if (sessionNameElement == null) return false;
      supportType = sessionNameElement.getDataSourceName();
      if ((supportType != null) && (!("".equals(supportType))) && 
        (this.dataSourceHandle.getJdbcTemplate(supportType) != null)) return true;
    }
    else if (sessionName != null)
    {
      SessionElement sessionElement = (SessionElement)this.sessionElementMap.get(sessionName);
      if (sessionElement == null) return false;
      supportType = sessionElement.getDataSourceName();
      if ((supportType != null) && (!("".equals(supportType))) && 
        (this.dataSourceHandle.getJdbcTemplate(supportType) != null)) return true;
    }

    return result;
  }

  public String getCacheName(String sessionName, String sessionInfoName)
  {
    String supportType;
    String[] cacheNames;
    int i;
    if ((sessionName != null) && (sessionInfoName != null))
    {
      SessionNameElement sessionNameElement = getSessionNameElement(sessionName, sessionInfoName);
      if (sessionNameElement == null) return null;
      supportType = sessionNameElement.getCacheName();
      if ((supportType != null) && (!("".equals(supportType))))
      {
        cacheNames = this.ifpCacheManager.getCacheNames();
        for (i = 0; i < cacheNames.length; ++i)
        {
          if (supportType.equals(cacheNames[i])) return cacheNames[i];
        }
      }
    } else if (sessionName != null)
    {
      SessionElement sessionElement = (SessionElement)this.sessionElementMap.get(sessionName);
      if (sessionElement == null) return null;
      supportType = sessionElement.getCacheName();
      if ((supportType != null) && (!("".equals(supportType))))
      {
        cacheNames = this.ifpCacheManager.getCacheNames();
        for (i = 0; i < cacheNames.length; ++i)
        {
          if (supportType.equals(cacheNames[i])) return cacheNames[i];
        }
      }
    }
    return this.sessionCache;
  }

  public String getDataSourceName(String sessionName, String sessionInfoName)
  {
    String supportType;
    if ((sessionName != null) && (sessionInfoName != null))
    {
      SessionNameElement sessionNameElement = getSessionNameElement(sessionName, sessionInfoName);
      if (sessionNameElement == null) return null;
      supportType = sessionNameElement.getDataSourceName();
      if ((supportType != null) && (!("".equals(supportType))))
      {
        return supportType;
      }
    } else if (sessionName != null)
    {
      SessionElement sessionElement = (SessionElement)this.sessionElementMap.get(sessionName);
      if (sessionElement == null) return null;
      supportType = sessionElement.getDataSourceName();
      if ((supportType != null) && (!("".equals(supportType))))
      {
        return supportType;
      }
    }
    return this.sessionCache;
  }

  private void addResponseCookie(String sessionName, String sessionInfoName, SessionInfo info, HttpServletResponse response)
  {
    Field[] fields = info.getClass().getFields();
    String key = sessionName + "." + sessionInfoName + ".";
    int maxAge = (getMaxInactiveInterval(sessionName, sessionInfoName) == 0) ? this.cookieMaxAge : getMaxInactiveInterval(sessionName, sessionInfoName);

    boolean isHttpOnly = getHttpOnly(sessionName, sessionInfoName);
    for (int i = 0; i < fields.length; ++i) {
      String name = fields[i].getName();
      Object value = getFieldValueByName(fields[i].getName(), info);

      if (value instanceof List)
      {
        List list = (List)value;
        for (int j = 0; j < list.size(); ++j)
        {
          Cookie cookie = new Cookie(key + name + ".ListValue$" + (j + 1), this.encrypt.getEncryptStr((String)list.get(j)));
          cookie.setMaxAge(maxAge);
          if (response != null)
          {
            CookieUtil.addCookie(response, cookie, isHttpOnly);
          }
        }
      } else if (value instanceof Map)
      {
        Map map = (Map)value;
        Iterator it = map.keySet().iterator();
        while (it.hasNext())
        {
          String mapKey = (String)it.next();
          Cookie cookie = new Cookie(key + name + "." + mapKey, this.encrypt.getEncryptStr((String)map.get(mapKey)));
          cookie.setMaxAge(maxAge);
          if (response != null)
          {
            CookieUtil.addCookie(response, cookie, isHttpOnly);
          }
        }
      } else {
        Cookie cookie = new Cookie(key + name, this.encrypt.getEncryptStr(String.valueOf(value)));
        cookie.setMaxAge(maxAge);
        if (response != null)
        {
          CookieUtil.addCookie(response, cookie, isHttpOnly);
        }
      }
    }
  }

  private Object getFieldValueByName(String fieldName, Object o)
  {
    Method method;
    try
    {
      method = o.getClass().getMethod("get" + StringUtils.capitalize(fieldName), new Class[0]);
      Object value = method.invoke(o, new Object[0]);
      return value; } catch (Exception e) {
    }
    return null;
  }

  private Object getSessionInfoBean(String sessionInfoName)
  {
    return SpringContextsUtil.getBean(sessionInfoName);
  }

  private void setSessionInfoObjVaue(SessionInfo sessionInfoObj, String fieldName, Object value, Class<?> type)
    throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException
  {
    Method method = sessionInfoObj.getClass().getMethod("set" + StringUtils.capitalize(fieldName), new Class[] { type });
    if (("int".equals(type.toString())) || (type == Integer.class))
    {
      method.invoke(sessionInfoObj, new Object[] { Integer.valueOf(Integer.parseInt(value.toString())) });
    } else if (("long".equals(type.toString())) || (type == Long.class))
    {
      method.invoke(sessionInfoObj, new Object[] { Long.valueOf(Long.parseLong(value.toString())) });
    } else if (("List".equals(type.toString())) || (type == List.class))
    {
      method.invoke(sessionInfoObj, new Object[] { (List)value });
    } else if (("Map".equals(type.toString())) || (type == Map.class))
    {
      method.invoke(sessionInfoObj, new Object[] { (Map)value });
    }
    else method.invoke(sessionInfoObj, new Object[] { value });
  }

  public String getSessionCache()
  {
    return this.sessionCache;
  }

  public void setSessionCache(String sessionCache) {
    this.sessionCache = sessionCache; }

  public String getCacheManager() {
    return this.cacheManager; }

  public void setCacheManager(String cacheManager) {
    this.cacheManager = cacheManager; }

  public String getGetSessionSQL() {
    return this.getSessionSQL; }

  public void setGetSessionSQL(String getSessionSQL) {
    this.getSessionSQL = getSessionSQL; }

  public String getCreateSessionSQL() {
    return this.createSessionSQL; }

  public void setCreateSessionSQL(String createSessionSQL) {
    this.createSessionSQL = createSessionSQL; }

  public String getUpdateSessionSQL() {
    return this.updateSessionSQL; }

  public void setUpdateSessionSQL(String updateSessionSQL) {
    this.updateSessionSQL = updateSessionSQL; }

  public String getDeleteSessionSQL() {
    return this.deleteSessionSQL; }

  public void setDeleteSessionSQL(String deleteSessionSQL) {
    this.deleteSessionSQL = deleteSessionSQL;
  }

  public String getGetSessionInfoSQL() {
    return this.getSessionInfoSQL; }

  public void setGetSessionInfoSQL(String getSessionInfoSQL) {
    this.getSessionInfoSQL = getSessionInfoSQL; }

  public String getUpdateSessionInfoSQL() {
    return this.updateSessionInfoSQL; }

  public void setUpdateSessionInfoSQL(String updateSessionInfoSQL) {
    this.updateSessionInfoSQL = updateSessionInfoSQL; }

  public String getSaveSessionInfoSQL() {
    return this.saveSessionInfoSQL; }

  public void setSaveSessionInfoSQL(String saveSessionInfoSQL) {
    this.saveSessionInfoSQL = saveSessionInfoSQL;
  }

  public CacheManager getIfpCacheManager() {
    return this.ifpCacheManager; }

  public void setIfpCacheManager(CacheManager ifpCacheManager) {
    this.ifpCacheManager = ifpCacheManager;
  }

  public DataSourceHandle getDataSourceHandle() {
    return this.dataSourceHandle; }

  public void setDataSourceHandle(DataSourceHandle dataSourceHandle) {
    this.dataSourceHandle = dataSourceHandle; }

  public EncryptHandle getEncrypt() {
    return this.encrypt; }

  public void setEncrypt(EncryptHandle encrypt) {
    this.encrypt = encrypt;
  }

  public Map getSessions() {
    return this.sessions;
  }

  public void setSessions(Map sessions) {
    this.sessions = sessions;
  }

  public boolean isCreateWhenNotCreate() {
    return this.createWhenNotCreate;
  }

  public void setCreateWhenNotCreate(boolean createWhenNotCreate) {
    this.createWhenNotCreate = createWhenNotCreate;
  }

  public long getLimit() {
    return this.limit;
  }

  public void setLimit(long limit) {
    this.limit = limit;
  }

  private String getClazz(String sessionName)
  {
    if (this.sessionElementMap != null)
    {
      SessionElement sessionelement = (SessionElement)this.sessionElementMap.get(sessionName);
      if (StringUtil.hasText(sessionelement.getClazz()))
      {
        return sessionelement.getClazz();
      }
    }
    return null;
  }

  public List<IFPSession> getAllSessionFromCache(String cacheName)
  {
    if (this.ifpCacheManager instanceof CacheHandler) {
      CacheManager cm = (CacheManager)((CacheHandler)this.ifpCacheManager).getCacheMap().get(cacheName);
      if (cm instanceof IFPRedisManager) {
        IFPRedisManager redisMgr = (IFPRedisManager)cm;
        Set keys = redisMgr.getKeys(cacheName, cacheName + "_" + "sessionId:" + "*");
        if ((keys == null) || (keys.isEmpty()))
          return Collections.EMPTY_LIST;

        List sessionStr = redisMgr.getMString(cacheName, (String[])keys.toArray(new String[keys.size()]));
        if ((sessionStr == null) || (sessionStr.isEmpty()))
          return Collections.EMPTY_LIST;

        List sessionList = new ArrayList();
        for (Iterator i$ = sessionStr.iterator(); i$.hasNext(); ) { String sStr = (String)i$.next();
          try {
            if (StringUtil.hasText(sStr))
            {
              Object o = SerializeUtils.unSerialize(sStr);
              sessionList.add((IFPSession)o);
            } else {
              Trace.log("MONITOR", 2, "sessionStr is null:{}", new Object[] { sStr });
            }
          } catch (BaseException e) {
            while (true) Trace.log("MONITOR", 3, "getAllSessionFromCache Error!", e);
          }
        }

        return sessionList;
      }

    }

    return Collections.EMPTY_LIST;
  }

  public String getClientMacFieldName() {
    return this.clientMacFieldName;
  }

  public void setClientMacFieldName(String clientMacFieldName) {
    this.clientMacFieldName = clientMacFieldName;
  }

  public String getDeviceIdFieldName() {
    return this.deviceIdFieldName;
  }

  public void setDeviceIdFieldName(String deviceIdFieldName) {
    this.deviceIdFieldName = deviceIdFieldName;
  }

  public String getDeviceNameFieldName() {
    return this.deviceNameFieldName;
  }

  public void setDeviceNameFieldName(String deviceNameFieldName) {
    this.deviceNameFieldName = deviceNameFieldName;
  }

  public String getSessionId(Object requestObj, Object responseObj, String sessionName, ClogicContext context) throws BaseException
  {
    IFPSession session;
    try {
      session = getSession(requestObj, sessionName);
      if ((session == null) && (this.createWhenNotCreate))
      {
        session = createSession(responseObj, requestObj, sessionName, context);
      }
      if (session != null) return session.getId();
    } catch (BaseException e) {
      Trace.log("CORE", 3, "get sessionID ERROR...", e);
    }
    return null;
  }

  public IFPSession createSession(Object responseObj, Object requestObj, String sessionName, ClogicContext context)
    throws BaseException
  {
    Map paramsMap = (Map)context.getDataMap();
    if ((null == paramsMap) || (paramsMap.isEmpty())) {
      return createSession(responseObj, requestObj, sessionName);
    }

    if (this.count <= this.limit)
      try
      {
        LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
        String sessionId = generateSessionId(sessionName, null);
        IFPSession session = new IFPSession(sessionId, sessionName);
        if (StringUtil.hasText(getClazz(sessionName)))
        {
          Class c = Class.forName(getClazz(sessionName));
          session = (IFPSession)c.newInstance();
          session.setSessionId(sessionId);
          session.setSessionName(sessionName);
        }
        String reqIP = ((HttpServletRequest)requestObj).getRemoteAddr();
        String uri = ((HttpServletRequest)requestObj).getRequestURI();
        session.setAttribute("CLIENT_IP", reqIP);
        session = setSessionFromRequest(paramsMap, session);

        if (ifSaveCookie(sessionName))
          saveSessionToCookie(uri, responseObj, session, sessionId, sessionName);
        if (useDb(sessionName, null))
        {
          saveSessionToDB(session, sessionId, sessionName);
        }
        else if (useCache(sessionName, null))
        {
          saveSessionToCache(session, sessionId);
        }
        else {
          this.sessions.put(sessionId, session);
          synchronized (this) {
            this.count += -3763407398824312831L;
          }
        }
        logHandle.logFlumeSessionCreate(session);
        if (null != logHandle.getFlumeLogInf())
          logHandle.getFlumeLogInf().setFlumeSessionId(session.getId());

        return session;
      } catch (Exception e) {
        throw new SessionException(e);
      }

    throw new SessionException("系统繁忙，请稍后再试！");
  }

  private class SessionCheckTask extends TimerTask
  {
    public void run()
    {
      this.this$0.clearSessionOfTimeout();
    }
  }
}