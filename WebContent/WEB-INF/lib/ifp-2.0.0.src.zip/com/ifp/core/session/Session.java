package com.ifp.core.session;

import java.util.Enumeration;

public abstract interface Session
{
  public abstract void setAttribute(String paramString, Object paramObject);

  public abstract Object getAttribute(String paramString);

  public abstract void removeAttribute(String paramString);

  public abstract Enumeration getAttributeNames();

  public abstract String getId();

  public abstract String getSessionName();

  public abstract long getLastAccessTime();

  public abstract void setLastAccessTime(long paramLong);

  public abstract long getCreateTime();
}