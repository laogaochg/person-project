package com.ifp.core.session;

import java.util.Enumeration;
import javax.servlet.http.HttpSession;

public class IFPHttpSession
  implements Session
{
  private HttpSession httpSession;

  public IFPHttpSession()
  {
  }

  public IFPHttpSession(HttpSession session)
  {
    this.httpSession = session;
  }

  public void setAttribute(String key, Object value) {
    if (this.httpSession != null)
      this.httpSession.setAttribute(key, value);
  }

  public Object getAttribute(String key) {
    if (this.httpSession != null)
      return this.httpSession.getAttribute(key);

    return null;
  }

  public void removeAttribute(String key) {
    if (this.httpSession != null)
      this.httpSession.removeAttribute(key);
    else
      return;
  }

  public Enumeration getAttributeNames() {
    if (this.httpSession == null)
      return null;

    return this.httpSession.getAttributeNames();
  }

  public String getId()
  {
    return this.httpSession.getId();
  }

  public String getSessionName()
  {
    return null;
  }

  public long getLastAccessTime()
  {
    return -3763401076632453120L;
  }

  public long getCreateTime()
  {
    return -3763401076632453120L;
  }

  public void setLastAccessTime(long lastAccessTime)
  {
  }
}