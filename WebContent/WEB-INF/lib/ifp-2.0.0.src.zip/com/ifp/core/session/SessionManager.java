package com.ifp.core.session;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.data.SessionElement;
import com.ifp.core.exception.BaseException;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract interface SessionManager
{
  public abstract String getSessionId(Object paramObject1, Object paramObject2, String paramString)
    throws BaseException;

  public abstract String getSessionId(Object paramObject1, Object paramObject2, String paramString, ClogicContext paramClogicContext)
    throws BaseException;

  public abstract void removeSession(Session paramSession);

  public abstract void sessionRequestEnd(Session paramSession);

  public abstract String encodeURL(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString1, String paramString2);

  public abstract int getSessionCount();

  public abstract Map getSessions();

  public abstract void setSessions(Map paramMap);

  public abstract void terminate();

  public abstract void removeSession(String paramString1, String paramString2);

  public abstract void updateSession(Session paramSession);

  public abstract Session getSession(String paramString1, String paramString2);

  public abstract void setSessionElementMap(Map<String, SessionElement> paramMap);

  public abstract void initialize();

  public abstract void saveSessionInfo(String paramString1, String paramString2, SessionInfo paramSessionInfo, Object paramObject)
    throws BaseException;

  public abstract void updateSessionInfo(String paramString1, String paramString2, SessionInfo paramSessionInfo, Object paramObject)
    throws BaseException;

  public abstract SessionInfo getSessionInfo(String paramString1, String paramString2, String paramString3, Object paramObject)
    throws BaseException;

  public abstract Session createSession(Object paramObject1, Object paramObject2, String paramString)
    throws BaseException;

  public abstract Session createSession(Object paramObject1, Object paramObject2, String paramString, ClogicContext paramClogicContext)
    throws BaseException;

  public abstract void updateSessionLastAccessTime(Session paramSession);
}