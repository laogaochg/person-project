package com.ifp.core.session.schema;

import com.ifp.core.session.schema.parser.SessionInfoNameParser;
import com.ifp.core.session.schema.parser.SessionNameParser;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

public class SessionNamespaceHandler extends NamespaceHandlerSupport
{
  public void init()
  {
    registerBeanDefinitionParser("session", new SessionNameParser());
    registerBeanDefinitionParser("sessions", new SessionInfoNameParser());
  }
}