package com.ifp.gateway.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.AbstractAction;
import com.ifp.core.monitor.Monitor;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.gateway.exception.GatewayBusinessException;
import com.ifp.gateway.handle.GatewayHandle;

@Deprecated
public class GatewayAction extends AbstractAction
{
  private GatewayHandle gwHandle;

  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try {
      String commClient = confMap.getElementValue("commClientName");
      String sysCode = confMap.getElementValue("sysCode");
      String trxCode = confMap.getElementValue("trxCode");

      DataMap headMap = new DataMap();
      headMap.put("commClient", new DataField("commClient", commClient));
      headMap.put("channelId", new DataField("channelId", sysCode));
      headMap.put("transCode", new DataField("transCode", trxCode));
      headMap.put("LogicCode", new DataField("LogicCode", context.getLogicCode()));
      MonitorManager monitorMgr = (MonitorManager)SpringContextsUtil.getBean("monitorManager");
      Monitor monitor = monitorMgr.getMonitor(context.getMonitorId());
      if (null != monitor)
        headMap.put("actionId", new DataField("actionId", monitor.getCurrentMonitorStep()));

      this.gwHandle.execute(headMap, dataMap);
    } catch (GatewayBusinessException e) {
      throw e;
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }

  public GatewayHandle getGwHandle() {
    return this.gwHandle;
  }

  public void setGwHandle(GatewayHandle gwHandle) {
    this.gwHandle = gwHandle;
  }
}