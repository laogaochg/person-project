package com.ifp.gateway.formatter.template;

import com.ifp.core.data.DataMap;
import com.ifp.core.util.DataMapChangeUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.formatter.IFormatter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.lang.StringUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;

public class TemplateFormatter
  implements IFormatter<Map>
{
  private TemplateContent templateContent;
  private String encoding;

  public TemplateFormatter()
  {
    this.encoding = "UTF-8"; }

  public String format(Map headMap, Map dataMap, MessageDefine msgDefine) throws Exception {
    String channelId = StringUtil.getValue(headMap.get("channelId"));
    String transCode = StringUtil.getValue(headMap.get("transCode"));
    if ((StringUtil.hasText(channelId)) && (StringUtil.hasText(transCode))) {
      String templateStr = this.templateContent.getRequestTemplateContent(channelId, transCode);

      Template template = Velocity.getTemplate(templateStr, this.encoding);
      VelocityContext context = new VelocityContext();

      Map paramMap = new HashMap();

      if (headMap instanceof DataMap)
        DataMapChangeUtil.dataMapToMap((DataMap)headMap, paramMap);
      else {
        paramMap.putAll(headMap);
      }

      if (dataMap instanceof DataMap)
        DataMapChangeUtil.dataMapToMap((DataMap)dataMap, paramMap);
      else {
        paramMap.putAll(dataMap);
      }

      Iterator it = paramMap.keySet().iterator();
      while (it.hasNext()) {
        String key = (String)it.next();
        Object value = paramMap.get(key);
        if (value == null)
          value = "";

        if (value instanceof String)
          context.put(key, StringUtils.replace((String)value, "<", "&lt;"));
        else if (value instanceof List)
          context.put(key, value);
      }

      StringWriter writer = new StringWriter();
      template.merge(context, writer);

      return writer.toString();
    }
    throw new Exception("channelId or transCode is null: " + channelId + "," + transCode);
  }

  public Map unformat(Map headMap, String recMsg, MessageDefine msgDefine) throws Exception
  {
    return null;
  }

  public void unformat(Map headMap, Map dataMap, String recMsg, MessageDefine msgDefine) throws Exception
  {
  }

  public TemplateContent getTemplateContent() {
    return this.templateContent;
  }

  public void setTemplateContent(TemplateContent templateContent) {
    this.templateContent = templateContent;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }
}