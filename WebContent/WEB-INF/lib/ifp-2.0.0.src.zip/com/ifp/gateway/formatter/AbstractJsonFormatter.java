package com.ifp.gateway.formatter;

import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.util.List;
import java.util.Map;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public abstract class AbstractJsonFormatter<T extends Map, D extends List>
  implements IFormatter<T>
{
  public abstract Object format(T paramT1, T paramT2, MessageDefine paramMessageDefine)
    throws Exception;

  public abstract void formatGroup(StringBuffer paramStringBuffer, T paramT1, T paramT2, GroupMap paramGroupMap)
    throws Exception;

  public abstract void formatField(StringBuffer paramStringBuffer, T paramT1, T paramT2, MsgField paramMsgField)
    throws Exception;

  public abstract void formatList(StringBuffer paramStringBuffer, T paramT, D paramD, MsgList paramMsgList)
    throws Exception;

  public abstract void unformat(T paramT1, T paramT2, String paramString, MessageDefine paramMessageDefine)
    throws Exception;

  public abstract void unformatGroup(T paramT1, T paramT2, JSONObject paramJSONObject, GroupMap paramGroupMap)
    throws Exception;

  public abstract void unformatField(T paramT1, T paramT2, String paramString, MsgField paramMsgField)
    throws Exception;

  public abstract void unformatList(T paramT1, T paramT2, JSONArray paramJSONArray, MsgList paramMsgList)
    throws Exception;
}