package com.ifp.gateway.formatter;

import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.util.List;
import java.util.Map;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class PassMessageFormatter extends AbstractJsonFormatter<Map, List>
{
  private String msgKey;

  public PassMessageFormatter()
  {
    this.msgKey = "passMessageInOne";
  }

  public Object format(Map headMap, Map dataMap, MessageDefine msgDefine) throws Exception {
    return StringUtil.getValue(dataMap.get(this.msgKey));
  }

  public void formatGroup(StringBuffer msg, Map headMap, Map dataMap, GroupMap groupDefine)
    throws Exception
  {
  }

  public void formatField(StringBuffer msg, Map headMap, Map dataMap, MsgField fieldDefine)
    throws Exception
  {
  }

  public void formatList(StringBuffer msg, Map headMap, List dataList, MsgList listDefine)
    throws Exception
  {
  }

  public void unformat(Map headMap, Map dataMap, String recMsg, MessageDefine msgDefine) throws Exception
  {
    StringUtil.setValue(dataMap, this.msgKey, recMsg);
  }

  public void unformatGroup(Map headMap, Map outDataMap, JSONObject groupObject, GroupMap defineMap)
    throws Exception
  {
  }

  public void unformatField(Map headMap, Map outDataMap, String jsonValue, MsgField fieldDefine)
    throws Exception
  {
  }

  public void unformatList(Map headMap, Map outDataMap, JSONArray jsonArray, MsgList listDefine) throws Exception
  {
  }

  public String getMsgKey()
  {
    return this.msgKey;
  }

  public void setMsgKey(String msgKey) {
    this.msgKey = msgKey;
  }
}