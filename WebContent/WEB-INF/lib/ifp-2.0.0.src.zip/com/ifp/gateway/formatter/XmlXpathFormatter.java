package com.ifp.gateway.formatter;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;

public class XmlXpathFormatter extends AbstractXmlXpathFormatter<Map, List>
{
  private String fieldValueName;

  public void formatGroup(Map headMap, Map dataMap, Node node, GroupMap groupDefine, String xpath)
    throws Exception
  {
    String npath = "/" + groupDefine.getXpath();

    Element groupElement = null;
    int index = npath.indexOf("[");
    if (index >= 0)
      groupElement = createXpathElement((Element)node, npath);
    else {
      groupElement = DocumentHelper.makeElement((Element)node, npath);
    }

    Iterator defineIterator = groupDefine.entrySet().iterator();
    while (defineIterator.hasNext()) {
      Map.Entry defineEntry = (Map.Entry)defineIterator.next();
      String key = (String)defineEntry.getKey();
      DataElement defineElement = (DataElement)defineEntry.getValue();
      if (defineElement instanceof GroupMap)
        formatGroup(headMap, dataMap, groupElement, (GroupMap)defineElement, npath);
      else
        formatElement(headMap, dataMap, groupElement, defineElement, npath);
    }
  }

  public void formatElement(Map headMap, Map dataMap, Node node, DataElement defineElement, String xpath)
    throws Exception
  {
    if (defineElement instanceof MsgField) {
      formatField(headMap, dataMap, node, (MsgField)defineElement, xpath);
    } else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null != listDefine) {
        Object listElement = dataMap.get(listDefine.getRefName());
        if (null == listElement) {
          if (listDefine.isNeed())
            throw new Exception(listDefine.getName() + " is need!");

          return;
        }

        if (!(listElement instanceof List))
          throw new Exception(listDefine.getName() + " is undefine list, here expect of List!");

        formatList(headMap, (List)listElement, node, listDefine, xpath);
      }
    }
  }

  public void formatField(Map headMap, Map dataMap, Node node, MsgField fieldDefine, String xpath)
    throws Exception
  {
    Object dataElement;
    String key = fieldDefine.getName();
    String value = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();

    if ((null != fieldDefine.getPattern()) && (fieldDefine.getPattern().equalsIgnoreCase("head")))
      dataElement = headMap.get(refName);
    else
      dataElement = dataMap.get(refName);

    if (null == dataElement) {
      if ((!(fieldDefine.isNeed())) || (StringUtil.hasText(value))) break label176;
      throw new Exception(fieldDefine.getName() + " is need!");
    }

    if (dataElement instanceof DataElement) {
      DataField dataField = (DataField)dataElement;
      if ((null != dataField) && (StringUtil.hasText(dataField.getValue())))
        value = dataField.getValue();
    }
    else if (StringUtil.hasText(dataElement)) {
      value = (String)dataElement;
    }

    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      label176: throw new Exception(fieldDefine.getName() + " is empty!");
    }

    String npath = "/" + fieldDefine.getXpath();
    Element element = createXpathElement((Element)node, npath);
    value = (value == null) ? "" : value;
    if (StringUtil.hasText(this.fieldValueName))
      element.addAttribute(this.fieldValueName, value);
    else
      element.setText(value);
  }

  public void formatList(Map headMap, List dataList, Node node, MsgList listDefine, String xpath)
    throws Exception
  {
    String npath = "/" + listDefine.getXpath();
    Element listElement = (Element)node;
    if (StringUtil.hasText(listDefine.getSubXpath())) {
      listElement = createXpathElement(listElement, npath);
      npath = listDefine.getSubXpath();
    }

    Object[] fieldDefineArray = listDefine.values().toArray();
    for (Iterator i$ = dataList.iterator(); i$.hasNext(); ) { Object rowElement = i$.next();
      if (rowElement instanceof Map) {
        Element mapElement = createXpathListElement(listElement, npath);
        Map rowMap = (Map)rowElement;
        Object[] arr$ = fieldDefineArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object defineObject = arr$[i$];
          formatElement(headMap, rowMap, mapElement, (DataElement)defineObject, npath);
        }
      } else {
        throw new Exception("List rows expect of Map");
      }
    }
  }

  public void unformat(Map headMap, Map dataMap, String recMsg, MessageDefine msgDefine)
    throws Exception
  {
    Document document = DocumentHelper.parseText(recMsg);
    String xpath = "/" + msgDefine.getXpath();

    Iterator elementIter = msgDefine.getElementMap().entrySet().iterator();
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof GroupMap) {
        GroupMap defineGroup = (GroupMap)defineElement;
        String type = defineGroup.getType();
        if ((null != type) && (type.equals("head")))
          unformatGroup(headMap, headMap, document, defineGroup, xpath);
        else
          unformatGroup(headMap, dataMap, document, defineGroup, xpath);
      }
      else {
        unformatElement(headMap, dataMap, document, defineElement, xpath);
      }
    }
  }

  public void unformatGroup(Map headMap, Map outDataMap, Node node, GroupMap defineMap, String xpath) throws Exception
  {
    String npath = xpath + "/" + defineMap.getXpath();

    if (node.selectSingleNode(npath) == null) {
      if (defineMap.isNeed())
        throw new Exception(defineMap.getName() + " is need!");

      return;
    }

    Iterator defineIterator = defineMap.values().iterator();
    while (defineIterator.hasNext()) {
      DataElement defineElement = (DataElement)defineIterator.next();
      if (defineElement instanceof GroupMap)
        unformatGroup(headMap, outDataMap, node, (GroupMap)defineElement, npath);
      else
        unformatElement(headMap, outDataMap, node, defineElement, npath);
    }
  }

  public void unformatElement(Map headMap, Map outDataMap, Node node, DataElement defineElement, String xpath)
    throws Exception
  {
    if (defineElement instanceof MsgField) {
      MsgField msgField = (MsgField)defineElement;
      String npath = xpath + "/" + msgField.getXpath();
      if (node.selectSingleNode(npath) == null) {
        if (msgField.isNeed())
          throw new Exception(defineElement.getName() + " is need!");

        return;
      }

      unformatField(headMap, outDataMap, node, msgField, npath);
    } else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null != listDefine)
        unformatList(headMap, outDataMap, node, listDefine, xpath);
    }
  }

  public void unformatField(Map headMap, Map outDataMap, Node node, MsgField fieldDefine, String xpath)
    throws Exception
  {
    Node fieldNode = node.selectSingleNode(xpath);
    String key = fieldDefine.getName();
    String value = null;
    if (StringUtil.hasText(this.fieldValueName))
      value = fieldNode.valueOf("@" + this.fieldValueName);
    else {
      value = fieldNode.getText().trim();
    }

    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      throw new Exception(fieldDefine.getName() + " is empty!");
    }

    String defaultValue = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (StringUtil.hasText(refName)) {
      key = refName;
    }

    if ((null != defaultValue) && (!(StringUtil.hasText(value)))) {
      value = defaultValue;
    }

    value = (value == null) ? "" : value;
    if ((null != fieldDefine.getPattern()) && (fieldDefine.getPattern().equalsIgnoreCase("head")))
      StringUtil.setValue(headMap, key, value);
    else
      StringUtil.setValue(outDataMap, key, value);
  }

  public void unformatList(Map headMap, Map outDataMap, Node node, MsgList listDefine, String xpath)
    throws Exception
  {
    String npath = xpath + "/" + listDefine.getXpath();
    if (node.selectSingleNode(npath) == null) {
      if (listDefine.isNeed())
        throw new Exception(listDefine.getName() + " is need!");

      return;
    }

    Object[] fieldDefineArray = listDefine.values().toArray();
    String key = listDefine.getName();
    String refName = listDefine.getRefName();
    if (StringUtil.hasText(refName)) {
      key = refName;
    }

    if (outDataMap instanceof DataMap)
    {
      DataList dList;
      DataMap outMap = (DataMap)outDataMap;

      if (outMap.containsKey(key)) {
        DataElement outElement = outMap.get(key);
        if (outElement instanceof DataList)
          dList = (DataList)outElement;
        else
          throw new Exception(key + " is define list, expect of DataList in context here!");
      }
      else {
        dList = new DataList();
        dList.setDefineMap((DataMap)outMap.getDefineMap().get(key));
      }

      String spath = listDefine.getSubXpath();
      if (StringUtil.hasText(spath)) {
        int idx = spath.indexOf("/");
        if (idx >= 0) {
          npath = npath + "/" + spath.substring(0, idx);
          spath = spath.substring(idx);
        } else {
          npath = npath + "/" + spath;
          spath = "";
        }
      }

      List mapNodeList = node.selectNodes(npath);
      for (int i = 0; i < mapNodeList.size(); ++i) {
        DataMap dMap = dList.createSubDataMap();
        for (int j = 0; j < fieldDefineArray.length; ++j)
          unformatElement(headMap, dMap, node, (DataElement)fieldDefineArray[j], npath + "[" + (i + 1) + "]" + spath);

        dList.add(dMap);
      }

      outDataMap.put(key, dList);
    }
    else
    {
      List dList;
      if (outDataMap.containsKey(key)) {
        Object outElement = outDataMap.get(key);
        if (outElement instanceof List)
          dList = (List)outElement;
        else
          throw new Exception(key + " is define list, expect of List in context here!");
      }
      else {
        dList = new ArrayList();
      }

      String spath = listDefine.getSubXpath();
      if (StringUtil.hasText(spath)) {
        int idx = spath.indexOf("/");
        if (idx >= 0) {
          npath = npath + "/" + spath.substring(0, idx);
          spath = spath.substring(idx);
        } else {
          npath = npath + "/" + spath;
          spath = "";
        }
      }

      List mapNodeList = node.selectNodes(npath);
      for (int i = 0; i < mapNodeList.size(); ++i) {
        Map dMap = new HashMap();
        for (int j = 0; j < fieldDefineArray.length; ++j)
          unformatElement(headMap, dMap, node, (DataElement)fieldDefineArray[j], npath + "[" + (i + 1) + "]" + spath);

        dList.add(dMap);
      }

      outDataMap.put(key, dList);
    }
  }
}