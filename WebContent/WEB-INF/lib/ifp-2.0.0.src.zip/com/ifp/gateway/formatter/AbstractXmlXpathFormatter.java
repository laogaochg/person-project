package com.ifp.gateway.formatter;

import com.ifp.core.data.DataElement;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.dom4j.Branch;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;

public abstract class AbstractXmlXpathFormatter<T extends Map, D extends List>
  implements IFormatter<T>
{
  private String encoding;
  private Pattern pattern;

  public AbstractXmlXpathFormatter()
  {
    this.encoding = "UTF-8";
    this.pattern = Pattern.compile("\\[(( *@\\w+ *= *(#\\w+|'[^']+?') *)|( *and *))+\\]");
  }

  public Object format(T headMap, T dataMap, MessageDefine msgDefine)
    throws Exception
  {
    Document document = DocumentHelper.createDocument();
    document.setXMLEncoding(this.encoding);
    String xpath = msgDefine.getXpath();
    String npath = "/" + xpath;

    Element element = createXpathElement(document, npath);

    Iterator elementIter = msgDefine.getElementMap().entrySet().iterator();
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      String key = (String)elementEntry.getKey();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof GroupMap)
        formatGroup(headMap, dataMap, element, (GroupMap)defineElement, npath);
      else
        formatElement(headMap, dataMap, element, defineElement, npath);

    }

    return document.asXML();
  }

  public abstract void formatGroup(T paramT1, T paramT2, Node paramNode, GroupMap paramGroupMap, String paramString)
    throws Exception;

  public abstract void formatElement(T paramT1, T paramT2, Node paramNode, DataElement paramDataElement, String paramString)
    throws Exception;

  public abstract void formatField(T paramT1, T paramT2, Node paramNode, MsgField paramMsgField, String paramString)
    throws Exception;

  public abstract void formatList(T paramT, D paramD, Node paramNode, MsgList paramMsgList, String paramString)
    throws Exception;

  public void unformat(T headMap, T dataMap, String recMsg, MessageDefine msgDefine)
    throws Exception
  {
  }

  public void unformatGroup(T headMap, T outDataMap, Node node, GroupMap defineMap, String xpath)
    throws Exception
  {
  }

  public void unformatElement(T headMap, T outDataMap, Node parendNode, DataElement defineElement, String xpath)
    throws Exception
  {
  }

  public void unformatField(T headMap, T outDataMap, Node node, MsgField fieldDefine, String xpath)
    throws Exception
  {
  }

  public void unformatList(T headMap, T outDataMap, Node node, MsgList listDefine, String xpath)
    throws Exception
  {
  }

  public Element createXpathElement(Branch branch, String xpath)
  {
    Pattern p = getPattern();
    Matcher matcher = p.matcher(xpath);
    int s_index = 0;
    int e_index = 0;
    Element element = null;
    while (matcher.find()) {
      e_index = matcher.start();
      String fpath = xpath.substring(s_index, e_index);
      int lastIndex = fpath.lastIndexOf("/");

      String nodeName = fpath;
      if (lastIndex >= 0) {
        nodeName = fpath.substring(lastIndex + 1);
      }

      element = DocumentHelper.makeElement(branch, fpath + "temp");
      if (null == element)
        element = branch.getDocument().getRootElement();

      element.setName(nodeName);
      s_index = e_index;
      e_index = matcher.end();
      String attributeStr = xpath.substring(s_index + 1, e_index - 1);

      String[] attributes = attributeStr.split(" and ");
      String[] arr$ = attributes; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String attribute = arr$[i$];
        String[] atts = attribute.split("=");
        String attKey = atts[0].trim().substring(1);
        String attValue = atts[1].trim();
        element.addAttribute(attKey, attValue.substring(1, attValue.length() - 1));
      }

      branch = element;
      s_index = e_index + 1;
    }
    e_index = xpath.length();
    if (s_index < xpath.length()) {
      element = DocumentHelper.makeElement(branch, xpath.substring(s_index, e_index));
      if (null == element)
        element = branch.getDocument().getRootElement();

    }

    return element;
  }

  public Element createXpathListElement(Element element, String xpath)
  {
    if (xpath.startsWith("/")) {
      xpath = xpath.substring(1);
    }

    String nodeName = xpath;
    int index = xpath.indexOf("/");
    if (index > 0) {
      nodeName = xpath.substring(0, index);
      Element subElement = element.addElement(nodeName);
      return DocumentHelper.makeElement(subElement, xpath.substring(index));
    }
    return element.addElement(nodeName);
  }

  public String getEncoding()
  {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public Pattern getPattern() {
    return this.pattern;
  }
}