package com.ifp.gateway.formatter;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.dom4j.Element;

public class KValueFormatter extends AbstractKValueFormatter<Map, List>
{
  protected String encoding;

  public KValueFormatter()
  {
    this.encoding = "UTF-8";
  }

  public String format(Map headMap, Map dataMap, MessageDefine msgDefine)
    throws Exception
  {
    StringBuffer msg = new StringBuffer();
    Iterator elementIter = msgDefine.getElementMap().entrySet().iterator();
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      String key = (String)elementEntry.getKey();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof GroupMap) {
        GroupMap defineGroup = (GroupMap)defineElement;
        formatGroup(msg, headMap, dataMap, defineGroup);
      }
      else {
        formatElement(msg, headMap, dataMap, defineElement);
      }
    }
    return msg.toString().substring(1);
  }

  protected void formatGroup(StringBuffer msg, Map headMap, Map dataMap, GroupMap groupDefine) throws Exception
  {
    Iterator defineIterator = groupDefine.entrySet().iterator();
    while (defineIterator.hasNext()) {
      Map.Entry defineEntry = (Map.Entry)defineIterator.next();
      DataElement defineElement = (DataElement)defineEntry.getValue();
      if (defineElement instanceof GroupMap)
        formatGroup(msg, headMap, dataMap, (GroupMap)defineElement);
      else
        formatElement(msg, headMap, dataMap, defineElement);
    }
  }

  protected void formatElement(StringBuffer msg, Map headMap, Map dataMap, DataElement defineElement) throws Exception {
    if (defineElement instanceof MsgField) {
      formatField(msg, headMap, dataMap, (MsgField)defineElement);
    } else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null != listDefine) {
        String key = listDefine.getName();
        String refName = listDefine.getRefName();
        if (StringUtil.hasText(refName))
          key = refName;

        Object listElement = dataMap.get(key);
        if (null == listElement) {
          if (listDefine.isNeed())
            throw new Exception(listDefine.getName() + " is need!");

          return;
        }

        if (!(listElement instanceof List))
          throw new Exception(key + " is undefine list, here expect of List!");

        formatList(msg, headMap, (List)listElement, listDefine);
      }
    }
  }

  protected void formatField(StringBuffer repMsg, Map headMap, Map dataMap, MsgField fieldDefine)
    throws Exception
  {
    Object dataElement;
    String key = fieldDefine.getName();
    String value = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (!(StringUtil.hasText(refName))) {
      refName = fieldDefine.getName();
    }

    if ((null != fieldDefine.getPattern()) && (fieldDefine.getPattern().equalsIgnoreCase("head")))
      dataElement = headMap.get(refName);
    else {
      dataElement = dataMap.get(refName);
    }

    if (null == dataElement) {
      if ((!(fieldDefine.isNeed())) || (StringUtil.hasText(value))) break label191;
      throw new Exception(fieldDefine.getName() + " is need!");
    }

    if (dataElement instanceof DataElement) {
      DataField dataField = (DataField)dataElement;
      if ((null != dataField) && (StringUtil.hasText(dataField.getValue())))
        value = dataField.getValue();
    }
    else if (StringUtil.hasText(dataElement)) {
      value = (String)dataElement;
    }

    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      label191: throw new Exception(fieldDefine.getName() + " is empty!");
    }

    value = (value == null) ? "" : value;
    repMsg.append("&").append(key).append("=").append(URLEncoder.encode(value, this.encoding));
  }

  protected void formatList(StringBuffer repMsg, Map headMap, List dataList, MsgList listDefine)
    throws Exception
  {
    String listName = listDefine.getName();
    for (int i = 0; i < dataList.size(); ++i)
      if (dataList.get(i) instanceof Map) {
        Map dataMap = (Map)dataList.get(i);
        Iterator keyIterator = dataMap.keySet().iterator();
        while (keyIterator.hasNext()) {
          String key = (String)keyIterator.next();
          Object value = dataMap.get(key);

          if (value instanceof List)
            repMsg.append(listToKValueStr((List)value, listName + "." + key + "[" + i + "]"));
          else
            repMsg.append("&").append(listName).append(".").append(key).append("[").append(i).append("]").append("=");
        }
      }
  }

  private String listToKValueStr(List dataList, String listName)
  {
    if (null == dataList) {
      return "";
    }

    StringBuffer repMsg = new StringBuffer();
    for (int i = 0; i < dataList.size(); ++i)
      if (dataList.get(i) instanceof Map) {
        Map dataMap = (Map)dataList.get(i);
        Iterator keyIterator = dataMap.keySet().iterator();
        while (keyIterator.hasNext()) {
          String key = (String)keyIterator.next();
          Object value = dataMap.get(key);

          if (value instanceof List)
            repMsg.append(listToKValueStr((List)value, listName + "." + key + "[" + i + "]"));
          else
            repMsg.append("&").append(listName).append(".").append(key).append("[").append(i).append("]").append("=");
        }
      }


    return repMsg.toString();
  }

  protected void unformatGroup(Map headMap, Map outDataMap, Element element, GroupMap defineMap)
    throws Exception
  {
  }

  protected void unformatField(Map headMap, Map outDataMap, Element element, MsgField fieldDefine)
    throws Exception
  {
  }

  protected void unformatList(Map headMap, Map outDataMap, Element element, MsgList listDefine)
    throws Exception
  {
  }

  public String getEncoding()
  {
    return this.encoding; }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }
}