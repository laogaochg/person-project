package com.ifp.gateway.formatter.template;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.apache.commons.collections.ExtendedProperties;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.apache.velocity.runtime.resource.Resource;
import org.apache.velocity.runtime.resource.loader.ResourceLoader;

public class StringResourceLoader extends ResourceLoader
{
  public long getLastModified(Resource resource)
  {
    return -3763401214071406592L;
  }

  public InputStream getResourceStream(String templateString)
    throws ResourceNotFoundException
  {
    if ((templateString == null) || (templateString.length() == 0))
      throw new ResourceNotFoundException("No template string provided!");

    InputStream result = new ByteArrayInputStream(templateString.getBytes());
    return result;
  }

  public boolean isSourceModified(Resource resource)
  {
    return false;
  }

  public void init(ExtendedProperties configuration)
  {
  }
}