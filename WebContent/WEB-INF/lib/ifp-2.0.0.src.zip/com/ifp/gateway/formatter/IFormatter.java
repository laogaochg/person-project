package com.ifp.gateway.formatter;

import com.ifp.gateway.bean.MessageDefine;
import java.util.Map;

public abstract interface IFormatter<T extends Map>
{
  public abstract Object format(T paramT1, T paramT2, MessageDefine paramMessageDefine)
    throws Exception;

  public abstract void unformat(T paramT1, T paramT2, String paramString, MessageDefine paramMessageDefine)
    throws Exception;
}