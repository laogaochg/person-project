package com.ifp.gateway.formatter.template;

import com.ifp.core.base.SystemConf;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import com.ifp.core.util.UrlUtil;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.apache.commons.io.IOUtils;
import org.apache.velocity.app.Velocity;

public class TemplateContent
{
  private Map<String, Map<String, String>> requestTemplateMap;
  private Map<String, Map<String, String>> responseTemplateMap;
  private SystemConf systemConf;
  private String templateDir;
  private String proFilePath;
  private String encoding;
  private int maxSize;

  public TemplateContent()
  {
    this.requestTemplateMap = new HashMap();
    this.responseTemplateMap = new HashMap();

    this.encoding = "UTF-8";

    this.maxSize = 1048576; }

  public void init() {
    String rootPath;
    try { rootPath = this.systemConf.getWebRootPath();
      if (this.templateDir.startsWith("classpath:")) {
        rootPath = UrlUtil.getClassPath(super.getClass());
        this.templateDir = this.templateDir.replace("classpath:", "");
      }

      if (this.templateDir.startsWith("/"))
        this.templateDir = this.templateDir.substring(1);
      this.templateDir = rootPath + this.templateDir;
      File templateDirFile = new File(this.templateDir);
      if (!(templateDirFile.exists())) {
        Trace.logError("CONNECT", "load template error, file path unexists:" + this.templateDir);
        return;
      }

      initTemplateMap(templateDirFile);

      Properties p = null;
      if (StringUtil.hasText(this.proFilePath)) {
        File f = new File(rootPath + this.proFilePath);
        if (f.exists()) {
          p = new Properties();
          p.load(new FileInputStream(f));
        }
      }

      if (null != p) {
        Velocity.init(p);
      } else {
        Properties props = new Properties();
        props.put("resource.loader", "srs");
        props.put("srs.resource.loader.public.name", "StringResourceLoader");
        props.put("srs.resource.loader.class", "com.ifp.gateway.formater.template.StringResourceLoader");
        props.put("runtime.log", "velocity.log");
        props.put("input.encoding", this.encoding);
        props.put("output.encoding", this.encoding);
        props.put("runtime.log.logsystem.class", "org.apache.velocity.runtime.log.Log4JLogChute");
        props.put("runtime.log.logsystem.log4j.logger", "velocity");
        props.put("log4j.logger.org.apache.velocity", "ERROR");
        props.setProperty("ISO-8859-1", this.encoding);
        props.setProperty("input.encoding", this.encoding);
        props.setProperty("output.encoding", this.encoding);
        Velocity.init(props);
      }
    } catch (Exception e) {
      Trace.logError("CONNECT", "gateway template content init error!", e);
    }
  }

  public String getRequestTemplateContent(String channelId, String transCode)
  {
    Map transMap = (Map)this.requestTemplateMap.get(channelId);
    if (null == transMap)
      return null;

    return ((String)transMap.get(transCode));
  }

  public String getResponseTemplateContent(String channelId, String transCode)
  {
    Map transMap = (Map)this.responseTemplateMap.get(channelId);
    if (null == transMap)
      return null;

    return ((String)transMap.get(transCode));
  }

  private void initTemplateMap(File dirFile)
  {
    if (dirFile.isDirectory()) {
      File[] tfiles = dirFile.listFiles();
      for (int i = 0; i < tfiles.length; ++i)
        dirFileDataToMap(tfiles[i]);
    }
  }

  private void dirFileDataToMap(File filedir)
  {
    Map map = new HashMap();
    File[] childs = filedir.listFiles();
    for (int i = 0; i < childs.length; ++i)
      if ("request".equals(childs[i].getName().toLowerCase())) {
        fileDataToMap(map, childs[i]);
        this.requestTemplateMap.put(filedir.getName(), map);
      } else if ("response".equals(childs[i].getName().toLowerCase())) {
        fileDataToMap(map, childs[i]);
        this.responseTemplateMap.put(filedir.getName(), map);
      }
  }

  private void fileDataToMap(Map<String, String> map, File dir)
  {
    File[] file = dir.listFiles();
    for (int i = 0; i < file.length; ++i) {
      String fileName = file[i].getName();
      if (!(file[i].isDirectory())) { int k;
        if ((!(fileName.endsWith(".xml"))) && (!(fileName.endsWith(".json"))) && (!(fileName.endsWith(".txt"))) && (!(fileName.endsWith(".properties"))))
        {
          break label150:
        }
        if (file[i].length() > this.maxSize) {
          break label150:
        }

        if ((k = fileName.lastIndexOf(".")) > 0)
          fileName = fileName.substring(0, k); label150: 
        try
        {
          map.put(fileName, readTxtFile(file[i]));
        } catch (IOException e) {
          Trace.logError("CONNECT", "load template file error!", e);
        }
      }
    }
  }

  public String readTxtFile(File file)
    throws IOException
  {
    return IOUtils.toString(new FileInputStream(file), this.encoding);
  }

  public String getProFilePath() {
    return this.proFilePath;
  }

  public void setProFilePath(String proFilePath) {
    this.proFilePath = proFilePath;
  }

  public String getTemplateDir() {
    return this.templateDir;
  }

  public void setTemplateDir(String templateDir) {
    this.templateDir = templateDir;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public int getMaxSize() {
    return this.maxSize;
  }

  public void setMaxSize(int maxSize) {
    this.maxSize = maxSize;
  }

  public SystemConf getSystemConf() {
    return this.systemConf;
  }

  public void setSystemConf(SystemConf systemConf) {
    this.systemConf = systemConf;
  }
}