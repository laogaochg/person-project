package com.ifp.gateway.formatter;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.dom4j.Element;
import org.dom4j.Node;

public class XmlFormatter1 extends AbstractXmlFormatter<Map, List>
{
  public void formatGroup(StringBuffer msg, Map headMap, Map dataMap, GroupMap groupDefine)
    throws Exception
  {
    Iterator defineIterator = groupDefine.entrySet().iterator();
    while (defineIterator.hasNext()) {
      Map.Entry defineEntry = (Map.Entry)defineIterator.next();
      String key = (String)defineEntry.getKey();
      DataElement defineElement = (DataElement)defineEntry.getValue();
      if (defineElement instanceof GroupMap) {
        msg.append("<").append(key).append(">");
        formatGroup(msg, headMap, dataMap, (GroupMap)defineElement);
        msg.append("</").append(key).append(">");
      } else {
        formatElement(msg, headMap, dataMap, defineElement);
      }
    }
  }

  public void formatElement(StringBuffer msg, Map headMap, Map dataMap, DataElement defineElement) throws Exception
  {
    if (defineElement instanceof MsgField) {
      formatField(msg, headMap, dataMap, (MsgField)defineElement);
    } else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null != listDefine) {
        String key = listDefine.getName();
        String refName = listDefine.getRefName();
        if (StringUtil.hasText(refName))
          key = refName;

        Object listElement = dataMap.get(key);
        if (null == listElement) {
          if (listDefine.isNeed())
            throw new Exception(listDefine.getName() + " is need!");

          return;
        }

        if (!(listElement instanceof List))
          throw new Exception(key + " is undefine list, here expect of List!");

        formatList(msg, headMap, (List)listElement, listDefine);
      }
    }
  }

  public void formatField(StringBuffer msg, Map headMap, Map dataMap, MsgField fieldDefine)
    throws Exception
  {
    Object dataElement;
    String key = fieldDefine.getName();
    String value = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (!(StringUtil.hasText(refName))) {
      refName = fieldDefine.getName();
    }

    if ((null != fieldDefine.getPattern()) && (fieldDefine.getPattern().equalsIgnoreCase("head")))
      dataElement = headMap.get(refName);
    else
      dataElement = dataMap.get(refName);

    if (null == dataElement) {
      if ((!(fieldDefine.isNeed())) || (StringUtil.hasText(value))) break label191;
      throw new Exception(fieldDefine.getName() + " is need!");
    }

    if (dataElement instanceof DataElement) {
      DataField dataField = (DataField)dataElement;
      if ((null != dataField) && (StringUtil.hasText(dataField.getValue())))
        value = dataField.getValue();
    }
    else if (StringUtil.hasText(dataElement)) {
      value = (String)dataElement;
    }

    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      label191: throw new Exception(fieldDefine.getName() + " is empty!");
    }

    value = (value == null) ? "" : value;
    msg.append("<").append(key).append(">").append(value).append("</").append(key).append(">");
  }

  public void formatList(StringBuffer msg, Map headMap, List dataList, MsgList listDefine) throws Exception
  {
    Object[] fieldDefineArray = listDefine.values().toArray();
    for (Iterator i$ = dataList.iterator(); i$.hasNext(); ) { Object rowElement = i$.next();
      msg.append("<").append(listDefine.getName()).append(">");
      if (rowElement instanceof Map) {
        Map rowMap = (Map)rowElement;
        Object[] arr$ = fieldDefineArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object defineObject = arr$[i$];
          formatElement(msg, headMap, rowMap, (DataElement)defineObject);
        }
      } else {
        throw new Exception("List rows expect of Map");
      }
      msg.append("</").append(listDefine.getName()).append(">");
    }
  }

  public void unformatGroup(Map headMap, Map outDataMap, Node node, GroupMap defineMap) throws Exception
  {
    Element element = (Element)node;
    if (null == element) {
      if (defineMap.isNeed())
        throw new Exception(defineMap.getName() + " is need!");

      return;
    }

    Iterator defineIterator = defineMap.values().iterator();
    while (defineIterator.hasNext()) {
      DataElement defineElement = (DataElement)defineIterator.next();
      if (defineElement instanceof GroupMap) {
        List dataList = element.elements(defineElement.getName());
        for (int j = 0; j < dataList.size(); ++j)
          unformatGroup(headMap, outDataMap, (Node)dataList.get(j), (GroupMap)defineElement);
      }
      else {
        unformatElement(headMap, outDataMap, element, defineElement);
      }
    }
  }

  public void unformatElement(Map headMap, Map outDataMap, Node parentNode, DataElement defineElement) throws Exception
  {
    Element parentElement = (Element)parentNode;
    if (null == parentElement) {
      throw new Exception(defineElement.getName() + " is null!");
    }

    if (defineElement instanceof MsgField) {
      MsgField msgField = (MsgField)defineElement;
      Element fieldElement = parentElement.element(defineElement.getName());
      if (null == fieldElement) {
        if (msgField.isNeed()) {
          throw new Exception(defineElement.getName() + " is need!");
        }

        if ((null != msgField.getPattern()) && (msgField.getPattern().equalsIgnoreCase("head")))
          headMap.put(msgField.getRefName(), "");
        else
          outDataMap.put(msgField.getRefName(), "");

        return;
      }

      unformatField(headMap, outDataMap, fieldElement, msgField);
    } else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null != listDefine) {
        List dataList = parentElement.elements(defineElement.getName());
        if ((null == dataList) || (dataList.size() == 0)) {
          if (listDefine.isNeed())
            throw new Exception(defineElement.getName() + " is need!");

          return;
        }

        for (int j = 0; j < dataList.size(); ++j)
          unformatList(headMap, outDataMap, (Node)dataList.get(j), listDefine);
      }
    }
  }

  public void unformatField(Map headMap, Map outDataMap, Node node, MsgField fieldDefine)
    throws Exception
  {
    String key = node.getName();
    String value = node.getText().trim();
    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      throw new Exception(fieldDefine.getName() + " is empty!");
    }

    String defaultValue = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (StringUtil.hasText(refName)) {
      key = refName;
    }

    if ((null != defaultValue) && (!(StringUtil.hasText(value)))) {
      value = defaultValue;
    }

    value = (value == null) ? "" : value;
    if ((null != fieldDefine.getPattern()) && (fieldDefine.getPattern().equalsIgnoreCase("head")))
      StringUtil.setValue(headMap, key, value);
    else
      StringUtil.setValue(outDataMap, key, value);
  }

  public void unformatList(Map headMap, Map outDataMap, Node node, MsgList listDefine)
    throws Exception
  {
    int i;
    Object[] fieldDefineArray = listDefine.values().toArray();
    String key = listDefine.getName();
    String refName = listDefine.getRefName();
    if (StringUtil.hasText(refName)) {
      key = refName;
    }

    if (outDataMap instanceof DataMap)
    {
      DataList dList;
      DataMap outMap = (DataMap)outDataMap;

      if (outMap.containsKey(key)) {
        DataElement outElement = outMap.get(key);
        if (outElement instanceof DataList)
          dList = (DataList)outElement;
        else
          throw new Exception(key + " is define list, expect of DataList in context here!");
      }
      else {
        dList = new DataList();
        dList.setDefineMap((DataMap)outMap.getDefineMap().get(key));
      }

      DataMap dMap = dList.createSubDataMap();
      for (i = 0; i < fieldDefineArray.length; ++i)
        unformatElement(headMap, dMap, node, (DataElement)fieldDefineArray[i]);

      dList.add(dMap);

      outDataMap.put(key, dList);
    }
    else
    {
      List dList;
      if (outDataMap.containsKey(key)) {
        Object outElement = outDataMap.get(key);
        if (outElement instanceof List)
          dList = (List)outElement;
        else
          throw new Exception(key + " is define list, expect of List in context here!");
      }
      else {
        dList = new ArrayList();
      }

      Element element = (Element)node;
      if (element.elements().size() > 0) {
        Map dMap = new HashMap();
        for (i = 0; i < fieldDefineArray.length; ++i)
          unformatElement(headMap, dMap, node, (DataElement)fieldDefineArray[i]);

        dList.add(dMap);
      }

      outDataMap.put(key, dList);
    }
  }
}