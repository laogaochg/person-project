package com.ifp.gateway.formatter;

import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.util.List;
import java.util.Map;
import org.dom4j.Element;

public abstract class AbstractKValueFormatter<T extends Map, D extends List>
  implements IFormatter<T>
{
  protected abstract void formatGroup(StringBuffer paramStringBuffer, T paramT1, T paramT2, GroupMap paramGroupMap)
    throws Exception;

  protected abstract void formatField(StringBuffer paramStringBuffer, T paramT1, T paramT2, MsgField paramMsgField)
    throws Exception;

  protected abstract void formatList(StringBuffer paramStringBuffer, T paramT, D paramD, MsgList paramMsgList)
    throws Exception;

  public void unformat(T headMap, T dataMap, String recMsg, MessageDefine msgDefine)
    throws Exception
  {
  }

  protected abstract void unformatGroup(T paramT1, T paramT2, Element paramElement, GroupMap paramGroupMap)
    throws Exception;

  protected abstract void unformatField(T paramT1, T paramT2, Element paramElement, MsgField paramMsgField)
    throws Exception;

  protected abstract void unformatList(T paramT1, T paramT2, Element paramElement, MsgList paramMsgList)
    throws Exception;
}