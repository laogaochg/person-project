package com.ifp.gateway.connector.connect;

public abstract class AbstractLongConnect
  implements ILongConnect
{
  private boolean inUse;

  public AbstractLongConnect()
  {
    this.inUse = false;
  }

  public void init()
    throws Exception
  {
  }

  public Object sendAndReceive(Object message) throws Exception
  {
    return null;
  }

  public void releaseConnect()
    throws Exception
  {
  }

  public boolean isInUse()
  {
    return this.inUse;
  }

  public void setInUse(boolean flag) {
    this.inUse = flag;
  }
}