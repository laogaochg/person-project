package com.ifp.gateway.connector.netty;

import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import java.util.Iterator;
import java.util.List;

public class NettyChannelInitializer extends ChannelInitializer<SocketChannel>
{
  private List<ChannelHandler> channelHandlerList;

  public NettyChannelInitializer(List<ChannelHandler> channelHandlerList)
  {
    this.channelHandlerList = channelHandlerList;
  }

  protected void initChannel(SocketChannel sc) throws Exception
  {
    for (Iterator i$ = this.channelHandlerList.iterator(); i$.hasNext(); ) { ChannelHandler channelHandler = (ChannelHandler)i$.next();
      sc.pipeline().addLast(new ChannelHandler[] { channelHandler });
    }
  }

  public List<ChannelHandler> getChannelHandlerList() {
    return this.channelHandlerList;
  }

  public void setChannelHandlerList(List<ChannelHandler> channelHandlerList) {
    this.channelHandlerList = channelHandlerList;
  }
}