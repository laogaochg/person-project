package com.ifp.gateway.connector.listener;

import com.ifp.gateway.exception.GatewayException;

public abstract interface CallbackListener
{
  public abstract void receiveMsg(byte[] paramArrayOfByte)
    throws GatewayException;
}