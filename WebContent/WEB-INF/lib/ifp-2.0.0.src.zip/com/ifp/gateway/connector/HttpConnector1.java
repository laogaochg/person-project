package com.ifp.gateway.connector;

import com.ifp.core.data.DataMap;
import com.ifp.core.log.Trace;
import com.ifp.core.util.DataMapChangeUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.connector.connect.HttpConnect1;
import com.ifp.gateway.connector.connect.IConnect;
import com.ifp.gateway.exception.GatewayConnectException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HttpConnector1<T extends Map> extends AbstractHttpConnector<T>
{
  private Map<String, String> headMap;
  private int connectTimeOut;
  private int connectionRequestTimeOut;
  private int socketTimeOut;
  private boolean proxyAuthor;
  private String proxyIP;
  private int proxyPort;
  private String proxyUser;
  private String proxyPwd;
  private int currSize;
  private int maxSize;
  private int waitIdleTimeOut;
  private List<IConnect> poolList;
  private boolean fullUrl;
  private String uriSuffix;
  private String contentType;
  private String keyStore;
  private String keyStore_Type;
  private String keyStore_Password;
  private String trustStore;
  private String trustStore_Type;
  private String trustStore_Password;
  private String sslProtocol;
  private String hostNameVerify;

  public HttpConnector1()
  {
    this.connectTimeOut = 6000;

    this.connectionRequestTimeOut = 60000;

    this.socketTimeOut = 6000;

    this.proxyPort = -1;

    this.currSize = 0;

    this.maxSize = -1;

    this.waitIdleTimeOut = 60000;

    this.poolList = new ArrayList();

    this.fullUrl = true;

    this.uriSuffix = "";

    this.contentType = "text/html";

    this.sslProtocol = "TLS";
  }

  public void init()
    throws Exception
  {
  }

  public Object sendAndReceive(Object message)
    throws Exception
  {
    IConnect conn = getIdleConnect();
    try {
      Object localObject1 = conn.sendAndReceive(message);

      return localObject1; } catch (Exception e) { } finally { releaseConnect(conn);
    }
  }

  public Object sendAndReceive(Object message, T headMap) throws Exception
  {
    HttpConnect1 conn = (HttpConnect1)getIdleConnect();
    try {
      if ((!(isFullUrl())) && (conn instanceof HttpConnect1)) {
        String tranCode = StringUtil.getValue(headMap.get("transCode"));
        conn.setUrl(this.url + tranCode + this.uriSuffix);
      }
      Map map = new HashMap();
      if (headMap instanceof DataMap)
        DataMapChangeUtil.dataMapToMap((DataMap)headMap, map);
      else
        map.putAll(headMap);

      conn.setHeadMap(map);
      Object localObject1 = conn.sendAndReceive(message);

      return localObject1; } catch (Exception e) { } finally { releaseConnect(conn);
    }
  }

  protected synchronized IConnect getIdleConnect()
    throws Exception
  {
    if (this.maxSize < 0) {
      HttpConnect1 connect = new HttpConnect1();
      connect.setUrl(this.url);
      connect.setEncoding(this.encoding);
      connect.setHeadMap(this.headMap);
      connect.setMethod(this.method);
      connect.setConnectTimeOut(this.connectTimeOut);
      connect.setConnectionRequestTimeOut(this.connectionRequestTimeOut);
      connect.setSocketTimeOut(this.socketTimeOut);
      connect.setProxyAuthor(this.proxyAuthor);
      connect.setProxyIP(this.proxyIP);
      connect.setProxyPort(this.proxyPort);
      connect.setProxyUser(this.proxyUser);
      connect.setProxyPwd(this.proxyPwd);
      connect.setInUse(true);
      connect.setContentType(this.contentType);
      connect.setURLEncoderFlag(this.URLEncoderFlag);
      connect.setURLEncoderEncoding((StringUtil.hasText(this.URLEncoderEncoding)) ? this.URLEncoderEncoding : this.encoding);
      connect.setKeyStore(this.keyStore);
      connect.setKeyStore_Type(this.keyStore_Type);
      connect.setKeyStore_Password(this.keyStore_Password);
      connect.setTrustStore(this.trustStore);
      connect.setTrustStore_Type(this.trustStore_Type);
      connect.setTrustStore_Password(this.trustStore_Password);
      connect.setSslProtocol(this.sslProtocol);
      connect.setHostNameVerify(this.hostNameVerify);

      this.currSize += 1;
      return connect;
    }

    long beginTime = System.currentTimeMillis();
    while (true)
    {
      for (int i = 0; i < this.poolList.size(); ++i) {
        IConnect conn = (IConnect)this.poolList.get(i);
        if (!(conn.isInUse())) {
          conn.setInUse(true);
          this.currSize += 1;
          return conn;
        }

      }

      if (this.poolList.size() < this.maxSize) {
        HttpConnect1 connect = new HttpConnect1();
        connect.setUrl(this.url);
        connect.setEncoding(this.encoding);
        connect.setHeadMap(this.headMap);
        connect.setMethod(this.method);
        connect.setConnectTimeOut(this.connectTimeOut);
        connect.setConnectionRequestTimeOut(this.connectionRequestTimeOut);
        connect.setSocketTimeOut(this.socketTimeOut);
        connect.setProxyAuthor(this.proxyAuthor);
        connect.setProxyIP(this.proxyIP);
        connect.setProxyPort(this.proxyPort);
        connect.setProxyUser(this.proxyUser);
        connect.setProxyPwd(this.proxyPwd);
        connect.setInUse(true);
        connect.setContentType(this.contentType);
        connect.setURLEncoderFlag(this.URLEncoderFlag);
        connect.setURLEncoderEncoding((StringUtil.hasText(this.URLEncoderEncoding)) ? this.URLEncoderEncoding : this.encoding);
        connect.setKeyStore(this.keyStore);
        connect.setKeyStore_Type(this.keyStore_Type);
        connect.setKeyStore_Password(this.keyStore_Password);
        connect.setTrustStore(this.trustStore);
        connect.setTrustStore_Type(this.trustStore_Type);
        connect.setTrustStore_Password(this.trustStore_Password);
        connect.setSslProtocol(this.sslProtocol);
        connect.setHostNameVerify(this.hostNameVerify);
        this.poolList.add(connect);
        this.currSize += 1;
        return connect;
      }

      if (this.waitIdleTimeOut < 0)
      {
        throw new GatewayConnectException("All connections are unavailable for [" + this.url + "]!");
      }
      long currTime = System.currentTimeMillis();
      long waitTime = currTime - beginTime;
      if (waitTime >= this.waitIdleTimeOut)
        throw new GatewayConnectException("TimeOut to get connect! The waitTime=" + waitTime + "ms!");

      Trace.logDebug("CONNECT", "wait time:{}/{}", new Object[] { Long.valueOf(waitTime), Integer.valueOf(this.waitIdleTimeOut) });
      wait();
    }
  }

  protected synchronized void releaseConnect(IConnect conn)
  {
    conn.setInUse(false);
    this.currSize -= 1;
    notifyAll();
  }

  public Map<String, String> getHeadMap() {
    return this.headMap;
  }

  public void setHeadMap(Map<String, String> headMap) {
    this.headMap = headMap;
  }

  public boolean isProxyAuthor() {
    return this.proxyAuthor;
  }

  public void setProxyAuthor(boolean proxyAuthor) {
    this.proxyAuthor = proxyAuthor;
  }

  public String getProxyIP() {
    return this.proxyIP;
  }

  public void setProxyIP(String proxyIP) {
    this.proxyIP = proxyIP;
  }

  public int getProxyPort() {
    return this.proxyPort;
  }

  public void setProxyPort(int proxyPort) {
    this.proxyPort = proxyPort;
  }

  public String getProxyUser() {
    return this.proxyUser;
  }

  public void setProxyUser(String proxyUser) {
    this.proxyUser = proxyUser;
  }

  public String getProxyPwd() {
    return this.proxyPwd;
  }

  public void setProxyPwd(String proxyPwd) {
    this.proxyPwd = proxyPwd;
  }

  public int getCurrSize() {
    return this.currSize;
  }

  public void setCurrSize(int currSize) {
    this.currSize = currSize;
  }

  public int getMaxSize() {
    return this.maxSize;
  }

  public void setMaxSize(int maxSize) {
    this.maxSize = maxSize;
  }

  public int getWaitIdleTimeOut() {
    return this.waitIdleTimeOut;
  }

  public void setWaitIdleTimeOut(int waitIdleTimeOut) {
    this.waitIdleTimeOut = waitIdleTimeOut;
  }

  public boolean isFullUrl() {
    return this.fullUrl;
  }

  public void setFullUrl(boolean fullUrl) {
    this.fullUrl = fullUrl;
  }

  public String getUriSuffix() {
    return this.uriSuffix;
  }

  public void setUriSuffix(String uriSuffix) {
    this.uriSuffix = uriSuffix;
  }

  public String getContentType() {
    return this.contentType;
  }

  public void setContentType(String contentType) {
    this.contentType = contentType;
  }

  public int getConnectTimeOut() {
    return this.connectTimeOut;
  }

  public void setConnectTimeOut(int connectTimeOut) {
    this.connectTimeOut = connectTimeOut;
  }

  public int getConnectionRequestTimeOut() {
    return this.connectionRequestTimeOut;
  }

  public void setConnectionRequestTimeOut(int connectionRequestTimeOut) {
    this.connectionRequestTimeOut = connectionRequestTimeOut;
  }

  public String getKeyStore() {
    return this.keyStore;
  }

  public void setKeyStore(String keyStore) {
    this.keyStore = keyStore;
  }

  public String getKeyStore_Type() {
    return this.keyStore_Type;
  }

  public void setKeyStore_Type(String keyStore_Type) {
    this.keyStore_Type = keyStore_Type;
  }

  public String getKeyStore_Password() {
    return this.keyStore_Password;
  }

  public void setKeyStore_Password(String keyStore_Password) {
    this.keyStore_Password = keyStore_Password;
  }

  public String getTrustStore() {
    return this.trustStore;
  }

  public void setTrustStore(String trustStore) {
    this.trustStore = trustStore;
  }

  public String getTrustStore_Type() {
    return this.trustStore_Type;
  }

  public void setTrustStore_Type(String trustStore_Type) {
    this.trustStore_Type = trustStore_Type;
  }

  public String getTrustStore_Password() {
    return this.trustStore_Password;
  }

  public void setTrustStore_Password(String trustStore_Password) {
    this.trustStore_Password = trustStore_Password;
  }

  public String getSslProtocol() {
    return this.sslProtocol;
  }

  public void setSslProtocol(String sslProtocol) {
    this.sslProtocol = sslProtocol;
  }

  public String getHostNameVerify() {
    return this.hostNameVerify;
  }

  public void setHostNameVerify(String hostNameVerify) {
    this.hostNameVerify = hostNameVerify;
  }
}