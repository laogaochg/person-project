package com.ifp.gateway.connector;

import java.util.Map;

public abstract class AbstractTcpConnector<T extends Map>
  implements IConnector<T>
{
  protected String ip;
  protected int port;
  protected String encoding;

  public AbstractTcpConnector()
  {
    this.encoding = "UTF-8"; }

  public abstract void init() throws Exception;

  public abstract Object sendAndReceive(Object paramObject) throws Exception;

  public abstract Object sendAndReceive(Object paramObject, T paramT) throws Exception;

  public String getIp() {
    return this.ip;
  }

  public void setIp(String ip) {
    this.ip = ip;
  }

  public int getPort() {
    return this.port;
  }

  public void setPort(int port) {
    this.port = port;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }
}