package com.ifp.gateway.connector;

import java.util.Map;

public abstract interface IConnector<T extends Map>
{
  public abstract void init()
    throws Exception;

  public abstract Object sendAndReceive(Object paramObject)
    throws Exception;

  public abstract Object sendAndReceive(Object paramObject, T paramT)
    throws Exception;
}