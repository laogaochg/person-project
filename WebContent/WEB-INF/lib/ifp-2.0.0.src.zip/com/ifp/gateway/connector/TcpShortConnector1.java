package com.ifp.gateway.connector;

import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.connector.connect.IConnect;
import com.ifp.gateway.connector.connect.SocketShortConnect;
import com.ifp.gateway.connector.connect.SocketShortConnect1;
import com.ifp.gateway.exception.GatewayConnectException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TcpShortConnector1<T extends Map> extends AbstractTcpConnector<T>
{
  private int sendBuffer;
  private int receiveBuffer;
  private boolean noDelay;
  private int soLinger;
  private int timeOut;
  private int msgHeadLen;
  private int receiveMsgLen;
  private int currSize;
  private int maxSize;
  private int waitIdleTimeOut;
  private List<IConnect> poolList;

  public TcpShortConnector1()
  {
    this.noDelay = true;

    this.soLinger = 0;

    this.timeOut = 60000;

    this.msgHeadLen = 8;

    this.receiveMsgLen = 0;

    this.currSize = 0;

    this.maxSize = -1;

    this.waitIdleTimeOut = 60000;

    this.poolList = new ArrayList();
  }

  public void init() throws Exception {
  }

  public Object sendAndReceive(Object message) throws Exception {
    IConnect conn = getIdleConnect();
    try {
      Object localObject1 = conn.sendAndReceive(message);

      return localObject1; } catch (Exception e) { } finally { releaseConnect(conn);
    }
  }

  public Object sendAndReceive(Object message, T headMap)
    throws Exception
  {
    if (StringUtil.hasText(headMap.get("receiveMsgLen")))
    {
      this.receiveMsgLen = Integer.parseInt(StringUtil.getValue(headMap.get("receiveMsgLen")));
    }
    return sendAndReceive(message);
  }

  protected synchronized IConnect getIdleConnect()
    throws Exception
  {
    if (this.maxSize < 0) {
      SocketShortConnect1 connect = new SocketShortConnect1(this.ip, this.port);
      connect.setEncoding(this.encoding);
      connect.setNoDelay(this.noDelay);
      connect.setSendBuffer(this.sendBuffer);
      connect.setReceiveBuffer(this.receiveBuffer);
      connect.setMsgHeadLen(this.msgHeadLen);
      connect.setTimeOut(this.timeOut);
      connect.setInUse(true);
      connect.setReceiveMsgLen(this.receiveMsgLen);
      this.currSize += 1;
      return connect;
    }

    long beginTime = System.currentTimeMillis();
    while (true)
    {
      for (int i = 0; i < this.poolList.size(); ++i) {
        IConnect conn = (IConnect)this.poolList.get(i);
        if (!(conn.isInUse())) {
          conn.setInUse(true);
          this.currSize += 1;
          return conn;
        }

      }

      if (this.poolList.size() < this.maxSize) {
        SocketShortConnect connect = new SocketShortConnect(this.ip, this.port);
        connect.setEncoding(this.encoding);
        connect.setNoDelay(this.noDelay);
        connect.setSendBuffer(this.sendBuffer);
        connect.setReceiveBuffer(this.receiveBuffer);
        connect.setMsgHeadLen(this.msgHeadLen);
        connect.setTimeOut(this.timeOut);
        connect.setInUse(true);
        this.poolList.add(connect);
        this.currSize += 1;
        return connect;
      }

      if (this.waitIdleTimeOut < 0)
      {
        throw new GatewayConnectException("All connections are unavailable for [" + this.ip + ":" + this.port + "]!");
      }
      long currTime = System.currentTimeMillis();
      long waitTime = currTime - beginTime;
      if (waitTime >= this.waitIdleTimeOut)
        throw new GatewayConnectException("TimeOut to get connect! The waitTime=" + waitTime + "ms!");

      Trace.logDebug("CONNECT", "wait time:{}/{}", new Object[] { Long.valueOf(waitTime), Integer.valueOf(this.waitIdleTimeOut) });
      wait();
    }
  }

  protected synchronized void releaseConnect(IConnect conn)
  {
    if (null != conn) {
      conn.setInUse(false);
      conn = null;
    }
    this.currSize -= 1;
    notifyAll();
  }

  public int getSendBuffer() {
    return this.sendBuffer;
  }

  public void setSendBuffer(int sendBuffer) {
    this.sendBuffer = sendBuffer;
  }

  public int getReceiveBuffer() {
    return this.receiveBuffer;
  }

  public void setReceiveBuffer(int receiveBuffer) {
    this.receiveBuffer = receiveBuffer;
  }

  public boolean isNoDelay() {
    return this.noDelay;
  }

  public void setNoDelay(boolean noDelay) {
    this.noDelay = noDelay;
  }

  public int getTimeOut() {
    return this.timeOut;
  }

  public void setTimeOut(int timeOut) {
    this.timeOut = timeOut;
  }

  public int getMsgHeadLen() {
    return this.msgHeadLen;
  }

  public void setMsgHeadLen(int msgHeadLen) {
    this.msgHeadLen = msgHeadLen;
  }

  public int getMaxSize() {
    return this.maxSize;
  }

  public void setMaxSize(int maxSize) {
    this.maxSize = maxSize;
  }

  public int getWaitIdleTimeOut() {
    return this.waitIdleTimeOut;
  }

  public void setWaitIdleTimeOut(int waitIdleTimeOut) {
    this.waitIdleTimeOut = waitIdleTimeOut;
  }

  public int getCurrSize() {
    return this.currSize;
  }

  public void setCurrSize(int currSize) {
    this.currSize = currSize;
  }

  public int getSoLinger() {
    return this.soLinger;
  }

  public void setSoLinger(int soLinger) {
    this.soLinger = soLinger;
  }
}