package com.ifp.gateway.connector;

import java.util.Map;

public abstract class AbstractHttpConnector<T extends Map>
  implements IConnector<T>
{
  protected String url;
  protected String encoding;
  protected String method;
  protected int connectTimeOut;
  protected boolean URLEncoderFlag;
  protected String URLEncoderEncoding;

  public AbstractHttpConnector()
  {
    this.encoding = "UTF-8";

    this.method = "POST";

    this.connectTimeOut = 6000;

    this.URLEncoderFlag = true;
  }

  public abstract void init()
    throws Exception;

  public abstract Object sendAndReceive(Object paramObject)
    throws Exception;

  public abstract Object sendAndReceive(Object paramObject, T paramT) throws Exception;

  public String getUrl()
  {
    return this.url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public String getMethod() {
    return this.method;
  }

  public void setMethod(String method) {
    this.method = method;
  }

  public int getConnectTimeOut() {
    return this.connectTimeOut;
  }

  public void setConnectTimeOut(int connectTimeOut) {
    this.connectTimeOut = connectTimeOut;
  }

  public boolean isURLEncoderFlag() {
    return this.URLEncoderFlag;
  }

  public void setURLEncoderFlag(boolean uRLEncoderFlag) {
    this.URLEncoderFlag = uRLEncoderFlag;
  }

  public String getURLEncoderEncoding() {
    return this.URLEncoderEncoding;
  }

  public void setURLEncoderEncoding(String uRLEncoderEncoding) {
    this.URLEncoderEncoding = uRLEncoderEncoding;
  }
}