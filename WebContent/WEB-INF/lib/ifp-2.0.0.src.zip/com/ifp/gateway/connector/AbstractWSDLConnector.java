package com.ifp.gateway.connector;

import java.util.Map;

public abstract class AbstractWSDLConnector<T extends Map>
  implements IConnector<T>
{
  protected String wsdlUri;
  protected String encoding;

  public AbstractWSDLConnector()
  {
    this.encoding = "UTF-8"; }

  public abstract void init() throws Exception;

  public abstract Object sendAndReceive(Object paramObject) throws Exception;

  public abstract Object sendAndReceive(Object paramObject, T paramT) throws Exception;

  public String getWsdlUri() {
    return this.wsdlUri;
  }

  public void setWsdlUri(String wsdlUri) {
    this.wsdlUri = wsdlUri;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }
}