package com.ifp.gateway.connector.connect;

import com.ifp.core.log.Trace;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.Map;
import java.util.Properties;
import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;
import org.apache.axis.client.Call;
import org.apache.axis.client.Service;

public class WSDLConnect extends AbstractConnect
{
  protected String wsdlUri;
  private String encoding = "UTF-8";
  private boolean decode = true;
  private int msgHeadLen = 8;
  private int sendBuffer;
  private int receiveBuffer;
  private String keyStorePath;
  private String keyStorePwd;

  public WSDLConnect()
  {
  }

  public WSDLConnect(String wsdlUri)
  {
    this.wsdlUri = wsdlUri;
  }

  public Object sendAndReceive(Object obj)
    throws Exception
  {
    if (this.wsdlUri.startsWith("https")) {
      System.getProperties().put("javax.net.ssl.keyStore", this.keyStorePath);
      System.getProperties().put("javax.net.ssl.keyStorePassword", this.keyStorePwd);
    }
    if (obj == null) {
      Trace.logInfo("CONNECT", "wsdl 参数输入为空 ");
      return null;
    }
    Map paramMap = (Map)obj;
    String method = (String)paramMap.get("method");
    Object[] param = (Object[])(Object[])paramMap.get("params");
    Call call = callWebServices(method);
    call.setTimeout(Integer.valueOf(60000));

    tranceLog(param);
    String resultMsg = (String)call.invoke(param);
    if (this.decode) {
      resultMsg = URLDecoder.decode(resultMsg, this.encoding);
    }

    Trace.logInfo("CONNECT", "wsdl receive message:{}", new Object[] { resultMsg });
    return resultMsg; }

  protected Call callWebServices(Object method) throws IOException, ServiceException {
    Service service;
    try {
      service = new Service();
      Call call = null;
      call = (Call)service.createCall();

      String nameSpaceUri = this.wsdlUri.split("\\?")[0];
      call.setOperationName(new QName(nameSpaceUri, (String)method));
      call.setTargetEndpointAddress(new String(this.wsdlUri));
      return call;
    } catch (Exception e) {
      Trace.logInfo("CONNECT", "调用webservices错误：" + e.getMessage());
    }

    return null;
  }

  public void tranceLog(Object[] param) {
    StringBuffer sb = new StringBuffer("\n");
    int i = 0;
    Object[] arr$ = param; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object object = arr$[i$];
      sb.append("[").append(i).append("]:");
      if (object instanceof String)
        sb.append((String)object);
      else
        sb.append(object);

      sb.append("\n");
      ++i;
    }

    Trace.logInfo("CONNECT", "wsdl send ..............................." + sb.toString());
  }

  public String getWsdlUri()
  {
    return this.wsdlUri;
  }

  public void setWsdlUri(String wsdlUri) {
    this.wsdlUri = wsdlUri;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public int getMsgHeadLen() {
    return this.msgHeadLen;
  }

  public void setMsgHeadLen(int msgHeadLen) {
    this.msgHeadLen = msgHeadLen;
  }

  public int getSendBuffer() {
    return this.sendBuffer;
  }

  public void setSendBuffer(int sendBuffer) {
    this.sendBuffer = sendBuffer;
  }

  public int getReceiveBuffer() {
    return this.receiveBuffer;
  }

  public void setReceiveBuffer(int receiveBuffer) {
    this.receiveBuffer = receiveBuffer;
  }

  public boolean isDecode() {
    return this.decode;
  }

  public void setDecode(boolean decode) {
    this.decode = decode;
  }

  public String getKeyStorePath() {
    return this.keyStorePath;
  }

  public void setKeyStorePath(String keyStorePath) {
    this.keyStorePath = keyStorePath;
  }

  public String getKeyStorePwd() {
    return this.keyStorePwd;
  }

  public void setKeyStorePwd(String keyStorePwd) {
    this.keyStorePwd = keyStorePwd;
  }
}