package com.ifp.gateway.connector.connect;

import com.ifp.core.log.Trace;
import com.ifp.gateway.exception.GatewayConnectException;
import com.ifp.gateway.exception.GatewayNoResultException;
import java.io.InputStream;

public class SocketShortConnect1 extends SocketShortConnect
{
  private int receiveMsgLen = 0;

  public SocketShortConnect1()
  {
  }

  public SocketShortConnect1(String ip, int port)
  {
    super(ip, port);
  }

  protected byte[] readPackage(InputStream in) throws Exception {
    int len;
    int contentLength = getMsgHeadLen();
    if (contentLength > 0) {
      byte[] revMessage = new byte[contentLength];
      off = 0;
      while (off < contentLength) {
        len = in.read(revMessage, off, contentLength - off);
        if (len <= 0)
          throw new GatewayNoResultException("connect is close, while read head length: {}", new String(revMessage));

        off += len;
      }
      contentLength = Integer.parseInt(new String(revMessage).trim());
    } else {
      if (this.receiveMsgLen <= 0)
        throw new GatewayConnectException("there isn't message receive!");

      contentLength = this.receiveMsgLen;
    }
    Trace.logDebug("CONNECT", "contentHeadLen: {}, contentLen:{}...", new Object[] { Integer.valueOf(getMsgHeadLen()), Integer.valueOf(contentLength) });

    byte[] contentBuf = new byte[contentLength];
    int off = 0;
    while (off < contentLength) {
      len = in.read(contentBuf, off, contentLength - off);
      if (len <= 0)
        break;

      off += len;
    }
    Trace.logDebug("CONNECT", "Read in package As:{} ", new Object[] { new String(contentBuf, getEncoding()) });

    return contentBuf;
  }

  public int getReceiveMsgLen() {
    return this.receiveMsgLen;
  }

  public void setReceiveMsgLen(int receiveMsgLen) {
    this.receiveMsgLen = receiveMsgLen;
  }
}