package com.ifp.gateway.connector.connect;

import com.ifp.core.util.StringUtil;
import com.ifp.gateway.connector.connect.netty.GwLengthFieldBasedFrameDecoder;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import java.io.PrintStream;
import java.util.concurrent.TimeUnit;

public class TcpNettyLongConnect2 extends AbstractLongConnect
{
  private String ip;
  private int port;
  private String encoding;
  private int sendBuffer;
  private int receiveBuffer;
  private boolean noDelay;
  private long connectTimeOut;
  private long timeOut;
  private int msgHeadLen;
  private ChannelInitializer channelInitializer;
  private EventLoopGroup group;
  private SocketChannel socketChannel;

  public TcpNettyLongConnect2()
  {
    this.encoding = "UTF-8";

    this.noDelay = true;

    this.connectTimeOut = 60000L;

    this.timeOut = 60000L;

    this.msgHeadLen = 8;
  }

  public void init()
    throws Exception
  {
    System.out.println("init tcp long connector");
    try
    {
      this.group = new NioEventLoopGroup();

      Bootstrap bootstrap = new Bootstrap();
      ((Bootstrap)((Bootstrap)((Bootstrap)((Bootstrap)((Bootstrap)bootstrap.group(this.group)).channel(NioSocketChannel.class)).option(ChannelOption.TCP_NODELAY, Boolean.valueOf(this.noDelay))).option(ChannelOption.SO_KEEPALIVE, Boolean.valueOf(true))).option(ChannelOption.CONNECT_TIMEOUT_MILLIS, Integer.valueOf(Long.valueOf(this.connectTimeOut).intValue()))).option(ChannelOption.SO_TIMEOUT, Integer.valueOf(Long.valueOf(this.timeOut).intValue()));

      if (this.sendBuffer > 0)
        bootstrap.option(ChannelOption.SO_SNDBUF, Integer.valueOf(this.sendBuffer));

      if (this.receiveBuffer > 0)
        bootstrap.option(ChannelOption.SO_RCVBUF, Integer.valueOf(this.receiveBuffer));

      bootstrap.handler(this.channelInitializer);

      ChannelFuture channelFuture = bootstrap.connect(this.ip, this.port).sync();
      if (channelFuture.isSuccess()) {
        System.out.println("connect successful==>ip:{}, port:" + this.ip + ":" + this.port);

        this.socketChannel = ((SocketChannel)channelFuture.channel());
      }
    } catch (Exception e) {
      System.out.println("tcp long connector init faild" + e.getMessage());
    }
  }

  public void send(Object identity, Object message) throws Exception {
    System.out.println("send message:" + message);
    ByteBuf firstMessage = Unpooled.buffer();

    int msgLen = StringUtil.getStringLen((String)message, this.encoding);
    int len = String.valueOf(msgLen).length();
    StringBuffer msg = new StringBuffer();
    if (this.msgHeadLen > 0) {
      for (int i = 0; i < this.msgHeadLen - len; ++i)
        msg.append(0);

      msg.append(msgLen);
    }
    msg.append(message);

    firstMessage.writeBytes(msg.toString().getBytes(this.encoding));
    this.socketChannel.writeAndFlush(firstMessage);
  }

  public void destroy()
  {
    this.group.shutdownGracefully();
  }

  public void finalize() throws Throwable
  {
    destroy();
    finalize();
  }

  public String getIp() {
    return this.ip;
  }

  public void setIp(String ip) {
    this.ip = ip;
  }

  public int getPort() {
    return this.port;
  }

  public void setPort(int port) {
    this.port = port;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public int getSendBuffer() {
    return this.sendBuffer;
  }

  public void setSendBuffer(int sendBuffer) {
    this.sendBuffer = sendBuffer;
  }

  public int getReceiveBuffer() {
    return this.receiveBuffer;
  }

  public void setReceiveBuffer(int receiveBuffer) {
    this.receiveBuffer = receiveBuffer;
  }

  public boolean isNoDelay() {
    return this.noDelay;
  }

  public void setNoDelay(boolean noDelay) {
    this.noDelay = noDelay;
  }

  public long getConnectTimeOut() {
    return this.connectTimeOut;
  }

  public void setConnectTimeOut(long connectTimeOut) {
    this.connectTimeOut = connectTimeOut;
  }

  public long getTimeOut() {
    return this.timeOut;
  }

  public void setTimeOut(long timeOut) {
    this.timeOut = timeOut;
  }

  public ChannelInitializer getChannelInitializer() {
    return this.channelInitializer;
  }

  public void setChannelInitializer(ChannelInitializer channelInitializer) {
    this.channelInitializer = channelInitializer;
  }

  public int getMsgHeadLen() {
    return this.msgHeadLen;
  }

  public void setMsgHeadLen(int msgHeadLen) {
    this.msgHeadLen = msgHeadLen;
  }

  public static void main(String[] args) throws Exception {
    TcpNettyLongConnect2 conn = new TcpNettyLongConnect2();

    conn.setIp("127.0.0.1");
    conn.setPort(9999);
    conn.setNoDelay(true);
    conn.setEncoding("UTF-8");
    conn.setTimeOut(60000L);
    conn.setConnectTimeOut(60000L);
    conn.setMsgHeadLen(8);

    ChannelInitializer channelInitializer = new ChannelInitializer()
    {
      protected void initChannel(SocketChannel sc) throws Exception {
        sc.pipeline().addLast(new ChannelHandler[] { new GwLengthFieldBasedFrameDecoder(2097152, 0, 8, 0, 8) });
        sc.pipeline().addLast(new ChannelHandler[] { new ChannelInboundHandlerAdapter(this)
        {
          public void channelRead(, Object msg) throws Exception {
            System.out.println("客户端收到服务器响应数据");
            ByteBuf buf = (ByteBuf)msg;
            byte[] req = new byte[buf.readableBytes()];
            buf.readBytes(req);
            System.out.println("receive msg:" + new String(req, "UTF-8"));
          }

          public void channelReadComplete()
            throws Exception
          {
          }

          public void exceptionCaught(, Throwable cause)
            throws Exception
          {
            System.out.println("Unexpected exception from downstream:" + cause.getMessage());
          }
        }

         });
      }

    };
    conn.setChannelInitializer(channelInitializer);
    conn.init();

    ByteBuf firstMessage = Unpooled.buffer();
    firstMessage.writeBytes("000000101234567890".getBytes("UTF-8"));
    conn.socketChannel.writeAndFlush(firstMessage);
    TimeUnit.SECONDS.sleep(3L);
    ByteBuf firstMessage2 = Unpooled.buffer();
    firstMessage2.writeBytes("000000101234567899".getBytes("UTF-8"));
    conn.socketChannel.writeAndFlush(firstMessage2);
  }
}