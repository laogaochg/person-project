package com.ifp.gateway.connector.connect;

public abstract interface IConnect
{
  public abstract void init()
    throws Exception;

  public abstract Object sendAndReceive(Object paramObject)
    throws Exception;

  public abstract boolean isInUse();

  public abstract void setInUse(boolean paramBoolean);

  public abstract void releaseConnect()
    throws Exception;
}