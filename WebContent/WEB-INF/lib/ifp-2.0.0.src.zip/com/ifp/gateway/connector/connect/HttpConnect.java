package com.ifp.gateway.connector.connect;

import com.ifp.core.log.Trace;
import com.ifp.core.util.Base64;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.exception.GatewayConnectException;
import com.ifp.gateway.exception.GatewayNoResultException;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;
import sun.net.www.protocol.https.Handler;

public class HttpConnect extends AbstractConnect
{
  private String url;
  private Map<String, String> headMap;
  private int connectTimeOut = 6000;
  private int readTimeOut = 60000;
  private String encoding = "UTF-8";
  private String method = "POST";
  private boolean proxyAuthor;
  private String proxyIP;
  private int proxyPort = -1;
  private String proxyUser;
  private String proxyPwd;
  private String contentType = "text/html";
  private boolean URLEncoderFlag = true;
  private String URLEncoderEncoding = "UTF-8";

  public Object sendAndReceive(Object message)
    throws Exception
  {
    if (this.url.startsWith("https"))
      return sendAndReceiveHttps(message);

    return sendAndReceiveHttp(message);
  }

  public Object sendAndReceiveHttps(Object message)
    throws Exception
  {
    String msg = null;
    if (message instanceof Map) {
      StringBuffer params = new StringBuffer();
      Map msgMap = (Map)message;
      Iterator paramsIterator = msgMap.entrySet().iterator();
      while (paramsIterator.hasNext()) {
        Map.Entry paramsEntry = (Map.Entry)paramsIterator.next();
        if (this.URLEncoderFlag)
          params.append((String)paramsEntry.getKey()).append("=").append(URLEncoder.encode((String)paramsEntry.getValue(), this.URLEncoderEncoding)).append("&");
        else
          params.append((String)paramsEntry.getKey()).append("=").append((String)paramsEntry.getValue()).append("&");
      }

      if (params.length() > 0)
        params.deleteCharAt(params.length() - 1);

      msg = params.toString();
    } else {
      msg = (String)message;
    }

    HttpsURLConnection reqConnection = null;
    InputStream input = null;
    OutputStream output = null;
    try {
      String httpURL = this.url;
      if ((null != this.method) && ("GET".equals(this.method)) && (null != msg)) {
        if (httpURL.indexOf("?") < 0) {
          httpURL = httpURL + "?" + msg;
        }
        else if (httpURL.endsWith("&"))
          httpURL = httpURL + msg;
        else
          httpURL = httpURL + "&" + msg;

      }

      Trace.logInfo("CONNECT", "target httpURL: {}", new Object[] { httpURL });
      URL reqUrl = new URL(null, httpURL, new Handler());
      reqConnection = (HttpsURLConnection)reqUrl.openConnection();
      reqConnection.setRequestMethod(this.method);

      if (this.proxyAuthor) {
        if ((this.proxyIP != null) && (this.proxyIP.trim().length() != 0))
        {
          System.getProperties().put("proxySet", "true");
          System.getProperties().put("proxyHost", this.proxyIP);
          System.getProperties().put("proxyPort", "" + this.proxyPort);
        }

        if ((this.proxyUser != null) && (this.proxyUser.trim().length() != 0)) {
          reqConnection.setRequestProperty("Proxy-Authorization", new String(Base64.encode(this.proxyUser + ":" + this.proxyPwd.getBytes())));

          reqConnection.setRequestProperty("Proxy-Connection", "Keep-Alive");
        }
      }

      if (this.headMap != null) {
        Iterator headIterator = this.headMap.entrySet().iterator();
        while (headIterator.hasNext()) {
          Map.Entry entry = (Map.Entry)headIterator.next();
          reqConnection.setRequestProperty((String)entry.getKey(), (String)entry.getValue());
        }
      }

      reqConnection.setConnectTimeout(this.connectTimeOut);
      reqConnection.setReadTimeout(this.readTimeOut);
      reqConnection.setDoInput(true);
      reqConnection.setDoOutput(true);
      reqConnection.setUseCaches(false);

      Trace.logInfo("CONNECT", "send message:{}", new Object[] { message });
      if ("POST".equals(this.method)) {
        if (message instanceof Map) {
          reqConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
          output = new DataOutputStream(reqConnection.getOutputStream());
        } else {
          reqConnection.setRequestProperty("Content-Type", this.contentType + "; charset=" + this.encoding);
          reqConnection.setRequestProperty("Connection", "Keep-Alive");
          int contentLength = StringUtil.getStringLen(msg, this.encoding);
          reqConnection.addRequestProperty("Content-Length", String.valueOf(contentLength));
          output = reqConnection.getOutputStream();
        }
        if (null != msg)
          output.write(msg.getBytes(this.encoding));

        output.flush();
        output.close();
        output = null;
      }

      int responseCode = -1;
      try {
        responseCode = reqConnection.getResponseCode();
      } catch (IOException e) {
        throw new GatewayConnectException("http access failed ==> " + httpURL, e);
      }

      if (responseCode != 200) {
        throw new GatewayNoResultException("http access failed ==> " + httpURL + ", responseCode = " + responseCode + " msg=" + reqConnection.getResponseMessage());
      }

      input = reqConnection.getInputStream();

      byte[] buffer = new byte[2048];
      byte[] buf = new byte[2048];
      int readLen = 0;
      while (true) {
        int len = input.read(buf);
        if (len <= 0)
          break;

        if (len + readLen >= buffer.length) {
          byte[] tmp = new byte[buffer.length + len + 1024];
          System.arraycopy(buffer, 0, tmp, 0, readLen);
          buffer = tmp;
        }

        System.arraycopy(buf, 0, buffer, readLen, len);
        readLen += len;
      }

      String resultMsg = new String(buffer, 0, readLen, this.encoding);
      Trace.logInfo("CONNECT", "receive message:{}", new Object[] { resultMsg });
      String str1 = resultMsg;

      return str1;
    }
    catch (Exception e)
    {
    }
    finally
    {
      if (null != input) {
        input.close();
        input = null;
      }
      if (null != output) {
        output.close();
        output = null;
      }
      reqConnection.disconnect();
    }
  }

  public Object sendAndReceiveHttp(Object message)
    throws Exception
  {
    String msg = null;
    if (message instanceof Map) {
      StringBuffer params = new StringBuffer();
      Map msgMap = (Map)message;
      Iterator paramsIterator = msgMap.entrySet().iterator();
      while (paramsIterator.hasNext()) {
        Map.Entry paramsEntry = (Map.Entry)paramsIterator.next();
        if (this.URLEncoderFlag)
          params.append((String)paramsEntry.getKey()).append("=").append(URLEncoder.encode((String)paramsEntry.getValue(), this.URLEncoderEncoding)).append("&");
        else
          params.append((String)paramsEntry.getKey()).append("=").append((String)paramsEntry.getValue()).append("&");
      }

      if (params.length() > 0)
        params.deleteCharAt(params.length() - 1);

      msg = params.toString();
    } else {
      msg = (String)message;
    }

    HttpURLConnection reqConnection = null;
    InputStream input = null;
    OutputStream output = null;
    try {
      String httpURL = this.url;
      if ((null != this.method) && ("GET".equals(this.method)) && (null != msg)) {
        if (httpURL.indexOf("?") < 0) {
          httpURL = httpURL + "?" + msg;
        }
        else if (httpURL.endsWith("&"))
          httpURL = httpURL + msg;
        else
          httpURL = httpURL + "&" + msg;

      }

      Trace.logInfo("CONNECT", "target httpURL: {}", new Object[] { httpURL });
      URL reqUrl = new URL(httpURL);
      reqConnection = (HttpURLConnection)reqUrl.openConnection();
      reqConnection.setRequestMethod(this.method);

      if (this.proxyAuthor) {
        if ((this.proxyIP != null) && (this.proxyIP.trim().length() != 0))
        {
          System.getProperties().put("proxySet", "true");
          System.getProperties().put("proxyHost", this.proxyIP);
          System.getProperties().put("proxyPort", "" + this.proxyPort);
        }

        if ((this.proxyUser != null) && (this.proxyUser.trim().length() != 0)) {
          reqConnection.setRequestProperty("Proxy-Authorization", new String(Base64.encode(this.proxyUser + ":" + this.proxyPwd.getBytes())));

          reqConnection.setRequestProperty("Proxy-Connection", "Keep-Alive");
        }
      }

      if (this.headMap != null) {
        Iterator headIterator = this.headMap.entrySet().iterator();
        while (headIterator.hasNext()) {
          Map.Entry entry = (Map.Entry)headIterator.next();
          reqConnection.setRequestProperty((String)entry.getKey(), (String)entry.getValue());
        }
      }

      reqConnection.setConnectTimeout(this.connectTimeOut);
      reqConnection.setReadTimeout(this.readTimeOut);
      reqConnection.setDoInput(true);
      reqConnection.setDoOutput(true);
      reqConnection.setUseCaches(false);

      Trace.logInfo("CONNECT", "send message:{}", new Object[] { msg });
      if ("POST".equals(this.method)) {
        if (message instanceof Map) {
          reqConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
          output = new DataOutputStream(reqConnection.getOutputStream());
        } else {
          reqConnection.setRequestProperty("Content-Type", this.contentType + "; charset=" + this.encoding);
          reqConnection.setRequestProperty("Connection", "Keep-Alive");
          int contentLength = StringUtil.getStringLen(msg, this.encoding);
          reqConnection.addRequestProperty("Content-Length", String.valueOf(contentLength));
          output = reqConnection.getOutputStream();
        }
        if (null != msg)
          output.write(msg.getBytes(this.encoding));

        output.flush();
        output.close();
        output = null;
      }

      int responseCode = -1;
      try {
        responseCode = reqConnection.getResponseCode();
      } catch (IOException e) {
        throw new GatewayConnectException("http access failed ==> " + httpURL, e);
      }

      if (responseCode != 200) {
        throw new GatewayNoResultException("http access failed ==> " + httpURL + ", responseCode = " + responseCode + " msg=" + reqConnection.getResponseMessage());
      }

      input = reqConnection.getInputStream();

      byte[] buffer = new byte[2048];
      byte[] buf = new byte[2048];
      int readLen = 0;
      while (true) {
        int len = input.read(buf);
        if (len <= 0)
          break;

        if (len + readLen >= buffer.length) {
          byte[] tmp = new byte[buffer.length + len + 1024];
          System.arraycopy(buffer, 0, tmp, 0, readLen);
          buffer = tmp;
        }

        System.arraycopy(buf, 0, buffer, readLen, len);
        readLen += len;
      }

      String resultMsg = new String(buffer, 0, readLen, this.encoding);
      Trace.logInfo("CONNECT", "receive message:{}", new Object[] { resultMsg });
      String str1 = resultMsg;

      return str1;
    }
    catch (Exception e)
    {
    }
    finally
    {
      if (null != input) {
        input.close();
        input = null;
      }
      if (null != output) {
        output.close();
        output = null;
      }
      if (null != reqConnection)
        reqConnection.disconnect();
    }
  }

  public String getUrl()
  {
    return this.url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public Map<String, String> getHeadMap() {
    return this.headMap;
  }

  public void setHeadMap(Map<String, String> headMap) {
    this.headMap = headMap;
  }

  public int getConnectTimeOut() {
    return this.connectTimeOut;
  }

  public void setConnectTimeOut(int connectTimeOut) {
    this.connectTimeOut = connectTimeOut;
  }

  public int getReadTimeOut() {
    return this.readTimeOut;
  }

  public void setReadTimeOut(int readTimeOut) {
    this.readTimeOut = readTimeOut;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public String getMethod() {
    return this.method;
  }

  public void setMethod(String method) {
    this.method = method.toUpperCase();
  }

  public boolean isProxyAuthor() {
    return this.proxyAuthor;
  }

  public void setProxyAuthor(boolean proxyAuthor) {
    this.proxyAuthor = proxyAuthor;
  }

  public String getProxyIP() {
    return this.proxyIP;
  }

  public void setProxyIP(String proxyIP) {
    this.proxyIP = proxyIP;
  }

  public int getProxyPort() {
    return this.proxyPort;
  }

  public void setProxyPort(int proxyPort) {
    this.proxyPort = proxyPort;
  }

  public String getProxyUser() {
    return this.proxyUser;
  }

  public void setProxyUser(String proxyUser) {
    this.proxyUser = proxyUser;
  }

  public String getProxyPwd() {
    return this.proxyPwd;
  }

  public void setProxyPwd(String proxyPwd) {
    this.proxyPwd = proxyPwd;
  }

  public String getContentType() {
    return this.contentType;
  }

  public void setContentType(String contentType) {
    this.contentType = contentType;
  }

  public boolean isURLEncoderFlag() {
    return this.URLEncoderFlag;
  }

  public void setURLEncoderFlag(boolean uRLEncoderFlag) {
    this.URLEncoderFlag = uRLEncoderFlag;
  }

  public String getURLEncoderEncoding() {
    return this.URLEncoderEncoding;
  }

  public void setURLEncoderEncoding(String uRLEncoderEncoding) {
    this.URLEncoderEncoding = uRLEncoderEncoding;
  }
}