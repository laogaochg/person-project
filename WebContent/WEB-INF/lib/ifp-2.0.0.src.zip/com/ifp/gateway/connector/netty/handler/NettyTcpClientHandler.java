package com.ifp.gateway.connector.netty.handler;

import com.ifp.core.log.Trace;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import java.io.PrintStream;

public class NettyTcpClientHandler extends ChannelInboundHandlerAdapter
{
  private ByteBuf firstMessage;

  public void channelRead(ChannelHandlerContext ctx, Object msg)
    throws Exception
  {
    Trace.logDebug("CONNECT", "客户端收到服务器响应数据");
    System.out.println(this);
    ByteBuf buf = (ByteBuf)msg;
    byte[] req = new byte[buf.readableBytes()];
    buf.readBytes(req);
    String body = new String(req, "UTF-8");
    Trace.logDebug("CONNECT", "receive msg:{}", new Object[] { body });
  }

  public void channelReadComplete(ChannelHandlerContext ctx) throws Exception
  {
    ctx.flush();
    Trace.logDebug("CONNECT", "客户端收到服务器响应数据处理完成");
  }

  public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
    throws Exception
  {
    cause.printStackTrace();
    Trace.logDebug("CONNECT", "Unexpected exception from downstream:" + cause.getMessage());
    ctx.close();
    Trace.logDebug("CONNECT", "客户端异常退出");
  }
}