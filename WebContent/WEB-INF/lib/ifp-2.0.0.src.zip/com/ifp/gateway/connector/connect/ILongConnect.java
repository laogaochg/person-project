package com.ifp.gateway.connector.connect;

public abstract interface ILongConnect extends IConnect
{
  public abstract void send(Object paramObject1, Object paramObject2)
    throws Exception;
}