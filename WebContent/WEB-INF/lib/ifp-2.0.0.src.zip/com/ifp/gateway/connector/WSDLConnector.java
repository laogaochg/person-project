package com.ifp.gateway.connector;

import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.Channel;
import com.ifp.gateway.connector.connect.IConnect;
import com.ifp.gateway.connector.connect.WSDLConnect;
import com.ifp.gateway.exception.GatewayConnectException;
import com.ifp.gateway.handle.GatewayHandle;
import com.ifp.gateway.service.WSDLService;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class WSDLConnector<T extends Map> extends AbstractWSDLConnector<T>
{
  private int maxSize;
  private int currSize;
  private int waitIdleTimeOut;
  private List<IConnect> poolList;
  private boolean decode;
  private String keyStorePath;
  private String keyStorePwd;

  public WSDLConnector()
  {
    this.maxSize = -1;

    this.currSize = 0;

    this.waitIdleTimeOut = 60000;

    this.poolList = new ArrayList();

    this.decode = true;
  }

  public void init()
    throws Exception
  {
  }

  public Object sendAndReceive(Object message)
    throws Exception
  {
    IConnect conn = getIdleConnect();
    try {
      Object localObject1 = conn.sendAndReceive(message);

      return localObject1; } catch (Exception e) { } finally { releaseConnect();
    }
  }

  public Object sendAndReceive(Object message, T headMap) throws Exception
  {
    GatewayHandle gwHandle = (GatewayHandle)SpringContextsUtil.getBean("gatewayHandle");
    String commClient = StringUtil.getValue(headMap.get("commClient"));
    String systemId = StringUtil.getValue(headMap.get("channelId"));
    String transCode = StringUtil.getValue(headMap.get("transCode"));
    Channel channel = (Channel)gwHandle.getChannelMap().get(commClient);
    if (null == channel)
      throw new Exception("can not found channel:" + commClient);

    if (!("0".equals(channel.getStatus())))
      throw new Exception("channel's status is close!");

    WSDLService service = (WSDLService)channel.getServiceByTransCode(transCode);
    if (null == service)
      service = (WSDLService)channel.getServiceBySysCode(systemId);

    Object paramMap = service.getParamasFromXml((String)message, transCode);
    return sendAndReceive(paramMap);
  }

  protected synchronized IConnect getIdleConnect()
    throws Exception
  {
    if (this.maxSize < 0) {
      this.currSize += 1;
      WSDLConnect connect = new WSDLConnect(this.wsdlUri);
      connect.setEncoding(this.encoding);
      connect.setDecode(this.decode);
      connect.setKeyStorePath(this.keyStorePath);
      connect.setKeyStorePwd(this.keyStorePwd);
      return connect;
    }
    long beginTime = System.currentTimeMillis();
    while (true)
    {
      for (int i = 0; i < this.poolList.size(); ++i) {
        IConnect conn = (IConnect)this.poolList.get(i);
        if (!(conn.isInUse())) {
          conn.setInUse(true);
          this.currSize += 1;
          return conn;
        }

      }

      if (this.poolList.size() < this.maxSize) {
        WSDLConnect connect = new WSDLConnect(this.wsdlUri);
        connect.setEncoding(this.encoding);
        connect.setDecode(this.decode);
        connect.setKeyStorePath(this.keyStorePath);
        connect.setKeyStorePwd(this.keyStorePwd);
        this.poolList.add(connect);
        this.currSize += 1;
        return connect;
      }

      if (this.waitIdleTimeOut < 0)
      {
        throw new GatewayConnectException("All connections are unavailable for [" + this.wsdlUri + "]!");
      }
      long currTime = System.currentTimeMillis();
      long waitTime = currTime - beginTime;
      if (waitTime >= this.waitIdleTimeOut)
        throw new GatewayConnectException("TimeOut to get connect! The waitTime=" + waitTime + "ms!");

      Trace.logDebug("CONNECT", "wait time:{}/{}", new Object[] { Long.valueOf(waitTime), Integer.valueOf(this.waitIdleTimeOut) });
      wait();
    }
  }

  protected synchronized void releaseConnect()
  {
    this.currSize -= 1;
    notifyAll();
  }

  public int getMaxSize() {
    return this.maxSize;
  }

  public void setMaxSize(int maxSize) {
    this.maxSize = maxSize;
  }

  public int getCurrSize() {
    return this.currSize;
  }

  public void setCurrSize(int currSize) {
    this.currSize = currSize;
  }

  public int getWaitIdleTimeOut() {
    return this.waitIdleTimeOut;
  }

  public void setWaitIdleTimeOut(int waitIdleTimeOut) {
    this.waitIdleTimeOut = waitIdleTimeOut;
  }

  public boolean isDecode() {
    return this.decode;
  }

  public void setDecode(boolean decode) {
    this.decode = decode;
  }

  public String getKeyStorePath() {
    return this.keyStorePath;
  }

  public void setKeyStorePath(String keyStorePath) {
    this.keyStorePath = keyStorePath;
  }

  public String getKeyStorePwd() {
    return this.keyStorePwd;
  }

  public void setKeyStorePwd(String keyStorePwd) {
    this.keyStorePwd = keyStorePwd;
  }
}