package com.ifp.gateway.connector.identity;

public abstract interface IPackageIdentity
{
  public abstract byte[] getSendPackageIdentity(byte[] paramArrayOfByte);

  public abstract byte[] getReceivePackageIdentity(byte[] paramArrayOfByte);
}