package com.ifp.gateway.connector.connect;

import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

public class TcpNettyLongConnect extends AbstractLongConnect
{
  private String ip;
  private int port;
  private String encoding;
  private int sendBuffer;
  private int receiveBuffer;
  private boolean noDelay;
  private long connectTimeOut;
  private long timeOut;
  private int msgHeadLen;
  private ChannelInitializer channelInitializer;
  private EventLoopGroup group;
  private SocketChannel socketChannel;

  public TcpNettyLongConnect()
  {
    this.encoding = "UTF-8";

    this.noDelay = true;

    this.connectTimeOut = 60000L;

    this.timeOut = 60000L;

    this.msgHeadLen = 8;
  }

  public void init()
    throws Exception
  {
    Trace.logDebug("CONNECT", "init tcp long connector");
    try
    {
      this.group = new NioEventLoopGroup();

      Bootstrap bootstrap = new Bootstrap();
      ((Bootstrap)((Bootstrap)((Bootstrap)((Bootstrap)((Bootstrap)bootstrap.group(this.group)).channel(NioSocketChannel.class)).option(ChannelOption.TCP_NODELAY, Boolean.valueOf(this.noDelay))).option(ChannelOption.SO_KEEPALIVE, Boolean.valueOf(true))).option(ChannelOption.CONNECT_TIMEOUT_MILLIS, Integer.valueOf(Long.valueOf(this.connectTimeOut).intValue()))).option(ChannelOption.SO_TIMEOUT, Integer.valueOf(Long.valueOf(this.timeOut).intValue()));

      if (this.sendBuffer > 0)
        bootstrap.option(ChannelOption.SO_SNDBUF, Integer.valueOf(this.sendBuffer));

      if (this.receiveBuffer > 0)
        bootstrap.option(ChannelOption.SO_RCVBUF, Integer.valueOf(this.receiveBuffer));

      bootstrap.handler(this.channelInitializer);

      ChannelFuture channelFuture = bootstrap.connect(this.ip, this.port).sync();
      if (channelFuture.isSuccess()) {
        Trace.logDebug("CONNECT", "connect successful==>ip:{}, port:{}", new Object[] { this.ip, Integer.valueOf(this.port) });

        this.socketChannel = ((SocketChannel)channelFuture.channel());
      }
    } catch (Exception e) {
      Trace.logError("CONNECT", "tcp long connector init faild", e);
    }
  }

  public void send(Object identity, Object message) throws Exception {
    Trace.logInfo("CONNECT", "send message:{}", new Object[] { message });
    ByteBuf firstMessage = Unpooled.buffer();

    int msgLen = StringUtil.getStringLen((String)message, this.encoding);
    int len = String.valueOf(msgLen).length();
    StringBuffer msg = new StringBuffer();
    if (this.msgHeadLen > 0) {
      for (int i = 0; i < this.msgHeadLen - len; ++i)
        msg.append(0);

      msg.append(msgLen);
    }
    msg.append(message);

    firstMessage.writeBytes(msg.toString().getBytes(this.encoding));
    this.socketChannel.writeAndFlush(firstMessage);
  }

  public void destroy()
  {
    this.socketChannel.closeFuture().syncUninterruptibly();
    this.group.shutdownGracefully();
  }

  public void finalize() throws Throwable
  {
    destroy();
    finalize();
  }

  public String getIp() {
    return this.ip;
  }

  public void setIp(String ip) {
    this.ip = ip;
  }

  public int getPort() {
    return this.port;
  }

  public void setPort(int port) {
    this.port = port;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public int getSendBuffer() {
    return this.sendBuffer;
  }

  public void setSendBuffer(int sendBuffer) {
    this.sendBuffer = sendBuffer;
  }

  public int getReceiveBuffer() {
    return this.receiveBuffer;
  }

  public void setReceiveBuffer(int receiveBuffer) {
    this.receiveBuffer = receiveBuffer;
  }

  public boolean isNoDelay() {
    return this.noDelay;
  }

  public void setNoDelay(boolean noDelay) {
    this.noDelay = noDelay;
  }

  public long getConnectTimeOut() {
    return this.connectTimeOut;
  }

  public void setConnectTimeOut(long connectTimeOut) {
    this.connectTimeOut = connectTimeOut;
  }

  public long getTimeOut() {
    return this.timeOut;
  }

  public void setTimeOut(long timeOut) {
    this.timeOut = timeOut;
  }

  public ChannelInitializer getChannelInitializer() {
    return this.channelInitializer;
  }

  public void setChannelInitializer(ChannelInitializer channelInitializer) {
    this.channelInitializer = channelInitializer;
  }

  public int getMsgHeadLen() {
    return this.msgHeadLen;
  }

  public void setMsgHeadLen(int msgHeadLen) {
    this.msgHeadLen = msgHeadLen;
  }
}