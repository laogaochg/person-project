package com.ifp.gateway.connector;

import com.ifp.core.log.Trace;
import com.ifp.gateway.connector.connect.IConnect;
import com.ifp.gateway.connector.connect.ILongConnect;
import com.ifp.gateway.connector.connect.TcpNettyLongConnect;
import com.ifp.gateway.connector.connect.netty.GwLengthFieldBasedFrameDecoder;
import com.ifp.gateway.connector.identity.IPackageIdentity;
import com.ifp.gateway.connector.listener.CallbackListener;
import com.ifp.gateway.exception.GatewayConnectException;
import com.ifp.gateway.exception.GatewayException;
import com.ifp.gateway.exception.GatewayReceiveTimeOutException;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.util.ReferenceCountUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TcpNettyLongConnector<T extends Map> extends AbstractTcpConnector<T>
  implements CallbackListener
{
  private int sendBuffer;
  private int receiveBuffer;
  private boolean noDelay;
  private int connectTimeOut;
  private long timeOut;
  private long receiveTimeOut;
  private int msgHeadLen;
  private IConnect connect;
  private int maxSize;
  private int currSize;
  private int waitIdleTimeOut;
  private String encoding;
  private int maxLength;
  private ChannelInitializer channelInitializer;
  private List<ChannelHandler> channelHandlerList;
  private IPackageIdentity packageIdentity;
  private Map<String, Object> identityMap;
  private Map<String, Object> msgMap;

  public TcpNettyLongConnector()
  {
    this.noDelay = true;

    this.connectTimeOut = 60000;

    this.timeOut = 60000L;

    this.receiveTimeOut = 60000L;

    this.msgHeadLen = 8;

    this.maxSize = -1;

    this.currSize = 0;

    this.waitIdleTimeOut = 60000;

    this.encoding = "UTF-8";

    this.maxLength = 2097152;

    this.identityMap = new ConcurrentHashMap();

    this.msgMap = new ConcurrentHashMap(); }

  public void init() throws Exception {
    this.connect = initConnect();
  }

  public Object sendAndReceive(Object message) throws Exception {
    byte[] identity = this.packageIdentity.getSendPackageIdentity(((String)message).getBytes(this.encoding));
    if ((null == identity) || (identity.length == 0)) {
      throw new GatewayConnectException("SSGS0002", "获取报文identity失败");
    }

    ILongConnect conn = (ILongConnect)getIdleConnect();
    try {
      this.identityMap.put(new String(identity), identity);
      conn.send(identity, message);
      Object localObject1 = waitForMsg(identity, this.receiveTimeOut);

      return localObject1; } catch (Exception e) { } finally { releaseConnect();
    }
  }

  public Object sendAndReceive(Object message, T headMap) throws Exception
  {
    return sendAndReceive(message);
  }

  protected synchronized IConnect getIdleConnect()
    throws Exception
  {
    this.currSize += 1;
    if (null != this.connect) {
      return this.connect;
    }

    this.connect = initConnect();
    return this.connect;
  }

  private IConnect initConnect()
    throws Exception
  {
    try
    {
      if (null == this.channelInitializer) {
        if (null == this.channelHandlerList)
        {
          1LongChannelInboundHandlerAdapter lcihApapter = new ChannelInboundHandlerAdapter(this)
          {
            private CallbackListener callbackListener;

            public void channelRead(, Object msg)
              throws Exception
            {
              Trace.logDebug("CONNECT", "客户端收到服务器响应数据{}", new Object[] { msg });
              ByteBuf buf = (ByteBuf)msg;
              byte[] req = new byte[buf.readableBytes()];
              buf.readBytes(req);
              Trace.logInfo("CONNECT", "receive msg:{}", new Object[] { new String(req, TcpNettyLongConnector.access$000(this.this$0)) });
              ReferenceCountUtil.release(msg);
              this.callbackListener.receiveMsg(req);
            }

            public void channelReadComplete()
              throws Exception
            {
            }

            public void exceptionCaught(, Throwable cause) throws Exception
            {
              Trace.logError("CONNECT", "Unexpected exception from downstream:" + cause.getMessage());
              ctx.close();
            }

            public CallbackListener getCallbackListener() {
              return this.callbackListener;
            }

            public void setCallbackListener() {
              this.callbackListener = callbackListener;
            }

          };
          lcihApapter.setCallbackListener(this);
          this.channelHandlerList = new ArrayList();
          this.channelHandlerList.add(new GwLengthFieldBasedFrameDecoder(this.maxLength, 0, 8, 0, 8));

          this.channelHandlerList.add(lcihApapter);
        }

        this.channelInitializer = new ChannelInitializer(this)
        {
          protected void initChannel() throws Exception {
            for (Iterator i$ = TcpNettyLongConnector.access$100(this.this$0).iterator(); i$.hasNext(); ) { ChannelHandler channelHandler = (ChannelHandler)i$.next();
              sc.pipeline().addLast(new ChannelHandler[] { channelHandler });
            }
          }
        };
      }

      TcpNettyLongConnect conn = new TcpNettyLongConnect();
      conn.setIp(this.ip);
      conn.setPort(this.port);
      conn.setNoDelay(this.noDelay);
      conn.setEncoding(this.encoding);
      conn.setTimeOut(this.timeOut);
      conn.setConnectTimeOut(this.connectTimeOut);
      conn.setMsgHeadLen(this.msgHeadLen);
      conn.setSendBuffer(this.sendBuffer);
      conn.setReceiveBuffer(this.receiveBuffer);
      conn.setChannelInitializer(this.channelInitializer);
      conn.init();

      return conn;
    } catch (Exception e) {
      throw new GatewayException("SSGT0001", "初始化连接失败", e);
    }
  }

  protected synchronized void releaseConnect()
  {
    this.currSize -= 1;
  }

  private Object waitForMsg(Object identity, long timeOut)
    throws GatewayException
  {
    String id = new String((byte[])(byte[])identity);
    try {
      long startTime = System.currentTimeMillis();
      if (!(this.msgMap.containsKey(id)))
        try {
          long waitTime = timeOut - System.currentTimeMillis() - startTime;
          if (waitTime <= -3763400011480563712L)
            throw new GatewayReceiveTimeOutException("SSGR0001", "接收报文超时[" + timeOut + "], id:" + id);

          synchronized (identity) {
            identity.wait(waitTime);
          }
        } catch (InterruptedException e) {
          throw new GatewayException("SSGR0002", "接收报文出现异常, id:" + id, e);
        }


      e = new String((byte[])(byte[])this.msgMap.get(id));

      return e;
    }
    finally
    {
      this.msgMap.remove(id);
      this.identityMap.remove(id);
    }
  }

  public void receiveMsg(byte[] msg) throws GatewayException {
    String id = "";
    try {
      id = new String(this.packageIdentity.getReceivePackageIdentity(msg));
      Object identity = this.identityMap.get(id);
      if (null == identity) {
        Trace.logDebug("CONNECT", "identityMap: {}", new Object[] { this.identityMap });
        throw new GatewayException("SSGR0003", "找不到发送的identity：" + id);
      }

      this.msgMap.put(id, msg);
      synchronized (identity) {
        identity.notifyAll();
      }
    } catch (GatewayException e) {
      throw e;
    } catch (Exception e) {
      throw new GatewayException("SSGR0002", "接收报文出现异常, id: " + id, e);
    }
  }

  public int getSendBuffer() {
    return this.sendBuffer;
  }

  public void setSendBuffer(int sendBuffer) {
    this.sendBuffer = sendBuffer;
  }

  public int getReceiveBuffer() {
    return this.receiveBuffer;
  }

  public void setReceiveBuffer(int receiveBuffer) {
    this.receiveBuffer = receiveBuffer;
  }

  public boolean isNoDelay() {
    return this.noDelay;
  }

  public void setNoDelay(boolean noDelay) {
    this.noDelay = noDelay;
  }

  public int getConnectTimeOut() {
    return this.connectTimeOut;
  }

  public void setConnectTimeOut(int connectTimeOut) {
    this.connectTimeOut = connectTimeOut;
  }

  public long getTimeOut() {
    return this.timeOut;
  }

  public void setTimeOut(long timeOut) {
    this.timeOut = timeOut;
  }

  public long getReceiveTimeOut() {
    return this.receiveTimeOut;
  }

  public void setReceiveTimeOut(long receiveTimeOut) {
    this.receiveTimeOut = receiveTimeOut;
  }

  public ChannelInitializer getChannelInitializer() {
    return this.channelInitializer;
  }

  public void setChannelInitializer(ChannelInitializer channelInitializer) {
    this.channelInitializer = channelInitializer;
  }

  public int getMsgHeadLen() {
    return this.msgHeadLen;
  }

  public void setMsgHeadLen(int msgHeadLen) {
    this.msgHeadLen = msgHeadLen;
  }

  public int getMaxSize() {
    return this.maxSize;
  }

  public void setMaxSize(int maxSize) {
    this.maxSize = maxSize;
  }

  public int getWaitIdleTimeOut() {
    return this.waitIdleTimeOut;
  }

  public void setWaitIdleTimeOut(int waitIdleTimeOut) {
    this.waitIdleTimeOut = waitIdleTimeOut;
  }

  public int getCurrSize() {
    return this.currSize;
  }

  public void setCurrSize(int currSize) {
    this.currSize = currSize;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public int getMaxLength() {
    return this.maxLength;
  }

  public void setMaxLength(int maxLength) {
    this.maxLength = maxLength;
  }

  public IPackageIdentity getPackageIdentity() {
    return this.packageIdentity;
  }

  public void setPackageIdentity(IPackageIdentity packageIdentity) {
    this.packageIdentity = packageIdentity;
  }

  public List<ChannelHandler> getChannelHandlerList() {
    return this.channelHandlerList;
  }

  public void setChannelHandlerList(List<ChannelHandler> channelHandlerList) {
    this.channelHandlerList = channelHandlerList;
  }
}