package com.ifp.gateway.connector.connect;

import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.io.File;
import java.io.FileInputStream;
import java.net.URLEncoder;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.net.ssl.SSLContext;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.config.RequestConfig.Builder;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

public class HttpConnect1 extends AbstractConnect
{
  private String url;
  private Map<String, String> headMap;
  private int connectTimeOut = 6000;
  private int connectionRequestTimeOut = 60000;
  private int socketTimeOut = 6000;
  private String encoding = "UTF-8";
  private String method = "POST";
  private boolean proxyAuthor;
  private String proxyIP;
  private int proxyPort = -1;
  private String proxyUser;
  private String proxyPwd;
  private String contentType = "text/html";
  private boolean URLEncoderFlag = true;
  private String URLEncoderEncoding = "UTF-8";
  private String keyStore;
  private String keyStore_Type;
  private String keyStore_Password;
  private String trustStore;
  private String trustStore_Type;
  private String trustStore_Password;
  private String sslProtocol = "TLS";
  private String hostNameVerify;
  private CloseableHttpClient httpClient = null;

  public Object sendAndReceive(Object message)
    throws Exception
  {
    if (this.url.startsWith("https"))
      return sendAndReceiveHttps(message);

    return sendAndReceiveHttp(message);
  }

  public Object sendAndReceiveHttps(Object message)
    throws Exception
  {
    String msg = null;
    if (message instanceof Map) {
      StringBuffer params = new StringBuffer();
      Map msgMap = (Map)message;
      Iterator paramsIterator = msgMap.entrySet().iterator();
      while (paramsIterator.hasNext()) {
        Map.Entry paramsEntry = (Map.Entry)paramsIterator.next();
        if (this.URLEncoderFlag)
          params.append((String)paramsEntry.getKey()).append("=").append(URLEncoder.encode((String)paramsEntry.getValue(), this.URLEncoderEncoding)).append("&");
        else
          params.append((String)paramsEntry.getKey()).append("=").append((String)paramsEntry.getValue()).append("&");
      }

      if (params.length() > 0)
        params.deleteCharAt(params.length() - 1);

      msg = params.toString();
    } else {
      msg = (String)message;
    }

    CloseableHttpClient httpClient = null;
    try {
      Iterator headIterator;
      Map.Entry entry;
      HttpEntity entity;
      String resultMsg;
      String str1;
      String httpURL = this.url;
      RequestConfig.Builder requestConfigBuilder = RequestConfig.custom().setConnectionRequestTimeout(this.connectionRequestTimeOut).setConnectTimeout(this.connectTimeOut).setSocketTimeout(this.socketTimeOut);

      httpClient = getHttpsClient(requestConfigBuilder);
      RequestConfig requestConfig = requestConfigBuilder.build();

      if (this.method.equals("POST")) {
        ContentType cType;
        StringEntity reqEntity;
        Trace.logInfo("CONNECT", "target httpURL: {}", new Object[] { httpURL });
        HttpPost httppost = new HttpPost(httpURL);
        httppost.setConfig(requestConfig);

        if (this.headMap != null) {
          headIterator = this.headMap.entrySet().iterator();
          while (headIterator.hasNext()) {
            entry = (Map.Entry)headIterator.next();
            httppost.addHeader((String)entry.getKey(), (String)entry.getValue());
          }
        }

        Trace.logInfo("CONNECT", "send message:{}", new Object[] { message });
        if (message instanceof Map) {
          cType = ContentType.create("application/x-www-form-urlencoded", this.encoding);
          reqEntity = new StringEntity(msg, cType);
          httppost.setEntity(reqEntity);
        } else {
          cType = ContentType.create(this.contentType, this.encoding);
          reqEntity = new StringEntity(msg, cType);
          httppost.addHeader("Content-Type", this.contentType + "; charset=" + this.encoding);
          httppost.addHeader("Connection", "Keep-Alive");
          httppost.setEntity(reqEntity);
        }

        response = httpClient.execute(httppost);
        try {
          entity = response.getEntity();
          resultMsg = (entity != null) ? EntityUtils.toString(entity, this.encoding) : "";
          Trace.logInfo("CONNECT", "receive message:{}", new Object[] { resultMsg });
          str1 = resultMsg;

          return str1; } finally { response.close();
        }
      }
      if (httpURL.indexOf("?") < 0) {
        httpURL = httpURL + "?" + msg;
      }
      else if (httpURL.endsWith("&"))
        httpURL = httpURL + msg;
      else {
        httpURL = httpURL + "&" + msg;
      }

      Trace.logInfo("CONNECT", "target httpURL: {}", new Object[] { httpURL });
      HttpGet httpget = new HttpGet(httpURL);
      httpget.setConfig(requestConfig);

      if (this.headMap != null) {
        response = this.headMap.entrySet().iterator();
        while (response.hasNext()) {
          entity = (Map.Entry)response.next();
          httpget.addHeader((String)entity.getKey(), (String)entity.getValue());
        }
      }

      Trace.logInfo("CONNECT", "send message:{}", new Object[] { msg });
      CloseableHttpResponse response = httpClient.execute(httpget);
      try {
        entity = response.getEntity();
        resultMsg = (entity != null) ? EntityUtils.toString(entity, this.encoding) : "";
        Trace.logInfo("CONNECT", "receive message:{}", new Object[] { resultMsg });
        str1 = resultMsg;

        return str1; } finally { response.close();
      }
    }
    catch (Exception e) {
      Trace.logError("CONNECT", "http sendAndWait failed!", e);
      throw e;
    }
  }

  private CloseableHttpClient getHttpsClient(RequestConfig.Builder requestConfigBuilder)
    throws Exception
  {
    if (null == this.httpClient) {
      SSLContextBuilder ssLContextBuilder = SSLContexts.custom();

      if ((null != this.sslProtocol) && (this.sslProtocol.equals("SSL")))
        ssLContextBuilder.useSSL();
      else {
        ssLContextBuilder.useTLS();
      }

      KeyStore httpsKeyStore = null;
      KeyStore httpsTrustStore = null;

      if (StringUtil.hasText(this.keyStore)) {
        httpsKeyStore = getHttpsKeyStore();
        ssLContextBuilder.loadKeyMaterial(httpsKeyStore, this.keyStore_Password.toCharArray());
      }

      if (StringUtil.hasText(this.trustStore)) {
        httpsTrustStore = getHttpsTrustStore();
        ssLContextBuilder.loadTrustMaterial(httpsTrustStore);
      } else {
        ssLContextBuilder.loadTrustMaterial(null, new TrustStrategy(this)
        {
          public boolean isTrusted(, String authType) throws CertificateException {
            return true;
          }

        });
      }

      SSLContext sslContext = ssLContextBuilder.build();

      SSLConnectionSocketFactory sslSocketFactory = null;
      if (!(StringUtil.hasText(this.hostNameVerify))) {
        sslSocketFactory = new SSLConnectionSocketFactory(sslContext);
      }
      else if (this.hostNameVerify.equals("ALLOW_ALL"))
        sslSocketFactory = new SSLConnectionSocketFactory(sslContext, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
      else if (this.hostNameVerify.equals("BROWSER_COMPATIBLE"))
        sslSocketFactory = new SSLConnectionSocketFactory(sslContext, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
      else if (this.hostNameVerify.equals("STRICT"))
        sslSocketFactory = new SSLConnectionSocketFactory(sslContext, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
      else {
        sslSocketFactory = new SSLConnectionSocketFactory(sslContext);
      }

      HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();

      setProxy(httpClientBuilder, requestConfigBuilder);
      httpClientBuilder.setSSLSocketFactory(sslSocketFactory);
      this.httpClient = httpClientBuilder.build();
    }

    return this.httpClient;
  }

  private CloseableHttpClient getHttpClient(RequestConfig.Builder requestConfigBuilder)
    throws Exception
  {
    if (null == this.httpClient)
    {
      HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();

      setProxy(httpClientBuilder, requestConfigBuilder);
      this.httpClient = httpClientBuilder.build();
    }

    return this.httpClient;
  }

  private void setProxy(HttpClientBuilder httpClientBuilder, RequestConfig.Builder requestConfigBuilder)
  {
    if (this.proxyAuthor) {
      HttpHost proxy = null;

      if ((this.proxyIP != null) && (this.proxyIP.trim().length() != 0))
      {
        proxy = new HttpHost(this.proxyIP, this.proxyPort);
      }

      if ((this.proxyUser != null) && (this.proxyUser.trim().length() != 0))
      {
        CredentialsProvider credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(new AuthScope(this.proxyIP, this.proxyPort), new UsernamePasswordCredentials(this.proxyUser, this.proxyPwd));

        httpClientBuilder.setDefaultCredentialsProvider(credsProvider);
      }

      if (null != proxy)
        requestConfigBuilder.setProxy(proxy);
    }
  }

  public KeyStore getHttpsKeyStore() throws Exception
  {
    FileInputStream keyStore_f = new FileInputStream(new File(this.keyStore));
    KeyStore kStore = null;
    try {
      kStore = KeyStore.getInstance(this.keyStore_Type);
      kStore.load(keyStore_f, this.keyStore_Password.toCharArray());
      KeyStore localKeyStore1 = kStore;

      return localKeyStore1; } catch (Exception e) { } finally { keyStore_f.close();
    }
  }

  public KeyStore getHttpsTrustStore() throws Exception {
    FileInputStream trustStore_f = new FileInputStream(new File(this.trustStore));
    KeyStore tStore = null;
    try {
      tStore = KeyStore.getInstance(this.trustStore_Type);
      tStore.load(trustStore_f, this.trustStore_Password.toCharArray());
      KeyStore localKeyStore1 = tStore;

      return localKeyStore1; } catch (Exception e) { } finally { trustStore_f.close();
    }
  }

  public Object sendAndReceiveHttp(Object message)
    throws Exception
  {
    String msg = null;
    if (message instanceof Map) {
      StringBuffer params = new StringBuffer();
      Map msgMap = (Map)message;
      Iterator paramsIterator = msgMap.entrySet().iterator();
      while (paramsIterator.hasNext()) {
        Map.Entry paramsEntry = (Map.Entry)paramsIterator.next();
        if (this.URLEncoderFlag)
          params.append((String)paramsEntry.getKey()).append("=").append(URLEncoder.encode((String)paramsEntry.getValue(), this.URLEncoderEncoding)).append("&");
        else
          params.append((String)paramsEntry.getKey()).append("=").append((String)paramsEntry.getValue()).append("&");
      }

      if (params.length() > 0)
        params.deleteCharAt(params.length() - 1);

      msg = params.toString();
    } else {
      msg = (String)message;
    }

    CloseableHttpClient httpClient = null;
    try {
      Iterator headIterator;
      CloseableHttpResponse response;
      Map.Entry entry;
      HttpEntity entity;
      String resultMsg;
      String str1;
      String httpURL = this.url;

      RequestConfig.Builder requestConfigBuilder = RequestConfig.custom().setConnectionRequestTimeout(this.connectionRequestTimeOut).setConnectTimeout(this.connectTimeOut).setSocketTimeout(this.socketTimeOut);

      httpClient = getHttpClient(requestConfigBuilder);
      RequestConfig requestConfig = requestConfigBuilder.build();

      if (this.method.equals("POST")) {
        ContentType cType;
        StringEntity reqEntity;
        Trace.logInfo("CONNECT", "target httpURL: {}", new Object[] { httpURL });
        HttpPost httppost = new HttpPost(httpURL);
        httppost.setConfig(requestConfig);

        if (this.headMap != null) {
          headIterator = this.headMap.entrySet().iterator();
          while (headIterator.hasNext()) {
            entry = (Map.Entry)headIterator.next();
            httppost.addHeader((String)entry.getKey(), (String)entry.getValue());
          }
        }

        Trace.logInfo("CONNECT", "send message:{}", new Object[] { message });
        if (message instanceof Map) {
          cType = ContentType.create("application/x-www-form-urlencoded", this.encoding);
          reqEntity = new StringEntity(msg, cType);
          httppost.setEntity(reqEntity);
        } else {
          cType = ContentType.create(this.contentType, this.encoding);
          reqEntity = new StringEntity(msg, cType);
          httppost.addHeader("Content-Type", this.contentType + "; charset=" + this.encoding);
          httppost.addHeader("Connection", "Keep-Alive");
          httppost.setEntity(reqEntity);
        }

        response = httpClient.execute(httppost);
        try {
          entity = response.getEntity();
          resultMsg = (entity != null) ? EntityUtils.toString(entity, this.encoding) : "";
          Trace.logInfo("CONNECT", "receive message:{}", new Object[] { resultMsg });
          str1 = resultMsg;

          response.close();

          if (null != httpClient);
          return str1;
        }
        finally
        {
          response.close();
        }
      }
      if (httpURL.indexOf("?") < 0) {
        httpURL = httpURL + "?" + msg;
      }
      else if (httpURL.endsWith("&"))
        httpURL = httpURL + msg;
      else {
        httpURL = httpURL + "&" + msg;
      }

      Trace.logInfo("CONNECT", "target httpURL: {}", new Object[] { httpURL });
      HttpGet httpget = new HttpGet(httpURL);
      httpget.setConfig(requestConfig);

      if (this.headMap != null) {
        response = this.headMap.entrySet().iterator();
        while (response.hasNext()) {
          entity = (Map.Entry)response.next();
          httpget.addHeader((String)entity.getKey(), (String)entity.getValue());
        }

      }

      try
      {
        entity = response.getEntity();
        resultMsg = (entity != null) ? EntityUtils.toString(entity, this.encoding) : "";
        Trace.logInfo("CONNECT", "receive message:{}", new Object[] { resultMsg });
        str1 = resultMsg;

        response.close();

        if (null != httpClient);
        return str1;
      }
      finally
      {
        response.close();
      }
    }
    catch (Exception e)
    {
    }
    finally {
      if (null != httpClient)
        httpClient.close();
    }
  }

  public void releaseConnect()
    throws Exception
  {
    if (null != this.httpClient) {
      this.httpClient.close();
      this.httpClient = null;
    }
  }

  public String getUrl() {
    return this.url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public Map<String, String> getHeadMap() {
    return this.headMap;
  }

  public void setHeadMap(Map<String, String> headMap) {
    this.headMap = headMap;
  }

  public int getConnectTimeOut() {
    return this.connectTimeOut;
  }

  public void setConnectTimeOut(int connectTimeOut) {
    this.connectTimeOut = connectTimeOut;
  }

  public int getConnectionRequestTimeOut() {
    return this.connectionRequestTimeOut;
  }

  public void setConnectionRequestTimeOut(int connectionRequestTimeOut) {
    this.connectionRequestTimeOut = connectionRequestTimeOut;
  }

  public int getSocketTimeOut() {
    return this.socketTimeOut;
  }

  public void setSocketTimeOut(int socketTimeOut) {
    this.socketTimeOut = socketTimeOut;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public String getMethod() {
    return this.method;
  }

  public void setMethod(String method) {
    this.method = method.toUpperCase();
  }

  public boolean isProxyAuthor() {
    return this.proxyAuthor;
  }

  public void setProxyAuthor(boolean proxyAuthor) {
    this.proxyAuthor = proxyAuthor;
  }

  public String getProxyIP() {
    return this.proxyIP;
  }

  public void setProxyIP(String proxyIP) {
    this.proxyIP = proxyIP;
  }

  public int getProxyPort() {
    return this.proxyPort;
  }

  public void setProxyPort(int proxyPort) {
    this.proxyPort = proxyPort;
  }

  public String getProxyUser() {
    return this.proxyUser;
  }

  public void setProxyUser(String proxyUser) {
    this.proxyUser = proxyUser;
  }

  public String getProxyPwd() {
    return this.proxyPwd;
  }

  public void setProxyPwd(String proxyPwd) {
    this.proxyPwd = proxyPwd;
  }

  public String getContentType() {
    return this.contentType;
  }

  public void setContentType(String contentType) {
    this.contentType = contentType;
  }

  public boolean isURLEncoderFlag() {
    return this.URLEncoderFlag;
  }

  public void setURLEncoderFlag(boolean uRLEncoderFlag) {
    this.URLEncoderFlag = uRLEncoderFlag;
  }

  public String getURLEncoderEncoding() {
    return this.URLEncoderEncoding;
  }

  public void setURLEncoderEncoding(String uRLEncoderEncoding) {
    this.URLEncoderEncoding = uRLEncoderEncoding;
  }

  public String getKeyStore() {
    return this.keyStore;
  }

  public void setKeyStore(String keyStore) {
    this.keyStore = keyStore;
  }

  public String getKeyStore_Type() {
    return this.keyStore_Type;
  }

  public void setKeyStore_Type(String keyStore_Type) {
    this.keyStore_Type = keyStore_Type;
  }

  public String getKeyStore_Password() {
    return this.keyStore_Password;
  }

  public void setKeyStore_Password(String keyStore_Password) {
    this.keyStore_Password = keyStore_Password;
  }

  public String getTrustStore() {
    return this.trustStore;
  }

  public void setTrustStore(String trustStore) {
    this.trustStore = trustStore;
  }

  public String getTrustStore_Type() {
    return this.trustStore_Type;
  }

  public void setTrustStore_Type(String trustStore_Type) {
    this.trustStore_Type = trustStore_Type;
  }

  public String getTrustStore_Password() {
    return this.trustStore_Password;
  }

  public void setTrustStore_Password(String trustStore_Password) {
    this.trustStore_Password = trustStore_Password;
  }

  public String getSslProtocol() {
    return this.sslProtocol;
  }

  public void setSslProtocol(String sslProtocol) {
    this.sslProtocol = sslProtocol;
  }

  public String getHostNameVerify() {
    return this.hostNameVerify;
  }

  public void setHostNameVerify(String hostNameVerify) {
    this.hostNameVerify = hostNameVerify;
  }
}