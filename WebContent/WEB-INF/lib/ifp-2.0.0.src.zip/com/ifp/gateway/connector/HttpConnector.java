package com.ifp.gateway.connector;

import com.ifp.core.data.DataMap;
import com.ifp.core.log.Trace;
import com.ifp.core.util.DataMapChangeUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.connector.connect.HttpConnect;
import com.ifp.gateway.connector.connect.IConnect;
import com.ifp.gateway.exception.GatewayConnectException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HttpConnector<T extends Map> extends AbstractHttpConnector<T>
{
  private Map<String, String> headMap;
  private int readTimeOut;
  private boolean proxyAuthor;
  private String proxyIP;
  private int proxyPort;
  private String proxyUser;
  private String proxyPwd;
  private int currSize;
  private int maxSize;
  private int waitIdleTimeOut;
  private List<IConnect> poolList;
  private boolean fullUrl;
  private String uriSuffix;
  private String contentType;

  public HttpConnector()
  {
    this.readTimeOut = 60000;

    this.proxyPort = -1;

    this.currSize = 0;

    this.maxSize = -1;

    this.waitIdleTimeOut = 60000;

    this.poolList = new ArrayList();

    this.fullUrl = true;

    this.uriSuffix = "";

    this.contentType = "text/html";
  }

  public void init() throws Exception {
  }

  public Object sendAndReceive(Object message) throws Exception {
    IConnect conn = getIdleConnect();
    try {
      Object localObject1 = conn.sendAndReceive(message);

      return localObject1; } catch (Exception e) { } finally { releaseConnect(conn);
    }
  }

  public Object sendAndReceive(Object message, T headMap) throws Exception
  {
    HttpConnect conn = (HttpConnect)getIdleConnect();
    try {
      if ((!(isFullUrl())) && (conn instanceof HttpConnect)) {
        String tranCode = StringUtil.getValue(headMap.get("transCode"));
        conn.setUrl(this.url + tranCode + this.uriSuffix);
      }
      Map map = new HashMap();
      if (headMap instanceof DataMap)
        DataMapChangeUtil.dataMapToMap((DataMap)headMap, map);
      else
        map.putAll(headMap);

      conn.setHeadMap(map);
      Object localObject1 = conn.sendAndReceive(message);

      return localObject1; } catch (Exception e) { } finally { releaseConnect(conn);
    }
  }

  protected synchronized IConnect getIdleConnect()
    throws Exception
  {
    if (this.maxSize < 0) {
      HttpConnect connect = new HttpConnect();
      connect.setUrl(this.url);
      connect.setEncoding(this.encoding);
      connect.setHeadMap(this.headMap);
      connect.setMethod(this.method);
      connect.setConnectTimeOut(this.connectTimeOut);
      connect.setReadTimeOut(this.readTimeOut);
      connect.setProxyAuthor(this.proxyAuthor);
      connect.setProxyIP(this.proxyIP);
      connect.setProxyPort(this.proxyPort);
      connect.setProxyUser(this.proxyUser);
      connect.setProxyPwd(this.proxyPwd);
      connect.setInUse(true);
      connect.setContentType(this.contentType);
      connect.setURLEncoderFlag(this.URLEncoderFlag);
      connect.setURLEncoderEncoding((StringUtil.hasText(this.URLEncoderEncoding)) ? this.URLEncoderEncoding : this.encoding);

      this.currSize += 1;
      return connect;
    }

    long beginTime = System.currentTimeMillis();
    while (true)
    {
      for (int i = 0; i < this.poolList.size(); ++i) {
        IConnect conn = (IConnect)this.poolList.get(i);
        if (!(conn.isInUse())) {
          conn.setInUse(true);
          this.currSize += 1;
          return conn;
        }

      }

      if (this.poolList.size() < this.maxSize) {
        HttpConnect connect = new HttpConnect();
        connect.setUrl(this.url);
        connect.setEncoding(this.encoding);
        connect.setHeadMap(this.headMap);
        connect.setMethod(this.method);
        connect.setConnectTimeOut(this.connectTimeOut);
        connect.setReadTimeOut(this.readTimeOut);
        connect.setProxyAuthor(this.proxyAuthor);
        connect.setProxyIP(this.proxyIP);
        connect.setProxyPort(this.proxyPort);
        connect.setProxyUser(this.proxyUser);
        connect.setProxyPwd(this.proxyPwd);
        connect.setInUse(true);
        connect.setContentType(this.contentType);
        connect.setURLEncoderFlag(this.URLEncoderFlag);
        connect.setURLEncoderEncoding((StringUtil.hasText(this.URLEncoderEncoding)) ? this.URLEncoderEncoding : this.encoding);
        this.poolList.add(connect);
        this.currSize += 1;
        return connect;
      }

      if (this.waitIdleTimeOut < 0)
      {
        throw new GatewayConnectException("All connections are unavailable for [" + this.url + "]!");
      }
      long currTime = System.currentTimeMillis();
      long waitTime = currTime - beginTime;
      if (waitTime >= this.waitIdleTimeOut)
        throw new GatewayConnectException("TimeOut to get connect! The waitTime=" + waitTime + "ms!");

      Trace.logDebug("CONNECT", "wait time:{}/{}", new Object[] { Long.valueOf(waitTime), Integer.valueOf(this.waitIdleTimeOut) });
      wait();
    }
  }

  protected synchronized void releaseConnect(IConnect conn)
  {
    conn.setInUse(false);
    this.currSize -= 1;
    notifyAll();
  }

  public Map<String, String> getHeadMap() {
    return this.headMap;
  }

  public void setHeadMap(Map<String, String> headMap) {
    this.headMap = headMap;
  }

  public int getReadTimeOut() {
    return this.readTimeOut;
  }

  public void setReadTimeOut(int readTimeOut) {
    this.readTimeOut = readTimeOut;
  }

  public boolean isProxyAuthor() {
    return this.proxyAuthor;
  }

  public void setProxyAuthor(boolean proxyAuthor) {
    this.proxyAuthor = proxyAuthor;
  }

  public String getProxyIP() {
    return this.proxyIP;
  }

  public void setProxyIP(String proxyIP) {
    this.proxyIP = proxyIP;
  }

  public int getProxyPort() {
    return this.proxyPort;
  }

  public void setProxyPort(int proxyPort) {
    this.proxyPort = proxyPort;
  }

  public String getProxyUser() {
    return this.proxyUser;
  }

  public void setProxyUser(String proxyUser) {
    this.proxyUser = proxyUser;
  }

  public String getProxyPwd() {
    return this.proxyPwd;
  }

  public void setProxyPwd(String proxyPwd) {
    this.proxyPwd = proxyPwd;
  }

  public int getCurrSize() {
    return this.currSize;
  }

  public void setCurrSize(int currSize) {
    this.currSize = currSize;
  }

  public int getMaxSize() {
    return this.maxSize;
  }

  public void setMaxSize(int maxSize) {
    this.maxSize = maxSize;
  }

  public int getWaitIdleTimeOut() {
    return this.waitIdleTimeOut;
  }

  public void setWaitIdleTimeOut(int waitIdleTimeOut) {
    this.waitIdleTimeOut = waitIdleTimeOut;
  }

  public boolean isFullUrl() {
    return this.fullUrl;
  }

  public void setFullUrl(boolean fullUrl) {
    this.fullUrl = fullUrl;
  }

  public String getUriSuffix() {
    return this.uriSuffix;
  }

  public void setUriSuffix(String uriSuffix) {
    this.uriSuffix = uriSuffix;
  }

  public String getContentType() {
    return this.contentType;
  }

  public void setContentType(String contentType) {
    this.contentType = contentType;
  }
}