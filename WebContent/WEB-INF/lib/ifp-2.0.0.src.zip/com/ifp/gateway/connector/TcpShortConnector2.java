package com.ifp.gateway.connector;

import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.util.ReferenceCountUtil;
import java.io.PrintStream;
import java.util.Map;

public class TcpShortConnector2<T extends Map>
  implements IConnector<T>
{
  private String ip;
  private int port;
  private String requestEncoding;
  private String responseEncoding;
  private int sendBuffer;
  private int receiveBuffer;
  private boolean noDelay;
  private int connectTimeOut;
  private int timeOut;
  private int msgHeadLen;
  private EventLoopGroup group;
  private Bootstrap bootstrap;
  StringBuffer msgBuff;

  public TcpShortConnector2()
  {
    this.requestEncoding = "UTF-8";

    this.responseEncoding = "UTF-8";

    this.noDelay = true;

    this.connectTimeOut = 1000;

    this.timeOut = 60000;

    this.msgHeadLen = 8;
  }

  public void init()
    throws Exception
  {
    this.group = new NioEventLoopGroup();

    this.bootstrap = new Bootstrap();
    ((Bootstrap)((Bootstrap)((Bootstrap)((Bootstrap)((Bootstrap)this.bootstrap.group(this.group)).channel(NioSocketChannel.class)).option(ChannelOption.TCP_NODELAY, Boolean.valueOf(this.noDelay))).option(ChannelOption.SO_KEEPALIVE, Boolean.valueOf(false))).option(ChannelOption.CONNECT_TIMEOUT_MILLIS, Integer.valueOf(this.connectTimeOut))).option(ChannelOption.SO_TIMEOUT, Integer.valueOf(this.timeOut));

    if (this.sendBuffer > 0)
      this.bootstrap.option(ChannelOption.SO_SNDBUF, Integer.valueOf(this.sendBuffer));

    if (this.receiveBuffer > 0)
      this.bootstrap.option(ChannelOption.SO_RCVBUF, Integer.valueOf(this.receiveBuffer));

    this.bootstrap.handler(new ChannelInitializer(this)
    {
      protected void initChannel() throws Exception {
        sc.pipeline().addLast(new ChannelHandler[] { new ChannelInboundHandlerAdapter(this)
        {
          public void channelRead(, Object msg) throws Exception
          {
            Trace.logDebug("CONNECT", "客户端收到服务器响应数据");
            ByteBuf buf = (ByteBuf)msg;
            byte[] req = new byte[buf.readableBytes()];
            buf.readBytes(req);
            this.this$1.this$0.msgBuff.append(new String(req, TcpShortConnector2.access$000(this.this$1.this$0)));
            ReferenceCountUtil.release(msg);
          }

          public void channelReadComplete() throws Exception
          {
            ctx.close();
          }

          public void exceptionCaught(, Throwable cause) throws Exception
          {
            Trace.logDebug("CONNECT", "Unexpected exception from downstream:", new Object[] { cause.getMessage() });
            ctx.close();
            System.out.println("客户端异常退出333");
          }
        }
         });
      }
    });
  }

  public Object sendAndReceive(Object message) throws Exception {
    Trace.logDebug("CONNECT", "send message:{}", new Object[] { message });
    this.msgBuff = new StringBuffer();

    int msgLen = StringUtil.getStringLen((String)message, this.requestEncoding);
    int len = String.valueOf(msgLen).length();
    StringBuffer msg = new StringBuffer();
    if (this.msgHeadLen > 0) {
      for (int i = 0; i < this.msgHeadLen - len; ++i)
        msg.append(0);

      msg.append(msgLen);
    }
    msg.append(message);

    ChannelFuture channelFuture = this.bootstrap.connect(this.ip, this.port).sync();
    if (channelFuture.isSuccess()) {
      ByteBuf firstMessage = Unpooled.buffer();

      firstMessage.writeBytes(msg.toString().getBytes(this.requestEncoding));
      channelFuture.channel().writeAndFlush(firstMessage);
    }
    channelFuture.channel().closeFuture().sync();
    message = new String(this.msgBuff.toString().getBytes(), this.responseEncoding).substring(this.msgHeadLen);
    Trace.logDebug("CONNECT", "receive message:{}", new Object[] { message });
    this.msgBuff = null;
    return message;
  }

  public void destroy() {
    this.group.shutdownGracefully();
  }

  public void finalize() throws Throwable
  {
    destroy();
    super.finalize();
  }

  public String getIp() {
    return this.ip;
  }

  public void setIp(String ip) {
    this.ip = ip;
  }

  public int getPort() {
    return this.port;
  }

  public void setPort(int port) {
    this.port = port;
  }

  public String getRequestEncoding() {
    return this.requestEncoding;
  }

  public void setRequestEncoding(String requestEncoding) {
    this.requestEncoding = requestEncoding;
  }

  public String getResponseEncoding() {
    return this.responseEncoding;
  }

  public void setResponseEncoding(String responseEncoding) {
    this.responseEncoding = responseEncoding;
  }

  public EventLoopGroup getGroup() {
    return this.group;
  }

  public void setGroup(EventLoopGroup group) {
    this.group = group;
  }

  public Bootstrap getBootstrap() {
    return this.bootstrap;
  }

  public void setBootstrap(Bootstrap bootstrap) {
    this.bootstrap = bootstrap;
  }

  public StringBuffer getMsgBuff() {
    return this.msgBuff;
  }

  public void setMsgBuff(StringBuffer msgBuff) {
    this.msgBuff = msgBuff;
  }

  public int getSendBuffer() {
    return this.sendBuffer;
  }

  public void setSendBuffer(int sendBuffer) {
    this.sendBuffer = sendBuffer;
  }

  public int getReceiveBuffer() {
    return this.receiveBuffer;
  }

  public void setReceiveBuffer(int receiveBuffer) {
    this.receiveBuffer = receiveBuffer;
  }

  public boolean isNoDelay() {
    return this.noDelay;
  }

  public void setNoDelay(boolean noDelay) {
    this.noDelay = noDelay;
  }

  public int getConnectTimeOut() {
    return this.connectTimeOut;
  }

  public void setConnectTimeOut(int connectTimeOut) {
    this.connectTimeOut = connectTimeOut;
  }

  public int getTimeOut() {
    return this.timeOut;
  }

  public void setTimeOut(int timeOut) {
    this.timeOut = timeOut;
  }

  public int getMsgHeadLen() {
    return this.msgHeadLen;
  }

  public void setMsgHeadLen(int msgHeadLen) {
    this.msgHeadLen = msgHeadLen;
  }

  public Object sendAndReceive(Object message, T headMap)
    throws Exception
  {
    return null;
  }
}