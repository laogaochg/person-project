package com.ifp.gateway.connector.identity;

import org.apache.commons.lang.ArrayUtils;

public class TcpPackageIdentity
  implements IPackageIdentity
{
  private int sendStartIndex;
  private int sendEndIndex;
  private int receiveStartIndex;
  private int receiveEndIndex;

  public byte[] getSendPackageIdentity(byte[] msg)
  {
    return ArrayUtils.subarray(msg, this.sendStartIndex, this.sendEndIndex);
  }

  public byte[] getReceivePackageIdentity(byte[] msg) {
    return ArrayUtils.subarray(msg, this.receiveStartIndex, this.receiveEndIndex);
  }

  public int getSendStartIndex() {
    return this.sendStartIndex;
  }

  public void setSendStartIndex(int sendStartIndex) {
    this.sendStartIndex = sendStartIndex;
  }

  public int getSendEndIndex() {
    return this.sendEndIndex;
  }

  public void setSendEndIndex(int sendEndIndex) {
    this.sendEndIndex = sendEndIndex;
  }

  public int getReceiveStartIndex() {
    return this.receiveStartIndex;
  }

  public void setReceiveStartIndex(int receiveStartIndex) {
    this.receiveStartIndex = receiveStartIndex;
  }

  public int getReceiveEndIndex() {
    return this.receiveEndIndex;
  }

  public void setReceiveEndIndex(int receiveEndIndex) {
    this.receiveEndIndex = receiveEndIndex;
  }
}