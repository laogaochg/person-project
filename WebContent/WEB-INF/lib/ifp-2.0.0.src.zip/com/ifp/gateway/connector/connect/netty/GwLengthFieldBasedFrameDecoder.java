package com.ifp.gateway.connector.connect.netty;

import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import java.nio.ByteOrder;

public class GwLengthFieldBasedFrameDecoder extends LengthFieldBasedFrameDecoder
{
  public GwLengthFieldBasedFrameDecoder(int maxFrameLength, int lengthFieldOffset, int lengthFieldLength)
  {
    super(maxFrameLength, lengthFieldOffset, lengthFieldLength);
  }

  public GwLengthFieldBasedFrameDecoder(int maxFrameLength, int lengthFieldOffset, int lengthFieldLength, int lengthAdjustment, int initialBytesToStrip)
  {
    super(maxFrameLength, lengthFieldOffset, lengthFieldLength, lengthAdjustment, initialBytesToStrip);
  }

  public GwLengthFieldBasedFrameDecoder(int maxFrameLength, int lengthFieldOffset, int lengthFieldLength, int lengthAdjustment, int initialBytesToStrip, boolean failFast)
  {
    super(maxFrameLength, lengthFieldOffset, lengthFieldLength, lengthAdjustment, initialBytesToStrip, failFast);
  }

  public GwLengthFieldBasedFrameDecoder(ByteOrder byteOrder, int maxFrameLength, int lengthFieldOffset, int lengthFieldLength, int lengthAdjustment, int initialBytesToStrip, boolean failFast)
  {
    super(byteOrder, maxFrameLength, lengthFieldOffset, lengthFieldLength, lengthAdjustment, initialBytesToStrip, failFast);
  }

  protected long getUnadjustedFrameLength(ByteBuf buf, int offset, int length, ByteOrder order)
  {
    buf = buf.order(order);

    byte[] dst = new byte[length];
    buf.getBytes(offset, dst);

    long frameLength = Long.parseLong(new String(dst));

    return frameLength;
  }
}