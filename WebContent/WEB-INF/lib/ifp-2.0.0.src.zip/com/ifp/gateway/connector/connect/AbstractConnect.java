package com.ifp.gateway.connector.connect;

public abstract class AbstractConnect
  implements IConnect
{
  private boolean inUse;

  public AbstractConnect()
  {
    this.inUse = false;
  }

  public void init()
    throws Exception
  {
  }

  public void releaseConnect()
    throws Exception
  {
  }

  public boolean isInUse()
  {
    return this.inUse;
  }

  public void setInUse(boolean flag) {
    this.inUse = flag;
  }
}