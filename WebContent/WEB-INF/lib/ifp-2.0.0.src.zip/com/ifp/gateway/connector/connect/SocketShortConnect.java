package com.ifp.gateway.connector.connect;

import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.exception.GatewayConnectException;
import com.ifp.gateway.exception.GatewayNoResultException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

public class SocketShortConnect extends AbstractConnect
{
  private String ip;
  private int port;
  private String encoding = "UTF-8";
  private int msgHeadLen = 8;
  private int sendBuffer;
  private int receiveBuffer;
  private boolean noDelay = true;
  private int soLinger = 0;
  private int timeOut = 60000;
  private Socket socket;
  private OutputStream out = null;
  private InputStream in = null;
  private InetSocketAddress socketAddr;

  public SocketShortConnect()
  {
  }

  public SocketShortConnect(String ip, int port)
  {
    this.ip = ip;
    this.port = port;
    this.socketAddr = new InetSocketAddress(ip, port);
  }

  public Object sendAndReceive(Object message) throws Exception {
    connect();
    String resultMsg = null;
    try
    {
      int msgLen = StringUtil.getStringLen((String)message, this.encoding);
      int len = String.valueOf(msgLen).length();
      StringBuffer msg = new StringBuffer();
      if (this.msgHeadLen > 0) {
        for (int i = 0; i < this.msgHeadLen - len; ++i)
          msg.append(0);

        msg.append(msgLen);
      }
      msg.append(message);

      Trace.logInfo("CONNECT", "send message[{}:{}]:{}", new Object[] { this.ip, Integer.valueOf(this.port), msg.toString() });
      this.out.write(msg.toString().getBytes(this.encoding));
      byte[] msgBytes = readPackage(this.in);
      resultMsg = new String(msgBytes, this.encoding);
      Trace.logInfo("CONNECT", "receive message:{}", new Object[] { resultMsg });
    } catch (Exception e) {
    }
    finally {
      releaseConnection();
    }

    return resultMsg;
  }

  protected void connect() throws GatewayConnectException {
    if (null == this.socket)
      try {
        if (null == this.socketAddr)
          this.socketAddr = new InetSocketAddress(this.ip, this.port);

        this.socket = new Socket();

        this.socket.setSoLinger(true, this.soLinger);
        if (this.timeOut > 0)
        {
          this.socket.setSoTimeout(this.timeOut);
        }

        if (this.sendBuffer > 0)
        {
          this.socket.setSendBufferSize(this.sendBuffer);
        }
        if (this.receiveBuffer > 0)
        {
          this.socket.setReceiveBufferSize(this.receiveBuffer);
        }

        this.socket.setTcpNoDelay(this.noDelay);

        Trace.logDebug("CONNECT", "connect to host {}:{}...", new Object[] { this.ip, Integer.valueOf(this.port) });
        this.socket.connect(this.socketAddr);

        this.out = this.socket.getOutputStream();
        this.in = this.socket.getInputStream();
      } catch (Exception e) {
        throw new GatewayConnectException("connect fail ==> " + this.ip + ":" + this.port, e);
      }
  }

  protected byte[] readPackage(InputStream in) throws Exception
  {
    int contentLength = this.msgHeadLen;
    byte[] revMessage = new byte[contentLength];
    int off = 0;
    while (off < contentLength) {
      int len = in.read(revMessage, off, contentLength - off);
      if (len <= 0)
        throw new GatewayNoResultException("connect is close, while read head length: {}", new String(revMessage));

      off += len;
    }
    contentLength = Integer.parseInt(new String(revMessage).trim());
    Trace.logDebug("CONNECT", "contentHeadLen: {}, contentLen:{}...", new Object[] { Integer.valueOf(this.msgHeadLen), Integer.valueOf(contentLength) });

    byte[] contentBuf = new byte[contentLength];
    off = 0;
    while (off < contentLength) {
      int len = in.read(contentBuf, off, contentLength - off);
      if (len <= 0)
        break;

      off += len;
    }
    Trace.logDebug("CONNECT", "Read in package As:{} ", new Object[] { new String(contentBuf, this.encoding) });

    return contentBuf;
  }

  protected void releaseConnection()
    throws IOException
  {
    if (null != this.in) {
      this.in.close();
      this.in = null;
    }
    if (null != this.out) {
      this.out.close();
      this.out = null;
    }
    if (null != this.socket) {
      this.socket.close();
      this.socket = null;
    }
  }

  public String getIp() {
    return this.ip;
  }

  public void setIp(String ip) {
    this.ip = ip;
  }

  public int getPort() {
    return this.port;
  }

  public void setPort(int port) {
    this.port = port;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public int getMsgHeadLen() {
    return this.msgHeadLen;
  }

  public void setMsgHeadLen(int msgHeadLen) {
    this.msgHeadLen = msgHeadLen;
  }

  public int getSendBuffer() {
    return this.sendBuffer;
  }

  public void setSendBuffer(int sendBuffer) {
    this.sendBuffer = sendBuffer;
  }

  public int getReceiveBuffer() {
    return this.receiveBuffer;
  }

  public void setReceiveBuffer(int receiveBuffer) {
    this.receiveBuffer = receiveBuffer;
  }

  public boolean isNoDelay() {
    return this.noDelay;
  }

  public void setNoDelay(boolean noDelay) {
    this.noDelay = noDelay;
  }

  public int getTimeOut() {
    return this.timeOut;
  }

  public void setTimeOut(int timeOut) {
    this.timeOut = timeOut;
  }

  public int getSoLinger() {
    return this.soLinger;
  }

  public void setSoLinger(int soLinger) {
    this.soLinger = soLinger;
  }

  public Socket getSocket() {
    return this.socket;
  }

  public void setSocket(Socket socket) {
    this.socket = socket;
  }

  public OutputStream getOut() {
    return this.out;
  }

  public void setOut(OutputStream out) {
    this.out = out;
  }

  public InputStream getIn() {
    return this.in;
  }

  public void setIn(InputStream in) {
    this.in = in;
  }
}