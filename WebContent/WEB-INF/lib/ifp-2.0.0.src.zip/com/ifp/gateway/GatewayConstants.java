package com.ifp.gateway;

public class GatewayConstants
{
  public static final String PATTERN_HEAD = "head";
  public static final String COMM_CLIENT = "commClient";
  public static final String CHANNEL_ID = "channelId";
  public static final String TRANS_CODE = "transCode";
  public static final String DEFINE_TYPE_REQUEST = "_send";
  public static final String DEFINE_TYPE_RESPONSE = "_receive";
  public static final String DEFINE_TYPE_TEMPLATE = "template";
  public static final String ACTION_ID = "actionId";
  public static final String LOGIC_CODE = "LogicCode";
  public static final String ACTION_ERRORCODE = "errorCode";
  public static final String ACTION_ERRORMSG = "errorMsg";
  public static final String RECEIVE_MSG_LEN = "receiveMsgLen";
}