package com.ifp.gateway.service;

import com.ifp.gateway.connector.IConnector;
import java.util.List;

public class TcpService extends AbstractService
{
  private int index;

  public TcpService()
  {
    this.index = 0;
  }

  protected IConnector getIdleConnector()
  {
    List connectorList = getConnectorList();
    if (null != connectorList)
      synchronized (this) {
        if (this.index >= connectorList.size())
          this.index = 0;

        return ((IConnector)connectorList.get(this.index++));
      }

    return null;
  }
}