package com.ifp.gateway.service;

import com.ifp.core.data.DataField;
import com.ifp.core.log.FlumeLogInf;
import com.ifp.core.log.LogHandle;
import com.ifp.core.util.IpUtils;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.connector.IConnector;
import com.ifp.gateway.exception.GatewayConnectException;
import com.ifp.gateway.exception.GatewayException;
import com.ifp.gateway.exception.GatewayNoResultException;
import com.ifp.gateway.formatter.IFormatter;
import com.ifp.gateway.processor.IGatewayProcessor;
import java.util.List;
import java.util.Map;
import java.util.Random;

public abstract class AbstractService
  implements IService<Map>
{
  private List<IConnector> connectorList;
  private IFormatter formater;
  private IFormatter requestFormater;
  private String requestType;
  private IFormatter responseFormater;
  private String responseType;
  private IGatewayProcessor processor;
  private boolean messageDefineFlag;

  public AbstractService()
  {
    this.messageDefineFlag = true;
  }

  public Object sendAndReceive(Object message)
    throws Exception
  {
    IConnector connector = getIdleConnector();
    try {
      return connector.sendAndReceive(message);
    } catch (Exception e) {
      throw new GatewayNoResultException(e);
    }
  }

  public Object sendAndReceive(Object message, Map headMap)
    throws Exception
  {
    IConnector connector = getIdleConnector();

    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");

    String idc = StringUtil.getValue(headMap.get("commClient"));
    String appId = StringUtil.getValue(headMap.get("channelId"));
    String svcId = StringUtil.getValue(headMap.get("transCode"));

    Long startTime = Long.valueOf(System.currentTimeMillis());

    String cid = IpUtils.getHostAddress() + logHandle.getAppName() + String.valueOf(startTime) + StringUtil.generateRandomString(7);
    StringBuffer para = new StringBuffer("GatewayAction@");
    para.append("client=").append(idc).append("&").append("channel=").append(appId).append("&").append("transCode=").append(svcId);

    headMap.put("pcid", new DataField("pcid", cid));

    FlumeLogInf flumeLogInf = logHandle.getFlumeLogInf();
    if (null != flumeLogInf)
      headMap.put("reqId", new DataField("reqId", flumeLogInf.getFlumeReqid()));

    try
    {
      Object rt = connector.sendAndReceive(message, headMap);
      logHandle.logFlumeSIService(para.toString(), null, null, null, startTime, cid);
      return rt;
    } catch (GatewayConnectException e) {
      logHandle.logFlumeSISvcEx(para.toString(), null, null, null, startTime, cid, e);
      throw e;
    } catch (GatewayNoResultException e) {
      throw e;
    } catch (Exception e) {
      throw new GatewayNoResultException(e);
    }
  }

  public Object format(Map headMap, Map dataMap, MessageDefine messageDefine)
    throws Exception
  {
    if (null != this.processor) {
      this.processor.processSend(headMap, dataMap);
    }

    Object sendObj = null;
    if (null != this.requestFormater)
      sendObj = this.requestFormater.format(headMap, dataMap, messageDefine);
    else if (null != this.formater)
      sendObj = this.formater.format(headMap, dataMap, messageDefine);
    else {
      throw new GatewayException("requestFormater had not define, please check gateway service config!");
    }

    if (null != this.processor)
      return this.processor.beforeSend(sendObj, headMap, dataMap, messageDefine);

    return sendObj;
  }

  public Object format(Map headMap, Map dataMap, String transCode)
    throws Exception
  {
    MessageDefine messageDefine = null;
    if (this.messageDefineFlag)
      messageDefine = getRequestDefine(transCode);

    return format(headMap, dataMap, messageDefine);
  }

  public void unformat(Map headMap, Map dataMap, String recMsg, MessageDefine messageDefine)
    throws Exception
  {
    if (null != this.processor) {
      recMsg = this.processor.afterReceive(recMsg, headMap, dataMap, messageDefine);
    }

    if (null != this.responseFormater)
      this.responseFormater.unformat(headMap, dataMap, recMsg, messageDefine);
    else if (null != this.formater)
      this.formater.unformat(headMap, dataMap, recMsg, messageDefine);
    else {
      throw new GatewayException("responseFormater had not define, please check gateway service config!");
    }

    if (null != this.processor)
      this.processor.processReceive(headMap, dataMap);
  }

  public void unformat(Map headMap, Map dataMap, String recMsg, String transCode)
    throws Exception
  {
    MessageDefine messageDefine = null;
    if (this.messageDefineFlag)
      messageDefine = getResponseDefine(transCode);

    unformat(headMap, dataMap, recMsg, messageDefine);
  }

  public MessageDefine getMessageDefine(String transCode, String type)
  {
    if (null != type)
      return ((MessageDefine)SpringContextsUtil.getBean(transCode + type, MessageDefine.class));

    return null;
  }

  public MessageDefine getRequestDefine(String transCode)
  {
    if (null != this.requestType) {
      if (this.requestType.equalsIgnoreCase("template"))
        return null;

      return ((MessageDefine)SpringContextsUtil.getBean(transCode + this.requestType, MessageDefine.class));
    }

    return ((MessageDefine)SpringContextsUtil.getBean(transCode + "_send", MessageDefine.class));
  }

  public MessageDefine getResponseDefine(String transCode)
  {
    if (null != this.responseType) {
      if (this.responseType.equalsIgnoreCase("template"))
        return null;

      return ((MessageDefine)SpringContextsUtil.getBean(transCode + this.responseType, MessageDefine.class));
    }

    return ((MessageDefine)SpringContextsUtil.getBean(transCode + "_receive", MessageDefine.class));
  }

  protected IConnector getIdleConnector()
  {
    List connectorList = getConnectorList();
    if (null != connectorList) {
      Random random = new Random();

      int index = random.nextInt(connectorList.size());
      return ((IConnector)connectorList.get(index));
    }
    return null;
  }

  public List<IConnector> getConnectorList()
  {
    return this.connectorList;
  }

  public void setConnectorList(List<IConnector> connectorList) {
    this.connectorList = connectorList;
  }

  public IFormatter getFormater() {
    return this.formater;
  }

  public void setFormater(IFormatter formater) {
    this.formater = formater;
    if (null == this.requestFormater)
      this.requestFormater = this.formater;

    if (null == this.responseFormater)
      this.responseFormater = this.formater;
  }

  public IGatewayProcessor getProcessor()
  {
    return this.processor;
  }

  public void setProcessor(IGatewayProcessor processor) {
    this.processor = processor;
  }

  public IFormatter getRequestFormater() {
    return this.requestFormater;
  }

  public void setRequestFormater(IFormatter requestFormater) {
    this.requestFormater = requestFormater;
  }

  public IFormatter getResponseFormater() {
    return this.responseFormater;
  }

  public void setResponseFormater(IFormatter responseFormater) {
    this.responseFormater = responseFormater;
  }

  public String getRequestType() {
    return this.requestType;
  }

  public void setRequestType(String requestType) {
    this.requestType = requestType;
  }

  public String getResponseType() {
    return this.responseType;
  }

  public void setResponseType(String responseType) {
    this.responseType = responseType;
  }

  public boolean isMessageDefineFlag() {
    return this.messageDefineFlag;
  }

  public void setMessageDefineFlag(boolean messageDefineFlag) {
    this.messageDefineFlag = messageDefineFlag;
  }
}