package com.ifp.gateway.service;

import com.ifp.gateway.bean.MessageDefine;
import java.util.Map;

public abstract interface IService<T extends Map>
{
  public abstract Object sendAndReceive(Object paramObject)
    throws Exception;

  public abstract Object sendAndReceive(Object paramObject, T paramT)
    throws Exception;

  public abstract Object format(T paramT1, T paramT2, MessageDefine paramMessageDefine)
    throws Exception;

  public abstract Object format(T paramT1, T paramT2, String paramString)
    throws Exception;

  public abstract void unformat(T paramT1, T paramT2, String paramString, MessageDefine paramMessageDefine)
    throws Exception;

  public abstract void unformat(T paramT1, T paramT2, String paramString1, String paramString2)
    throws Exception;

  public abstract MessageDefine getRequestDefine(String paramString);

  public abstract MessageDefine getResponseDefine(String paramString);
}