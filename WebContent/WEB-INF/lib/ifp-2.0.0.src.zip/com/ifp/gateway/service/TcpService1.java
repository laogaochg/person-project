package com.ifp.gateway.service;

import com.ifp.core.data.DataField;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.connector.IConnector;
import java.util.List;
import java.util.Map;

public class TcpService1 extends AbstractService
{
  private int index;

  public TcpService1()
  {
    this.index = 0;
  }

  protected IConnector getIdleConnector()
  {
    List connectorList = getConnectorList();
    if (null != connectorList)
      synchronized (this) {
        if (this.index >= connectorList.size())
          this.index = 0;

        return ((IConnector)connectorList.get(this.index++));
      }

    return null;
  }

  public Object format(Map headMap, Map dataMap, String transCode)
    throws Exception
  {
    MessageDefine messageDefine = getResponseDefine(transCode);
    headMap.put("receiveMsgLen", new DataField("receiveMsgLen", String.valueOf(messageDefine.countMsgLen())));

    return super.format(headMap, dataMap, transCode);
  }
}