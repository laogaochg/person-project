package com.ifp.gateway.service;

import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.log.Trace;
import com.ifp.core.util.DataMapChangeUtil;
import com.ifp.core.util.SpringContextsUtil;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;

public class MockService extends AbstractService
{
  public Object format(Map headMap, Map dataMap, String transCode)
    throws Exception
  {
    return "";
  }

  public Object sendAndReceive(Object message) throws Exception
  {
    return "";
  }

  public Object sendAndReceive(Object message, Map headMap) throws Exception
  {
    return "";
  }

  public void unformat(Map headMap, Map dataMap, String recMsg, String transCode) throws Exception {
    Map responseMap;
    try {
      responseMap = (Map)SpringContextsUtil.getBean("mock_" + transCode + "_receive", Map.class);
      Iterator iterator = responseMap.entrySet().iterator();

      while (iterator.hasNext()) {
        Map.Entry entry = (Map.Entry)iterator.next();
        String key = (String)entry.getKey();
        Object dataElement = dataMap.get(key);
        if (null == dataElement) {
          throw new Exception("not found element in context: " + key);
        }

        Object obj = entry.getValue();
        if (dataMap instanceof DataMap) {
          if (dataElement instanceof DataList) {
            DataList dataList = (DataList)dataElement;
            if (obj instanceof List)
              dataMap.put(key, DataMapChangeUtil.listToDataList((List)obj, dataList.getDefineMap()));
            else
              throw new Exception(key + "is not a list");
          }
          else if (dataElement instanceof DataField) {
            DataField dataField = (DataField)dataElement;
            if (obj instanceof String)
              dataField.setValue((String)obj);
            else
              throw new Exception(key + "is not a field");
          }
        }
        else {
          if (dataElement instanceof List) {
            if (obj instanceof List) {
              dataMap.put(key, (List)obj); continue;
            }
            throw new Exception(key + "is not a list");
          }
          if (dataElement instanceof DataField)
            if (obj instanceof String)
              dataMap.put(key, (String)obj);
            else
              throw new Exception(key + "is not a field");
        }
      }
    }
    catch (NoSuchBeanDefinitionException e)
    {
      Trace.logError("CONNECT", "找不到模拟报文：mock_{}{}", new Object[] { transCode, "_receive" });
      throw e;
    }
  }
}