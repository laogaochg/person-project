package com.ifp.gateway.service;

import com.ifp.core.data.DataMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.connector.IConnector;
import com.ifp.gateway.formatter.IFormatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class WSDLService extends AbstractService
{
  private int index;

  public WSDLService()
  {
    this.index = 0;
  }

  protected IConnector getIdleConnector()
  {
    List connectorList = getConnectorList();
    if (null != connectorList)
      synchronized (this) {
        if (this.index >= connectorList.size())
          this.index = 0;

        return ((IConnector)connectorList.get(this.index++));
      }

    return null;
  }

  public Object getParamasFromXml(String recMsg, String transCode) throws Exception
  {
    Map paramMap = new HashMap();

    paramMap.put("method", transCode);

    MessageDefine msgDefine = getRequestDefine(transCode);

    DataMap headMap = new DataMap();
    DataMap dataMap = new DataMap();

    getFormater().unformat(headMap, dataMap, recMsg, msgDefine);

    Iterator elementIter = msgDefine.getElementMap().entrySet().iterator();
    String[] params = new String[msgDefine.getElementMap().size()];
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      MsgField msgField = (MsgField)elementEntry.getValue();
      params[java.lang.Integer.parseInt(msgField.getPattern())] = dataMap.getElementValue(msgField.getRefName());
    }
    paramMap.put("params", params);
    return paramMap;
  }
}