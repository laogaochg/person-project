package com.ifp.gateway.helper;

import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.util.StringUtils;

public class SchemaParserHelper
{
  public static void addPropertyValue(BeanDefinitionBuilder builder, String key, String value)
  {
    if (StringUtils.hasText(value))
      builder.addPropertyValue(key, value);
  }

  public static void addPropertyValue(BeanDefinitionBuilder builder, String confPath, String groupName, String key, String value)
  {
    if (StringUtils.hasText(value))
      builder.addPropertyValue(key, value);
  }

  private static String getConfValue(String confPath, String groupName, String key)
  {
    return null;
  }
}