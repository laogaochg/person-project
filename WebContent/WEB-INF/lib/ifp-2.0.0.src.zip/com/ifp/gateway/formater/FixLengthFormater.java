package com.ifp.gateway.formater;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.dom4j.Element;

@Deprecated
public class FixLengthFormater
  implements IFormater
{
  private int messageLengthHead;
  private String fillCharacter;
  private String encoding;

  public FixLengthFormater()
  {
    this.messageLengthHead = 0;

    this.fillCharacter = " ";

    this.encoding = "UTF-8"; }

  public Object format(DataMap headMap, DataMap dataMap, MessageDefine msgDefine) throws Exception {
    StringBuffer msg = new StringBuffer();

    Iterator elementIter = msgDefine.getElementMap().entrySet().iterator();
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      String key = (String)elementEntry.getKey();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof GroupMap)
        formatGroup(msg, headMap, dataMap, (GroupMap)defineElement);
      else
        formatElement(msg, headMap, dataMap, defineElement);
    }

    Trace.log("FORMAT", 1, "format msg's:{}", new Object[] { msg.toString() });
    return msg.toString();
  }

  public void formatGroup(StringBuffer msg, DataMap headMap, DataMap dataMap, GroupMap groupDefine) throws Exception {
    Iterator defineIterator = groupDefine.entrySet().iterator();
    while (defineIterator.hasNext()) {
      Map.Entry defineEntry = (Map.Entry)defineIterator.next();
      String key = (String)defineEntry.getKey();
      DataElement defineElement = (DataElement)defineEntry.getValue();
      if (defineElement instanceof GroupMap)
        formatGroup(msg, headMap, dataMap, (GroupMap)defineElement);
      else
        formatElement(msg, headMap, dataMap, defineElement);
    }
  }

  public void formatElement(StringBuffer msg, DataMap headMap, DataMap dataMap, DataElement defineElement) throws Exception
  {
    if (defineElement instanceof MsgField)
      formatField(msg, headMap, dataMap, (MsgField)defineElement);
    else if (defineElement instanceof MsgList);
  }

  public void formatList(StringBuffer msg, DataMap headMap, DataList<DataElement> dataList, MsgList listDefine)
    throws Exception
  {
    Object[] fieldDefineArray = listDefine.values().toArray();
    for (Iterator i$ = dataList.iterator(); i$.hasNext(); ) { DataElement rowElement = (DataElement)i$.next();
      if (rowElement instanceof DataMap) {
        DataMap rowMap = (DataMap)rowElement;
        Object[] arr$ = fieldDefineArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object defineObject = arr$[i$];
          formatElement(msg, headMap, rowMap, (DataElement)defineObject);
        }
      } else {
        throw new Exception("DataList rows expect of DataMap");
      }
    }
  }

  public void formatField(StringBuffer msg, DataMap headMap, DataMap dataMap, MsgField fieldDefine) throws Exception {
    DataElement dataElement;
    String key = fieldDefine.getName();
    String value = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (!(StringUtil.hasText(refName))) {
      refName = fieldDefine.getName();
    }

    if ((null != fieldDefine.getPattern()) && (fieldDefine.getPattern().equalsIgnoreCase("head")))
      dataElement = headMap.get(refName);
    else
      dataElement = dataMap.get(refName);

    if (null == dataElement) {
      if ((!(fieldDefine.isNeed())) || (StringUtil.hasText(value))) break label197;
      throw new Exception(fieldDefine.getName() + " is need!");
    }

    if (!(dataElement instanceof DataField)) {
      throw new Exception(key + " is define field, expect of DataField in context here!");
    }

    DataField dataField = (DataField)dataElement;
    if ((null != dataField) && (StringUtil.hasText(dataField.getValue()))) {
      value = dataField.getValue();
    }

    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      label197: throw new Exception(fieldDefine.getName() + " is empty!");
    }

    value = (value == null) ? "" : value;
    buildFixLengthField(msg, key, value, fieldDefine.getType(), fieldDefine.getLength());
  }

  protected String formatHead(DataMap dataMap, DataMap headDefine) throws Exception {
    StringBuffer msg = new StringBuffer();
    Iterator fieldIterator = headDefine.entrySet().iterator();
    while (fieldIterator.hasNext()) {
      Map.Entry fieldEntry = (Map.Entry)fieldIterator.next();
      DataElement dataElement = (DataElement)fieldEntry.getValue();
      formatElement(dataMap, dataElement, msg);
    }

    return msg.toString();
  }

  protected String formatBody(DataMap dataMap, DataMap bodyDefine) throws Exception {
    StringBuffer msg = new StringBuffer();
    Iterator fieldIterator = bodyDefine.entrySet().iterator();
    while (fieldIterator.hasNext()) {
      Map.Entry fieldEntry = (Map.Entry)fieldIterator.next();
      DataElement dataElement = (DataElement)fieldEntry.getValue();
      formatElement(dataMap, dataElement, msg);
    }

    return msg.toString();
  }

  private void formatElement(DataMap dataMap, DataElement defineElement, StringBuffer msg) throws Exception {
    String key;
    if (defineElement instanceof MsgField) {
      MsgField msgField = (MsgField)defineElement;
      key = msgField.getName();
      String value = msgField.getValue();
      String refName = msgField.getRefName();
      if (!(StringUtil.hasText(refName))) {
        refName = msgField.getName();
      }

      DataElement dataElement = dataMap.get(refName);
      if (null == dataElement)
        throw new Exception(refName + " is null!");
      if (!(dataElement instanceof DataField))
        throw new Exception(key + " is define field, here expect of DataField!");

      DataField dataField = (DataField)dataElement;
      if (null != dataField) {
        value = dataField.getValue();
      }

      buildFixLengthField(msg, key, value, msgField.getType(), msgField.getLength());
    } else if (defineElement instanceof DataMap) {
      DataMap listDefine = (DataMap)defineElement;
      if (null != listDefine) {
        key = listDefine.getName();
        DataElement listElement = dataMap.get(key);
        if (!(listElement instanceof DataList))
          throw new Exception(key + " is define list, here expect of DataList!");

        DataList dataList = (DataList)listElement;
        Object[] fieldDefineArray = listDefine.values().toArray();

        for (Iterator i$ = dataList.iterator(); i$.hasNext(); ) { DataElement rowElement = (DataElement)i$.next();
          if (rowElement instanceof DataMap) {
            DataMap rowMap = (DataMap)rowElement;
            Object[] arr$ = fieldDefineArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object defineObject = arr$[i$];
              formatElement(rowMap, (DataElement)defineObject, msg);
            }
          } else {
            throw new Exception("DataList rows expect of DataMap");
          }
        }
      }
    }
  }

  private void buildFixLengthField(StringBuffer str, String key, String text, String type, String length)
    throws Exception
  {
    int len;
    int textLen;
    int i;
    if (null == length) {
      throw new Exception("fixLengthProcessor error: " + key + "'s length is null");
    }

    if (type.equals("S")) {
      len = Integer.parseInt(length);
      textLen = StringUtil.getStringLen(text, this.encoding);
      for (i = 0; i < len - textLen; ++i)
        str.append(this.fillCharacter);

      label601: str.append(text);
    } else if (type.equals("SR")) {
      len = Integer.parseInt(length);
      textLen = StringUtil.getStringLen(text, this.encoding);
      str.append(text);
      for (i = 0; i < len - textLen; ++i)
        str.append(this.fillCharacter);
    } else {
      String[] lenArr;
      if (type.equals("F")) {
        lenArr = length.split(",");
        String[] textArr = text.split("\\.");

        if (lenArr.length == 2) {
          int len1 = Integer.parseInt(lenArr[0]);
          int len2 = Integer.parseInt(lenArr[1]);
          int textLen = textArr[0].length();

          for (int i = 0; i < len1 - len2 - textLen; ++i)
            str.append(this.fillCharacter);

          str.append(textArr[0]);

          if (textArr.length > 1) {
            int decLen = textArr[1].length();
            if (decLen == len2)
              str.append(textArr[1]);
            else if (decLen < len2)
              for (int i = 0; i < len2 - decLen; ++i)
                str.append(0);

            else
              str.append(textArr[1].substring(0, len2));
          }
          else {
            for (i = 0; i < len2; ++i)
              str.append(0);
          }
        }
        else {
          throw new Exception("fixLengthProcessor error: " + key + "'s type 'F' is not define 'x,x'");
        }
      } else if (type.equals("C")) {
        lenArr = length.split(",");
        if (lenArr.length == 2) {
          int len1 = Integer.parseInt(lenArr[0]);
          int len2 = Integer.parseInt(lenArr[1]);
          int textLen = StringUtil.getStringLen(text, this.encoding);
          int textLen2 = String.valueOf(textLen).length();
          if (textLen <= len2) {
            if (textLen2 <= len1) {
              str.append(textLen2).append(text); break label601:
            }
            throw new Exception("fixLengthProcessor error: " + key + "'s digits is bigger than define: " + textLen2 + ">" + len1);
          }

          throw new Exception("fixLengthProcessor error: " + key + "'s length is bigger than define: " + textLen + ">" + len2);
        }
        else if (lenArr.length == 1) {
          int len = Integer.parseInt(lenArr[0]);
          int textLen = StringUtil.getStringLen(text, this.encoding);
          int textLen2 = String.valueOf(textLen).length();
          if (textLen2 <= len)
            str.append(textLen2).append(text);
          else
            throw new Exception("fixLengthProcessor error: " + key + "'s length is bigger than define: " + textLen2 + ">" + len);
        }
        else {
          throw new Exception("fixLengthProcessor error: " + key + "'s type 'F' is not define 'x,x' or 'x'");
        }
      }
      else {
        len = Integer.parseInt(length);
        textLen = StringUtil.getStringLen(text, this.encoding);
        for (i = 0; i < len - textLen; ++i)
          str.append(this.fillCharacter);

        str.append(text); }
    }
  }

  public DataMap unformat(DataMap headMap, String recMsg, MessageDefine msgDefine) throws Exception {
    DataMap dataMap = new DataMap();

    return dataMap;
  }

  public void unformat(DataMap headMap, DataMap dataMap, String recMsg, MessageDefine msgDefine)
    throws Exception
  {
    Trace.log("FORMAT", 1, "unformat msg's:{}", new Object[] { recMsg });
    Iterator elementIter = msgDefine.getElementMap().entrySet().iterator();
    byte[] recMsgs = recMsg.getBytes(this.encoding);
    int beginIndex = 0;
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof MsgList)
      {
        DataList dataList = (DataList)dataMap.get(defineElement.getName());
        int listLen = ((MsgList)defineElement).getIntLength();
        while (true) { if (beginIndex >= recMsgs.length) return;

          if (beginIndex + listLen >= recMsgs.length)
            break;
          byte[] temps = new byte[listLen];
          System.arraycopy(recMsgs, beginIndex, temps, 0, listLen);
          if ("".equals(new String(temps, this.encoding).trim()))
          {
            Trace.log("FORMAT", 0, "list's value is null,unformatList end...");
            return;
          }
          DataMap datamap = dataList.createSubDataMap();
          beginIndex = unformatList(headMap, datamap, beginIndex, recMsgs, (MsgList)defineElement);
          dataList.add(datamap);
        }
        Trace.log("FORMAT", 0, "beginIndex + listLen < recMsgs.length,unformatList end...");
        return;
      }

      beginIndex = unformatField(headMap, dataMap, beginIndex, recMsgs, (MsgField)defineElement);
    }
  }

  public int unformatField(DataMap headMap, DataMap outDataMap, int beginIndex, byte[] msgs, MsgField fieldDefine) throws Exception
  {
    String key = fieldDefine.getName();
    byte[] temps = new byte[fieldDefine.getIntLength()];
    System.arraycopy(msgs, beginIndex, temps, 0, fieldDefine.getIntLength());
    String value = new String(temps, this.encoding);
    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      throw new Exception(fieldDefine.getName() + " is empty!");
    }

    String defaultValue = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (StringUtil.hasText(refName)) {
      key = refName;
    }

    if ((null != defaultValue) && (!(StringUtil.hasText(value))))
      value = defaultValue;

    value = (value == null) ? "" : value.trim();

    if ((null != fieldDefine.getPattern()) && (fieldDefine.getPattern().equalsIgnoreCase("head"))) {
      headMap.put(key, value);
    }
    else if (outDataMap.containsKey(key))
      outDataMap.setElementValue(key, value);
    else {
      outDataMap.put(key, value);
    }

    beginIndex += fieldDefine.getIntLength();
    return beginIndex;
  }

  public int unformatList(DataMap headMap, DataMap dataMap, int beginIndex, byte[] msgs, MsgList defineMap) throws Exception {
    Iterator defineIterator = defineMap.values().iterator();
    while (defineIterator.hasNext()) {
      DataElement defineElement = (DataElement)defineIterator.next();
      if (defineElement instanceof MsgList)
        beginIndex = unformatList(headMap, dataMap, beginIndex, msgs, (MsgList)defineElement);
      else
        beginIndex = unformatField(headMap, dataMap, beginIndex, msgs, (MsgField)defineElement);
    }

    return beginIndex;
  }

  protected void unformatHead(Object recMsg, DataMap headDefine, DataMap outDataMap) throws Exception {
    Element headElement = (Element)recMsg;
    List fieldList = headElement.elements();
    if (headDefine.size() > fieldList.size()) {
      throw new Exception("message head define field number is bigger than receive field!");
    }

    Iterator defineIterator = headDefine.values().iterator();
    int i = 0;
    while (defineIterator.hasNext()) {
      DataElement dataElement = (DataElement)defineIterator.next();
      unformatElement((Element)fieldList.get(i++), outDataMap, dataElement);
    }
  }

  protected void unformatBody(Object recMsg, DataMap bodyDefine, DataMap outDataMap) throws Exception {
    Element bodyElement = (Element)recMsg;
    List fieldList = bodyElement.elements();
    if (bodyDefine.size() > fieldList.size()) {
      throw new Exception("message head define field number is bigger than receive field!");
    }

    Iterator defineIterator = bodyDefine.values().iterator();
    int i = 0;
    while (defineIterator.hasNext()) {
      DataElement dataElement = (DataElement)defineIterator.next();
      unformatElement((Element)fieldList.get(i++), outDataMap, dataElement);
    }
  }

  private void unformatElement(Element element, DataMap outDataMap, DataElement define)
    throws Exception
  {
  }

  public String getFillCharacter()
  {
    return this.fillCharacter;
  }

  public void setFillCharacter(String fillCharacter) {
    this.fillCharacter = fillCharacter;
  }

  public int getMessageLengthHead() {
    return this.messageLengthHead;
  }

  public void setMessageLengthHead(int messageLengthHead) {
    this.messageLengthHead = messageLengthHead;
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }
}