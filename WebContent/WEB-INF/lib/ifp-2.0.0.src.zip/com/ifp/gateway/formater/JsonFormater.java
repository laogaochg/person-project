package com.ifp.gateway.formater;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import net.sf.json.JSONArray;
import net.sf.json.JSONNull;
import net.sf.json.JSONObject;

@Deprecated
public class JsonFormater extends AbstractJsonFormater
{
  public Object format(DataMap headMap, DataMap dataMap, MessageDefine msgDefine)
    throws Exception
  {
    StringBuffer msg = new StringBuffer();
    msg.append("{");

    Iterator elementIter = msgDefine.getElementMap().entrySet().iterator();
    int size = msgDefine.getElementMap().size();
    int index = 0;
    while (elementIter.hasNext()) {
      Map.Entry defineEntry = (Map.Entry)elementIter.next();
      String key = (String)defineEntry.getKey();
      DataElement defineElement = (DataElement)defineEntry.getValue();
      if (defineElement instanceof GroupMap) {
        msg.append("\"").append(key).append("\":{");
        formatGroup(msg, headMap, dataMap, (GroupMap)defineElement);
        ++index;
        if (index < size)
          msg.append("},");
        else
          msg.append("}");
      }
      else {
        formatElement(msg, headMap, dataMap, defineElement);
        ++index;
        if (index < size)
          msg.append(",");
      }

    }

    msg.append("}");
    return msg.toString();
  }

  public void formatGroup(StringBuffer msg, DataMap headMap, DataMap dataMap, GroupMap groupDefine) throws Exception
  {
    Iterator defineIterator = groupDefine.entrySet().iterator();
    int size = groupDefine.size();
    int index = 0;
    while (defineIterator.hasNext()) {
      Map.Entry defineEntry = (Map.Entry)defineIterator.next();
      String key = (String)defineEntry.getKey();
      DataElement defineElement = (DataElement)defineEntry.getValue();
      if (defineElement instanceof GroupMap) {
        msg.append("\"").append(key).append("\":{");
        formatGroup(msg, headMap, dataMap, (GroupMap)defineElement);
        ++index;
        if (index < size)
          msg.append("},");
        else
          msg.append("}");
      }
      else {
        formatElement(msg, headMap, dataMap, defineElement);
        ++index;
        if (index < size)
          msg.append(",");
      }
    }
  }

  public void formatElement(StringBuffer msg, DataMap headMap, DataMap dataMap, DataElement defineElement) throws Exception
  {
    if (defineElement instanceof MsgField) {
      formatField(msg, headMap, dataMap, (MsgField)defineElement);
    } else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null != listDefine) {
        String key = listDefine.getName();
        String refName = listDefine.getRefName();
        if (StringUtil.hasText(refName))
          key = refName;

        DataElement listElement = dataMap.get(key);
        if (null == listElement) {
          if (listDefine.isNeed())
            throw new Exception(listDefine.getName() + " is need!");

          return;
        }

        if (!(listElement instanceof DataList))
          throw new Exception(key + " is undefine list, here expect of DataList!");

        formatList(msg, headMap, (DataList)listElement, listDefine);
      }
    }
  }

  public void formatField(StringBuffer msg, DataMap headMap, DataMap dataMap, MsgField fieldDefine)
    throws Exception
  {
    DataElement dataElement;
    String key = fieldDefine.getName();
    String value = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (!(StringUtil.hasText(refName))) {
      refName = fieldDefine.getName();
    }

    if ((null != fieldDefine.getPattern()) && (fieldDefine.getPattern().equalsIgnoreCase("head")))
      dataElement = headMap.get(refName);
    else {
      dataElement = dataMap.get(refName);
    }

    if (null == dataElement) {
      if ((!(fieldDefine.isNeed())) || (StringUtil.hasText(value))) break label197;
      throw new Exception(fieldDefine.getName() + " is need!");
    }

    if (!(dataElement instanceof DataField)) {
      throw new Exception(key + " is define field, expect of DataField in context here!");
    }

    DataField dataField = (DataField)dataElement;
    if ((null != dataField) && (StringUtil.hasText(dataField.getValue()))) {
      value = dataField.getValue();
    }

    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      label197: throw new Exception(fieldDefine.getName() + " is empty!");
    }

    value = (value == null) ? "" : value;
    msg.append("\"").append(key).append("\":\"").append(StringUtil.formatJSONText(value)).append("\"");
  }

  public void formatList(StringBuffer msg, DataMap headMap, DataList<DataElement> dataList, MsgList listDefine) throws Exception
  {
    Object[] fieldDefineArray = listDefine.values().toArray();
    msg.append("\"").append(listDefine.getName()).append("\":[");
    int size = dataList.size();
    int index = 0;
    int c_index = 0;
    for (Iterator i$ = dataList.iterator(); i$.hasNext(); ) { DataElement rowElement = (DataElement)i$.next();
      c_index = 0;
      if (rowElement instanceof DataMap) {
        msg.append("{");
        DataMap rowMap = (DataMap)rowElement;
        Object[] arr$ = fieldDefineArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object defineObject = arr$[i$];
          int c_size = fieldDefineArray.length;
          formatElement(msg, headMap, rowMap, (DataElement)defineObject);
          ++c_index;
          if (c_index < c_size)
            msg.append(",");
        }

        ++index;
        if (index < size)
          msg.append("},");
        else
          msg.append("}");
      }
      else {
        throw new Exception("DataList rows expect of DataMap");
      }
    }
    msg.append("]");
  }

  public void unformat(DataMap headMap, DataMap dataMap, String recMsg, MessageDefine msgDefine) throws Exception
  {
    JSONObject jsonObject = JSONObject.fromObject(recMsg);

    Iterator elementIter = msgDefine.getElementMap().entrySet().iterator();
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      String key = (String)elementEntry.getKey();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof GroupMap) {
        GroupMap defineGroup = (GroupMap)defineElement;
        JSONObject groupObject = jsonObject.getJSONObject(key);
        String type = defineGroup.getType();
        if ((null != type) && (type.equals("head")))
          unformatGroup(headMap, headMap, groupObject, defineGroup);
        else
          unformatGroup(headMap, dataMap, groupObject, defineGroup);
      }
      else {
        unformatElement(headMap, dataMap, jsonObject.get(defineElement.getName()), defineElement);
      }
    }
  }

  public void unformatGroup(DataMap headMap, DataMap outDataMap, JSONObject groupObject, GroupMap defineMap) throws Exception
  {
    if (groupObject.isNullObject()) {
      if (defineMap.isNeed())
        throw new Exception(defineMap.getName() + " is need!");

      return;
    }

    Iterator defineIterator = defineMap.values().iterator();
    while (defineIterator.hasNext()) {
      DataElement defineElement = (DataElement)defineIterator.next();
      if (defineElement instanceof GroupMap)
        unformatGroup(headMap, outDataMap, groupObject.getJSONObject(defineElement.getName()), (GroupMap)defineElement);
      else
        unformatElement(headMap, outDataMap, groupObject.get(defineElement.getName()), defineElement);
    }
  }

  private void unformatElement(DataMap headMap, DataMap outDataMap, Object object, DataElement defineElement) throws Exception
  {
    if (defineElement instanceof MsgField) {
      MsgField msgField = (MsgField)defineElement;
      if (null == object) {
        if (msgField.isNeed())
          throw new Exception(defineElement.getName() + " is need!");

        return;
      }

      if ((object instanceof JSONNull) || (object.toString().trim().equals("null")))
        unformatField(headMap, outDataMap, "", msgField);
      else {
        unformatField(headMap, outDataMap, object.toString(), msgField);
      }

    }
    else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null == object) {
        if (listDefine.isNeed())
          throw new Exception(defineElement.getName() + " is need!");

        return;
      }

      if (object instanceof JSONArray)
        unformatList(headMap, outDataMap, (JSONArray)object, listDefine);
      else if ((object instanceof JSONNull) || (object.toString().trim().equals("null")))
        unformatList(headMap, outDataMap, new JSONArray(), listDefine);
      else
        throw new Exception("message define " + defineElement.getName() + ", expect for a list!");
    }
  }

  public void unformatField(DataMap headMap, DataMap outDataMap, String jsonValue, MsgField fieldDefine)
    throws Exception
  {
    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(jsonValue)))) {
      throw new Exception(fieldDefine.getName() + " is empty!");
    }

    String key = fieldDefine.getName();
    String value = jsonValue;
    String defaultValue = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (StringUtil.hasText(refName)) {
      key = refName;
    }

    if ((null != defaultValue) && (!(StringUtil.hasText(value)))) {
      value = defaultValue;
    }

    value = (value == null) ? "" : value;
    if ((null != fieldDefine.getPattern()) && (fieldDefine.getPattern().equalsIgnoreCase("head"))) {
      headMap.put(key, value);
    }
    else if (outDataMap.containsKey(key))
      outDataMap.setElementValue(key, value);
    else
      outDataMap.put(key, value);
  }

  public void unformatList(DataMap headMap, DataMap outDataMap, JSONArray jsonArray, MsgList listDefine)
    throws Exception
  {
    DataList dList;
    Object[] fieldDefineArray = listDefine.values().toArray();
    String key = listDefine.getName();
    String refName = listDefine.getRefName();
    if (StringUtil.hasText(refName)) {
      key = refName;
    }

    if (outDataMap.containsKey(key)) {
      DataElement outElement = outDataMap.get(key);
      if (outElement instanceof DataList)
        dList = (DataList)outElement;
      else
        throw new Exception(key + " is define list, expect of DataList in context here!");
    }
    else {
      dList = new DataList();
      dList.setDefineMap((DataMap)outDataMap.getDefineMap().get(key));
    }

    for (int j = 0; j < jsonArray.size(); ++j) {
      DataMap dMap = dList.createSubDataMap();
      JSONObject jObject = jsonArray.getJSONObject(j);
      for (int i = 0; i < fieldDefineArray.length; ++i) {
        DataElement defineElement = (DataElement)fieldDefineArray[i];
        unformatElement(headMap, dMap, jObject.get(defineElement.getName()), defineElement);
      }
      dList.add(dMap);
    }

    outDataMap.put(key, dList);
  }
}