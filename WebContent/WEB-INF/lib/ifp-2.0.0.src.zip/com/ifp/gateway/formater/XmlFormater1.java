package com.ifp.gateway.formater;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import org.dom4j.Element;
import org.dom4j.Node;

@Deprecated
public class XmlFormater1 extends AbstractXmlFormater
{
  public void formatGroup(StringBuffer msg, DataMap headMap, DataMap dataMap, GroupMap groupDefine)
    throws Exception
  {
    Iterator defineIterator = groupDefine.entrySet().iterator();
    while (defineIterator.hasNext()) {
      Map.Entry defineEntry = (Map.Entry)defineIterator.next();
      String key = (String)defineEntry.getKey();
      DataElement defineElement = (DataElement)defineEntry.getValue();
      if (defineElement instanceof GroupMap) {
        msg.append("<").append(key).append(">");
        formatGroup(msg, headMap, dataMap, (GroupMap)defineElement);
        msg.append("</").append(key).append(">");
      } else {
        formatElement(msg, headMap, dataMap, defineElement);
      }
    }
  }

  public void formatElement(StringBuffer msg, DataMap headMap, DataMap dataMap, DataElement defineElement) throws Exception
  {
    if (defineElement instanceof MsgField) {
      formatField(msg, headMap, dataMap, (MsgField)defineElement);
    } else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null != listDefine) {
        String key = listDefine.getName();
        String refName = listDefine.getRefName();
        if (StringUtil.hasText(refName))
          key = refName;

        DataElement listElement = dataMap.get(key);
        if (null == listElement) {
          if (listDefine.isNeed())
            throw new Exception(listDefine.getName() + " is need!");

          return;
        }

        if (!(listElement instanceof DataList))
          throw new Exception(key + " is undefine list, here expect of DataList!");

        formatList(msg, headMap, (DataList)listElement, listDefine);
      }
    }
  }

  public void formatField(StringBuffer msg, DataMap headMap, DataMap dataMap, MsgField fieldDefine)
    throws Exception
  {
    DataElement dataElement;
    String key = fieldDefine.getName();
    String value = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (!(StringUtil.hasText(refName))) {
      refName = fieldDefine.getName();
    }

    if ((null != fieldDefine.getPattern()) && (fieldDefine.getPattern().equalsIgnoreCase("head")))
      dataElement = headMap.get(refName);
    else
      dataElement = dataMap.get(refName);

    if (null == dataElement) {
      if ((!(fieldDefine.isNeed())) || (StringUtil.hasText(value))) break label197;
      throw new Exception(fieldDefine.getName() + " is need!");
    }

    if (!(dataElement instanceof DataField)) {
      throw new Exception(key + " is define field, expect of DataField in context here!");
    }

    DataField dataField = (DataField)dataElement;
    if ((null != dataField) && (StringUtil.hasText(dataField.getValue()))) {
      value = dataField.getValue();
    }

    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      label197: throw new Exception(fieldDefine.getName() + " is empty!");
    }

    value = (value == null) ? "" : value;
    msg.append("<").append(key).append(">").append(value).append("</").append(key).append(">");
  }

  public void formatList(StringBuffer msg, DataMap headMap, DataList<DataElement> dataList, MsgList listDefine) throws Exception
  {
    Object[] fieldDefineArray = listDefine.values().toArray();
    for (Iterator i$ = dataList.iterator(); i$.hasNext(); ) { DataElement rowElement = (DataElement)i$.next();
      msg.append("<").append(listDefine.getName()).append(">");
      if (rowElement instanceof DataMap) {
        DataMap rowMap = (DataMap)rowElement;
        Object[] arr$ = fieldDefineArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object defineObject = arr$[i$];
          formatElement(msg, headMap, rowMap, (DataElement)defineObject);
        }
      } else {
        throw new Exception("DataList rows expect of DataMap");
      }
      msg.append("</").append(listDefine.getName()).append(">");
    }
  }

  public void unformatGroup(DataMap headMap, DataMap outDataMap, Node node, GroupMap defineMap) throws Exception
  {
    Element element = (Element)node;
    if (null == element) {
      if (defineMap.isNeed())
        throw new Exception(defineMap.getName() + " is need!");

      return;
    }

    Iterator defineIterator = defineMap.values().iterator();
    while (defineIterator.hasNext()) {
      DataElement defineElement = (DataElement)defineIterator.next();
      if (defineElement instanceof GroupMap) {
        List dataList = element.elements(defineElement.getName());
        for (int j = 0; j < dataList.size(); ++j)
          unformatGroup(headMap, outDataMap, (Node)dataList.get(j), (GroupMap)defineElement);
      }
      else {
        unformatElement(headMap, outDataMap, element, defineElement);
      }
    }
  }

  public void unformatElement(DataMap headMap, DataMap outDataMap, Node parentNode, DataElement defineElement) throws Exception
  {
    Element parentElement = (Element)parentNode;
    if (null == parentElement) {
      throw new Exception(defineElement.getName() + " is null!");
    }

    if (defineElement instanceof MsgField) {
      MsgField msgField = (MsgField)defineElement;
      Element fieldElement = parentElement.element(defineElement.getName());
      if (null == fieldElement) {
        if (msgField.isNeed()) {
          throw new Exception(defineElement.getName() + " is need!");
        }

        if ((null != msgField.getPattern()) && (msgField.getPattern().equalsIgnoreCase("head")))
          headMap.put(msgField.getRefName(), "");
        else
          outDataMap.put(msgField.getRefName(), "");

        return;
      }

      unformatField(headMap, outDataMap, fieldElement, msgField);
    } else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null != listDefine) {
        List dataList = parentElement.elements(defineElement.getName());
        if ((null == dataList) || (dataList.size() == 0)) {
          if (listDefine.isNeed())
            throw new Exception(defineElement.getName() + " is need!");

          return;
        }

        for (int j = 0; j < dataList.size(); ++j)
          unformatList(headMap, outDataMap, (Node)dataList.get(j), listDefine);
      }
    }
  }

  public void unformatField(DataMap headMap, DataMap outDataMap, Node node, MsgField fieldDefine)
    throws Exception
  {
    String key = node.getName();
    String value = node.getText().trim();
    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      throw new Exception(fieldDefine.getName() + " is empty!");
    }

    String defaultValue = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (StringUtil.hasText(refName)) {
      key = refName;
    }

    if ((null != defaultValue) && (!(StringUtil.hasText(value)))) {
      value = defaultValue;
    }

    value = (value == null) ? "" : value;
    if ((null != fieldDefine.getPattern()) && (fieldDefine.getPattern().equalsIgnoreCase("head"))) {
      headMap.put(key, value);
    }
    else if (outDataMap.containsKey(key))
      outDataMap.setElementValue(key, value);
    else
      outDataMap.put(key, value);
  }

  public void unformatList(DataMap headMap, DataMap outDataMap, Node node, MsgList listDefine)
    throws Exception
  {
    DataList dList;
    Object[] fieldDefineArray = listDefine.values().toArray();
    String key = listDefine.getName();
    String refName = listDefine.getRefName();
    if (StringUtil.hasText(refName)) {
      key = refName;
    }

    if (outDataMap.containsKey(key)) {
      DataElement outElement = outDataMap.get(key);
      if (outElement instanceof DataList)
        dList = (DataList)outElement;
      else
        throw new Exception(key + " is define list, expect of DataList in context here!");
    }
    else {
      dList = new DataList();
      dList.setDefineMap((DataMap)outDataMap.getDefineMap().get(key));
    }

    Element element = (Element)node;
    if (element.elements().size() > 0) {
      DataMap dMap = dList.createSubDataMap();
      for (int i = 0; i < fieldDefineArray.length; ++i)
        unformatElement(headMap, dMap, node, (DataElement)fieldDefineArray[i]);

      dList.add(dMap);
    }

    outDataMap.put(key, dList);
  }
}