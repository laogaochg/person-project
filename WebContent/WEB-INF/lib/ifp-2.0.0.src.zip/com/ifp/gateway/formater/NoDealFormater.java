package com.ifp.gateway.formater;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataMap;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

@Deprecated
public class NoDealFormater
  implements IFormater
{
  public void unformat(DataMap headMap, DataMap dataMap, String recMsg, MessageDefine msgDefine)
    throws Exception
  {
    Iterator elementIter;
    Map.Entry elementEntry;
    String key;
    DataElement defineElement;
    GroupMap defineGroup;
    Trace.logDebug("FORMAT", "return direct XML unformat MSG :", new Object[] { recMsg });
    try {
      Document document = DocumentHelper.parseText(recMsg);
      Element rootElement = document.getRootElement();
      elementIter = msgDefine.getElementMap().entrySet().iterator();
      while (elementIter.hasNext()) {
        elementEntry = (Map.Entry)elementIter.next();
        key = (String)elementEntry.getKey();
        defineElement = (DataElement)elementEntry.getValue();
        Element element = rootElement.element(key);
        if (defineElement instanceof GroupMap) {
          defineGroup = (GroupMap)defineElement;
          unformatXmlGroup(dataMap, element, defineGroup);
        } else {
          MsgField msgField = (MsgField)defineElement;
          String pattern = msgField.getPattern();
          if ((StringUtil.hasText(pattern)) && (pattern.equalsIgnoreCase("head"))) {
            unformatXmlHead(dataMap, rootElement, msgField);
          } else {
            String retMsg = element2xmlString(rootElement);
            dataMap.put(msgField.getRefName(), retMsg);
          }
        }
      }
    } catch (DocumentException e) {
      try {
        JSONObject rootObject = JSONObject.fromObject(recMsg);
        elementIter = msgDefine.getElementMap().entrySet().iterator();
        while (elementIter.hasNext()) {
          elementEntry = (Map.Entry)elementIter.next();
          key = (String)elementEntry.getKey();
          defineElement = (DataElement)elementEntry.getValue();
          JSONObject groupObject = rootObject.getJSONObject(key);
          if (defineElement instanceof GroupMap) {
            defineGroup = (GroupMap)defineElement;
            unformatJsonGroup(dataMap, groupObject, defineGroup);
          } else {
            unformatJsonFiled(dataMap, rootObject, defineElement);
          }
        }
      } catch (JSONException je) {
        Trace.log("ADAPTER", 3, "NoDealFormater unformat error :", new Object[] { "返回报文格式错误。" });
      }
    }
  }

  protected void unformatJsonGroup(DataMap dataMap, JSONObject groupObject, GroupMap groupDefine) throws Exception {
    Iterator defineIterator = groupDefine.entrySet().iterator();
    int size = groupDefine.size();
    int index = 0;
    while (defineIterator.hasNext()) {
      Map.Entry defineEntry = (Map.Entry)defineIterator.next();
      DataElement defineElement = (DataElement)defineEntry.getValue();
      if (defineElement instanceof GroupMap)
        unformatJsonGroup(dataMap, groupObject, groupDefine);
      else
        unformatJsonFiled(dataMap, groupObject, defineElement);
    }
  }

  protected void unformatJsonFiled(DataMap dataMap, JSONObject groupObject, DataElement defineElement) throws Exception
  {
    MsgField msgField = (MsgField)defineElement;
    String pattern = msgField.getPattern();
    if ((StringUtil.hasText(pattern)) && (pattern.equalsIgnoreCase("head"))) {
      Object obj = groupObject.get(msgField.getName());
      if (null == obj) {
        if (msgField.isNeed())
          throw new Exception(msgField.getName() + " is need!");

        return;
      }

      String value = "";
      if (obj instanceof String)
        value = String.valueOf(obj);
      else
        try {
          obj = obj + "";
        }
        catch (Exception e)
        {
        }
      if ((!(msgField.isEmpty())) && (!(StringUtil.hasText(value))))
        throw new Exception(msgField.getName() + " is empty!");

      String key = msgField.getName();
      String defaultValue = msgField.getValue();
      String refName = msgField.getRefName();
      if (StringUtil.hasText(refName))
        key = refName;

      if ((null != defaultValue) && (!(StringUtil.hasText(value))))
        value = defaultValue;

      if (dataMap.containsKey(key))
        dataMap.setElementValue(key, value);
      else
        dataMap.put(key, value);
    }
    else
    {
      if (null == groupObject) {
        if (msgField.isNeed())
          throw new Exception(msgField.getName() + " is need!");

        return;
      }

      String retMsg = json2xmlString(groupObject);
      dataMap.put(msgField.getRefName(), retMsg);
    }
  }

  protected String json2xmlString(JSONObject groupObject)
  {
    StringBuffer sb = new StringBuffer();
    Set keySet = groupObject.keySet();
    for (Iterator i$ = keySet.iterator(); i$.hasNext(); ) { String key = (String)i$.next();
      try {
        JSONObject jsonObject = groupObject.getJSONObject(key);
        sb.append("<").append(key).append(">");
        sb.append(json2xmlString(jsonObject));
        sb.append("</").append(key).append(">");
      } catch (JSONException e) {
        try {
          JSONArray jsonArray = groupObject.getJSONArray(key);
          sb.append(json2xmlList(jsonArray, key));
        } catch (JSONException e2) {
          sb.append("<").append(key).append(">");
          sb.append(String.valueOf(groupObject.get(key)));
          sb.append("</").append(key).append(">");
        }
      }
    }
    return sb.toString();
  }

  protected String json2xmlList(JSONArray jsonArray, String ListKey)
  {
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < jsonArray.size(); ++i) {
      JSONObject jsonObject = (JSONObject)jsonArray.get(i);
      Set keySet = jsonObject.keySet();
      sb.append("<").append(ListKey).append(">");
      for (Iterator i$ = keySet.iterator(); i$.hasNext(); ) { String key = (String)i$.next();
        sb.append("<").append(key).append(">");
        sb.append(String.valueOf(jsonObject.get(key)));
        sb.append("</").append(key).append(">");
      }
      sb.append("</").append(ListKey).append(">");
    }
    return sb.toString();
  }

  protected void unformatXmlGroup(DataMap outDataMap, Element element, GroupMap defineMap) throws Exception {
    if (null == element) {
      if (defineMap.isNeed())
        throw new Exception(defineMap.getName() + " is need!");

      return;
    }

    Iterator defineIterator = defineMap.values().iterator();
    while (defineIterator.hasNext()) {
      DataElement defineElement = (DataElement)defineIterator.next();
      if (defineElement instanceof GroupMap) {
        List dataList = element.elements(defineElement.getName());
        for (int j = 0; j < dataList.size(); ++j)
          unformatXmlGroup(outDataMap, (Element)dataList.get(j), (GroupMap)defineElement);
      }
      else {
        MsgField msgField = (MsgField)defineElement;
        String pattern = msgField.getPattern();
        if ((StringUtil.hasText(pattern)) && (pattern.equalsIgnoreCase("head"))) {
          unformatXmlHead(outDataMap, element, msgField);
        } else {
          String retMsg = element2xmlString(element);
          outDataMap.put(msgField.getRefName(), retMsg);
        }
      }
    }
  }

  protected String element2xmlString(Element element)
  {
    StringBuffer sb = new StringBuffer();
    sb.append("<").append(element.getName()).append(">");
    List arrList = element.attributes();
    for (Iterator i$ = arrList.iterator(); i$.hasNext(); ) { Attribute atrr = (Attribute)i$.next();
      sb.append("<").append(atrr.getName()).append(">").append(atrr.getValue()).append("</").append(atrr.getName()).append(">");
    }

    List elist = element.elements();
    for (Iterator i$ = elist.iterator(); i$.hasNext(); ) { Element e = (Element)i$.next();
      sb.append(element2xmlString(e));
    }
    sb.append(element.getTextTrim());
    sb.append("</").append(element.getName()).append(">");
    return sb.toString();
  }

  protected void unformatXmlHead(DataMap outDataMap, Element element, MsgField msgField) throws Exception {
    unformatElement(outDataMap, element, msgField); }

  private void unformatElement(DataMap outDataMap, Element parentElement, DataElement defineElement) throws Exception {
    if (null == parentElement) {
      throw new Exception(defineElement.getName() + " is null!");
    }

    if (defineElement instanceof MsgField) {
      MsgField msgField = (MsgField)defineElement;
      Element fieldElement = parentElement.element(defineElement.getName());
      if (null == fieldElement) {
        List arrArray = parentElement.attributes();
        String value = null;
        for (Iterator i$ = arrArray.iterator(); i$.hasNext(); ) { Attribute attr = (Attribute)i$.next();
          if (msgField.getName().equals(attr.getName())) {
            value = attr.getValue();
            break;
          }
        }
        if (StringUtil.hasText(value)) {
          outDataMap.put(msgField.getRefName(), value);
          return;
        }

        if (msgField.isNeed())
          throw new Exception(defineElement.getName() + " is need!");

        return;
      }

      unformatField(outDataMap, fieldElement, msgField);
    }
  }

  protected void unformatField(DataMap outDataMap, Element element, MsgField fieldDefine) throws Exception {
    String key = element.getName();
    String value = element.getTextTrim();
    if ((!(fieldDefine.isEmpty())) && (!(StringUtil.hasText(value)))) {
      throw new Exception(fieldDefine.getName() + " is empty!");
    }

    String defaultValue = fieldDefine.getValue();
    String refName = fieldDefine.getRefName();
    if (StringUtil.hasText(refName)) {
      key = refName;
    }

    if ((null != defaultValue) && (!(StringUtil.hasText(value))))
      value = defaultValue;

    outDataMap.put(key, value);
  }

  public DataMap unformat(DataMap headMap, String recMsg, MessageDefine msgDefine) throws Exception {
    return null; }

  public String format(DataMap headMap, DataMap dataMap, MessageDefine msgDefine) throws Exception {
    return null;
  }
}