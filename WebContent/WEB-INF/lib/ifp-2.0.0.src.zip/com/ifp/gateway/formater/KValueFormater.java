package com.ifp.gateway.formater;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.dom4j.Element;

@Deprecated
public class KValueFormater extends AbstractKValueFormater
{
  protected String encoding;

  public KValueFormater()
  {
    this.encoding = "UTF-8";
  }

  public String format(DataMap headMap, DataMap dataMap, MessageDefine msgDefine)
    throws Exception
  {
    StringBuffer msg = new StringBuffer();
    Iterator elementIter = msgDefine.getElementMap().entrySet().iterator();
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      String key = (String)elementEntry.getKey();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof GroupMap) {
        GroupMap defineGroup = (GroupMap)defineElement;
        formatGroup(msg, headMap, dataMap, defineGroup);
      }
      else {
        formatElement(msg, headMap, dataMap, defineElement);
      }
    }
    return msg.toString().substring(1);
  }

  protected void formatGroup(StringBuffer msg, DataMap headMap, DataMap dataMap, GroupMap groupDefine) throws Exception
  {
    Iterator defineIterator = groupDefine.entrySet().iterator();
    while (defineIterator.hasNext()) {
      Map.Entry defineEntry = (Map.Entry)defineIterator.next();
      DataElement defineElement = (DataElement)defineEntry.getValue();
      if (defineElement instanceof GroupMap)
        formatGroup(msg, headMap, dataMap, (GroupMap)defineElement);
      else
        formatElement(msg, headMap, dataMap, defineElement);
    }
  }

  protected void formatElement(StringBuffer msg, DataMap headMap, DataMap dataMap, DataElement defineElement) throws Exception {
    if (defineElement instanceof MsgField) {
      formatField(msg, headMap, dataMap, (MsgField)defineElement);
    } else if (defineElement instanceof MsgList) {
      MsgList listDefine = (MsgList)defineElement;
      if (null != listDefine) {
        String key = listDefine.getName();
        String refName = listDefine.getRefName();
        if (StringUtil.hasText(refName))
          key = refName;

        DataElement listElement = dataMap.get(key);
        if (null == listElement) {
          if (listDefine.isNeed())
            throw new Exception(listDefine.getName() + " is need!");

          return;
        }

        if (!(listElement instanceof DataList))
          throw new Exception(key + " is undefine list, here expect of DataList!");

        formatList(msg, headMap, (DataList)listElement, listDefine);
      }
    }
  }

  protected void formatField(StringBuffer repMsg, DataMap headMap, DataMap dataMap, MsgField fieldDefine)
    throws Exception
  {
    String name = fieldDefine.getName();
    String key = fieldDefine.getRefName();
    key = (StringUtil.hasText(key)) ? key : name;
    Object value = dataMap.get(key);
    repMsg.append("&").append(name).append("=");
    if (!(value instanceof String))
      value = dataMap.getElementValue(key);

    if ((!(StringUtil.hasText(value))) && (StringUtil.hasText(fieldDefine.getValue())))
      value = fieldDefine.getValue();

    repMsg.append(URLEncoder.encode((String)value, this.encoding));
  }

  protected void formatList(StringBuffer repMsg, DataMap headMap, DataList<DataElement> dataList, MsgList listDefine)
    throws Exception
  {
    String listName = listDefine.getName();
    for (int i = 0; i < dataList.size(); ++i)
      if (dataList.get(i) instanceof Map) {
        Map dataMap = (Map)dataList.get(i);
        for (Iterator i$ = dataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
          if (entry.getValue() instanceof List)
            repMsg.append(listToKValueStr((List)entry.getValue(), listName + "." + ((String)entry.getKey()) + "[" + i + "]"));
          else
            repMsg.append("&").append(listName).append(".").append((String)entry.getKey()).append("[").append(i).append("]").append("=");
        }
      }
  }

  private String listToKValueStr(List dataList, String listName)
  {
    if (null == dataList) {
      return "";
    }

    StringBuffer repMsg = new StringBuffer();
    for (int i = 0; i < dataList.size(); ++i)
      if (dataList.get(i) instanceof Map) {
        Map dataMap = (Map)dataList.get(i);
        for (Iterator i$ = dataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
          if (entry.getValue() instanceof List)
            repMsg.append(listToKValueStr((List)entry.getValue(), listName + "." + ((String)entry.getKey()) + "[" + i + "]"));
          else
            repMsg.append("&").append(listName).append(".").append((String)entry.getKey()).append("[").append(i).append("]").append("=");
        }
      }


    return repMsg.toString();
  }

  protected void unformatGroup(DataMap headMap, DataMap outDataMap, Element element, GroupMap defineMap)
    throws Exception
  {
  }

  protected void unformatField(DataMap headMap, DataMap outDataMap, Element element, MsgField fieldDefine)
    throws Exception
  {
  }

  protected void unformatList(DataMap headMap, DataMap outDataMap, Element element, MsgList listDefine)
    throws Exception
  {
  }

  public String getEncoding()
  {
    return this.encoding; }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }
}