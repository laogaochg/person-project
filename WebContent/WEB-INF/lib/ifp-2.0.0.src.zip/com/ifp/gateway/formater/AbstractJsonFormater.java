package com.ifp.gateway.formater;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Deprecated
public abstract class AbstractJsonFormater
  implements IFormater
{
  public abstract Object format(DataMap paramDataMap1, DataMap paramDataMap2, MessageDefine paramMessageDefine)
    throws Exception;

  public abstract void formatGroup(StringBuffer paramStringBuffer, DataMap paramDataMap1, DataMap paramDataMap2, GroupMap paramGroupMap)
    throws Exception;

  public abstract void formatField(StringBuffer paramStringBuffer, DataMap paramDataMap1, DataMap paramDataMap2, MsgField paramMsgField)
    throws Exception;

  public abstract void formatList(StringBuffer paramStringBuffer, DataMap paramDataMap, DataList<DataElement> paramDataList, MsgList paramMsgList)
    throws Exception;

  public DataMap unformat(DataMap headMap, String recMsg, MessageDefine msgDefine)
    throws Exception
  {
    DataMap dataMap = new DataMap();
    unformat(headMap, dataMap, recMsg, msgDefine);
    return dataMap;
  }

  public abstract void unformat(DataMap paramDataMap1, DataMap paramDataMap2, String paramString, MessageDefine paramMessageDefine)
    throws Exception;

  public abstract void unformatGroup(DataMap paramDataMap1, DataMap paramDataMap2, JSONObject paramJSONObject, GroupMap paramGroupMap)
    throws Exception;

  public abstract void unformatField(DataMap paramDataMap1, DataMap paramDataMap2, String paramString, MsgField paramMsgField)
    throws Exception;

  public abstract void unformatList(DataMap paramDataMap1, DataMap paramDataMap2, JSONArray paramJSONArray, MsgList paramMsgList)
    throws Exception;
}