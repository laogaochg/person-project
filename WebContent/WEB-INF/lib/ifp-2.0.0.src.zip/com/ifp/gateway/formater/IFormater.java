package com.ifp.gateway.formater;

import com.ifp.core.data.DataMap;
import com.ifp.gateway.formatter.IFormatter;

@Deprecated
public abstract interface IFormater extends IFormatter<DataMap>
{
}