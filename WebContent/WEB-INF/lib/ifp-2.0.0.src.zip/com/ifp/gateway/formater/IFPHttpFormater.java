package com.ifp.gateway.formater;

import com.ifp.adapter.process.Processor;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataMap;
import com.ifp.core.flow.logic.BusinessLogic;
import com.ifp.core.flow.util.ContextMapChangeUtil;
import com.ifp.core.util.DataMapChangeUtil;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.gateway.bean.MessageDefine;
import java.util.HashMap;
import java.util.Map;

@Deprecated
public class IFPHttpFormater
  implements IFormater
{
  private Processor formatProcessor;
  private Processor unformatProcessor;
  private String encoding;
  private IFormater format;

  public IFPHttpFormater()
  {
    this.encoding = "UTF-8";
  }

  public Object format(DataMap headMap, DataMap dataMap, MessageDefine msgDefine)
    throws Exception
  {
    if (msgDefine == null)
    {
      String logicCode = headMap.getElementValue("LogicCode");
      BusinessLogic businessLogic = (BusinessLogic)SpringContextsUtil.getBean(logicCode);
      Map formatMap = new HashMap();

      Map reqHeadMap = new HashMap();
      DataMapChangeUtil.dataMapToMap(headMap, reqHeadMap);
      formatMap.put("header", reqHeadMap);

      Map reqbodyMap = ContextMapChangeUtil.dataMap2Map(dataMap, null, businessLogic.inputParamsList, true);
      formatMap.put("body", reqbodyMap);
      return this.formatProcessor.format(formatMap);
    }

    return getFormat().format(headMap, dataMap, msgDefine);
  }

  public DataMap unformat(DataMap headMap, String recMsg, MessageDefine msgDefine) throws Exception
  {
    DataMap dataMap = new DataMap();
    return dataMap;
  }

  public void unformat(DataMap headMap, DataMap dataMap, String recMsg, MessageDefine msgDefine) throws Exception {
    Map unformatMap = this.unformatProcessor.unformat(recMsg);
    Map bodyMap = (Map)unformatMap.get("body");

    if (msgDefine == null)
    {
      String logicCode = headMap.getElementValue("LogicCode");
      BusinessLogic businessLogic = (BusinessLogic)SpringContextsUtil.getBean(logicCode);
      ContextMapChangeUtil.copyDataMap(bodyMap, dataMap, businessLogic.outputParamsList);
      DataElement errorCode = dataMap.get("errorCode");
      if (errorCode != null)
      {
        ((DataField)errorCode).setValue(String.valueOf(bodyMap.get("errorCode")));
      }
      DataElement errorMsg = dataMap.get("errorMsg");
      if (errorMsg != null)
      {
        ((DataField)errorMsg).setValue(String.valueOf(bodyMap.get("errorMsg")));
      }
    }
    else {
      getFormat().unformat(headMap, dataMap, recMsg, msgDefine);
    }
  }

  public String getEncoding() {
    return this.encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public Processor getFormatProcessor() {
    return this.formatProcessor;
  }

  public void setFormatProcessor(Processor formatProcessor) {
    this.formatProcessor = formatProcessor;
  }

  public Processor getUnformatProcessor() {
    return this.unformatProcessor;
  }

  public void setUnformatProcessor(Processor unformatProcessor) {
    this.unformatProcessor = unformatProcessor;
  }

  public IFormater getFormat() {
    return this.format;
  }

  public void setFormat(IFormater format) {
    this.format = format;
  }
}