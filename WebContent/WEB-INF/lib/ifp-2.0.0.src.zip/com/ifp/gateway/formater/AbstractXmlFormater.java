package com.ifp.gateway.formater;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;

@Deprecated
public abstract class AbstractXmlFormater
  implements IFormater
{
  private String title;

  public AbstractXmlFormater()
  {
    this.title = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
  }

  public Object format(DataMap headMap, DataMap dataMap, MessageDefine msgDefine)
    throws Exception
  {
    StringBuffer msg = new StringBuffer(getTitle());
    msg.append("<").append(msgDefine.getName()).append(">");

    Iterator elementIter = msgDefine.getElementMap().entrySet().iterator();
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      String key = (String)elementEntry.getKey();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof GroupMap) {
        msg.append("<").append(key).append(">");
        formatGroup(msg, headMap, dataMap, (GroupMap)defineElement);
        msg.append("</").append(key).append(">");
      } else {
        formatElement(msg, headMap, dataMap, defineElement);
      }
    }

    msg.append("</").append(msgDefine.getName()).append(">");

    return msg.toString();
  }

  public abstract void formatElement(StringBuffer paramStringBuffer, DataMap paramDataMap1, DataMap paramDataMap2, DataElement paramDataElement)
    throws Exception;

  public abstract void formatGroup(StringBuffer paramStringBuffer, DataMap paramDataMap1, DataMap paramDataMap2, GroupMap paramGroupMap)
    throws Exception;

  public abstract void formatField(StringBuffer paramStringBuffer, DataMap paramDataMap1, DataMap paramDataMap2, MsgField paramMsgField)
    throws Exception;

  public abstract void formatList(StringBuffer paramStringBuffer, DataMap paramDataMap, DataList<DataElement> paramDataList, MsgList paramMsgList)
    throws Exception;

  public DataMap unformat(DataMap headMap, String recMsg, MessageDefine msgDefine)
    throws Exception
  {
    DataMap dataMap = new DataMap();
    unformat(headMap, dataMap, recMsg, msgDefine);
    return dataMap;
  }

  public void unformat(DataMap headMap, DataMap dataMap, String recMsg, MessageDefine msgDefine)
    throws Exception
  {
    Document document = DocumentHelper.parseText(recMsg);
    Element rootElement = document.getRootElement();

    Iterator elementIter = msgDefine.getElementMap().entrySet().iterator();
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      String key = (String)elementEntry.getKey();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof GroupMap) {
        Element element = rootElement.element(key);
        GroupMap defineGroup = (GroupMap)defineElement;
        String type = defineGroup.getType();
        if ((null != type) && (type.equals("head")))
          unformatGroup(headMap, headMap, element, defineGroup);
        else
          unformatGroup(headMap, dataMap, element, defineGroup);
      }
      else {
        unformatElement(headMap, dataMap, rootElement, defineElement);
      }
    }
  }

  public void unformatGroup(DataMap headMap, DataMap outDataMap, Node node, GroupMap defineMap)
    throws Exception
  {
  }

  public void unformatElement(DataMap headMap, DataMap outDataMap, Node parendNode, DataElement defineElement)
    throws Exception
  {
  }

  public void unformatField(DataMap headMap, DataMap outDataMap, Node node, MsgField fieldDefine)
    throws Exception
  {
  }

  public void unformatList(DataMap headMap, DataMap outDataMap, Node node, MsgList listDefine)
    throws Exception
  {
  }

  public String getTitle()
  {
    return this.title;
  }

  public void setTitle(String title) {
    this.title = title;
  }
}