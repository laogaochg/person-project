package com.ifp.gateway.formater;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.gateway.bean.GroupMap;
import com.ifp.gateway.bean.MessageDefine;
import com.ifp.gateway.bean.MsgField;
import com.ifp.gateway.bean.MsgList;
import org.dom4j.Element;

@Deprecated
public abstract class AbstractKValueFormater
  implements IFormater
{
  protected abstract void formatGroup(StringBuffer paramStringBuffer, DataMap paramDataMap1, DataMap paramDataMap2, GroupMap paramGroupMap)
    throws Exception;

  protected abstract void formatField(StringBuffer paramStringBuffer, DataMap paramDataMap1, DataMap paramDataMap2, MsgField paramMsgField)
    throws Exception;

  protected abstract void formatList(StringBuffer paramStringBuffer, DataMap paramDataMap, DataList<DataElement> paramDataList, MsgList paramMsgList)
    throws Exception;

  public DataMap unformat(DataMap headMap, String recMsg, MessageDefine msgDefine)
    throws Exception
  {
    DataMap dataMap = new DataMap();
    unformat(headMap, dataMap, recMsg, msgDefine);
    return dataMap;
  }

  public void unformat(DataMap headMap, DataMap dataMap, String recMsg, MessageDefine msgDefine)
    throws Exception
  {
  }

  protected abstract void unformatGroup(DataMap paramDataMap1, DataMap paramDataMap2, Element paramElement, GroupMap paramGroupMap)
    throws Exception;

  protected abstract void unformatField(DataMap paramDataMap1, DataMap paramDataMap2, Element paramElement, MsgField paramMsgField)
    throws Exception;

  protected abstract void unformatList(DataMap paramDataMap1, DataMap paramDataMap2, Element paramElement, MsgList paramMsgList)
    throws Exception;
}