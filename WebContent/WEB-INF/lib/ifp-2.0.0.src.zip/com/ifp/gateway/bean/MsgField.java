package com.ifp.gateway.bean;

import com.ifp.core.data.DataElement;
import com.ifp.core.exception.ElementChangeFailedException;
import com.ifp.core.util.StringUtil;

public class MsgField extends DataElement<MsgField>
{
  private String label;
  private String value;
  private String refName;
  private String type = "S";
  private String length;
  private boolean empty = true;
  private boolean need = true;
  private String security;
  private String pattern;
  private String desc;
  private String xpath;

  public MsgField()
  {
  }

  public MsgField(String name)
  {
    setName(name);
  }

  public MsgField(String name, String value) {
    setName(name);
    this.value = value;
  }

  public void check()
  {
    if (!(isChange()))
      throw new ElementChangeFailedException("MsgField can not be changed:" + getName());
  }

  public MsgField clone()
  {
    MsgField field = new MsgField(getName(), this.value);
    field.setChange(isChange());
    field.setRefName(this.refName);
    field.setType(this.type);
    field.setLength(this.length);
    field.setEmpty(this.empty);
    field.setNeed(this.need);
    field.setSecurity(this.security);
    field.setPattern(this.pattern);
    field.setXpath(this.xpath);
    field.setDesc(this.desc);
    return field;
  }

  public MsgField cloneWithOutData()
  {
    MsgField field = new MsgField(getName());
    field.setChange(isChange());
    return field;
  }

  public void copy(MsgField dataField)
  {
    this.value = dataField.getValue();
    this.refName = dataField.getRefName();
    this.type = dataField.getType();
    this.length = dataField.getLength();
    this.empty = dataField.isEmpty();
    this.need = dataField.isNeed();
    this.security = dataField.getSecurity();
    this.pattern = dataField.getPattern();
    this.xpath = dataField.getXpath();
    this.desc = dataField.getDesc();
  }

  public boolean equals(MsgField dataField)
  {
    return ((((getName() == dataField.getName()) || (getName().equals(dataField.getName())))) && (isChange() == dataField.isChange()) && (((this.value == dataField.getValue()) || ((null != this.value) && (this.value.equals(dataField.getValue()))))) && (((this.refName == dataField.getRefName()) || ((null != this.refName) && (this.refName.equals(dataField.getRefName()))))) && (((this.type == dataField.getType()) || ((null != this.type) && (this.type.equals(dataField.getType()))))) && (((this.length == dataField.getLength()) || ((null != this.length) && (this.length.equals(dataField.getLength()))))) && (this.empty == dataField.isEmpty()) && (this.need == dataField.isNeed()) && (((this.security == dataField.getSecurity()) || ((null != this.security) && (this.security.equals(dataField.getSecurity()))))) && (((this.pattern == dataField.getPattern()) || ((null != this.pattern) && (this.pattern.equals(dataField.getPattern()))))) && (((this.xpath == dataField.getXpath()) || ((null != this.xpath) && (this.xpath.equals(dataField.getXpath()))))) && (((this.desc == dataField.getDesc()) || ((null != this.desc) && (this.desc.equals(dataField.getDesc()))))));
  }

  public String toString()
  {
    return "{name:" + getName() + ",value:" + this.value + ",refName:" + this.refName + ",type:" + this.type + ",length:" + this.length + ",empty:" + this.empty + ",need:" + this.need + ",security:" + this.security + ",pattern:" + this.pattern + ",xpath:" + this.xpath + ",desc:" + this.desc + "}";
  }

  public String toJSON()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("{\"name\":\"").append(StringUtil.formatJSONText(getName()));
    strBuff.append("\",\"value\":\"").append(StringUtil.formatJSONText(this.value));
    strBuff.append("\",\"refName\":\"").append(StringUtil.formatJSONText(this.refName));
    strBuff.append("\",\"type\":\"").append(StringUtil.formatJSONText(this.type));
    strBuff.append("\",\"length\":\"").append(StringUtil.formatJSONText(this.length));
    strBuff.append("\",\"empty\":\"").append(this.empty);
    strBuff.append("\",\"need\":\"").append(this.need);
    strBuff.append("\",\"security\":\"").append(StringUtil.formatJSONText(this.security));
    strBuff.append("\",\"pattern\":\"").append(StringUtil.formatJSONText(this.pattern));
    strBuff.append("\",\"xpath\":\"").append(StringUtil.formatJSONText(this.xpath));
    strBuff.append("\",\"desc\":\"").append(StringUtil.formatJSONText(this.desc));
    strBuff.append("\"}");

    return strBuff.toString();
  }

  public String toXML()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("<field name=\"").append(StringUtil.formatXMLText(getName()));
    strBuff.append("\" value=\"").append(StringUtil.formatXMLText(this.value));
    strBuff.append("\" refName=\"").append(StringUtil.formatXMLText(this.refName));
    strBuff.append("\" type=\"").append(StringUtil.formatXMLText(this.type));
    strBuff.append("\" length=\"").append(StringUtil.formatXMLText(this.length));
    strBuff.append("\" empty=\"").append(this.empty);
    strBuff.append("\" need=\"").append(this.need);
    strBuff.append("\" security=\"").append(StringUtil.formatXMLText(this.security));
    strBuff.append("\" pattern=\"").append(StringUtil.formatXMLText(this.pattern));
    strBuff.append("\" xpath=\"").append(StringUtil.formatXMLText(this.xpath));
    strBuff.append("\" desc=\"").append(StringUtil.formatXMLText(this.desc));
    strBuff.append("\" />");

    return strBuff.toString();
  }

  public String getValue() {
    return this.value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public String getRefName() {
    return this.refName;
  }

  public void setRefName(String refName) {
    this.refName = refName;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getLength() {
    return this.length;
  }

  public int getIntLength()
  {
    if (StringUtil.hasText(this.length)) return Integer.parseInt(this.length);
    return 0;
  }

  public void setLength(String length) {
    this.length = length;
  }

  public boolean isEmpty() {
    return this.empty;
  }

  public void setEmpty(boolean empty) {
    this.empty = empty;
  }

  public String getSecurity() {
    return this.security;
  }

  public void setSecurity(String security) {
    this.security = security;
  }

  public String getPattern() {
    return this.pattern;
  }

  public void setPattern(String pattern) {
    this.pattern = pattern;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  public boolean isNeed() {
    return this.need;
  }

  public void setNeed(boolean need) {
    this.need = need;
  }

  public String getLabel() {
    return this.label;
  }

  public void setLabel(String label) {
    this.label = label;
  }

  public String getXpath() {
    return this.xpath;
  }

  public void setXpath(String xpath) {
    this.xpath = xpath;
  }
}