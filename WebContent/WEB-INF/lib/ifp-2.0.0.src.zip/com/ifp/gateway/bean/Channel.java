package com.ifp.gateway.bean;

import com.ifp.core.util.SpringContextsUtil;
import com.ifp.gateway.service.IService;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Channel
{
  private String status = "0";
  private Map<String, IService> trxInterfaceMap = new HashMap();
  private Map<String, IService> interfaceMap = new HashMap();

  public Channel()
  {
  }

  public Channel(Map<String, List<String>> interfaceMap)
  {
    Iterator keyIterator = interfaceMap.keySet().iterator();
    while (keyIterator.hasNext()) {
      String key = (String)keyIterator.next();
      IService service = (IService)SpringContextsUtil.getBean(key, IService.class);
      List interfaceList = (List)interfaceMap.get(key);
      for (Iterator i$ = interfaceList.iterator(); i$.hasNext(); ) { String iface = (String)i$.next();
        this.trxInterfaceMap.put(iface, service);
      }
    }
  }

  public IService getServiceBySysCode(String sysCode)
  {
    return ((IService)this.interfaceMap.get(sysCode));
  }

  public IService getServiceByTransCode(String transCode)
  {
    return ((IService)this.trxInterfaceMap.get(transCode));
  }

  public String getStatus() {
    return this.status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Map<String, IService> getInterfaceMap() {
    return this.interfaceMap;
  }

  public void setInterfaceMap(Map<String, IService> interfaceMap) {
    this.interfaceMap = interfaceMap;
  }
}