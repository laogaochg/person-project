package com.ifp.gateway.bean;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataMap;
import java.util.Map;

public class GroupMap extends DataMap
{
  private String label;
  private String type;
  private boolean need = false;
  private String xpath;

  public GroupMap()
  {
    setChange(false);
  }

  public GroupMap(String name) {
    setName(name);
    setChange(false);
  }

  public GroupMap(String name, boolean isChange) {
    setName(name);
    setChange(isChange);
  }

  public GroupMap(boolean isChange) {
    setChange(isChange);
  }

  public GroupMap(Map<String, DataElement> map) {
    super(map);
  }

  public GroupMap(String name, Map<String, DataElement> map) {
    super(name, map);
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public boolean isNeed() {
    return this.need;
  }

  public void setNeed(boolean need) {
    this.need = need;
  }

  public String getLabel() {
    return this.label;
  }

  public void setLabel(String label) {
    this.label = label;
  }

  public String getXpath() {
    return this.xpath;
  }

  public void setXpath(String xpath) {
    this.xpath = xpath;
  }
}