package com.ifp.gateway.bean;

import com.ifp.core.data.DataElement;
import com.ifp.core.util.StringUtil;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MessageDefine
{
  private String id;
  private String name;
  private String xpath;
  private Map<String, DataElement> elementMap;

  public DataElement getElementByKey(String key)
  {
    return ((DataElement)this.elementMap.get(key));
  }

  public String getId() {
    return this.id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Map<String, DataElement> getElementMap() {
    return this.elementMap;
  }

  public void setElementMap(Map<String, DataElement> elementMap) {
    this.elementMap = elementMap;
  }

  public String getXpath() {
    return this.xpath;
  }

  public void setXpath(String xpath) {
    this.xpath = xpath;
  }

  public void setParentDefine(MessageDefine parentDefine) {
    Map eMap = new LinkedHashMap();

    Iterator pDefineItor = parentDefine.getElementMap().entrySet().iterator();
    while (pDefineItor.hasNext()) {
      Map.Entry pDefineEntry = (Map.Entry)pDefineItor.next();
      String key = (String)pDefineEntry.getKey();
      DataElement pDefineElement = (DataElement)pDefineEntry.getValue();
      if (pDefineElement instanceof Refer) {
        DataElement defineElement = (DataElement)this.elementMap.get(key);
        eMap.put(key, defineElement);
      } else {
        eMap.put(key, pDefineElement);
      }
    }

    if (!(StringUtil.hasText(this.name))) {
      this.name = parentDefine.getName();
    }

    if (!(StringUtil.hasText(this.xpath))) {
      this.xpath = parentDefine.getXpath();
    }

    this.elementMap = eMap;
  }

  public int countMsgLen()
  {
    int count = 0;
    Iterator elementIter = this.elementMap.entrySet().iterator();
    while (elementIter.hasNext()) {
      Map.Entry elementEntry = (Map.Entry)elementIter.next();
      String key = (String)elementEntry.getKey();
      DataElement defineElement = (DataElement)elementEntry.getValue();
      if (defineElement instanceof MsgList) continue;

      if (defineElement instanceof MsgField) {
        count += ((MsgField)defineElement).getIntLength();
      }

    }

    return count;
  }

  private int getListLen(MsgList msgList)
  {
    int count = 0;
    return count;
  }
}