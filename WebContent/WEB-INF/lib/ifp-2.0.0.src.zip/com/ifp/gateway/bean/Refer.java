package com.ifp.gateway.bean;

import com.ifp.core.data.DataElement;
import com.ifp.core.util.StringUtil;

public class Refer extends DataElement<Refer>
{
  public Refer()
  {
  }

  public Refer(String name)
  {
    super(name);
  }

  public Refer clone()
  {
    Refer refGroup = new Refer(getName());
    return refGroup;
  }

  public Refer cloneWithOutData()
  {
    Refer refGroup = new Refer(getName());
    refGroup.setChange(isChange());
    return refGroup;
  }

  public void copy(Refer refGroup)
  {
  }

  public boolean equals(Refer refGroup)
  {
    return ((getName() == refGroup.getName()) || (getName().equals(refGroup.getName())));
  }

  public String toString()
  {
    return "{name:" + getName();
  }

  public String toJSON()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("{\"name\":\"").append(StringUtil.formatJSONText(getName()));
    strBuff.append("\"}");

    return strBuff.toString();
  }

  public String toXML()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("<field name=\"").append(StringUtil.formatXMLText(getName()));
    strBuff.append("\" />");

    return strBuff.toString();
  }
}