package com.ifp.gateway.bean;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataMap;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

public class MsgList extends DataMap
{
  private String label;
  private String refName;
  private boolean need = true;
  private String xpath;
  private String subXpath;

  public MsgList()
  {
    setChange(false);
  }

  public MsgList(String name) {
    setName(name);
    setChange(false);
  }

  public MsgList(String name, boolean isChange) {
    setName(name);
    setChange(isChange);
  }

  public MsgList(boolean isChange) {
    setChange(isChange);
  }

  public MsgList(Map<String, DataElement> map) {
    super(map);
  }

  public MsgList(String name, Map<String, DataElement> map) {
    super(name, map);
  }

  public String getRefName() {
    return this.refName;
  }

  public void setRefName(String refName) {
    this.refName = refName;
  }

  public boolean isNeed() {
    return this.need;
  }

  public void setNeed(boolean need) {
    this.need = need;
  }

  public String getLabel() {
    return this.label;
  }

  public void setLabel(String label) {
    this.label = label;
  }

  public String getXpath() {
    return this.xpath;
  }

  public void setXpath(String xpath) {
    this.xpath = xpath;
  }

  public String getSubXpath() {
    return this.subXpath;
  }

  public void setSubXpath(String subXpath) {
    this.subXpath = subXpath;
  }

  public int getIntLength()
  {
    int len = 0;
    Iterator defineIterator = values().iterator();
    while (defineIterator.hasNext()) {
      DataElement defineElement = (DataElement)defineIterator.next();
      len += ((MsgField)defineElement).getIntLength();
    }
    return len;
  }
}