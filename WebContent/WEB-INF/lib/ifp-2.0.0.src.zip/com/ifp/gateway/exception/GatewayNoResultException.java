package com.ifp.gateway.exception;

public class GatewayNoResultException extends GatewayException
{
  private static final long serialVersionUID = 1L;

  public GatewayNoResultException()
  {
  }

  public GatewayNoResultException(String errorMessage)
  {
    super(errorMessage);
  }

  public GatewayNoResultException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public GatewayNoResultException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public GatewayNoResultException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public GatewayNoResultException(Throwable cause)
  {
    super(cause);
  }
}