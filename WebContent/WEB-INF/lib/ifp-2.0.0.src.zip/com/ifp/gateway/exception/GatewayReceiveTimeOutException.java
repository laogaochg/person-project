package com.ifp.gateway.exception;

public class GatewayReceiveTimeOutException extends GatewayException
{
  private static final long serialVersionUID = 1L;

  public GatewayReceiveTimeOutException()
  {
  }

  public GatewayReceiveTimeOutException(String errorMessage)
  {
    super(errorMessage);
  }

  public GatewayReceiveTimeOutException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public GatewayReceiveTimeOutException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public GatewayReceiveTimeOutException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public GatewayReceiveTimeOutException(Throwable cause)
  {
    super(cause);
  }
}