package com.ifp.gateway.exception;

import com.ifp.core.exception.BaseException;

public class GatewayException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public GatewayException()
  {
  }

  public GatewayException(String errorMessage)
  {
    super(errorMessage);
  }

  public GatewayException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public GatewayException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public GatewayException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public GatewayException(Throwable cause)
  {
    super(cause);
  }
}