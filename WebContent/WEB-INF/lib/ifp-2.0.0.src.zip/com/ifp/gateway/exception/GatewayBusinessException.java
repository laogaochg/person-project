package com.ifp.gateway.exception;

public class GatewayBusinessException extends GatewayException
{
  private static final long serialVersionUID = 1L;

  public GatewayBusinessException()
  {
  }

  public GatewayBusinessException(String errorMessage)
  {
    super(errorMessage);
  }

  public GatewayBusinessException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public GatewayBusinessException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public GatewayBusinessException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public GatewayBusinessException(Throwable cause)
  {
    super(cause);
  }
}