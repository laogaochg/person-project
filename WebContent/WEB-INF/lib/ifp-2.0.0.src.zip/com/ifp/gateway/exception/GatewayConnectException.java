package com.ifp.gateway.exception;

public class GatewayConnectException extends GatewayException
{
  private static final long serialVersionUID = 1L;

  public GatewayConnectException()
  {
  }

  public GatewayConnectException(String errorMessage)
  {
    super(errorMessage);
  }

  public GatewayConnectException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public GatewayConnectException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public GatewayConnectException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public GatewayConnectException(Throwable cause)
  {
    super(cause);
  }
}