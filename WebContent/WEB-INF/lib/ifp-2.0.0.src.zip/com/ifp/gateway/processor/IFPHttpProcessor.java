package com.ifp.gateway.processor;

import com.ifp.core.data.DataField;
import com.ifp.core.data.DataMap;
import com.ifp.gateway.creater.IMessageIdCreater;

public class IFPHttpProcessor extends AbstractProcessor
{
  private IMessageIdCreater messageIdCreater;
  private String encoding;
  private String fillCharacter;
  private String requestType;

  public IFPHttpProcessor()
  {
    this.encoding = "UTF-8";

    this.fillCharacter = " ";

    this.requestType = "K";
  }

  public void processSend(DataMap headMap, DataMap dataMap)
    throws Exception
  {
    headMap.put("type", new DataField("type", getRequestType()));
  }

  public void processReceive(DataMap headMap, DataMap dataMap)
    throws Exception
  {
  }

  public IMessageIdCreater getMessageIdCreater()
  {
    return this.messageIdCreater;
  }

  public void setMessageIdCreater(IMessageIdCreater messageIdCreater) {
    this.messageIdCreater = messageIdCreater;
  }

  public String getFillCharacter() {
    return this.fillCharacter;
  }

  public void setFillCharacter(String fillCharacter) {
    this.fillCharacter = fillCharacter;
  }

  public String getRequestType() {
    return this.requestType;
  }

  public void setRequestType(String requestType) {
    this.requestType = requestType;
  }
}