package com.ifp.gateway.processor;

import com.ifp.gateway.bean.MessageDefine;

public abstract interface IGatewayProcessor<T>
{
  public abstract void processSend(T paramT1, T paramT2)
    throws Exception;

  public abstract Object beforeSend(Object paramObject, T paramT1, T paramT2, MessageDefine paramMessageDefine)
    throws Exception;

  public abstract String afterReceive(String paramString, T paramT1, T paramT2, MessageDefine paramMessageDefine)
    throws Exception;

  public abstract void processReceive(T paramT1, T paramT2)
    throws Exception;
}