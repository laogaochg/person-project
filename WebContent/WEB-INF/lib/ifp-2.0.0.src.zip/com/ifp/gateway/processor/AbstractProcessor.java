package com.ifp.gateway.processor;

import com.ifp.core.data.DataMap;
import com.ifp.gateway.bean.MessageDefine;

@Deprecated
public abstract class AbstractProcessor
  implements IProcessor
{
  public void processSend(DataMap headMap, DataMap dataMap)
    throws Exception
  {
  }

  public Object beforeSend(Object sendObj, DataMap headMap, DataMap dataMap, MessageDefine messageDefine)
    throws Exception
  {
    return sendObj;
  }

  public String afterReceive(String recMsg, DataMap headMap, DataMap dataMap, MessageDefine messageDefine)
    throws Exception
  {
    return recMsg;
  }

  public void processReceive(DataMap headMap, DataMap dataMap)
    throws Exception
  {
  }
}