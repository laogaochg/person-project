package com.ifp.gateway.processor;

import com.ifp.core.data.DataMap;
import com.ifp.gateway.bean.MessageDefine;

@Deprecated
public abstract interface IProcessor extends IGatewayProcessor<DataMap>
{
  public abstract void processSend(DataMap paramDataMap1, DataMap paramDataMap2)
    throws Exception;

  public abstract Object beforeSend(Object paramObject, DataMap paramDataMap1, DataMap paramDataMap2, MessageDefine paramMessageDefine)
    throws Exception;

  public abstract String afterReceive(String paramString, DataMap paramDataMap1, DataMap paramDataMap2, MessageDefine paramMessageDefine)
    throws Exception;

  public abstract void processReceive(DataMap paramDataMap1, DataMap paramDataMap2)
    throws Exception;
}