package com.ifp.gateway.processor;

import com.ifp.gateway.bean.MessageDefine;
import java.util.Map;

public class GatewayProcessor extends AbstractGatewayProcessor
{
  public void processSend(Map headMap, Map dataMap)
    throws Exception
  {
  }

  public Object beforeSend(Object sendObj, Map headMap, Map dataMap, MessageDefine messageDefine)
    throws Exception
  {
    return sendObj;
  }

  public String afterReceive(String recMsg, Map headMap, Map dataMap, MessageDefine messageDefine)
    throws Exception
  {
    return recMsg;
  }

  public void processReceive(Map headMap, Map dataMap)
    throws Exception
  {
  }
}