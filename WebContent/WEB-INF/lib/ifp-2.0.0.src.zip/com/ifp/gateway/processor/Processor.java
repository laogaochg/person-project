package com.ifp.gateway.processor;

import com.ifp.core.data.DataMap;

@Deprecated
public class Processor extends AbstractProcessor
{
  public void processSend(DataMap headMap, DataMap dataMap)
    throws Exception
  {
  }

  public void processReceive(DataMap headMap, DataMap dataMap)
    throws Exception
  {
  }
}