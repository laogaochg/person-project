package com.ifp.gateway.handle;

import com.ifp.core.exception.BaseException;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.RemoteCallInfo;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.Channel;
import com.ifp.gateway.connector.AbstractHttpConnector;
import com.ifp.gateway.connector.AbstractTcpConnector;
import com.ifp.gateway.connector.IConnector;
import com.ifp.gateway.exception.GatewayException;
import com.ifp.gateway.service.AbstractService;
import com.ifp.gateway.service.IService;
import java.util.List;
import java.util.Map;

public class GatewayHandle
{
  private Map<String, Channel> channelMap;

  public void execute(Map headMap, Map dataMap)
    throws Exception
  {
    String commClient = StringUtil.getValue(headMap.get("commClient"));
    String systemId = StringUtil.getValue(headMap.get("channelId"));
    String transCode = StringUtil.getValue(headMap.get("transCode"));
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    RemoteCallInfo rc = null;
    try {
      IService service = getService(commClient, systemId, transCode);

      long startTime = System.currentTimeMillis();
      Trace.logDebug("CONNECT", "start format...");
      Object msg = service.format(headMap, dataMap, transCode);
      Trace.logDebug("CONNECT", "end format..., time:{}ms", new Object[] { Long.valueOf(System.currentTimeMillis() - startTime) });
      Object recMsg = null;

      if ((headMap.containsKey("actionId")) && (service instanceof AbstractService)) {
        List connectorList = ((AbstractService)service).getConnectorList();
        if ((null != connectorList) && (connectorList.size() > 0)) {
          IConnector connector = (IConnector)connectorList.get(0);
          rc = new RemoteCallInfo(StringUtil.getValue(headMap.get("actionId")), transCode, "SICLIENT", null);
          if (connector instanceof AbstractHttpConnector) {
            rc.setTargetUrl(((AbstractHttpConnector)connector).getUrl());
          } else if (connector instanceof AbstractTcpConnector) {
            rc.setTargetIp(((AbstractTcpConnector)connector).getIp());
            rc.setTargetPort(String.valueOf(((AbstractTcpConnector)connector).getPort()));
          }
          logHandle.logFlumeRemote(rc);
        }
      }

      recMsg = service.sendAndReceive(msg, headMap);

      startTime = System.currentTimeMillis();
      Trace.logDebug("CONNECT", "start unformat...");
      service.unformat(headMap, dataMap, (String)recMsg, transCode);
      Trace.logDebug("CONNECT", "end unformat..., time:{}ms", new Object[] { Long.valueOf(System.currentTimeMillis() - startTime) });
    } catch (GatewayException e) {
    }
    catch (Exception e) {
    }
    finally {
      if (rc != null) {
        rc.setType("SISERVER");
        rc.setMarkTime(Long.valueOf(System.currentTimeMillis()));
        logHandle.logFlumeRemote(rc);
      }
    }
  }

  public void execute(Map headMap, Map inDataMap, Map outDataMap)
    throws Exception
  {
    String commClient = StringUtil.getValue(headMap.get("commClient"));
    String systemId = StringUtil.getValue(headMap.get("channelId"));
    String transCode = StringUtil.getValue(headMap.get("transCode"));
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    RemoteCallInfo rc = null;
    try {
      IService service = getService(commClient, systemId, transCode);

      Trace.logDebug("CONNECT", "start format...");
      Object msg = service.format(headMap, inDataMap, transCode);
      Trace.logDebug("CONNECT", "end format...");
      Object recMsg = null;

      if ((headMap.containsKey("actionId")) && (service instanceof AbstractService)) {
        List connectorList = ((AbstractService)service).getConnectorList();
        if ((null != connectorList) && (connectorList.size() > 0)) {
          IConnector connector = (IConnector)connectorList.get(0);
          rc = new RemoteCallInfo(StringUtil.getValue(headMap.get("actionId")), transCode, "SICLIENT", null);
          if (connector instanceof AbstractHttpConnector) {
            rc.setTargetUrl(((AbstractHttpConnector)connector).getUrl());
          }
          else if (connector instanceof AbstractTcpConnector) {
            rc.setTargetIp(((AbstractTcpConnector)connector).getIp());
            rc.setTargetPort(String.valueOf(((AbstractTcpConnector)connector).getPort()));
          }
          logHandle.logFlumeRemote(rc);
        }
      }

      recMsg = service.sendAndReceive(msg, headMap);

      Trace.logDebug("CONNECT", "start unformat...");
      service.unformat(headMap, outDataMap, (String)recMsg, transCode);
      Trace.logDebug("CONNECT", "end unformat...");
    } catch (GatewayException e) {
    }
    catch (Exception e) {
    }
    finally {
      if (rc != null) {
        rc.setType("SISERVER");
        rc.setMarkTime(Long.valueOf(System.currentTimeMillis()));
        logHandle.logFlumeRemote(rc);
      }
    }
  }

  public IService getService(String commClient, String systemId, String transCode) throws BaseException {
    Channel channel = (Channel)this.channelMap.get(commClient);
    if (null == channel) {
      throw new GatewayException("can not found channel:" + commClient);
    }

    if (!("0".equals(channel.getStatus()))) {
      throw new GatewayException("channel's status is close!");
    }

    IService service = channel.getServiceByTransCode(transCode);
    if (null == service) {
      service = channel.getServiceBySysCode(systemId);
    }

    return service;
  }

  public Map<String, Channel> getChannelMap() {
    return this.channelMap;
  }

  public void setChannelMap(Map<String, Channel> channelMap) {
    this.channelMap = channelMap;
  }
}