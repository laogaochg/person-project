package com.ifp.gateway.schema.parser;

import com.ifp.gateway.bean.MsgField;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

public class FieldParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String name;
    try
    {
      name = element.getAttribute("name");
      if (StringUtils.hasText(name))
        builder.addPropertyValue("name", name);
      else {
        throw new Exception("cant not found attribute 'name'");
      }

      String value = element.getAttribute("value");
      if (StringUtils.hasText(value)) {
        builder.addPropertyValue("value", value);
      }

      String refName = element.getAttribute("refName");
      if (StringUtils.hasText(refName))
        builder.addPropertyValue("refName", refName);
      else {
        builder.addPropertyValue("refName", name);
      }

      String type = element.getAttribute("type");
      if (StringUtils.hasText(type)) {
        builder.addPropertyValue("type", type);
      }

      String length = element.getAttribute("length");
      if (StringUtils.hasText(length)) {
        builder.addPropertyValue("length", length);
      }

      String empty = element.getAttribute("empty");
      if (StringUtils.hasText(empty)) {
        builder.addPropertyValue("empty", empty);
      }

      String need = element.getAttribute("need");
      if (StringUtils.hasText(need)) {
        builder.addPropertyValue("need", need);
      }

      String security = element.getAttribute("security");
      if (StringUtils.hasText(security)) {
        builder.addPropertyValue("security", security);
      }

      String pattern = element.getAttribute("pattern");
      if (StringUtils.hasText(pattern)) {
        builder.addPropertyValue("pattern", pattern);
      }

      String desc = element.getAttribute("desc");
      if (StringUtils.hasText(desc)) {
        builder.addPropertyValue("desc", desc);
      }

      String xpath = element.getAttribute("xpath");
      if (StringUtils.hasText(xpath))
        builder.addPropertyValue("xpath", xpath);
      else
        builder.addPropertyValue("xpath", name);
    }
    catch (Exception e) {
      parserContext.getReaderContext().error("class " + FieldParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<MsgField> getBeanClass(Element element)
  {
    return MsgField.class;
  }
}