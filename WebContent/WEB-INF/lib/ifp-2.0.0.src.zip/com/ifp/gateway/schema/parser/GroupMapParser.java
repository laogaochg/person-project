package com.ifp.gateway.schema.parser;

import com.ifp.core.exception.BaseRuntimeException;
import com.ifp.core.util.StringUtil;
import com.ifp.gateway.bean.GroupMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedMap;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.StringUtils;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class GroupMapParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String name;
    try
    {
      name = element.getAttribute("name");
      if (StringUtils.hasText(name))
        builder.addPropertyValue("name", name);
      else {
        throw new Exception("cant not found attribute 'name'");
      }

      String type = element.getAttribute("type");
      if (StringUtils.hasText(type)) {
        builder.addPropertyValue("type", type);
      }

      String need = element.getAttribute("need");
      if (StringUtils.hasText(need)) {
        builder.addPropertyValue("need", need);
      }

      String xpath = element.getAttribute("xpath");
      if (StringUtils.hasText(xpath))
        builder.addPropertyValue("xpath", xpath);
      else {
        builder.addPropertyValue("xpath", name);
      }

      Map map = parseDataMapElement(element, parserContext, builder, need);
      if (null != map)
        builder.addConstructorArgValue(map);
    }
    catch (Exception e) {
      parserContext.getReaderContext().error("class " + GroupMapParser.class.getName() + " can not be create", element, null, e);

      throw new BaseRuntimeException(e);
    }
  }

  protected Class<GroupMap> getBeanClass(Element element)
  {
    return GroupMap.class;
  }

  private Map<String, BeanDefinition> parseDataMapElement(Element element, ParserContext parserContext, BeanDefinitionBuilder builder, String need) {
    List propertyList = DomUtils.getChildElements(element);
    ManagedMap map = new ManagedMap(propertyList.size());
    map.setMergeEnabled(true);
    map.setSource(parserContext.getReaderContext().extractSource(element));

    for (Iterator i$ = propertyList.iterator(); i$.hasNext(); ) { Element propertyElement = (Element)i$.next();
      String name = propertyElement.getAttribute("name");

      if (StringUtil.hasText(need))
        propertyElement.setAttribute("need", need);

      map.put(name, parserContext.getDelegate().parseCustomElement(propertyElement, builder.getRawBeanDefinition()));
    }

    return map;
  }
}