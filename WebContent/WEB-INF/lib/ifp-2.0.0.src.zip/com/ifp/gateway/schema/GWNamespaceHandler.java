package com.ifp.gateway.schema;

import com.ifp.gateway.schema.parser.FieldParser;
import com.ifp.gateway.schema.parser.GroupMapParser;
import com.ifp.gateway.schema.parser.ListParser;
import com.ifp.gateway.schema.parser.MessageParser;
import com.ifp.gateway.schema.parser.ReferParser;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

public class GWNamespaceHandler extends NamespaceHandlerSupport
{
  public void init()
  {
    registerBeanDefinitionParser("message", new MessageParser());
    registerBeanDefinitionParser("group", new GroupMapParser());
    registerBeanDefinitionParser("list", new ListParser());
    registerBeanDefinitionParser("field", new FieldParser());
    registerBeanDefinitionParser("refer", new ReferParser());
  }
}