package com.ifp.gateway.schema.parser;

import com.ifp.core.exception.BaseRuntimeException;
import com.ifp.gateway.bean.Refer;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

public class ReferParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String name;
    try
    {
      name = element.getAttribute("name");
      if (StringUtils.hasText(name))
        builder.addPropertyValue("name", name);
      else
        throw new Exception("cant not found attribute 'name'");
    }
    catch (Exception e) {
      parserContext.getReaderContext().error("class " + ReferParser.class.getName() + " can not be create", element, null, e);

      throw new BaseRuntimeException(e);
    }
  }

  protected Class<Refer> getBeanClass(Element element)
  {
    return Refer.class;
  }
}