package com.ifp.gateway.creater;

public abstract interface IMessageIdCreater
{
  public abstract String createMessageId()
    throws Exception;
}