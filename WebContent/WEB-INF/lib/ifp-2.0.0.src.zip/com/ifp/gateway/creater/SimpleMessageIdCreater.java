package com.ifp.gateway.creater;

import com.ifp.core.util.StringUtil;
import java.io.PrintStream;

public class SimpleMessageIdCreater
  implements IMessageIdCreater
{
  public String createMessageId()
    throws Exception
  {
    return System.currentTimeMillis() + StringUtil.generateRandomString(7);
  }

  public static void main(String[] args) throws Exception {
    System.out.println(new SimpleMessageIdCreater().createMessageId());
    char a = '\r';
    char b = '\n';

    StringBuffer s = new StringBuffer(a).append(b);
    System.out.println("###" + s + "@@@");
  }
}