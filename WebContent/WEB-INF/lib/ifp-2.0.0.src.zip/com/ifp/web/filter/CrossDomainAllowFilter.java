package com.ifp.web.filter;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CrossDomainAllowFilter
  implements Filter
{
  private final Logger mLogger;
  private Map<String, String> attributes;

  public CrossDomainAllowFilter()
  {
    this.mLogger = LogManager.getLogger(CrossDomainAllowFilter.class);
  }

  public void init(FilterConfig filterConfig)
    throws ServletException
  {
    Enumeration paraNames = filterConfig.getInitParameterNames();
    this.attributes = new HashMap();
    while (paraNames.hasMoreElements()) {
      String paraName = (String)paraNames.nextElement();
      this.attributes.put(paraName, filterConfig.getInitParameter(paraName));
    }
  }

  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    String method = "";
    if (request instanceof HttpServletRequest) {
      HttpServletRequest httpRequest = (HttpServletRequest)request;
      HttpServletResponse httpResponse = (HttpServletResponse)response;

      method = httpRequest.getMethod();
      if ("OPTIONS".equals(method)) {
        for (Iterator i$ = this.attributes.keySet().iterator(); i$.hasNext(); ) { String headerName = (String)i$.next();
          httpResponse.setHeader(headerName, (String)this.attributes.get(headerName));
        }
        chain.doFilter(request, response);
      }
      else {
        httpResponse.setHeader("Access-Control-Allow-Origin", "*");
        chain.doFilter(request, response);
      }
    }
  }

  public void destroy()
  {
    this.attributes.clear();
    this.attributes = null;
  }
}