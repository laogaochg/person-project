package com.ifp.web.data;

import com.ifp.core.data.DataElement;
import java.util.List;

public class MvcView extends DataElement<MvcView>
{
  private String requestType;
  private String ref;
  private List<TargetView> targetViewList;

  public MvcView()
  {
  }

  public MvcView(String requestType, String ref)
  {
    this.requestType = requestType;
    this.ref = ref;
  }

  public MvcView(String name, String requestType, String ref) {
    setName(name);
    this.requestType = requestType;
    this.ref = ref;
  }

  public MvcView clone() {
    MvcView field = new MvcView(getRequestType(), this.ref);
    return field;
  }

  public MvcView cloneWithOutData() {
    MvcView field = new MvcView();
    field.setName(getName());
    return field;
  }

  public void copy(MvcView dataElement)
  {
    this.requestType = dataElement.getRequestType();
    this.ref = dataElement.getRef();
  }

  public String getRequestType() {
    return this.requestType;
  }

  public void setRequestType(String requestType) {
    this.requestType = requestType;
  }

  public String getRef()
  {
    return this.ref;
  }

  public void setRef(String ref) {
    this.ref = ref;
  }

  public String toString() {
    return "{name:" + getName() + ",ref:" + this.ref + ",requestType:" + this.requestType + "}";
  }

  public boolean equals(MvcView dataElement)
  {
    return false;
  }

  public String toJSON()
  {
    return null;
  }

  public String toXML()
  {
    return null;
  }

  public List<TargetView> getTargetViewList() {
    return this.targetViewList;
  }

  public void setTargetViewList(List<TargetView> targetViewList) {
    this.targetViewList = targetViewList;
  }
}