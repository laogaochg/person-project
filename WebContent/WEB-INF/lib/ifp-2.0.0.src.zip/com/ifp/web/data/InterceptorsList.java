package com.ifp.web.data;

import com.ifp.core.data.DataElement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class InterceptorsList extends DataElement<InterceptorsList>
{
  private List<DataElement> interceptorsList = new ArrayList();

  public int size()
  {
    return this.interceptorsList.size();
  }

  public boolean addElement(DataElement element) {
    return this.interceptorsList.add(element);
  }

  public void addAllElement(InterceptorsList interceptorsList) {
    this.interceptorsList.addAll(interceptorsList.getInterceptorsList());
  }

  public boolean removeElement(DataElement element) {
    return this.interceptorsList.remove(element);
  }

  public DataElement getElement(int index) {
    return ((DataElement)this.interceptorsList.get(index));
  }

  public boolean isEmpty() {
    return this.interceptorsList.isEmpty();
  }

  public boolean contains(DataElement element) {
    return contain(element);
  }

  private boolean contain(DataElement element)
  {
    for (int i = 0; i < this.interceptorsList.size(); ++i)
      if (((DataElement)this.interceptorsList.get(i)).getName().equals(element.getName()))
      {
        return true;
      }

    return false;
  }

  public void clear() {
    this.interceptorsList.clear();
  }

  public InterceptorsList() {
    this.interceptorsList = new ArrayList();
  }

  public InterceptorsList clone()
  {
    InterceptorsList list = new InterceptorsList();
    list.setName(getName());
    for (int i = 0; i < this.interceptorsList.size(); ++i) {
      DataElement dataElement = (DataElement)this.interceptorsList.get(i);
      list.addElement(dataElement.clone());
    }

    return list;
  }

  public InterceptorsList cloneWithOutData()
  {
    InterceptorsList list = new InterceptorsList();
    list.setName(getName());

    return list;
  }

  public void copy(InterceptorsList dataElement)
  {
  }

  public List<DataElement> getInterceptorsList()
  {
    return this.interceptorsList;
  }

  public void setInterceptorsList(List<DataElement> interceptorsList) {
    this.interceptorsList = interceptorsList;
  }

  public String toString() {
    StringBuffer str = new StringBuffer("[");
    int i = 0;
    for (Iterator i$ = this.interceptorsList.iterator(); i$.hasNext(); ) { DataElement element = (DataElement)i$.next();
      if (i > 0)
        str.append(",");

      str.append("{").append(element.toString()).append("}");

      ++i;
    }

    return str.append("]").toString();
  }

  public boolean equals(InterceptorsList dataElement)
  {
    return false;
  }

  public String toJSON()
  {
    return null;
  }

  public String toXML()
  {
    return null;
  }
}