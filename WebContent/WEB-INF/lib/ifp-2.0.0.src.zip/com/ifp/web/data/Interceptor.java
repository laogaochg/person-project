package com.ifp.web.data;

import com.ifp.core.data.DataElement;
import com.ifp.core.util.StringUtil;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Interceptor extends DataElement<Interceptor>
{
  private static final long serialVersionUID = 1L;
  private String regex;
  private String sourceName;
  private String desc;
  private Map<String, String> attributeMap;

  public Interceptor()
  {
  }

  public Interceptor(String name)
  {
  }

  public Interceptor(String name, String regex)
  {
    setName(name);
    this.sourceName = name;
    this.regex = regex;
  }

  public Interceptor(String name, String sourceName, String regex) {
    setName(name);
    this.sourceName = sourceName;
    this.regex = regex;
  }

  public Interceptor(String name, String sourceName, String regex, String desc) {
    setName(name);
    this.sourceName = sourceName;
    this.regex = regex;
    this.desc = desc;
  }

  public Interceptor clone()
  {
    Interceptor interceptor = new Interceptor(getName(), this.regex);
    interceptor.setChange(isChange());
    interceptor.setSourceName(this.sourceName);
    interceptor.setDesc(this.desc);
    interceptor.setAttributeMap(this.attributeMap);
    return interceptor;
  }

  public Interceptor cloneWithOutData()
  {
    Interceptor interceptor = new Interceptor(getName());
    interceptor.setChange(isChange());
    return interceptor;
  }

  public void copy(Interceptor dataElement)
  {
    this.sourceName = dataElement.getSourceName();
    this.regex = dataElement.getRegex();
    this.desc = dataElement.getDesc();
    this.attributeMap = dataElement.getAttributeMap();
  }

  public String getRegex() {
    return this.regex;
  }

  public void setRegex(String regex) {
    this.regex = regex;
  }

  public String getSourceName() {
    return this.sourceName;
  }

  public void setSourceName(String sourceName) {
    this.sourceName = sourceName;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  public boolean equals(Interceptor interceptor)
  {
    return ((((getName() == interceptor.getName()) || (getName().equals(interceptor.getName())))) && (isChange() == interceptor.isChange()) && (((this.regex == interceptor.getRegex()) || ((null != this.regex) && (this.regex.equals(interceptor.getRegex()))))) && (((this.sourceName == interceptor.getSourceName()) || ((null != this.sourceName) && (this.sourceName.equals(interceptor.getSourceName()))))));
  }

  public String toString()
  {
    StringBuffer strBuff = new StringBuffer().append("{name:").append(getName()).append(",sourceName:").append(this.sourceName).append(",regex:").append(this.regex);
    Iterator attIterator = this.attributeMap.entrySet().iterator();
    strBuff.append(",attributeMap:{");
    int i = 0;
    while (attIterator.hasNext()) {
      Map.Entry entry = (Map.Entry)attIterator.next();
      if (i > 0)
        strBuff.append(",");

      strBuff.append((String)entry.getKey()).append(":").append((String)entry.getValue());
      ++i;
    }
    return strBuff.append("}}").toString();
  }

  public String toJSON()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("{\"name\":\"").append(StringUtil.formatJSONText(getName()));
    strBuff.append("\",\"sourceName\":\"").append(StringUtil.formatJSONText(this.sourceName));
    strBuff.append("\",\"regex\":\"").append(StringUtil.formatJSONText(this.regex)).append("\"");

    Iterator attIterator = this.attributeMap.entrySet().iterator();
    strBuff.append(",\"attributeMap\":{");
    int i = 0;
    while (attIterator.hasNext()) {
      Map.Entry entry = (Map.Entry)attIterator.next();
      if (i > 0)
        strBuff.append(",");

      strBuff.append("\"").append((String)entry.getKey()).append("\":\"").append((String)entry.getValue()).append("\"");
      ++i;
    }

    strBuff.append("}}");

    return strBuff.toString();
  }

  public String toXML()
  {
    StringBuffer strBuff = new StringBuffer();
    strBuff.append("<Interceptor name=\"").append(StringUtil.formatXMLText(getName()));
    strBuff.append("\" sourceName=\"").append(StringUtil.formatXMLText(this.sourceName));
    strBuff.append("\" regex=\"").append(StringUtil.formatXMLText(this.regex));
    strBuff.append("\">");

    Iterator attIterator = this.attributeMap.entrySet().iterator();
    while (attIterator.hasNext()) {
      Map.Entry entry = (Map.Entry)attIterator.next();
      strBuff.append("<attribute name=\"").append((String)entry.getKey()).append("\" value=\"").append((String)entry.getValue()).append("\" />");
    }

    return strBuff.append("</Interceptor>").toString();
  }

  public Map<String, String> getAttributeMap() {
    return this.attributeMap;
  }

  public void setAttributeMap(Map<String, String> attributeMap) {
    this.attributeMap = attributeMap;
  }
}