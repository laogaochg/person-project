package com.ifp.web.data;

import com.ifp.core.data.DataElement;

public class TargetView extends DataElement<TargetView>
{
  private String dest;
  private String condition;

  public TargetView()
  {
  }

  public TargetView(String dest, String condition)
  {
    this.dest = dest;
    this.condition = condition;
  }

  public TargetView(String name, String dest, String condition) {
    setName(name);
    this.dest = dest;
    this.condition = condition;
  }

  public TargetView clone() {
    TargetView field = new TargetView(getDest(), this.condition);
    return field;
  }

  public TargetView cloneWithOutData() {
    TargetView field = new TargetView();
    field.setName(getName());
    return field;
  }

  public void copy(TargetView dataElement)
  {
    this.dest = dataElement.getDest();
    this.condition = dataElement.getCondition();
  }

  public String getDest() {
    return this.dest;
  }

  public void setDest(String dest) {
    this.dest = dest;
  }

  public String getCondition() {
    return this.condition;
  }

  public void setCondition(String condition) {
    this.condition = condition;
  }

  public String toString() {
    return "{name:" + getName() + ",condition:" + this.condition + ",dest:" + this.dest + "}";
  }

  public boolean equals(TargetView dataElement)
  {
    return false;
  }

  public String toJSON()
  {
    return null;
  }

  public String toXML()
  {
    return null;
  }
}