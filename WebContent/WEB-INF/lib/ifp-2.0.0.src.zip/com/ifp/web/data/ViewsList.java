package com.ifp.web.data;

import com.ifp.core.data.DataElement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ViewsList extends DataElement<ViewsList>
{
  private List<DataElement> viewsList = new ArrayList();

  public int size()
  {
    return this.viewsList.size();
  }

  public boolean addElement(DataElement element) {
    return this.viewsList.add(element);
  }

  public void addAllElement(ViewsList viewsList) {
    this.viewsList.addAll(viewsList.getviewsList());
  }

  public boolean removeElement(DataElement element) {
    return this.viewsList.remove(element);
  }

  public DataElement getElement(int index) {
    return ((DataElement)this.viewsList.get(index));
  }

  public boolean isEmpty() {
    return this.viewsList.isEmpty();
  }

  public boolean contains(DataElement element) {
    return this.viewsList.contains(element);
  }

  public void clear() {
    this.viewsList.clear();
  }

  public ViewsList() {
    this.viewsList = new ArrayList();
  }

  public ViewsList clone() {
    ViewsList list = new ViewsList();
    list.setName(getName());
    for (int i = 0; i < this.viewsList.size(); ++i) {
      DataElement dataElement = (DataElement)this.viewsList.get(i);
      list.addElement(dataElement.clone());
    }

    return list;
  }

  public ViewsList cloneWithOutData() {
    ViewsList list = new ViewsList();
    list.setName(getName());

    return list;
  }

  public void copy(ViewsList dataElement)
  {
  }

  public List<DataElement> getviewsList()
  {
    return this.viewsList;
  }

  public void setviewsList(List<DataElement> viewsList) {
    this.viewsList = viewsList;
  }

  public String toString() {
    StringBuffer str = new StringBuffer("[");
    int i = 0;
    for (Iterator i$ = this.viewsList.iterator(); i$.hasNext(); ) { DataElement element = (DataElement)i$.next();
      if (i > 0)
        str.append(",");

      str.append("{").append(element.toString()).append("}");

      ++i;
    }

    return str.append("]").toString();
  }

  public boolean equals(ViewsList dataElement)
  {
    return false;
  }

  public String toJSON()
  {
    return null;
  }

  public String toXML()
  {
    return null;
  }
}