package com.ifp.web.listener;

import com.ifp.core.base.SysParamInitInf;
import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.data.InputField;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.action.jdbc.AbstractJDBCAction;
import com.ifp.core.flow.logic.BusinessLogic;
import com.ifp.core.flow.logic.Flow;
import com.ifp.core.flow.step.IStep;
import com.ifp.core.log.LogHandle;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

public class ServletLoadedListener extends AbstractJDBCAction
  implements ApplicationListener<ContextRefreshedEvent>
{
  private Integer flumeInitFlag;

  public ServletLoadedListener()
  {
    this.flumeInitFlag = Integer.valueOf(2);
  }

  public void onApplicationEvent(ContextRefreshedEvent arg0)
  {
    if (arg0.getApplicationContext().getParent() == null)
    {
      LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
      if (!(logHandle.isDisable()))
      {
        String appName = arg0.getApplicationContext().getApplicationName().substring(1);
        logHandle.setAppName(appName);

        logHandle.logFlumeQPSInit();

        Map serviceNameMap = new HashMap();

        Map serviceDescMap = new HashMap();

        Map actionNameMap = new HashMap();

        Map actionDescMap = new HashMap();

        Map businessLogicMap = SpringContextsUtil.getBeansOfType(BusinessLogic.class);

        StringBuffer sb = new StringBuffer();
        actionNameMap.put("CL00", "1");
        actionNameMap.put("BL00", "2");
        actionNameMap.put("PA40", "3");
        int i = 1; int j = 4;
        for (Iterator i$ = businessLogicMap.keySet().iterator(); i$.hasNext(); ) { String key = (String)i$.next();
          sb.delete(0, sb.length());
          BusinessLogic bLogic = (BusinessLogic)businessLogicMap.get(key);
          serviceNameMap.put(bLogic.getId(), i + "");
          serviceDescMap.put(bLogic.getId(), bLogic.getName());
          sb.append(appName).append("|").append(bLogic.getId()).append("|").append(i).append("##");
          DataList inList = bLogic.getInputParamsList();
          DataList outList = bLogic.getInputParamsList();

          if (null != inList)
            for (int a = 0; a < inList.size(); ++a) {
              InputField inField = (InputField)inList.get(a);
              String paramin = inField.getName();
              if (StringUtil.hasText(inField.getSourceName()))
                paramin = inField.getSourceName();

              sb.append(paramin).append("|");
            }

          sb.deleteCharAt(sb.length() - 1);
          if (null != outList)
            for (int b = 0; b < outList.size(); ++b) {
              InputField outField = (InputField)inList.get(b);
              String paramout = outField.getName();
              if (StringUtil.hasText(outField.getSourceName()))
                paramout = outField.getSourceName();

              sb.append(paramout).append("|");
            }

          sb.deleteCharAt(sb.length() - 1);
          Flow flow = bLogic.getFlow();
          Map iStepMap = flow.getStepMap();
          Set iStepMapKeys = iStepMap.keySet();
          sb.append("#");
          for (Iterator i$ = iStepMapKeys.iterator(); i$.hasNext(); ) { String key2 = (String)i$.next();
            actionNameMap.put(((IStep)iStepMap.get(key2)).getStepId(), j + "");
            actionDescMap.put(((IStep)iStepMap.get(key2)).getStepId(), ((IStep)iStepMap.get(key2)).getConfMap().getName());
            sb.append("#").append(((IStep)iStepMap.get(key2)).getStepId()).append("|").append(j);
            ++j;
          }

          ++i;
        }
        logHandle.setServiceNameMap(serviceNameMap);
        logHandle.setActionNameMap(actionNameMap);
        logHandle.setServiceDescMap(serviceDescMap);
        logHandle.setActionDescMap(actionDescMap);
        switch (this.flumeInitFlag.intValue())
        {
        case 0:
          logHandle.logFlumeInitData();
          break;
        case 1:
          logHandle.logFlumeAppHost();
          break;
        case 2:
        }

      }

      Map sysParamInitInfMap = SpringContextsUtil.getBeansOfType(SysParamInitInf.class);

      for (Iterator i$ = sysParamInitInfMap.keySet().iterator(); i$.hasNext(); ) { String key = (String)i$.next();
        SysParamInitInf sysParamInitInf = (SysParamInitInf)sysParamInitInfMap.get(key);
        sysParamInitInf.init();
      }
    }
  }

  public int execute(BlogicContext context, DataMap confMap) throws BaseException
  {
    return 0;
  }

  public Integer getFlumeInitFlag() {
    return this.flumeInitFlag;
  }

  public void setFlumeInitFlag(Integer flumeInitFlag) {
    this.flumeInitFlag = flumeInitFlag;
  }
}