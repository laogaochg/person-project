package com.ifp.web.controller.schema;

import com.ifp.core.session.schema.parser.SessionInfoNameParser;
import com.ifp.core.session.schema.parser.SessionNameParser;
import com.ifp.web.controller.schema.parser.AttributeParser;
import com.ifp.web.controller.schema.parser.CLColumnFieldParser;
import com.ifp.web.controller.schema.parser.CLInFieldParser;
import com.ifp.web.controller.schema.parser.CLInListParser;
import com.ifp.web.controller.schema.parser.CLInputParser;
import com.ifp.web.controller.schema.parser.CLOutFieldParser;
import com.ifp.web.controller.schema.parser.CLOutListParser;
import com.ifp.web.controller.schema.parser.CLOutputParser;
import com.ifp.web.controller.schema.parser.InterceptorListParser;
import com.ifp.web.controller.schema.parser.InterceptorParser;
import com.ifp.web.controller.schema.parser.InterceptorsParser;
import com.ifp.web.controller.schema.parser.MVCActionParser;
import com.ifp.web.controller.schema.parser.MVCCommonParser;
import com.ifp.web.controller.schema.parser.TargetViewParser;
import com.ifp.web.controller.schema.parser.ValidationFieldParser;
import com.ifp.web.controller.schema.parser.ValidationFormParser;
import com.ifp.web.controller.schema.parser.ViewListParser;
import com.ifp.web.controller.schema.parser.ViewParser;
import com.ifp.web.controller.schema.parser.ViewsParser;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

public class CLNamespaceHandler extends NamespaceHandlerSupport
{
  public void init()
  {
    registerBeanDefinitionParser("mvcAction", new MVCActionParser());
    registerBeanDefinitionParser("common", new MVCCommonParser());
    registerBeanDefinitionParser("interceptors", new InterceptorsParser());
    registerBeanDefinitionParser("interceptor", new InterceptorParser());
    registerBeanDefinitionParser("attribute", new AttributeParser());
    registerBeanDefinitionParser("interceptorsList", new InterceptorListParser());
    registerBeanDefinitionParser("views", new ViewsParser());
    registerBeanDefinitionParser("view", new ViewParser());
    registerBeanDefinitionParser("targetView", new TargetViewParser());
    registerBeanDefinitionParser("viewList", new ViewListParser());

    registerBeanDefinitionParser("input", new CLInputParser());
    registerBeanDefinitionParser("inField", new CLInFieldParser());
    registerBeanDefinitionParser("inList", new CLInListParser());
    registerBeanDefinitionParser("columnField", new CLColumnFieldParser());

    registerBeanDefinitionParser("output", new CLOutputParser());
    registerBeanDefinitionParser("outField", new CLOutFieldParser());
    registerBeanDefinitionParser("outList", new CLOutListParser());

    registerBeanDefinitionParser("validationForm", new ValidationFormParser());
    registerBeanDefinitionParser("validationField", new ValidationFieldParser());

    registerBeanDefinitionParser("sessionName", new SessionNameParser());
    registerBeanDefinitionParser("sessionInfoName", new SessionInfoNameParser());
  }
}