package com.ifp.web.controller.schema.parser;

import com.ifp.web.controller.MvcCommon;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedMap;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.StringUtils;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class MVCCommonParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    try
    {
      builder.addPropertyValue("id", element.getAttribute("id"));

      String scope = element.getAttribute("scope");
      if (StringUtils.hasText(scope))
        builder.addPropertyValue("scope", element.getAttribute("scope"));

      String desc = element.getAttribute("desc");
      if (StringUtils.hasText(desc))
        builder.addPropertyValue("desc", element.getAttribute("desc"));

      builder.addPropertyValue("mvcInterceptorsMap", parseInterceptorsElement("interceptors", "views", element, parserContext, builder));
    }
    catch (Exception e) {
      parserContext.getReaderContext().error("class " + MVCCommonParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<MvcCommon> getBeanClass(Element element)
  {
    return MvcCommon.class;
  }

  private Map<String, Map<String, Object>> parseInterceptorsElement(String interceptorTagName, String viewTagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List elist = DomUtils.getChildElements(element);
    ManagedMap map = new ManagedMap(elist.size());
    map.setMergeEnabled(true);
    map.setSource(parserContext.getReaderContext().extractSource(element));
    for (int i = 0; i < elist.size(); ++i)
    {
      Element childElement = (Element)elist.get(i);
      String nodeName = childElement.getNodeName();
      ManagedMap childMap = new ManagedMap();
      childMap.setMergeEnabled(true);
      childMap.setSource(parserContext.getReaderContext().extractSource(element));
      int idx = nodeName.indexOf(":");
      if (idx != -1)
      {
        nodeName = nodeName.substring(idx + 1, nodeName.length());
      }
      if (nodeName.equals(interceptorTagName))
      {
        childMap.put("test", null);
        childMap.put("type", "interceptorsList");
        childMap.put("interceptorsList", parserContext.getDelegate().parseCustomElement(childElement, builder.getRawBeanDefinition()));
        childMap.put("viewsList", null);
      } else if (nodeName.equals(viewTagName))
      {
        childMap.put("test", null);
        childMap.put("type", "view");
        childMap.put("interceptorsList", null);
        childMap.put("viewsList", parserContext.getDelegate().parseCustomElement(childElement, builder.getRawBeanDefinition())); } else {
        String test;
        if (nodeName.equals("if")) {
          test = childElement.getAttribute("test");
          childMap.put("test", test);
          childMap.put("type", "if");
          childMap.put("interceptorsList", parseChildElement(interceptorTagName, childElement, parserContext, builder));
          childMap.put("viewsList", parseChildElement(viewTagName, childElement, parserContext, builder));
        } else if (nodeName.equals("elseif")) {
          test = childElement.getAttribute("test");
          childMap.put("test", test);
          childMap.put("type", "elseif");
          childMap.put("interceptorsList", parseChildElement(interceptorTagName, childElement, parserContext, builder));
          childMap.put("viewsList", parseChildElement(viewTagName, childElement, parserContext, builder));
        } else if (nodeName.equals("else")) {
          childMap.put("test", null);
          childMap.put("type", "else");
          childMap.put("interceptorsList", parseChildElement(interceptorTagName, childElement, parserContext, builder));
          childMap.put("viewsList", parseChildElement(viewTagName, childElement, parserContext, builder)); }
      }
      map.put(String.valueOf(i), childMap);
    }
    return map;
  }

  private BeanDefinition parseChildElement(String tagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List inputList = DomUtils.getChildElementsByTagName(element, tagName);
    if (inputList.size() > 0)
    {
      Element inputElement = (Element)inputList.get(0);
      BeanDefinition beanDefinition = parserContext.getDelegate().parseCustomElement(inputElement, builder.getRawBeanDefinition());
      return beanDefinition;
    }
    return null;
  }
}