package com.ifp.web.controller;

import com.ifp.core.data.DataList;

public abstract class AbstractMvcController
  implements IMvcController
{
  public String id;
  public String bid;
  public String securityType;
  public String requestType;
  public String TranCode;
  public boolean checkSession;
  public String sessionName;
  public boolean dubboFlow;
  public boolean execFlow;
  public DataList inputParamsList;
  public DataList outputParamsList;
  public String desc;

  public AbstractMvcController()
  {
    this.execFlow = true;
  }

  public String getId()
  {
    return this.id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getTranCode() {
    return this.TranCode;
  }

  public void setTranCode(String tranCode) {
    this.TranCode = tranCode;
  }

  public String getBid() {
    return this.bid;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public boolean isCheckSession() {
    return this.checkSession;
  }

  public void setCheckSession(boolean checkSession) {
    this.checkSession = checkSession;
  }

  public String getSessionName() {
    return this.sessionName;
  }

  public void setSessionName(String sessionName) {
    this.sessionName = sessionName;
  }

  public boolean isDubboFlow() {
    return this.dubboFlow;
  }

  public void setDubboFlow(boolean dubboFlow) {
    this.dubboFlow = dubboFlow;
  }

  public String getSecurityType() {
    return this.securityType;
  }

  public void setSecurityType(String securityType) {
    this.securityType = securityType;
  }

  public String getRequestType() {
    return this.requestType;
  }

  public void setRequestType(String requestType) {
    this.requestType = requestType;
  }

  public DataList getInputParamsList()
  {
    return this.inputParamsList;
  }

  public DataList getOutputParamsList()
  {
    return this.outputParamsList;
  }

  public void setInputParamsList(DataList inputParamsList)
  {
    this.inputParamsList = inputParamsList;
  }

  public void setOutputParamsList(DataList outputParamsList)
  {
    this.outputParamsList = outputParamsList;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  public boolean isExecFlow() {
    return this.execFlow;
  }

  public void setExecFlow(boolean execFlow) {
    this.execFlow = execFlow;
  }
}