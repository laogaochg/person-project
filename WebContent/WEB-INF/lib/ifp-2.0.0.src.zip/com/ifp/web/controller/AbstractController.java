package com.ifp.web.controller;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.Context;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.BusinessCompleteException;
import com.ifp.core.exception.MvcException;
import com.ifp.core.log.Trace;
import com.ifp.core.spel.SpELHandle;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.web.data.MvcView;
import com.ifp.web.interceptor.IFPInterceptor;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;

public abstract class AbstractController
  implements IController
{
  private Map<String, IFPInterceptor> interceptorMap;
  private IMvcController mvcController;
  private Map<String, Map<String, String>> attributesMap;
  private SpELHandle spELHandle;
  private Map<String, MvcView> viewMap;

  public AbstractController()
  {
    this.interceptorMap = new HashMap();

    this.attributesMap = new HashMap();
  }

  public void executePostHandle(HttpServletRequest request, HttpServletResponse response, ClogicContext context, List<IFPInterceptor> interceptorList, ModelAndView mv)
    throws BaseException
  {
    for (int i = interceptorList.size() - 1; i >= 0; --i) {
      IFPInterceptor interceptor = (IFPInterceptor)interceptorList.get(i);
      try {
        Trace.log("INTERCEPTOR", 0, "start execute [{}]Interceptor's method postHandle", new Object[] { interceptor });
        interceptor.postHandle(request, response, context, mv);
        Trace.log("INTERCEPTOR", 0, "end execute [{}]Interceptor's method postHandle", new Object[] { interceptor });
      } catch (Exception e) {
        Trace.logError("CTRL", "execute interceptor postHandle error, interceptorName: {}", new Object[] { interceptor.getName() });
        throw new MvcException("SCIS0001", "postHandle执行异常:" + interceptor.getName(), e);
      }
    }
  }

  public IFPInterceptor getInterceptor(String interceptorName)
  {
    return ((IFPInterceptor)this.interceptorMap.get(interceptorName));
  }

  public void executeInterceptor(String key, HttpServletRequest request, HttpServletResponse response, String interceptorName, ClogicContext context, List interceptorList)
    throws BaseException
  {
    context.getTempMap().put("interceptorAttributeKey", this.attributesMap.get(key));
    executeInterceptor(request, response, interceptorName, context, interceptorList);
  }

  public void executeInterceptor(HttpServletRequest request, HttpServletResponse response, String interceptorName, ClogicContext context, List interceptorList)
    throws BaseException
  {
    IFPInterceptor interceptor = (IFPInterceptor)this.interceptorMap.get(interceptorName);
    try {
      Trace.log("INTERCEPTOR", 0, "start execute [{}]Interceptor's method preHandle", new Object[] { interceptorName });
      if (!(interceptor.preHandle(request, response, context)))
        throw new BusinessCompleteException("SCIP0002", "执行preHandle返回false:" + interceptorName);

      Trace.log("INTERCEPTOR", 0, "end execute [{}]Interceptor's method preHandle", new Object[] { interceptorName });
    } catch (BusinessCompleteException e) {
      Trace.logError("CTRL", "execute interceptor preHandle error, interceptorName: {}", new Object[] { interceptorName });
      throw e;
    } catch (Exception e) {
      Trace.logError("CTRL", "execute interceptor preHandle error, interceptorName: {}", new Object[] { interceptorName });
      throw new MvcException("SCIP0001", "preHandle执行异常:" + interceptorName, e);
    }
    interceptorList.add(interceptor);
  }

  public boolean checkFunction(String function, Context<Map<String, Object>> context)
  {
    if (this.spELHandle == null)
      try
      {
        this.spELHandle = ((SpELHandle)SpringContextsUtil.getBean("spelHandle"));
      } catch (Exception e) {
        this.spELHandle = new SpELHandle();
      }

    return this.spELHandle.parseExpression(function, (Map)context.getDataMap());
  }

  public IMvcController getMvcController()
  {
    return this.mvcController;
  }

  public void setMvcController(IMvcController mvcController) {
    this.mvcController = mvcController;
  }

  public SpELHandle getSpELHandle() {
    return this.spELHandle;
  }

  public void setSpELHandle(SpELHandle spELHandle) {
    this.spELHandle = spELHandle;
  }

  public Map<String, IFPInterceptor> getInterceptorMap() {
    return this.interceptorMap;
  }

  public void setInterceptorMap(Map<String, IFPInterceptor> interceptorMap) {
    this.interceptorMap = interceptorMap;
  }

  public Map<String, MvcView> getViewMap() {
    return this.viewMap;
  }

  public void setViewMap(Map<String, MvcView> viewMap) {
    this.viewMap = viewMap;
  }

  public Map<String, Map<String, String>> getAttributesMap() {
    return this.attributesMap;
  }

  public void setAttributesMap(Map<String, Map<String, String>> attributesMap) {
    this.attributesMap = attributesMap;
  }
}