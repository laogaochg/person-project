package com.ifp.web.controller;

public abstract class AbstractMvcCommon
  implements IMvcCommon
{
  public String id;
  public String scope;
  public String desc;

  public String getId()
  {
    return this.id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getScope() {
    return this.scope;
  }

  public void setScope(String scope) {
    this.scope = scope;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }
}