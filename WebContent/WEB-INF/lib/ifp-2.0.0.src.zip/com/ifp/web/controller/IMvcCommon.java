package com.ifp.web.controller;

public abstract interface IMvcCommon
{
  public abstract String getId();

  public abstract void setId(String paramString);

  public abstract String getScope();

  public abstract void setScope(String paramString);

  public abstract String getDesc();

  public abstract void setDesc(String paramString);
}