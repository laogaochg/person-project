package com.ifp.web.controller;

import java.util.Map;

public class MvcCommon extends AbstractMvcCommon
{
  public Map<String, Map<String, Object>> mvcInterceptorsMap;

  public Map<String, Map<String, Object>> getMvcInterceptorsMap()
  {
    return this.mvcInterceptorsMap;
  }

  public void setMvcInterceptorsMap(Map<String, Map<String, Object>> mvcInterceptorsMap)
  {
    this.mvcInterceptorsMap = mvcInterceptorsMap;
  }
}