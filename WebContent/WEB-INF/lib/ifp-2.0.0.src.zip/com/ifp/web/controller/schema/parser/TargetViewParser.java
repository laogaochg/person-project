package com.ifp.web.controller.schema.parser;

import com.ifp.web.data.TargetView;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

public class TargetViewParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String dest;
    try
    {
      dest = element.getAttribute("dest");
      builder.addPropertyValue("dest", dest);

      String condition = element.getAttribute("condition");
      if (StringUtils.hasText(condition))
        builder.addPropertyValue("condition", condition);
    }
    catch (Exception e) {
      parserContext.getReaderContext().error("class " + TargetViewParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<TargetView> getBeanClass(Element element)
  {
    return TargetView.class;
  }
}