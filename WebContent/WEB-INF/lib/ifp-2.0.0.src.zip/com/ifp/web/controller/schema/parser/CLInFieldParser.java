package com.ifp.web.controller.schema.parser;

import com.ifp.core.data.CLInputField;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

public class CLInFieldParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String name = element.getAttribute("name");

    if (StringUtils.hasText(name)) {
      builder.addPropertyValue("name", element.getAttribute("name"));
    }

    String sourceName = element.getAttribute("sourceName");
    if (StringUtils.hasText(sourceName))
      builder.addPropertyValue("sourceName", sourceName);
    else if (StringUtils.hasText(name)) {
      builder.addPropertyValue("sourceName", name);
    }

    String checkType = element.getAttribute("checkType");
    if (StringUtils.hasText(checkType)) {
      builder.addPropertyValue("checkType", checkType);
    }

    String desc = element.getAttribute("desc");
    if (StringUtils.hasText(desc)) {
      builder.addPropertyValue("desc", desc);
    }

    builder.addPropertyValue("defaultValue", element.getAttribute("defaultValue"));
  }

  protected Class<CLInputField> getBeanClass(Element element)
  {
    return CLInputField.class;
  }
}