package com.ifp.web.controller;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.util.UrlUtil;
import java.util.List;
import javassist.ClassClassPath;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.CtNewMethod;
import javassist.NotFoundException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerGenerator
{
  private ClassPool pool = ClassPool.getDefault();
  private boolean writeFile = false;

  public ControllerGenerator()
  {
    this.pool.insertClassPath(new ClassClassPath(super.getClass())); } 
  public ControllerGenerator(boolean writeFile) { this.pool.insertClassPath(new ClassClassPath(super.getClass()));

    this.writeFile = writeFile;
  }

  public ControllerGenerator(String writeFile)
  {
    this.pool.insertClassPath(new ClassClassPath(super.getClass()));

    if (null != writeFile)
      this.writeFile = Boolean.valueOf(writeFile).booleanValue();
  }

  public IController generateMvcActionClass(String className, String methodString) throws BaseException
  {
    CtClass cls = null;
    boolean newFlag = false;
    try
    {
      try {
        cls = this.pool.get(className);
      } catch (NotFoundException e) {
        cls = this.pool.makeClass(className);
        newFlag = true;
      }

      if (newFlag)
      {
        cls.setSuperclass(this.pool.get("com.ifp.web.controller.AbstractController"));
      } else {
        CtClass[] paramTypes = { this.pool.get(HttpServletRequest.class.getName()), this.pool.get(HttpServletResponse.class.getName()), this.pool.get(ClogicContext.class.getName()), this.pool.get(List.class.getName()) };

        ctMethod = cls.getDeclaredMethod("executePreHandle", paramTypes);
        cls.removeMethod(ctMethod);
      }

      CtMethod ctMethod = CtNewMethod.make("public void executePreHandle(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response, com.ifp.core.context.ClogicContext context, java.util.List interceptorList) throws com.ifp.core.exception.BaseException" + methodString, cls);

      cls.addMethod(ctMethod);

      if (this.writeFile) {
        cls.writeFile(UrlUtil.getClassPath(super.getClass()));
      }

      CtMethod ctMethod = (IController)cls.toClass().newInstance();

      return ctMethod;
    }
    catch (Exception e)
    {
    }
    finally
    {
      if (null != cls)
        cls.detach();
    }
  }
}