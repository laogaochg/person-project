package com.ifp.web.controller;

import java.io.Serializable;
import java.util.Map;

public class MvcController extends AbstractMvcController
  implements Serializable
{
  public transient Map<String, Object> mvcInterceptorsMap;
  public transient String mvcCommonName;

  public Map<String, Object> getMvcInterceptorsMap()
  {
    return this.mvcInterceptorsMap;
  }

  public void setMvcInterceptorsMap(Map<String, Object> mvcInterceptorsMap)
  {
    this.mvcInterceptorsMap = mvcInterceptorsMap;
  }

  public String getMvcCommonName() {
    return this.mvcCommonName;
  }

  public void setMvcCommonName(String mvcCommonName) {
    this.mvcCommonName = mvcCommonName;
  }
}