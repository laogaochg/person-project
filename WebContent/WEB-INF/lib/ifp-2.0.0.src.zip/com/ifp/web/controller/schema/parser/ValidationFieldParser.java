package com.ifp.web.controller.schema.parser;

import com.ifp.web.validation.ValidationField;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

public class ValidationFieldParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String name = element.getAttribute("name");

    if (StringUtils.hasText(name)) {
      builder.addPropertyValue("name", element.getAttribute("name"));
    }

    String test = element.getAttribute("type");
    if (StringUtils.hasText(test)) {
      builder.addPropertyValue("type", test);
    }

    String desc = element.getAttribute("desc");
    if (StringUtils.hasText(desc))
      builder.addPropertyValue("desc", desc);
  }

  protected Class<ValidationField> getBeanClass(Element element)
  {
    return ValidationField.class;
  }
}