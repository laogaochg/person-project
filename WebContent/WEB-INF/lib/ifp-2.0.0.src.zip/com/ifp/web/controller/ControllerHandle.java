package com.ifp.web.controller;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.ClogicContext;
import com.ifp.core.data.CLColumnField;
import com.ifp.core.data.CLInputField;
import com.ifp.core.data.CLOutputField;
import com.ifp.core.data.CLOutputList;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.data.InputField;
import com.ifp.core.data.OutputField;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.MvcException;
import com.ifp.core.flow.logic.BusinessLogic;
import com.ifp.core.flow.service.FlowService;
import com.ifp.core.log.Trace;
import com.ifp.core.spel.SpELHandle;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.core.util.UrlUtil;
import com.ifp.web.common.IFPConstance;
import com.ifp.web.data.Interceptor;
import com.ifp.web.data.InterceptorsList;
import com.ifp.web.data.MvcView;
import com.ifp.web.data.TargetView;
import com.ifp.web.data.ViewsList;
import com.ifp.web.interceptor.IFPInterceptor;
import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.InitializingBean;

public class ControllerHandle
  implements InitializingBean
{
  private Map<String, IController> controllerMap;
  private Map<String, IFPInterceptor> interceptorMap;
  private Map<String, MvcCommon> mvcCommonMap;
  private SpELHandle spELHandle;
  private SystemConf systemConf;
  private Map<String, String> checkTransCodeMap;

  public ControllerHandle()
  {
    this.controllerMap = new HashMap();

    this.interceptorMap = new HashMap();

    this.checkTransCodeMap = new HashMap();
  }

  public void afterPropertiesSet()
    throws Exception
  {
    try
    {
      this.mvcCommonMap = SpringContextsUtil.getBeansOfType(MvcCommon.class);

      Map interceptors = SpringContextsUtil.getBeansOfType(IFPInterceptor.class);
      for (Iterator i$ = interceptors.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entity = (Map.Entry)i$.next();
        String key = (String)entity.getKey();
        IFPInterceptor interceptor = (IFPInterceptor)entity.getValue();
        interceptor.setName(key);
        interceptor.setSystemConf(this.systemConf);
        this.interceptorMap.put(key, interceptor);
      }

      ControllerGenerator ctlGenerator = new ControllerGenerator();

      String classRootPath = UrlUtil.getClassPath(super.getClass());
      String packageName = ControllerHandle.class.getPackage().getName() + ".mvcAction";
      String filePath = classRootPath + packageName.replaceAll("\\.", "/");
      String classPath = packageName + ".Action";

      File file = new File(filePath);
      if ((file.exists()) && (file.isDirectory())) {
        File[] files = file.listFiles();
        File[] arr$ = files; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { File f = arr$[i$];
          if (f.isFile())
            f.delete();
        }

      }

      Map controllers = SpringContextsUtil.getBeansOfType(AbstractMvcController.class);
      for (Iterator i$ = controllers.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entity = (Map.Entry)i$.next();
        String key = (String)entity.getKey();
        Trace.logInfo("MVC", "start init controller=>{}", new Object[] { key });
        AbstractMvcController mvcController = (AbstractMvcController)entity.getValue();
        try
        {
          getInOutPutParamsList(mvcController);
        } catch (Exception e) {
          Trace.log("MVC", 2, "init controller[{}] in/out params list fail!", new Object[] { key });
        }

        String className = classPath + mvcController.getId();
        StringBuffer methodString = new StringBuffer("{");
        methodString.append("try{");

        Map mvcMap = new HashMap();
        Map attributesMap = new HashMap();
        try {
          getInterceptorListAndViewName(mvcController, methodString, mvcMap, attributesMap);
        } catch (BaseException e) {
          while (true) Trace.logError("MVC", "init controller handle error: getInterceptorList failed!", e);
        }

        methodString.append("}catch(com.ifp.core.exception.BaseException e){throw e;");
        methodString.append("}catch(java.lang.Exception e){throw new com.ifp.core.exception.BaseException(e);");
        methodString.append("}}");
        try {
          Trace.logDebug("INTERCEPTOR", "generate mvc controller methodString:{}", new Object[] { methodString });
          IController controller = ctlGenerator.generateMvcActionClass(className, methodString.toString());
          controller.setInterceptorMap(this.interceptorMap);
          controller.setMvcController(mvcController);
          controller.setSpELHandle(this.spELHandle);
          controller.setViewMap(mvcMap);
          controller.setAttributesMap(attributesMap);

          this.controllerMap.put(key, controller);
          this.controllerMap.put(mvcController.getTranCode(), controller);
          Trace.logInfo("MVC", "init controller successful=>{}|{}", new Object[] { key, className });
        } catch (Exception e) {
          Trace.logError("MVC", "init controller handle error: generateMvcActionClass failed==>" + className, e);
        }
      }
    } catch (Exception e) {
      Trace.logError("MVC", "controller init error!", e);
    }
  }

  public void getInOutPutParamsList(IMvcController mvcController)
    throws BaseException
  {
    if (mvcController.isExecFlow())
    {
      DataList inputParamsList = mvcController.getInputParamsList();

      DataList outputParamsList = mvcController.getOutputParamsList();

      if (null == outputParamsList) {
        BusinessLogic businessLogic = null;

        String blogicId = mvcController.getBid();
        Object service = null;
        if (StringUtil.hasText(blogicId)) {
          if (!(mvcController.isDubboFlow())) {
            businessLogic = (BusinessLogic)SpringContextsUtil.getBean(mvcController.getBid(), BusinessLogic.class);
          } else {
            service = SpringContextsUtil.getRemoteBean(mvcController.getBid());

            if (service instanceof FlowService) {
              FlowService flowService = (FlowService)service;
              businessLogic = flowService.getBusinessLogic();
            }

          }

        }
        else if (null == outputParamsList) {
          throw new MvcException("SCPC0002", "请求输出参数未设置");
        }

        if (null != businessLogic) {
          DataMap dictMap = businessLogic.getDataDictionary();

          if (null == outputParamsList)
          {
            outputParamsList = new DataList();
            DataList outList = businessLogic.getOutputParamsList();
            for (int i = 0; i < outList.size(); ++i) {
              OutputField outField = (OutputField)outList.get(i);
              DataElement dataElement = dictMap.get(outField.getName());

              if (dataElement instanceof DataField)
                outputParamsList.add(outputFieldBL2CL((DataField)dataElement, outField));
              else if (dataElement instanceof DataMap)
                outputParamsList.add(dataListBL2CLForOutput((DataMap)dataElement, outField.getTargetName()));
            }
          }

        }

      }

      Map inputCommParamsMap = (Map)this.systemConf.getConfByKey("clogicInputCommParams");
      if ((null != inputCommParamsMap) && (null != mvcController.getInputParamsList())) {
        putInputCommToList(inputCommParamsMap, inputParamsList);
      }

      Map outputCommParamsMap = (Map)this.systemConf.getConfByKey("clogicOutputCommParams");
      if ((null != outputCommParamsMap) && (null != mvcController.getInputParamsList())) {
        if (null == outputParamsList) {
          outputParamsList = new DataList();
        }

        putOutputCommToList(outputCommParamsMap, outputParamsList);
      }

      mvcController.setInputParamsList(inputParamsList);
      mvcController.setOutputParamsList(outputParamsList);
    }
  }

  private void putInputCommToList(Map<String, Object> inputCommParamsMap, DataList inputParamsList) {
    Iterator iterator = inputCommParamsMap.entrySet().iterator();
    while (iterator.hasNext()) {
      Map.Entry entry = (Map.Entry)iterator.next();
      String key = (String)entry.getKey();
      Object value = entry.getValue();
      if (value instanceof Map) {
        Map map = (Map)value;
        DataList inputList = new DataList();
        putOutputCommToList(map, inputList);
        inputParamsList.add(inputList);
      } else {
        CLInputField iField = new CLInputField();
        iField.setName(key);
        iField.setSourceName((StringUtil.hasText(value)) ? (String)value : key);
        inputParamsList.add(iField);
      }
    }
  }

  private void putOutputCommToList(Map<String, Object> outputCommParamsMap, DataList outputParamsList) {
    Iterator iterator = outputCommParamsMap.entrySet().iterator();
    while (iterator.hasNext()) {
      Map.Entry entry = (Map.Entry)iterator.next();
      String key = (String)entry.getKey();
      Object value = entry.getValue();
      if (value instanceof Map) {
        Map map = (Map)value;
        DataList outputList = new DataList();
        putOutputCommToList(map, outputList);
        outputParamsList.add(outputList);
      } else {
        OutputField iField = new OutputField();
        iField.setName(key);
        iField.setTargetName((StringUtil.hasText(value)) ? (String)value : key);
        outputParamsList.add(iField);
      }
    }
  }

  private CLOutputField outputFieldCL2CL(CLOutputField outField)
  {
    CLOutputField newOutField = new CLOutputField();
    newOutField.setName(outField.getTargetName());
    newOutField.setTargetName(outField.getTargetName());
    newOutField.setDesc(outField.getDesc());
    return newOutField;
  }

  private CLOutputList outputListCL2CL(CLOutputList outputList)
  {
    CLOutputList newOutputList = new CLOutputList();
    newOutputList.setName(outputList.getTargetName());
    newOutputList.setTargetName(outputList.getTargetName());

    for (int i = 0; i < outputList.size(); ++i) {
      DataElement dataElement = outputList.get(i);
      if (dataElement instanceof CLOutputField)
        newOutputList.add(outputFieldCL2CL((CLOutputField)dataElement));
      else if (dataElement instanceof CLOutputList)
        newOutputList.add(outputListCL2CL((CLOutputList)dataElement));

    }

    return newOutputList;
  }

  private CLInputField inputFieldBL2CL(DataField dataField, InputField inputField)
  {
    CLInputField cinField = new CLInputField();
    cinField.setName(inputField.getSourceName());
    cinField.setSourceName(inputField.getSourceName());
    cinField.setRegex(inputField.getRegex());
    cinField.setDefaultValue(dataField.getDefaultValue());
    cinField.setDesc(dataField.getDesc());

    return cinField;
  }

  private CLOutputField outputFieldBL2CL(DataField dataField, OutputField outputField)
  {
    CLOutputField coutField = new CLOutputField();
    coutField.setName(outputField.getTargetName());
    coutField.setTargetName(outputField.getTargetName());
    coutField.setDesc(dataField.getDesc());

    return coutField;
  }

  private CLOutputList dataListBL2CLForOutput(DataMap dataListMap, String name)
  {
    CLOutputList dList = new CLOutputList();
    dList.setName(name);
    dList.setTargetName(name);

    Iterator keyIterator = dataListMap.keySet().iterator();
    while (keyIterator.hasNext()) {
      String key = (String)keyIterator.next();
      DataElement dataElement = dataListMap.get(key);
      if (dataElement instanceof DataField) {
        DataField dataField = (DataField)dataElement;
        CLColumnField columnField = new CLColumnField();
        columnField.setName(dataField.getName());
        columnField.setTargetName(dataField.getName());
        columnField.setDesc(dataField.getDesc());

        dList.add(columnField);
      } else if (dataElement instanceof DataMap) {
        dList.add(dataListBL2CLForOutput((DataMap)dataElement, dataElement.getName()));
      }
    }

    return dList;
  }

  public void execute(IController controller, HttpServletRequest request, HttpServletResponse response, String actionId, ClogicContext clogicContext, List<IFPInterceptor> interceptorList)
    throws Exception
  {
    controller.executePreHandle(request, response, clogicContext, interceptorList);

    controller.executePostHandle(request, response, clogicContext, interceptorList, null);
  }

  public void triggerAfterCompletion(List<IFPInterceptor> interceptorList, HttpServletRequest request, HttpServletResponse response, ClogicContext context, Exception ex)
  {
    if (null != interceptorList)
      for (int i = interceptorList.size() - 1; i >= 0; --i) {
        IFPInterceptor interceptor = (IFPInterceptor)interceptorList.get(i);
        try {
          Trace.log("INTERCEPTOR", 0, "start execute [{}]interceptor's method triggerAfterCompletion", new Object[] { interceptor });
          interceptor.afterCompletion(request, response, context, ex);
          Trace.log("INTERCEPTOR", 0, "end execute [{}]interceptor's method triggerAfterCompletion", new Object[] { interceptor });
        } catch (Throwable e) {
          Trace.logError("MVC", "execute interceptor afterCompletion error, interceptorName: {}, error info: {}", new Object[] { interceptor.getName(), e });
        }
      }
  }

  public String getActionId(HttpServletRequest request)
  {
    String reqURI = request.getRequestURI();
    String contextPath = request.getContextPath();
    String reqStr = reqURI;
    if (reqURI.startsWith(contextPath))
      reqStr = reqURI.substring(contextPath.length());

    int idx = reqStr.lastIndexOf(46);
    if (idx != -1)
      reqStr = reqStr.substring(0, idx);
    if (reqStr.startsWith("/"))
      reqStr = reqStr.substring(1);

    int idx2 = reqStr.lastIndexOf(47);
    if (idx2 != -1)
      reqStr = reqStr.substring(idx2 + 1, reqStr.length());

    return reqStr;
  }

  public IController getController(String actionId)
    throws BaseException
  {
    IController controller = (IController)this.controllerMap.get(actionId);
    if (null == controller) {
      throw new MvcException("can not found controller: " + actionId);
    }

    return controller;
  }

  private void getInterceptorListAndViewName(AbstractMvcController controller, StringBuffer methodString, Map<String, MvcView> mvcMap, Map<String, Map<String, String>> attributesMap)
    throws BaseException
  {
    String transCode = controller.getTranCode();
    if (this.checkTransCodeMap.containsKey(transCode))
      throw new BaseException("more than one mvcAction had the same tranCode, please check: " + transCode);

    this.checkTransCodeMap.put(transCode, transCode);

    Map map = controller.getMvcInterceptorsMap();
    StringBuffer interceptorString = new StringBuffer();
    String commonName = controller.getMvcCommonName();
    Trace.log("MVC", 0, "context's InterceptorsList is :{}", new Object[] { map });
    addBeforeInterceptors(interceptorString);
    addCommonInterceptors(controller, interceptorString, mvcMap, attributesMap);
    if (StringUtil.hasText(commonName)) {
      MvcCommon mCommon = (MvcCommon)SpringContextsUtil.getBean(commonName);
      addCommonInterceptors(controller, "action", mCommon, interceptorString, mvcMap, attributesMap);
    }

    for (int i = 0; i < map.keySet().size(); ++i) {
      MvcCommon mCommon;
      int j;
      Map childmap = (Map)map.get(String.valueOf(i));
      String type = (String)childmap.get("type");
      String function = (String)childmap.get("test");
      InterceptorsList list = (InterceptorsList)childmap.get("interceptorsList");
      ViewsList viewsList = (ViewsList)childmap.get("viewsList");
      String commName = (String)childmap.get("commonName");
      if ("if".equals(type)) {
        interceptorString.append("if(checkFunction(\"").append(function).append("\", context)){");
        if (StringUtil.hasText(commName)) {
          mCommon = (MvcCommon)this.mvcCommonMap.get(commName);
          addCommonInterceptors(controller, "action", mCommon, interceptorString, mvcMap, attributesMap);
        }
        if (null != list)
          for (j = 0; j < list.size(); ++j)
            addInterceptor(interceptorString, (Interceptor)list.getElement(j), attributesMap);


        interceptorString.append("}");
      } else if ("elseif".equals(type)) {
        interceptorString.append("else if(checkFunction(\"").append(function).append("\", context)){");
        if (StringUtil.hasText(commName)) {
          j = (MvcCommon)this.mvcCommonMap.get(commName);
          addCommonInterceptors(controller, "action", j, interceptorString, mvcMap, attributesMap);
        }
        if (null != list)
          for (j = 0; j < list.size(); ++j)
            addInterceptor(interceptorString, (Interceptor)list.getElement(j), attributesMap);


        interceptorString.append("}");
      } else if ("else".equals(type)) {
        interceptorString.append("else{");
        if (StringUtil.hasText(commName)) {
          j = (MvcCommon)this.mvcCommonMap.get(commName);
          addCommonInterceptors(controller, "action", j, interceptorString, mvcMap, attributesMap);
        }
        if (null != list)
          for (j = 0; j < list.size(); ++j)
            addInterceptor(interceptorString, (Interceptor)list.getElement(j), attributesMap);


        interceptorString.append("}");
      } else if ("interceptorsList".equals(type)) {
        if (null != list)
          for (j = 0; j < list.size(); ++j)
            addInterceptor(interceptorString, (Interceptor)list.getElement(j), attributesMap);

      }
      else if ("view".equals(type)) {
        updateViewName(viewsList, mvcMap);
      }
    }

    addAfterInterceptors(interceptorString);
    if (controller.isExecFlow())
    {
      if (controller.isDubboFlow())
        interceptorString.append("executeInterceptor(request, response, \"").append(IFPConstance.EXEC_INTERCEPTORS[1]).append("\", context, interceptorList);");
      else
        interceptorString.append("executeInterceptor(request, response, \"").append(IFPConstance.EXEC_INTERCEPTORS[0]).append("\", context, interceptorList);");

    }

    methodString.append(interceptorString);
  }

  private void doInterceptorName(String interceptorName)
    throws BaseException
  {
  }

  private void addInterceptor(StringBuffer interceptorString, Interceptor interceptor, Map<String, Map<String, String>> attributesMap)
    throws BaseException
  {
    String interceptorName = interceptor.getName();
    doInterceptorName(interceptorName);
    String key = System.nanoTime() + StringUtil.generateRandomString(15);
    while (true) {
      if (!(attributesMap.containsKey(key)))
        break;

      key = System.nanoTime() + StringUtil.generateRandomString(15);
    }
    interceptorString.append("executeInterceptor(\"").append(key).append("\", request, response, \"").append(interceptorName).append("\", context, interceptorList);");
    Trace.logDebug("COMMON", "init {} attributeMap {}: {}", new Object[] { interceptorName, key, interceptor.getAttributeMap() });
    attributesMap.put(key, interceptor.getAttributeMap());
  }

  private void addBeforeInterceptors(StringBuffer methodString)
  {
    String[] interceptors = null;
    Object obj = this.systemConf.getConfByKey("beforeInterceptorArray");
    if (obj instanceof String)
      interceptors = { (String)obj };
    else if (obj instanceof String[]) {
      interceptors = (String[])(String[])obj;
    }

    if (null == interceptors)
      interceptors = IFPConstance.BEFORE_INTERCEPTORS;

    for (int i = 0; i < interceptors.length; ++i) {
      String interceptor = interceptors[i];
      if (!("".equals(interceptor)))
        methodString.append("executeInterceptor(request, response, \"").append(interceptor).append("\", context, interceptorList);");
    }
  }

  private void addCommonInterceptors(AbstractMvcController controller, StringBuffer methodString, Map<String, MvcView> mvcMap, Map<String, Map<String, String>> attributesMap)
    throws BaseException
  {
    if (null != this.mvcCommonMap) {
      Iterator iterator = this.mvcCommonMap.values().iterator();
      while (iterator.hasNext()) {
        MvcCommon mCommon = (MvcCommon)iterator.next();
        addCommonInterceptors(controller, "application", mCommon, methodString, mvcMap, attributesMap);
      }
    }
  }

  private void addCommonInterceptors(AbstractMvcController controller, String scope, MvcCommon mCommon, StringBuffer methodString, Map<String, MvcView> mvcMap, Map<String, Map<String, String>> attributesMap)
    throws BaseException
  {
    StringBuffer interceptorString = new StringBuffer();
    if (mCommon != null) {
      String currScope = mCommon.getScope();
      if (scope.equals(currScope)) {
        Map map = mCommon.getMvcInterceptorsMap();
        for (int i = 0; i < map.keySet().size(); ++i) {
          int j;
          Map childmap = (Map)map.get(String.valueOf(i));
          String type = (String)childmap.get("type");
          String function = (String)childmap.get("test");
          InterceptorsList list = (InterceptorsList)childmap.get("interceptorsList");
          ViewsList viewsList = (ViewsList)childmap.get("viewsList");
          if ("if".equals(type)) {
            interceptorString.append("if(checkFunction(\"").append(function).append("\", context)){");
            if (null != list)
              for (j = 0; j < list.size(); ++j)
                addInterceptor(interceptorString, (Interceptor)list.getElement(j), attributesMap);


            interceptorString.append("}");
          } else if ("elseif".equals(type)) {
            interceptorString.append("else if(checkFunction(\"").append(function).append("\", context)){");
            if (null != list)
              for (j = 0; j < list.size(); ++j)
                addInterceptor(interceptorString, (Interceptor)list.getElement(j), attributesMap);


            interceptorString.append("}");
          } else if ("else".equals(type)) {
            interceptorString.append("else{");
            if (null != list)
              for (j = 0; j < list.size(); ++j)
                addInterceptor(interceptorString, (Interceptor)list.getElement(j), attributesMap);


            interceptorString.append("}");
          } else if ("interceptorsList".equals(type)) {
            if (null != list)
              for (j = 0; j < list.size(); ++j)
                addInterceptor(interceptorString, (Interceptor)list.getElement(j), attributesMap);

          }
          else if ("view".equals(type)) {
            updateViewName(viewsList, mvcMap);
          }
        }
      }
    }

    methodString.append(interceptorString);
  }

  private void addAfterInterceptors(StringBuffer methodString)
  {
    Object obj = this.systemConf.getConfByKey("afterInterceptorArray");
    String[] interceptors = null;
    if (obj instanceof String)
      interceptors = { (String)obj };
    else if (obj instanceof String[])
      interceptors = (String[])(String[])obj;

    if (null == interceptors)
      interceptors = IFPConstance.AFTER_INTERCEPTORS;

    for (int i = 0; i < interceptors.length; ++i) {
      String interceptor = interceptors[i];
      if (!("".equals(interceptor)))
        methodString.append("executeInterceptor(request, response, \"").append(interceptor).append("\", context, interceptorList);");
    }
  }

  private List<TargetView> updateViewName(ViewsList viewsList, Map<String, MvcView> mvcMap)
  {
    if (null != viewsList)
      for (int i = 0; i < viewsList.size(); ++i)
        if (viewsList.getElement(i) instanceof MvcView) {
          MvcView mvcView = (MvcView)viewsList.getElement(i);
          mvcMap.put(mvcView.getRequestType(), mvcView);
        }



    return null;
  }

  public SpELHandle getSpELHandle() {
    return this.spELHandle;
  }

  public void setSpELHandle(SpELHandle spELHandle) {
    this.spELHandle = spELHandle;
  }

  public SystemConf getSystemConf() {
    return this.systemConf;
  }

  public void setSystemConf(SystemConf systemConf) {
    this.systemConf = systemConf;
  }
}