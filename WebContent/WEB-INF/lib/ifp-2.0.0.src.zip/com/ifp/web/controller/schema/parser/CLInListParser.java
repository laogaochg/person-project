package com.ifp.web.controller.schema.parser;

import com.ifp.core.data.CLInputList;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedList;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.StringUtils;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class CLInListParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    List list;
    try
    {
      list = parseDataListElement(element, parserContext, builder);

      String name = element.getAttribute("name");

      if (StringUtils.hasText(name)) {
        builder.addPropertyValue("name", element.getAttribute("name"));
      }

      String sourceName = element.getAttribute("sourceName");
      if (StringUtils.hasText(sourceName))
        builder.addPropertyValue("sourceName", sourceName);
      else if (StringUtils.hasText(name)) {
        builder.addPropertyValue("sourceName", name);
      }

      String checkType = element.getAttribute("checkType");
      if (StringUtils.hasText(checkType)) {
        builder.addPropertyValue("checkType", checkType);
      }

      String desc = element.getAttribute("desc");
      if (StringUtils.hasText(desc)) {
        builder.addPropertyValue("desc", desc);
      }

      if (list.size() > 0)
        builder.addPropertyValue("dataList", list);
    }
    catch (Exception e) {
      parserContext.getReaderContext().error("class " + CLInListParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<CLInputList> getBeanClass(Element element)
  {
    return CLInputList.class;
  }

  private List<BeanDefinition> parseDataListElement(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List propertyList = DomUtils.getChildElements(element);
    ManagedList list = new ManagedList(propertyList.size());
    list.setMergeEnabled(true);
    list.setSource(parserContext.getReaderContext().extractSource(element));

    for (Iterator i$ = propertyList.iterator(); i$.hasNext(); ) { Element propertyElement = (Element)i$.next();
      list.add(parserContext.getDelegate().parseCustomElement(propertyElement, builder.getRawBeanDefinition()));
    }

    return list;
  }
}