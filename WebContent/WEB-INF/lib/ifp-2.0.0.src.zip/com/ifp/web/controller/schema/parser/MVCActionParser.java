package com.ifp.web.controller.schema.parser;

import com.ifp.core.util.StringUtil;
import com.ifp.web.controller.MvcController;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedMap;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class MVCActionParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String id;
    try
    {
      id = element.getAttribute("id");
      builder.addPropertyValue("id", id);
      builder.addPropertyValue("bid", element.getAttribute("bid"));
      String tranCode = element.getAttribute("tranCode");
      if (StringUtil.hasText(tranCode))
        builder.addPropertyValue("tranCode", tranCode);
      else
        builder.addPropertyValue("tranCode", id);

      builder.addPropertyValue("requestType", element.getAttribute("requestType"));
      builder.addPropertyValue("securityType", element.getAttribute("securityType"));
      builder.addPropertyValue("checkSession", Boolean.valueOf(StringUtil.hasText(element.getAttribute("sessionName"))));
      builder.addPropertyValue("sessionName", element.getAttribute("sessionName"));
      builder.addPropertyValue("desc", element.getAttribute("desc"));
      builder.addPropertyValue("dubboFlow", Boolean.valueOf(Boolean.parseBoolean(StringUtil.getText(element.getAttribute("dubboFlow"), "false").toLowerCase())));
      builder.addPropertyValue("execFlow", Boolean.valueOf(Boolean.parseBoolean(StringUtil.getText(element.getAttribute("execFlow"), "true").toLowerCase())));
      builder.addPropertyValue("mvcInterceptorsMap", parseInterceptorsElement("interceptors", "views", element, parserContext, builder));
      builder.addPropertyValue("mvcCommonName", parseCommonElement("commonName", element, parserContext, builder));

      builder.addPropertyValue("inputParamsList", parseElement("input", element, parserContext, builder));
      builder.addPropertyValue("outputParamsList", parseElement("output", element, parserContext, builder));
    }
    catch (Exception e) {
      parserContext.getReaderContext().error("class " + MVCActionParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<MvcController> getBeanClass(Element element)
  {
    return MvcController.class;
  }

  private Map<String, Object> parseInterceptorsElement(String interceptorTagName, String viewTagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    List elist = DomUtils.getChildElements(element);
    ManagedMap map = new ManagedMap(elist.size());
    map.setMergeEnabled(true);
    map.setSource(parserContext.getReaderContext().extractSource(element));
    for (int i = 0; i < elist.size(); ++i)
    {
      Element childElement = (Element)elist.get(i);
      String nodeName = childElement.getNodeName();
      ManagedMap childMap = new ManagedMap();
      childMap.setMergeEnabled(true);
      childMap.setSource(parserContext.getReaderContext().extractSource(element));
      int idx = nodeName.indexOf(":");
      if (idx != -1)
      {
        nodeName = nodeName.substring(idx + 1, nodeName.length());
      }
      if (nodeName.equals(interceptorTagName))
      {
        childMap.put("test", null);
        childMap.put("type", "interceptorsList");
        childMap.put("interceptorsList", parserContext.getDelegate().parseCustomElement(childElement, builder.getRawBeanDefinition()));
        childMap.put("viewsList", null);
        childMap.put("commonName", null);
      } else if (nodeName.equals(viewTagName))
      {
        childMap.put("test", null);
        childMap.put("type", "view");
        childMap.put("interceptorsList", null);
        childMap.put("viewsList", parserContext.getDelegate().parseCustomElement(childElement, builder.getRawBeanDefinition()));
        childMap.put("commonName", null); } else {
        String test;
        if (nodeName.equals("if")) {
          test = childElement.getAttribute("test");
          childMap.put("test", test);
          childMap.put("type", "if");
          childMap.put("interceptorsList", parseChildElement(interceptorTagName, childElement, parserContext, builder));
          childMap.put("viewsList", parseChildElement(viewTagName, childElement, parserContext, builder));
          childMap.put("commonName", parseCommonElement("commonName", childElement, parserContext, builder));
        } else if (nodeName.equals("elseif")) {
          test = childElement.getAttribute("test");
          childMap.put("test", test);
          childMap.put("type", "elseif");
          childMap.put("interceptorsList", parseChildElement(interceptorTagName, childElement, parserContext, builder));
          childMap.put("viewsList", parseChildElement(viewTagName, childElement, parserContext, builder));
          childMap.put("commonName", parseCommonElement("commonName", childElement, parserContext, builder));
        } else if (nodeName.equals("else")) {
          childMap.put("test", null);
          childMap.put("type", "else");
          childMap.put("interceptorsList", parseChildElement(interceptorTagName, childElement, parserContext, builder));
          childMap.put("viewsList", parseChildElement(viewTagName, childElement, parserContext, builder));
          childMap.put("commonName", parseCommonElement("commonName", childElement, parserContext, builder)); }
      }
      map.put(String.valueOf(i), childMap);
    }
    return map;
  }

  private BeanDefinition parseChildElement(String tagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    List inputList = DomUtils.getChildElementsByTagName(element, tagName);
    if (inputList.size() > 0)
    {
      Element inputElement = (Element)inputList.get(0);
      BeanDefinition beanDefinition = parserContext.getDelegate().parseCustomElement(inputElement, builder.getRawBeanDefinition());
      return beanDefinition;
    }
    return null;
  }

  private String parseCommonElement(String tagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    List inputList = DomUtils.getChildElementsByTagName(element, tagName);
    if (inputList.size() > 0)
    {
      Element inputElement = (Element)inputList.get(0);
      return inputElement.getAttribute("name");
    }
    return null;
  }

  private BeanDefinition parseElement(String tagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    List inputList = DomUtils.getChildElementsByTagName(element, tagName);
    if (inputList.size() < 1) return null;
    Element inputElement = (Element)inputList.get(0);
    BeanDefinition beanDefinition = parserContext.getDelegate().parseCustomElement(inputElement, builder.getRawBeanDefinition());
    return beanDefinition;
  }
}