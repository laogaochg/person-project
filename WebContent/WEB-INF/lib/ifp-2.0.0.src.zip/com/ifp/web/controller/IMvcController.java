package com.ifp.web.controller;

import com.ifp.core.data.DataList;
import java.util.Map;

public abstract interface IMvcController
{
  public abstract String getId();

  public abstract void setId(String paramString);

  public abstract String getBid();

  public abstract void setBid(String paramString);

  public abstract String getTranCode();

  public abstract void setTranCode(String paramString);

  public abstract void setCheckSession(boolean paramBoolean);

  public abstract boolean isCheckSession();

  public abstract String getSessionName();

  public abstract void setSessionName(String paramString);

  public abstract boolean isDubboFlow();

  public abstract void setDubboFlow(boolean paramBoolean);

  public abstract Map<String, Object> getMvcInterceptorsMap();

  public abstract void setMvcInterceptorsMap(Map<String, Object> paramMap);

  public abstract String getMvcCommonName();

  public abstract void setMvcCommonName(String paramString);

  public abstract String getSecurityType();

  public abstract void setSecurityType(String paramString);

  public abstract String getRequestType();

  public abstract void setRequestType(String paramString);

  public abstract DataList getInputParamsList();

  public abstract void setInputParamsList(DataList paramDataList);

  public abstract DataList getOutputParamsList();

  public abstract void setOutputParamsList(DataList paramDataList);

  public abstract String getDesc();

  public abstract void setDesc(String paramString);

  public abstract boolean isExecFlow();

  public abstract void setExecFlow(boolean paramBoolean);
}