package com.ifp.web.controller;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.spel.SpELHandle;
import com.ifp.web.data.MvcView;
import com.ifp.web.interceptor.IFPInterceptor;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;

public abstract interface IController
{
  public abstract void executePreHandle(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, ClogicContext paramClogicContext, List<IFPInterceptor> paramList)
    throws BaseException;

  public abstract void executePostHandle(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, ClogicContext paramClogicContext, List<IFPInterceptor> paramList, ModelAndView paramModelAndView)
    throws BaseException;

  public abstract IMvcController getMvcController();

  public abstract void setMvcController(IMvcController paramIMvcController);

  public abstract void setSpELHandle(SpELHandle paramSpELHandle);

  public abstract Map<String, IFPInterceptor> getInterceptorMap();

  public abstract void setInterceptorMap(Map<String, IFPInterceptor> paramMap);

  public abstract Map<String, MvcView> getViewMap();

  public abstract void setViewMap(Map<String, MvcView> paramMap);

  public abstract Map<String, Map<String, String>> getAttributesMap();

  public abstract void setAttributesMap(Map<String, Map<String, String>> paramMap);
}