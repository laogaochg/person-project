package com.ifp.web.inout.schema.parser;

import com.ifp.web.inout.bean.ListDefine;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedMap;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.StringUtils;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class ListParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String name;
    try
    {
      name = element.getAttribute("name");
      if (StringUtils.hasText(name)) {
        builder.addPropertyValue("name", name);
      }

      String refName = element.getAttribute("refName");
      if (StringUtils.hasText(refName)) {
        builder.addPropertyValue("refName", refName);
      }

      String need = element.getAttribute("need");
      if (StringUtils.hasText(need)) {
        builder.addPropertyValue("need", need);
      }

      Map map = parseDataMapElement(element, parserContext, builder);
      if (null != map)
        builder.addConstructorArgValue(map);
    }
    catch (Exception e) {
      parserContext.getReaderContext().error("class " + ListParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<ListDefine> getBeanClass(Element element)
  {
    return ListDefine.class;
  }

  private Map<String, BeanDefinition> parseDataMapElement(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List propertyList = DomUtils.getChildElements(element);
    ManagedMap map = new ManagedMap(propertyList.size());
    map.setMergeEnabled(true);
    map.setSource(parserContext.getReaderContext().extractSource(element));

    for (Iterator i$ = propertyList.iterator(); i$.hasNext(); ) { Element propertyElement = (Element)i$.next();
      String name = propertyElement.getAttribute("name");
      map.put(name, parserContext.getDelegate().parseCustomElement(propertyElement, builder.getRawBeanDefinition()));
    }

    return map;
  }
}