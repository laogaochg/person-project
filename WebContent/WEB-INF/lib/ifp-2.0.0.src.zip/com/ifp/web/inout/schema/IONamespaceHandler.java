package com.ifp.web.inout.schema;

import com.ifp.web.inout.schema.parser.FieldParser;
import com.ifp.web.inout.schema.parser.GroupParser;
import com.ifp.web.inout.schema.parser.ListParser;
import com.ifp.web.inout.schema.parser.MessageParser;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

public class IONamespaceHandler extends NamespaceHandlerSupport
{
  public void init()
  {
    registerBeanDefinitionParser("message", new MessageParser());
    registerBeanDefinitionParser("group", new GroupParser());
    registerBeanDefinitionParser("list", new ListParser());
    registerBeanDefinitionParser("field", new FieldParser());
  }
}