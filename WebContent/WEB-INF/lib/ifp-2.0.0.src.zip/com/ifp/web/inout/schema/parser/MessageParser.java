package com.ifp.web.inout.schema.parser;

import com.ifp.web.inout.bean.MessageDefine;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedMap;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.StringUtils;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class MessageParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    try
    {
      builder.addPropertyValue("id", element.getAttribute("id"));

      String name = element.getAttribute("name");
      if (StringUtils.hasText(name)) {
        builder.addPropertyValue("name", name);
      }

      Map map = parseDataMapElement(element, parserContext, builder);
      if (map.size() > 0)
        builder.addPropertyValue("group", map);
    }
    catch (Exception e) {
      parserContext.getReaderContext().error("class " + MessageParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<MessageDefine> getBeanClass(Element element)
  {
    return MessageDefine.class;
  }

  private Map<String, BeanDefinition> parseDataMapElement(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List propertyList = DomUtils.getChildElements(element);
    ManagedMap map = new ManagedMap(propertyList.size());
    map.setMergeEnabled(true);
    map.setSource(parserContext.getReaderContext().extractSource(element));

    for (Iterator i$ = propertyList.iterator(); i$.hasNext(); ) { Element propertyElement = (Element)i$.next();
      String name = propertyElement.getAttribute("name");
      map.put(name, parserContext.getDelegate().parseCustomElement(propertyElement, builder.getRawBeanDefinition()));
    }

    return map;
  }
}