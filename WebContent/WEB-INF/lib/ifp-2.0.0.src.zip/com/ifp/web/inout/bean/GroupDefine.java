package com.ifp.web.inout.bean;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataMap;
import java.util.Map;

public class GroupDefine extends DataMap
{
  private String type;
  private boolean need = true;

  public GroupDefine()
  {
    setChange(false);
  }

  public GroupDefine(String name) {
    setName(name);
    setChange(false);
  }

  public GroupDefine(String name, boolean isChange) {
    setName(name);
    setChange(isChange);
  }

  public GroupDefine(boolean isChange) {
    setChange(isChange);
  }

  public GroupDefine(Map<String, DataElement> map) {
    super(map);
  }

  public GroupDefine(String name, Map<String, DataElement> map) {
    super(name, map);
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public boolean isNeed() {
    return this.need;
  }

  public void setNeed(boolean need) {
    this.need = need;
  }
}