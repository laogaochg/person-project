package com.ifp.web.inout.bean;

import java.util.Map;

public class MessageDefine
{
  private String id;
  private String name;
  private Map<String, GroupDefine> group;

  public MessageDefine()
  {
    this.name = "document";
  }

  public GroupDefine getGroupByKey(String key)
  {
    return ((GroupDefine)this.group.get(key));
  }

  public String getId() {
    return this.id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Map<String, GroupDefine> getGroup() {
    return this.group;
  }

  public void setGroup(Map<String, GroupDefine> group) {
    this.group = group;
  }
}