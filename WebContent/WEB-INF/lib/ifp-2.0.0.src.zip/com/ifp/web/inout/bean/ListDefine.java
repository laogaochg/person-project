package com.ifp.web.inout.bean;

import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataMap;
import java.util.Map;

public class ListDefine extends DataMap
{
  private String refName;
  private boolean need = true;

  public ListDefine()
  {
    setChange(false);
  }

  public ListDefine(String name) {
    setName(name);
    setChange(false);
  }

  public ListDefine(String name, boolean isChange) {
    setName(name);
    setChange(isChange);
  }

  public ListDefine(boolean isChange) {
    setChange(isChange);
  }

  public ListDefine(Map<String, DataElement> map) {
    super(map);
  }

  public ListDefine(String name, Map<String, DataElement> map) {
    super(name, map);
  }

  public String getRefName() {
    return this.refName;
  }

  public void setRefName(String refName) {
    this.refName = refName;
  }

  public boolean isNeed() {
    return this.need;
  }

  public void setNeed(boolean need) {
    this.need = need;
  }
}