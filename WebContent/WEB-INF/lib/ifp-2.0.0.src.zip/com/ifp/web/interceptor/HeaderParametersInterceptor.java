package com.ifp.web.interceptor;

import com.ifp.adapter.message.field.MessageField;
import com.ifp.adapter.message.head.DefaultHead;
import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import com.ifp.web.common.IFPConstance;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HeaderParametersInterceptor extends IFPInterceptorAdapter
{
  private DefaultHead requestHead;
  private DefaultHead responseHead;

  public void preHandle(IContext context)
    throws BaseException
  {
    ClogicContext clogicContext = (ClogicContext)context;

    String securityType = clogicContext.getSecurityType();
    if ((StringUtil.hasText(securityType)) && (securityType.length() > 1) && (securityType.substring(1, 2).equals("1")))
      return;
    try
    {
      if (null != this.requestHead) {
        Map dataMap = (Map)clogicContext.getDataMap();
        List fieldOrder = this.requestHead.getFieldOrder();
        for (int i = 0; i < fieldOrder.size(); ++i) {
          Object obj = dataMap.get(((MessageField)fieldOrder.get(i)).getName());

          if ((((MessageField)fieldOrder.get(i)).getMustsent().booleanValue()) && (obj == null)) {
            Trace.log("INTERCEPTOR", 2, "is a Unqualified request... " + ((MessageField)fieldOrder.get(i)).getName() + " is Mustsent");

            throw IFPConstance.VALIDATIONEXCEPTION;
          }

          if ((obj != null) && ("".equals((String)obj)) && (((MessageField)fieldOrder.get(i)).getNotnull().booleanValue())) {
            Trace.log("INTERCEPTOR", 2, "is a Unqualified request... " + ((MessageField)fieldOrder.get(i)).getName() + "'s value is null");

            throw IFPConstance.VALIDATIONEXCEPTION;
          }
        }
      }
    }
    catch (BaseException e) {
      Trace.log("INTERCEPTOR", 3, "ValidationHeaderInterceptor Error...", e);
      throw e;
    } catch (Exception e) {
      Trace.log("INTERCEPTOR", 3, "ValidationHeaderInterceptor Error...", e);
      throw new BaseException(e);
    }
  }

  public void postHandle(IContext context) throws BaseException {
    ClogicContext clogicContext;
    try {
      clogicContext = (ClogicContext)context;

      String securityType = clogicContext.getSecurityType();
      if ((StringUtil.hasText(securityType)) && (securityType.length() > 1) && (securityType.substring(1, 2).equals("1")))
        return;

      if (null != this.responseHead) {
        Map headMap = (Map)((Map)clogicContext.getDataMap()).get("header");
        Map newHeadMap = new HashMap();
        List fieldOrder = this.responseHead.getFieldOrder();
        for (int i = 0; i < fieldOrder.size(); ++i) {
          Object obj;
          MessageField messageField = (MessageField)fieldOrder.get(i);
          String key = messageField.getName();

          if (headMap.containsKey(key))
            obj = headMap.get(key);
          else {
            obj = ((Map)clogicContext.getDataMap()).get(key);
          }

          if ((!(StringUtil.hasText((String)obj))) && (StringUtil.hasText(messageField.getDefault()))) {
            obj = messageField.getDefault();
          }

          if ((messageField.getNotnull().booleanValue()) && (!(StringUtil.hasText((String)obj))) && (messageField.getMustsent().booleanValue())) {
            Trace.log("INTERCEPTOR", 2, "is a Unqualified request... " + messageField.getName() + "'s value is null");

            throw IFPConstance.VALIDATIONEXCEPTION;
          }
          if ((!(StringUtil.hasText(obj))) && (!(messageField.getMustsent().booleanValue()))) { break label297:
          }

          label297: newHeadMap.put(key, obj);
        }

        ((Map)clogicContext.getDataMap()).put("header", newHeadMap);
      }
    } catch (BaseException e) {
      Trace.log("INTERCEPTOR", 3, "ValidationHeaderInterceptor Error...", e);
      throw e;
    } catch (Exception e) {
      Trace.log("INTERCEPTOR", 3, "ValidationHeaderInterceptor Error...", e);
      throw new BaseException(e);
    }
  }

  public DefaultHead getRequestHead() {
    return this.requestHead;
  }

  public void setRequestHead(DefaultHead requestHead) {
    this.requestHead = requestHead;
  }

  public DefaultHead getResponseHead() {
    return this.responseHead;
  }

  public void setResponseHead(DefaultHead responseHead) {
    this.responseHead = responseHead;
  }
}