package com.ifp.web.interceptor;

import com.ifp.adapter.message.field.MessageField;
import com.ifp.adapter.message.head.DefaultHead;
import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.web.common.IFPConstance;
import java.util.List;
import java.util.Map;

public class ValidationHeaderInterceptor extends IFPInterceptorAdapter
{
  private DefaultHead head;
  private List passActionList;

  public ValidationHeaderInterceptor()
  {
    this.head = null;
  }

  public void preHandle(IContext context)
    throws BaseException
  {
    try
    {
      if (context == null) {
        throw IFPConstance.VALIDATIONEXCEPTION;
      }

      ClogicContext clogicContext = (ClogicContext)context;

      if ((this.passActionList != null) && (this.passActionList.contains(clogicContext.getTransCode())))
      {
        return;
      }
      Map dataMap = (Map)clogicContext.getDataMap();
      if (null == this.head) {
        this.head = ((DefaultHead)SpringContextsUtil.getBean("httpHead"));
      }

      List fieldOrder = this.head.getFieldOrder();
      for (int i = 0; i < fieldOrder.size(); ++i) {
        MessageField msgField = (MessageField)fieldOrder.get(i);
        Object obj = dataMap.get(msgField.getName());
        if ((msgField.getNotnull().booleanValue()) && (((obj == null) || ("".equals((String)obj))))) {
          Trace.log("INTERCEPTOR", 2, "is a Unqualified request... " + ((MessageField)fieldOrder.get(i)).getName() + "'s value is null");

          throw IFPConstance.VALIDATIONEXCEPTION;
        }
      }
    } catch (BaseException e) {
      Trace.log("INTERCEPTOR", 3, "ValidationHeaderInterceptor Error...", e);
      throw e;
    } catch (Exception e) {
      Trace.log("INTERCEPTOR", 3, "ValidationHeaderInterceptor Error...", e);
      throw new BaseException(e);
    }
  }

  public List getPassActionList()
  {
    return this.passActionList;
  }

  public void setPassActionList(List passActionList) {
    this.passActionList = passActionList;
  }

  public DefaultHead getHead() {
    return this.head;
  }

  public void setHead(DefaultHead head) {
    this.head = head;
  }
}