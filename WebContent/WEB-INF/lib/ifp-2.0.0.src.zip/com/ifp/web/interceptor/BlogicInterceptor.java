package com.ifp.web.interceptor;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.FlowHandle;
import com.ifp.core.flow.logic.BusinessLogic;
import com.ifp.core.flow.util.ContextMapChangeUtil;
import com.ifp.core.log.FlumeLogInf;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.LogThread;
import com.ifp.core.log.Trace;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.DateUtil;
import com.ifp.core.util.SpringContextsUtil;
import java.util.List;
import java.util.Map;

public class BlogicInterceptor extends IFPInterceptorAdapter
{
  private FlowHandle blFlowHandle;

  public BlogicInterceptor()
  {
    this.blFlowHandle = ((FlowHandle)SpringContextsUtil.getBean("blFlowHandle"));
  }

  public void preHandle(IContext context) throws BaseException {
    ClogicContext clogicContext = (ClogicContext)context;
    BlogicContext blogicContext = new BlogicContext();
    String logicId = clogicContext.getLogicCode();
    blogicContext.setLogicCode(logicId);
    blogicContext.setCreateTime(DateUtil.getStringToday());
    blogicContext.setMonitorId(clogicContext.getMonitorId());
    BusinessLogic businessLogic = (BusinessLogic)this.blFlowHandle.getLogic(logicId);
    this.monitorManager.setCurrentMonitorStep(clogicContext.getMonitorId(), "BL00");

    ContextMapChangeUtil.doUpdateInputDataMap((Map)clogicContext.getDataMap(), blogicContext, businessLogic, true);
    this.blFlowHandle.setMonitorManager(this.monitorManager);
    Trace.log("MVC", 1, "begin to execute businessLogic:{}", new Object[] { logicId });

    List flumeLogInfList = this.logHandle.getLogThread().getFlumeLogInfList();
    if (flumeLogInfList.size() > 0) {
      FlumeLogInf flumeLogInf = (FlumeLogInf)flumeLogInfList.get(flumeLogInfList.size() - 1);
      String flumeReqId = flumeLogInf.getFlumeReqid();
      String flumeCid = flumeLogInf.getFlumeCid();
      ((DataMap)blogicContext.getDataMap()).put("reqId", new DataField("reqId", flumeReqId));
      ((DataMap)blogicContext.getDataMap()).put("pcid", new DataField("pcid", flumeCid));
      ((DataMap)blogicContext.getDataMap()).put("cid", new DataField("cid", flumeCid));
    }
    try {
      String result = this.blFlowHandle.execute(businessLogic, blogicContext);
      Trace.log("MVC", 1, "end execute businessLogic:{},result is :{}", new Object[] { logicId, result });

      ContextMapChangeUtil.doUpdateOutputDataMap((Map)clogicContext.getDataMap(), businessLogic, blogicContext, true);
      clogicContext.setValue("blogicResult", result);
    }
    finally {
      clogicContext.setValue("logFieldDefine", blogicContext.getTemp("logFieldDefine"));
    }
  }
}