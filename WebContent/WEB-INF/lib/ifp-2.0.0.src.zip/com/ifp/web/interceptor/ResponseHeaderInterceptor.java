package com.ifp.web.interceptor;

import com.ifp.core.context.IContext;

public class ResponseHeaderInterceptor extends IFPInterceptorAdapter
{
  public void preHandle(IContext context)
  {
  }
}