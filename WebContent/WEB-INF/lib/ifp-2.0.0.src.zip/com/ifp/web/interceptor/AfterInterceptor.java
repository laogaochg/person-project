package com.ifp.web.interceptor;

import com.ifp.core.context.IContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AfterInterceptor extends IFPInterceptorAdapter
{
  public void preHandle(IContext context)
  {
  }

  public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object context, Exception e)
    throws Exception
  {
  }
}