package com.ifp.web.interceptor;

public class RedirectLocaitonInterceptor extends IFPInterceptorAdapter
{
}