package com.ifp.web.interceptor;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.session.Session;
import com.ifp.core.session.SessionManager;
import com.ifp.core.util.SpringContextsUtil;
import java.util.Map;

public class checkLoginSessionInterceptor extends IFPInterceptorAdapter
{
  protected SessionManager sessionManager;

  public checkLoginSessionInterceptor()
  {
    this.sessionManager = ((SessionManager)SpringContextsUtil.getBean("sessionManager"));
  }

  public void preHandle(IContext context) throws BaseException
  {
    ClogicContext cContext = (ClogicContext)context;
    Map dataMap = (Map)cContext.getDataMap();
    String sessionId = (String)dataMap.get(cContext.getSessionName());
    Session session = this.sessionManager.getSession(cContext.getSessionName(), sessionId);
    if (session == null) throw new BaseException();
    this.sessionManager.updateSession(session);
  }
}