package com.ifp.web.interceptor;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.util.StringUtil;
import com.ifp.web.exception.ChannelFlowIllegitimateException;
import com.ifp.web.exception.RepetitionSubmitException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;

public class CheckReSubmitInterceptor extends IFPInterceptorAdapter
{
  private Map<String, String> channelConfMap;
  private Map<String, Map<Long, String>> channelMap;
  private Map<String, Long> channelMaxMap;
  private Map<String, ReadWriteLock> channelLockMap;
  private String channelIdName;
  private String channelFlowName;

  public CheckReSubmitInterceptor()
  {
    this.channelMap = new HashMap();
    this.channelMaxMap = new HashMap();
    this.channelLockMap = new HashMap();
    this.channelIdName = "channelId";
    this.channelFlowName = "channelFlow";
  }

  public void preHandle(IContext context) throws BaseException {
    ClogicContext c = (ClogicContext)context;
    String channelId = (String)c.getValue(this.channelIdName);
    String channelFlow = (String)c.getValue(this.channelFlowName);
    if (StringUtil.hasText(channelId))
      try {
        ReadWriteLock lock = (ReadWriteLock)this.channelLockMap.get(channelId);
        Map map = (Map)this.channelMap.get(channelId);
        if (null != map) {
          String value;
          String confStr = (String)this.channelConfMap.get(channelId);
          String[] confs = confStr.split(",");

          String dateStr = channelFlow.substring(Integer.parseInt(confs[0]), Integer.parseInt(confs[1]));
          SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
          Long key = Long.valueOf(formatter.parse(dateStr).getTime() / 1000L);

          Long maxKey = (Long)this.channelMaxMap.get(channelId);

          if (key.longValue() > maxKey.longValue()) {
            try {
              lock.writeLock().lock();
              value = (String)map.get(key);
              if (null != value) {
                if (value.indexOf("#" + channelFlow + "#") < 0) {
                  map.put(key, value + channelFlow + "#"); break label343:
                }
                throw new RepetitionSubmitException("channelFlow:" + channelFlow);
              }

              label343: map.put(key, "#" + channelFlow + "#");
            }
            finally {
              lock.writeLock().unlock();
            }
            label550: this.channelMaxMap.put(channelId, key);
          } else {
            try {
              lock.writeLock().lock();
              value = (String)map.get(key);
              if (null != value) {
                if (value.indexOf("#" + channelFlow + "#") < 0) {
                  map.put(key, value + channelFlow + "#"); break label550:
                }
                throw new RepetitionSubmitException("channelFlow:" + channelFlow);
              }

              throw new ChannelFlowIllegitimateException("channelFlow:" + channelFlow);
            }
            finally {
              lock.writeLock().unlock();
            }
          }
        }
      } catch (BaseException e) {
        throw e;
      } catch (Exception e) {
        new BaseException(e);
      }
  }

  public boolean checkReSubmit(String channelFlow)
  {
    return false;
  }
}