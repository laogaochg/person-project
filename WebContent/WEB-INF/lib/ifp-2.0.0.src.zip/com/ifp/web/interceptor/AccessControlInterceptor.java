package com.ifp.web.interceptor;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.listener.ISettingReloadListener;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import com.ifp.web.exception.OverMaxAccessException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class AccessControlInterceptor extends IFPInterceptorAdapter
  implements ISettingReloadListener
{
  private boolean switchAll;
  private boolean switchChannel;
  private boolean switchTransaction;
  private int maxAll;
  private int currAll;
  private String channelId;
  private Map<String, Integer> accessMap;
  private Map<String, Integer> accessCountMap;
  private Map<String, Integer> transCodeMap;
  private Map<String, Integer> transCodeCountMap;
  private int printAccessInfoFlag;
  private ReadWriteLock lock;

  public AccessControlInterceptor()
  {
    this.switchAll = false;

    this.switchChannel = false;

    this.switchTransaction = false;

    this.maxAll = -1;

    this.currAll = 0;

    this.channelId = "channelId";

    this.accessMap = new HashMap();
    this.accessCountMap = new HashMap();
    this.transCodeMap = new HashMap();
    this.transCodeCountMap = new HashMap();

    this.printAccessInfoFlag = 1;

    this.lock = new ReentrantReadWriteLock();
  }

  public synchronized void reload() {
    this.lock.writeLock().lock();

    this.switchAll = getSystemConf().getBooleanConfByKey("security.access.concurrent.switch.all", this.switchAll);
    this.switchChannel = getSystemConf().getBooleanConfByKey("security.access.concurrent.switch.channel", this.switchChannel);
    this.switchTransaction = getSystemConf().getBooleanConfByKey("security.access.concurrent.switch.transaction", this.switchTransaction);

    this.printAccessInfoFlag = getSystemConf().getIntConfByKey("security.access.concurrent.printAccessInfoFlag", this.printAccessInfoFlag);

    this.maxAll = getSystemConf().getIntConfByKey("security.access.concurrent.number.max", this.maxAll);

    Map channelSettingMap = (Map)getSystemConf().getConfByKey("security.access.concurrent.number.channel");
    if (null != channelSettingMap) {
      Iterator keyIterator = channelSettingMap.keySet().iterator();
      while (keyIterator.hasNext()) {
        String key = (String)keyIterator.next();
        this.accessMap.put(key, Integer.valueOf(Integer.parseInt((String)channelSettingMap.get(key))));
      }

      setAccessMap(this.accessMap);
    }

    Map transSettingMap = (Map)getSystemConf().getConfByKey("security.access.concurrent.number.transaction");
    if (null != transSettingMap) {
      Iterator keyIterator = transSettingMap.keySet().iterator();
      while (keyIterator.hasNext()) {
        String key = (String)keyIterator.next();
        this.transCodeMap.put(key, Integer.valueOf(Integer.parseInt((String)transSettingMap.get(key))));
      }

      setTransCodeMap(this.transCodeMap);
    }

    this.lock.writeLock().unlock();
  }

  public void preHandle(IContext context) throws BaseException
  {
    ClogicContext c = (ClogicContext)context;
    int step = 0;
    int totalCount = -1;
    int channelCount = -1;
    int transCodeCount = -1;
    String currChannelId = (String)c.getValue(this.channelId);
    String transCode = c.getTransCode();
    try
    {
      this.lock.readLock().lock();
      if ((this.switchAll) && (this.maxAll > 0))
        synchronized (this) {
          if (this.currAll < this.maxAll) {
            this.currAll += 1;
            totalCount = this.currAll;
          } else {
            throw new OverMaxAccessException("SYEC1001", "access concurrent over max access! maxAll:" + this.maxAll + ", currAll:" + this.currAll);
          }
        }


      ++step;

      if ((this.switchChannel) && (this.accessMap.size() > 0) && (StringUtil.hasText(currChannelId)))
      {
        Integer maxAcc = (Integer)this.accessMap.get(currChannelId);
        if (null != maxAcc)
          synchronized (maxAcc) {
            ??? = ((Integer)this.accessCountMap.get(currChannelId)).intValue();
            if (??? < maxAcc.intValue()) {
              channelCount = ++???;
              this.accessCountMap.put(currChannelId, Integer.valueOf(channelCount));
            } else {
              throw new OverMaxAccessException("SYEC1001", "access concurrent over channel[" + currChannelId + "] max access! maxAcc:" + maxAcc + ", currAcc:" + ???);
            }
          }

      }

      ++step;

      if ((this.switchTransaction) && (this.transCodeMap.size() > 0)) {
        String currTransCode = currChannelId + "." + transCode;
        Integer maxAcc = (Integer)this.transCodeMap.get(currTransCode);
        if (null != maxAcc) {
          synchronized (maxAcc) {
            int currAcc = ((Integer)this.transCodeCountMap.get(currTransCode)).intValue();
            if (currAcc < maxAcc.intValue()) {
              transCodeCount = ++currAcc;
              this.transCodeCountMap.put(currTransCode, Integer.valueOf(transCodeCount));
            } else {
              throw new OverMaxAccessException("SYEC1001", "access concurrent over transCode[" + currTransCode + "] max access! maxAcc:" + maxAcc + ", currAcc:" + currAcc);
            }

          }

        }

      }

    }
    catch (BaseException e)
    {
    }
    catch (Exception e)
    {
    }
    finally
    {
      if (this.printAccessInfoFlag > 0)
        Trace.log("ACCESS", 1, "access concurrent [{}.{}] all:{}, channel:{}, transCode:{}", new Object[] { currChannelId, transCode, Integer.valueOf(totalCount), Integer.valueOf(channelCount), Integer.valueOf(transCodeCount) });

      this.lock.readLock().unlock();
    }
  }

  private int releaseChannelMax(String channelId)
  {
    int cAcc = -1;
    if ((this.switchChannel) && (this.accessMap.size() > 0) && (StringUtil.hasText(channelId))) {
      Integer maxAcc = (Integer)this.accessMap.get(channelId);
      if (null != maxAcc)
        synchronized (maxAcc) {
          Integer currAcc = (Integer)this.accessCountMap.get(channelId);
          cAcc = ((currAcc = Integer.valueOf(currAcc.intValue() - 1)).intValue() > 0) ? currAcc.intValue() : 0;
          this.accessCountMap.put(channelId, Integer.valueOf(cAcc));
        }
    }

    return cAcc;
  }

  private void releaseMax()
  {
    if ((this.switchAll) && (this.maxAll > 0))
      synchronized (this) {
        this.currAll = ((--this.currAll > 0) ? this.currAll : 0);
      }
  }

  public void afterCompletion(IContext context, BaseException exception)
    throws BaseException
  {
    ClogicContext c = (ClogicContext)context;
    int totalCount = -1;
    int channelCount = -1;
    int transCodeCount = -1;
    String currChannelId = (String)c.getValue(this.channelId);
    String transCode = c.getTransCode();
    try
    {
      this.lock.readLock().lock();
      if (this.maxAll > 0) {
        synchronized (this) {
          this.currAll = ((--this.currAll > 0) ? this.currAll : 0);
          totalCount = this.currAll;
        }

      }

      channelCount = releaseChannelMax(currChannelId);

      if ((this.switchTransaction) && (this.transCodeMap.size() > 0)) {
        String currTransCode = currChannelId + "." + transCode;
        Integer maxAcc = (Integer)this.transCodeMap.get(currTransCode);
        if (null != maxAcc)
          synchronized (maxAcc) {
            int currAcc = ((Integer)this.transCodeCountMap.get(currTransCode)).intValue();
            transCodeCount = (--currAcc > 0) ? currAcc : 0;
            this.transCodeCountMap.put(currTransCode, Integer.valueOf(transCodeCount));
          }

      }

      if (this.printAccessInfoFlag > 0)
        Trace.log("ACCESS", 1, "access concurrent [{}.{}] all:{}, channel:{}, transCode:{}", new Object[] { currChannelId, transCode, Integer.valueOf(totalCount), Integer.valueOf(channelCount), Integer.valueOf(transCodeCount) });
    }
    finally {
      this.lock.readLock().unlock();
    }
  }

  public Map<String, Integer> getAccessMap() {
    return this.accessMap;
  }

  public void setAccessMap(Map<String, Integer> accessMap) {
    this.accessCountMap.clear();
    Iterator iter = accessMap.keySet().iterator();
    while (iter.hasNext()) {
      String key = (String)iter.next();
      int max = ((Integer)accessMap.get(key)).intValue();
      if (max > 0)
        this.accessCountMap.put(key, Integer.valueOf(0));
      else
        accessMap.remove(key);

    }

    this.accessMap = accessMap;
  }

  public String getChannelId() {
    return this.channelId;
  }

  public void setChannelId(String channelId) {
    this.channelId = channelId;
  }

  public int getMaxAll() {
    return this.maxAll;
  }

  public void setMaxAll(int maxAll) {
    this.maxAll = maxAll;
  }

  public Map<String, Integer> getTransCodeMap() {
    return this.transCodeMap;
  }

  public void setTransCodeMap(Map<String, Integer> transCodeMap) {
    this.transCodeCountMap.clear();
    Iterator iter = transCodeMap.keySet().iterator();
    while (iter.hasNext()) {
      String key = (String)iter.next();
      int max = ((Integer)transCodeMap.get(key)).intValue();
      if (max > 0)
        this.transCodeCountMap.put(key, Integer.valueOf(0));
      else
        transCodeMap.remove(key);

    }

    this.transCodeMap = transCodeMap;
  }

  public int getPrintAccessInfoFlag() {
    return this.printAccessInfoFlag;
  }

  public void setPrintAccessInfoFlag(int printAccessInfoFlag) {
    this.printAccessInfoFlag = printAccessInfoFlag;
  }

  public boolean isSwitchAll() {
    return this.switchAll;
  }

  public void setSwitchAll(boolean switchAll) {
    this.switchAll = switchAll;
  }

  public boolean isSwitchChannel() {
    return this.switchChannel;
  }

  public void setSwitchChannel(boolean switchChannel) {
    this.switchChannel = switchChannel;
  }

  public boolean isSwitchTransaction() {
    return this.switchTransaction;
  }

  public void setSwitchTransaction(boolean switchTransaction) {
    this.switchTransaction = switchTransaction;
  }
}