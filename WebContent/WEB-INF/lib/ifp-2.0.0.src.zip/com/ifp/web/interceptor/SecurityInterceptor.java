package com.ifp.web.interceptor;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;
import com.ifp.web.security.processor.ISecurityProcessor;
import java.util.Iterator;
import java.util.List;

public class SecurityInterceptor extends IFPInterceptorAdapter
{
  private List<ISecurityProcessor> processorList;

  public void preHandle(IContext context)
    throws BaseException
  {
    ClogicContext ctx = (ClogicContext)context;
    if (null != this.processorList)
      for (Iterator i$ = this.processorList.iterator(); i$.hasNext(); ) { ISecurityProcessor processor = (ISecurityProcessor)i$.next();
        processor.execute(ctx);
      }
  }

  public List<ISecurityProcessor> getProcessorList()
  {
    return this.processorList;
  }

  public void setProcessorList(List<ISecurityProcessor> processorList) {
    this.processorList = processorList;
  }
}