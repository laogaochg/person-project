package com.ifp.web.interceptor;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.web.inout.bean.FieldDefine;
import com.ifp.web.inout.bean.GroupDefine;
import com.ifp.web.inout.bean.ListDefine;
import com.ifp.web.inout.bean.MessageDefine;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class InOutParametersInterceptor extends IFPInterceptorAdapter
{
  private String securityFieldPrefix;

  public InOutParametersInterceptor()
  {
    this.securityFieldPrefix = "#";
  }

  public void preHandle(IContext icontext) throws BaseException {
    ClogicContext context = (ClogicContext)icontext;
    Map dataMap = (Map)context.getDataMap();

    String securityType = context.getSecurityType();
    if ((StringUtil.hasText(securityType)) && (securityType.length() > 2)) {
      String flag = securityType.substring(2, 3);
      if (((!(flag.equals("1"))) && (!(flag.equals("2")))) || 
        (!(dataMap.containsKey("topHead"))) || (
        (!(flag.equals("1"))) && (!(flag.equals("3")))))
        return;
    }
    try
    {
      Map mappingMap = (Map)dataMap.get("encryptDataArea");

      String transCode = context.getTransCode();
      if (StringUtil.hasText(transCode)) {
        MessageDefine messageDefine = (MessageDefine)SpringContextsUtil.getBean("message_" + transCode);
        GroupDefine groupDefine = messageDefine.getGroupByKey("request");
        if ((groupDefine == null) || (groupDefine.equals("null")))
          return;

        Iterator defineIterator = groupDefine.entrySet().iterator();
        while (defineIterator.hasNext()) {
          Map.Entry defineEntry = (Map.Entry)defineIterator.next();
          DataElement defineElement = (DataElement)defineEntry.getValue();
          if (defineElement instanceof GroupDefine)
            unformatGroup(dataMap, (GroupDefine)defineElement, mappingMap);
          else
            unformatElement(dataMap, defineElement, mappingMap);
        }
      }

      dataMap.put("body", new HashMap());
    } catch (BaseException e) {
      Trace.log("INTERCEPTOR", 3, "报文校验失败:", e);
      throw e;
    } catch (Exception e) {
      Trace.log("INTERCEPTOR", 3, "报文校验失败:", e);
      throw new BaseException(e);
    }
  }

  private void unformatGroup(Map<String, Object> dataMap, GroupDefine groupDefine, Map<String, String> mappingMap)
    throws Exception
  {
    Object groupObj = dataMap.get(groupDefine.getName());
    if ((groupObj != null) && (groupObj instanceof Map)) {
      Map groupMap = (Map)groupObj;
      Iterator defineIterator = groupDefine.entrySet().iterator();
      while (defineIterator.hasNext()) {
        Map.Entry defineEntry = (Map.Entry)defineIterator.next();
        DataElement defineElement = (DataElement)defineEntry.getValue();
        if (defineElement instanceof GroupDefine)
          unformatGroup(groupMap, (GroupDefine)defineElement, mappingMap);
        else
          unformatElement(groupMap, defineElement, mappingMap);
      }

      dataMap.putAll(groupMap);
    }
  }

  private void unformatElement(Map<String, Object> dataMap, DataElement defineElement, Map<String, String> mappingMap) throws Exception
  {
    if (defineElement instanceof FieldDefine) {
      unformatField(dataMap, (FieldDefine)defineElement, mappingMap);
    } else if (defineElement instanceof ListDefine) {
      ListDefine listDefine = (ListDefine)defineElement;
      String key = listDefine.getName();
      String refName = listDefine.getRefName();
      if (!(StringUtil.hasText(refName)))
        refName = key;

      List list = null;
      if (!(dataMap.containsKey(key))) {
        if (!(listDefine.isNeed())) break label124;
        throw new BaseException("CHECKERR0001", key + " 为必输项!");
      }

      list = (List)dataMap.get(key);

      label124: unformatList(list, listDefine, mappingMap);
      dataMap.put(refName, list);
      if (!(refName.endsWith(key)));
    }
  }

  private void unformatList(List<Object> dataList, ListDefine listDefine, Map<String, String> mappingMap)
    throws Exception
  {
    if (null != dataList) {
      Object[] fieldDefineArray = listDefine.values().toArray();
      for (Iterator i$ = dataList.iterator(); i$.hasNext(); ) { Object object = i$.next();
        if (object instanceof Map) {
          Map rowMap = (Map)object;
          Object[] arr$ = fieldDefineArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object defineObject = arr$[i$];
            unformatElement(rowMap, (DataElement)defineObject, mappingMap);
          }
        } else {
          throw new Exception("list rows expect of map");
        }
      }
    }
  }

  private void unformatField(Map<String, Object> dataMap, FieldDefine fieldDefine, Map<String, String> mappingMap) throws Exception {
    String key = fieldDefine.getName();
    String refName = fieldDefine.getRefName();
    if (!(StringUtil.hasText(refName))) {
      refName = key;
    }

    if ((!(dataMap.containsKey(key))) && 
      (fieldDefine.isNeed())) {
      throw new BaseException("CHECKERR0001", fieldDefine.getName() + " 为必输项!");
    }

    String recValue = (String)dataMap.get(key);
    String defaultValue = fieldDefine.getValue();
    String security = fieldDefine.getSecurity();

    if (!(StringUtil.hasText(recValue))) {
      if (StringUtil.hasText(defaultValue)) {
        recValue = defaultValue; break label246: }
      if (fieldDefine.isEmpty()) break label246;
      throw new BaseException("CHECKERR0002", fieldDefine.getName() + " 不能为空!");
    }
    if ((null != security) && ("true".equals(security))) {
      String sercurityKey = recValue.replaceFirst(this.securityFieldPrefix, "");
      String sercurityValue = (String)mappingMap.get(sercurityKey);
      if (StringUtil.hasText(sercurityValue))
        recValue = sercurityValue;
      else {
        throw new Exception("加密域encryptData的值为空: " + sercurityKey);
      }

    }

    if ((StringUtil.hasText(recValue)) && 
      (StringUtil.hasText(fieldDefine.getLength()))) {
      label246: int length = Integer.parseInt(fieldDefine.getLength());
      if (recValue.length() > length)
        throw new BaseException("CHECKERR0003", fieldDefine.getName() + " 超过合法长度!");

    }

    String pattern = fieldDefine.getPattern();
    if ((StringUtil.hasText(pattern)) && (!(recValue.matches(pattern)))) {
      throw new BaseException("CHECKERR0004", fieldDefine.getName() + " 校验失败!");
    }

    dataMap.put(refName, recValue);
    if (!(refName.endsWith(key)));
  }

  public void postHandle(IContext icontext)
    throws BaseException
  {
    ClogicContext context = (ClogicContext)icontext;

    String securityType = context.getSecurityType();
    if ((StringUtil.hasText(securityType)) && (securityType.length() > 2)) {
      String flag = securityType.substring(2, 3);
      if ((flag.equals("1")) || (flag.equals("2"))) {
        return;
      }

    }

    try
    {
      Map dataMap = (Map)context.getDataMap();
      Map newBodyMap = new HashMap();

      String transCode = context.getTransCode();
      if (StringUtil.hasText(transCode)) {
        Map mappingMap = new HashMap();
        MessageDefine messageDefine = (MessageDefine)SpringContextsUtil.getBean("message_" + transCode);
        GroupDefine groupDefine = messageDefine.getGroupByKey("response");
        Iterator defineIterator = groupDefine.entrySet().iterator();
        while (defineIterator.hasNext()) {
          Map.Entry defineEntry = (Map.Entry)defineIterator.next();
          String key = (String)defineEntry.getKey();
          DataElement defineElement = (DataElement)defineEntry.getValue();
          if (defineElement instanceof GroupDefine) {
            formatGroup(key, (GroupDefine)defineElement, newBodyMap, dataMap, mappingMap);
          } else {
            Object object = formatElement(dataMap, defineElement, mappingMap);
            if (object != null)
              newBodyMap.put(key, object);
          }
        }

        dataMap.put("body", newBodyMap);
        dataMap.put("encryptDataArea", mappingMap);
      }
    } catch (BaseException e) {
      Trace.log("INTERCEPTOR", 3, "报文校验失败:", e);
      throw e;
    } catch (Exception e) {
      Trace.log("INTERCEPTOR", 3, "报文校验失败:", e);
      throw new BaseException(e);
    }
  }

  private void formatGroup(String key, GroupDefine groupDefine, Map<String, Object> newBodyMap, Map<String, Object> dataMap, Map<String, String> mappingMap)
    throws Exception
  {
    Map groupMap = new HashMap();
    Iterator defineIterator = groupDefine.entrySet().iterator();
    while (defineIterator.hasNext()) {
      Map.Entry defineEntry = (Map.Entry)defineIterator.next();
      String key2 = (String)defineEntry.getKey();
      DataElement defineElement = (DataElement)defineEntry.getValue();
      if (defineElement instanceof GroupDefine) {
        formatGroup(key2, (GroupDefine)defineElement, newBodyMap, dataMap, mappingMap);
      } else {
        Object object = formatElement(dataMap, defineElement, mappingMap);
        if (object != null)
          groupMap.put(key2, object);
      }
    }

    newBodyMap.put(key, groupMap); }

  private Object formatElement(Map<String, Object> dataMap, DataElement defineElement, Map<String, String> mappingMap) throws Exception {
    if (defineElement instanceof FieldDefine) {
      FieldDefine msgField = (FieldDefine)defineElement;
      return formatField(dataMap, msgField, mappingMap); }
    if (defineElement instanceof ListDefine) {
      ListDefine listDefine = (ListDefine)defineElement;
      String key = listDefine.getName();
      String refName = listDefine.getRefName();
      List list = null;
      if (!(StringUtil.hasText(refName)))
        refName = key;

      if (!(dataMap.containsKey(refName))) {
        if (!(listDefine.isNeed())) break label136;
        throw new BaseException("CHECKERR0001", refName + " 为必输项!");
      }

      list = (List)dataMap.get(refName);
      return formatList(list, listDefine, mappingMap);
    }

    label136: return null;
  }

  private List<Object> formatList(List<Object> list, ListDefine listDefine, Map<String, String> mappingMap) throws Exception {
    List newList = new ArrayList();
    if (null != list) {
      Object[] fieldDefineArray = listDefine.values().toArray();
      for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object object = i$.next();
        if (object instanceof Map) {
          Map rowMap = (Map)object;
          Map newRowMap = new HashMap();
          Object[] arr$ = fieldDefineArray; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object defineObject = arr$[i$];
            DataElement dElement = (DataElement)defineObject;
            newRowMap.put(dElement.getName(), formatElement(rowMap, dElement, mappingMap));
          }
          newList.add(newRowMap);
        } else {
          throw new Exception("list rows expect of map");
        }
      }
    }
    return newList;
  }

  private Object formatField(Map<String, Object> dataMap, FieldDefine fieldDefine, Map<String, String> mappingMap) throws Exception {
    String refName = fieldDefine.getRefName();
    String key = fieldDefine.getName();
    String value = null;
    if (!(StringUtil.hasText(refName)))
      refName = key;

    if (!(dataMap.containsKey(refName))) {
      if (fieldDefine.isNeed())
        throw new BaseException("CHECKERR0001", refName + " 为必输项!");

      value = "";
    }
    else {
      value = (String)dataMap.get(refName);
    }

    String defaultValue = fieldDefine.getValue();
    if (!(StringUtil.hasText(value))) {
      if (StringUtil.hasText(defaultValue))
        value = defaultValue;
      else if (!(fieldDefine.isEmpty()))
        throw new BaseException("CHECKERR0002", fieldDefine.getName() + " 不能为空!");

    }

    String security = fieldDefine.getSecurity();
    if ((null != security) && ("true".equals(security))) {
      if (null == value) {
        throw new Exception("加密域encryptData的值为空: " + key);
      }

      if (!(mappingMap.containsKey(key))) {
        mappingMap.put(key, value);
        value = this.securityFieldPrefix + key;
      } else {
        String securityValue = (String)mappingMap.get(key);
        if (securityValue.equals(value)) {
          value = this.securityFieldPrefix + key;
        } else {
          int index = 0;
          while (true) {
            String key1 = key + (index++);
            if (!(mappingMap.containsKey(key1))) {
              mappingMap.put(key1, value);
              value = this.securityFieldPrefix + key1;
              break;
            }
            String securityValue1 = (String)mappingMap.get(key1);
            if (securityValue1.equals(value))
              value = this.securityFieldPrefix + key1;
          }
        }

      }

    }

    return value;
  }

  public String getSecurityFieldPrefix() {
    return this.securityFieldPrefix;
  }

  public void setSecurityFieldPrefix(String securityFieldPrefix) {
    this.securityFieldPrefix = securityFieldPrefix;
  }
}