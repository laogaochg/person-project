package com.ifp.web.interceptor.handle;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.web.interceptor.IFPInterceptor;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class InterceptorHandle
{
  public List<IFPInterceptor> getInterceptorList()
  {
    return null;
  }

  public String execute(HttpServletRequest request, HttpServletResponse response, ClogicContext context)
    throws BaseException
  {
    List interceptorsList = getInterceptorList();
    Trace.log("MVC", 1, "begin to execute interceptor:{}", new Object[] { interceptorsList });

    return "";
  }

  private void triggerAfterCompletion(List<IFPInterceptor> interceptorsList, int interceptorIndex, HttpServletRequest request, HttpServletResponse response, ClogicContext context, BaseException ex)
    throws Exception
  {
    if (interceptorsList != null)
      for (int i = interceptorIndex; i >= 0; --i) {
        IFPInterceptor interceptor = (IFPInterceptor)interceptorsList.get(i);
        try {
          interceptor.afterCompletion(request, response, context, ex);
        } catch (Exception e) {
          Trace.log("MVC", 3, "IFPInterceptor.afterCompletion threw exception", e);
        }
      }
  }
}