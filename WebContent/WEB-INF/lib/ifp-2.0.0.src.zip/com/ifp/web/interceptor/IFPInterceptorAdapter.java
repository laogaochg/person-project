package com.ifp.web.interceptor;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.Trace;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.SpringContextsUtil;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;

public class IFPInterceptorAdapter
  implements IFPInterceptor
{
  private String name;
  protected LogHandle logHandle;
  protected MonitorManager monitorManager;
  private SystemConf systemConf;

  public IFPInterceptorAdapter()
  {
    this.logHandle = ((LogHandle)SpringContextsUtil.getBean("logHandle"));
    this.monitorManager = ((MonitorManager)SpringContextsUtil.getBean("monitorManager"));
  }

  public void preHandle(IContext context)
    throws BaseException
  {
  }

  public void postHandle(IContext context)
    throws BaseException
  {
  }

  public void afterCompletion(IContext context, BaseException exception)
    throws BaseException
  {
  }

  public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object context, Exception e)
    throws Exception
  {
    Trace.log("INTERCEPTOR", 1, "exec afterCompletion() on {}", new Object[] { getName() });
    if (context instanceof IContext)
    {
      String className = super.getClass().getName();
      int idx = className.lastIndexOf(".");
      if (idx != -1)
      {
        className = className.substring(idx + 1);
      }
      try {
        this.monitorManager.setCurrentOperationName(((IContext)context).getMonitorId(), super.toString());
      } catch (Exception e2) {
        e2.printStackTrace();
      }
      BaseException baseException = null;
      if ((e != null) && (!(e instanceof BaseException)))
      {
        baseException = new BaseException(e);
      } else if (e instanceof BaseException)
      {
        baseException = (BaseException)e;
      }
      afterCompletion((IContext)context, baseException);
    }
  }

  public void postHandle(HttpServletRequest request, HttpServletResponse response, Object context, ModelAndView arg3) throws Exception
  {
    Trace.log("INTERCEPTOR", 1, "exec postHandle() on {}", new Object[] { getName() });
    if (context instanceof IContext)
    {
      String className = super.getClass().getName();
      int idx = className.lastIndexOf(".");
      if (idx != -1)
      {
        className = className.substring(idx + 1);
      }
      try {
        this.monitorManager.setCurrentOperationName(((IContext)context).getMonitorId(), super.toString());
      } catch (Exception e2) {
        e2.printStackTrace();
      }
      postHandle((IContext)context);
    }
  }

  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object context)
    throws Exception
  {
    Trace.log("INTERCEPTOR", 1, "exec preHandle() on {}", new Object[] { getName() });
    if (context instanceof IContext)
    {
      String className = super.getClass().getName();
      int idx = className.lastIndexOf(".");
      if (idx != -1)
      {
        className = className.substring(idx + 1);
      }
      try {
        this.monitorManager.setCurrentOperationName(((IContext)context).getMonitorId(), super.toString());
      } catch (Exception e2) {
        e2.printStackTrace();
      }
      preHandle((IContext)context);
    }
    return true;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getAttributeValue(IContext context, String name) {
    Map attributeMap = (Map)((ClogicContext)context).getTempMap().get("interceptorAttributeKey");
    if (null != attributeMap)
      return ((String)attributeMap.get(name));

    return null;
  }

  public SystemConf getSystemConf()
  {
    return this.systemConf;
  }

  public void setSystemConf(SystemConf systemConf)
  {
    this.systemConf = systemConf;
  }
}