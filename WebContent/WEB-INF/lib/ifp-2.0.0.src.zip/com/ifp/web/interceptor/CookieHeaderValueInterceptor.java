package com.ifp.web.interceptor;

public class CookieHeaderValueInterceptor extends IFPInterceptorAdapter
{
}