package com.ifp.web.interceptor;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.ValidationException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.validation.IFPValidationHandle;
import com.ifp.web.common.IFPConstance;
import com.ifp.web.validation.ValidationField;
import com.ifp.web.validation.ValidationForm;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.springframework.beans.factory.BeanFactoryUtils;

public class ValidationInterceptor extends IFPInterceptorAdapter
{
  private Map<String, ValidationForm> ValidationFormMap;

  public void preHandle(IContext icontext)
    throws BaseException
  {
    ClogicContext context;
    try
    {
      context = (ClogicContext)icontext;
      Map dataMap = (Map)context.getDataMap();
      String transCode = context.getTransCode();
      if (getValidationFormMap().get(context.getTransCode()) != null) {
        Map fieldMap = ((ValidationForm)getValidationFormMap().get(transCode)).getFieldMap();

        for (Iterator i$ = fieldMap.values().iterator(); i$.hasNext(); ) { ValidationField field = (ValidationField)i$.next();
          String fieldName = field.getName();
          String type = field.getType();
          String desc = field.getDesc();

          List checkList = IFPValidationHandle.getCheckList(fieldName, type, transCode);

          for (int i = 0; i < checkList.size(); ++i) {
            Map checkMap = (Map)checkList.get(i);
            String checkFieldName = (String)checkMap.get("fieldName");
            String typeName = (String)checkMap.get("typeName");
            String attribute = (String)checkMap.get("attribute");
            Object obj = dataMap.get(checkFieldName);

            if (!(IFPValidationHandle.doCheck(typeName, obj, attribute, (com.ifp.core.util.StringUtil.hasText(desc)) ? desc : checkFieldName))) {
              Trace.log("INTERCEPTOR", 0, "数据校验失败");
              throw IFPConstance.VALIDATIONEXCEPTION;
            }
          }
        }
      }
    } catch (ValidationException e) {
      Trace.log("INTERCEPTOR", 3, "数据校验失败:", e);
      throw e;
    } catch (BaseException e) {
      Trace.log("INTERCEPTOR", 3, "数据校验失败:", e);
      throw e;
    } catch (Exception e) {
      Trace.log("INTERCEPTOR", 3, "数据校验失败:", e);
      throw new BaseException(e);
    }
  }

  public Map<String, ValidationForm> getValidationFormMap() {
    if (this.ValidationFormMap == null) {
      this.ValidationFormMap = new HashMap();
      Map map = BeanFactoryUtils.beansOfTypeIncludingAncestors(SpringContextsUtil.getApplicationContext(), ValidationForm.class, true, false);

      for (Iterator i$ = map.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entity = (Map.Entry)i$.next();
        this.ValidationFormMap.put(((ValidationForm)entity.getValue()).getTranCode(), entity.getValue());
      }
    }
    return this.ValidationFormMap;
  }

  public void setValidationFormMap(Map<String, ValidationForm> ValidationFormMap) {
    this.ValidationFormMap = ValidationFormMap;
  }
}