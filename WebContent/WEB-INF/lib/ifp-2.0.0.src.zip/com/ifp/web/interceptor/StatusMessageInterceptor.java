package com.ifp.web.interceptor;

public class StatusMessageInterceptor extends IFPInterceptorAdapter
{
}