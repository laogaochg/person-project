package com.ifp.web.interceptor;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;
import org.springframework.web.servlet.HandlerInterceptor;

public abstract interface IFPInterceptor extends HandlerInterceptor
{
  public abstract void preHandle(IContext paramIContext)
    throws BaseException;

  public abstract void postHandle(IContext paramIContext)
    throws BaseException;

  public abstract void afterCompletion(IContext paramIContext, BaseException paramBaseException)
    throws BaseException;

  public abstract String getName();

  public abstract void setName(String paramString);

  public abstract String getAttributeValue(IContext paramIContext, String paramString);

  public abstract SystemConf getSystemConf();

  public abstract void setSystemConf(SystemConf paramSystemConf);
}