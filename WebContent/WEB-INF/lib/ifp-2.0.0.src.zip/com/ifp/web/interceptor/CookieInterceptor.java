package com.ifp.web.interceptor;

public class CookieInterceptor extends IFPInterceptorAdapter
{
}