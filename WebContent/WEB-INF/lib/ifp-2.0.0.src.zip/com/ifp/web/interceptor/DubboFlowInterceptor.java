package com.ifp.web.interceptor;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.context.IContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.rpc.RPCHandle;
import java.util.Map;

public class DubboFlowInterceptor extends IFPInterceptorAdapter
{
  private RPCHandle rpcHandle;

  public void preHandle(IContext context)
    throws BaseException
  {
    ClogicContext clogicContext = (ClogicContext)context;
    String logicId = clogicContext.getLogicCode();

    String result = "0";

    if (null == this.rpcHandle) {
      this.rpcHandle = ((RPCHandle)SpringContextsUtil.getBean("rpcHandle"));
    }

    this.rpcHandle.executeRemoteServiceForCL(clogicContext, logicId);

    Trace.log("MVC", 1, "end execute businessLogic:{},result is :{}", new Object[] { logicId, result });

    ((Map)clogicContext.getDataMap()).put("blogicResult", result);
  }
}