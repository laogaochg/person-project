package com.ifp.web.bean;

public class RuleBean
{
  private int timeStartIndex;
  private int timeEndIndex;
  private int idStartIndex;
  private int idEndIndex;

  public RuleBean()
  {
    this.timeStartIndex = 0;

    this.timeEndIndex = 0;

    this.idStartIndex = -1;

    this.idEndIndex = 0; }

  public int getTimeStartIndex() {
    return this.timeStartIndex;
  }

  public void setTimeStartIndex(int timeStartIndex) {
    this.timeStartIndex = timeStartIndex;
  }

  public int getTimeEndIndex() {
    return this.timeEndIndex;
  }

  public void setTimeEndIndex(int timeEndIndex) {
    this.timeEndIndex = timeEndIndex;
  }

  public int getIdStartIndex() {
    return this.idStartIndex;
  }

  public void setIdStartIndex(int idStartIndex) {
    this.idStartIndex = idStartIndex;
  }

  public int getIdEndIndex() {
    return this.idEndIndex;
  }

  public void setIdEndIndex(int idEndIndex) {
    this.idEndIndex = idEndIndex;
  }
}