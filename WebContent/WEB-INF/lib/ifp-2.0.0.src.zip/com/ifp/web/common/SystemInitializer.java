package com.ifp.web.common;

import com.ifp.core.base.SysParamInitInf;
import com.ifp.core.base.SystemConf;
import com.ifp.core.jdbc.DataSourceHandle;
import com.ifp.core.listener.ISettingReloadListener;
import com.ifp.core.log.Trace;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SystemInitializer
  implements SysParamInitInf
{
  SystemConf systemConf;
  private DataSourceHandle dataSourceHandle;
  private String dataSourceName;

  public void init()
  {
    initSysApr();
    initAppApr();

    loadSetting();
    this.dataSourceHandle.init();
  }

  private void initSysApr()
  {
    Trace.logInfo("MANAGE", "开始从数据库初始化sys配置...");
    try {
      String querySql = "SELECT SPR_CODE,SPR_KEY,SPR_VALUE,SPR_DATATYPE FROM PUB_SYSAPR";
      List rstList = this.dataSourceHandle.querySQL(this.dataSourceName, querySql);
      if ((null != rstList) && (rstList.size() > 0)) {
        Map confMap = this.systemConf.getConfMap();
        for (Iterator i$ = rstList.iterator(); i$.hasNext(); ) { String[] rst = (String[])i$.next();
          rst[0] = rst[0].trim();
          rst[1] = rst[1].trim();
          rst[2] = rst[2].trim();
          rst[3] = rst[3].trim();
          if (rst[3].equals("S")) {
            confMap.put(rst[0], rst[2]);
          } else if (rst[3].equals("B")) {
            confMap.put(rst[0], Boolean.valueOf(rst[2]));
          } else if (rst[3].equals("I")) {
            confMap.put(rst[0], Integer.valueOf(rst[2]));
          } else if (rst[3].equals("D")) {
            confMap.put(rst[0], Double.valueOf(rst[2]));
          } else if (rst[3].equals("M")) {
            Map map = (Map)confMap.get(rst[0]);
            if (null == map) {
              map = new HashMap();
            }

            map.put(rst[1], rst[2]);
            confMap.put(rst[0], map);
          } else if (rst[3].equals("L")) {
            List list = (List)confMap.get(rst[0]);
            if (null == list) {
              list = new ArrayList();
            }

            list.add(rst[2]);
            confMap.put(rst[0], list);
          }
        }
      }
    } catch (Exception e) {
      Trace.logError("COMMON", "数据库初始化sys配置失败");
    }
    Trace.logInfo("MANAGE", "完成从数据库初始化sys配置!");
  }

  private void initAppApr()
  {
    Trace.logInfo("MANAGE", "开始从数据库初始化app配置...");
    try {
      String querySql = "SELECT APR_CODE,APR_VALUE,APR_LANGUAGE,APR_SHOW,APR_CHANNELID FROM PUB_APPAPR";
      List rstList = this.dataSourceHandle.querySQL(this.dataSourceName, querySql);
      if ((null != rstList) && (rstList.size() > 0)) {
        Map aprMap = this.systemConf.getAprMap();
        for (Iterator i$ = rstList.iterator(); i$.hasNext(); ) { String key;
          String[] rst = (String[])i$.next();
          rst[0] = rst[0].trim();
          rst[1] = rst[1].trim();
          rst[2] = rst[2].trim();
          rst[3] = rst[3].trim();
          rst[4] = rst[4].trim();

          if (rst[2].toUpperCase().equals("ALL"))
            key = "all." + rst[0] + "." + rst[2];
          else
            key = rst[4] + "." + rst[0] + "." + rst[2];

          Map paramMap = (Map)aprMap.get(key);
          if (null == paramMap)
            paramMap = new LinkedHashMap();

          paramMap.put(rst[1], rst[3]);
          aprMap.put(key, paramMap);
        }
      }
    } catch (Exception e) {
      Trace.logError("COMMON", "数据库初始化app配置失败");
    }
    Trace.logInfo("MANAGE", "完成从数据库初始化app配置!");
  }

  private void loadSetting()
  {
    Map reloadMap = this.systemConf.getReloadMap();
    if ((null != reloadMap) && (reloadMap.size() > 0)) {
      Iterator keyIterator = reloadMap.keySet().iterator();
      while (keyIterator.hasNext()) {
        String key = (String)keyIterator.next();
        ISettingReloadListener reloadListener = (ISettingReloadListener)reloadMap.get(key);
        reloadListener.reload();
      }
    }
  }

  public SystemConf getSystemConf() {
    return this.systemConf;
  }

  public void setSystemConf(SystemConf systemConf) {
    this.systemConf = systemConf;
  }

  public DataSourceHandle getDataSourceHandle() {
    return this.dataSourceHandle;
  }

  public void setDataSourceHandle(DataSourceHandle dataSourceHandle) {
    this.dataSourceHandle = dataSourceHandle;
  }

  public String getDataSourceName() {
    return this.dataSourceName;
  }

  public void setDataSourceName(String dataSourceName) {
    this.dataSourceName = dataSourceName;
  }
}