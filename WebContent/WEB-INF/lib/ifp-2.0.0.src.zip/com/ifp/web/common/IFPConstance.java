package com.ifp.web.common;

import com.ifp.core.exception.ValidationException;

public class IFPConstance
{
  public static final String MVC_TYPE = "type";
  public static final String MVC_TYPE_DEFAULT_VALUE = "K";
  public static final String MVC_WEB_INPUT_DO_KEY = "webInputList";
  public static final String MVC_WEB_NOSERVICE_KEY = "noServiceList";
  public static final String MVC_TRANCODE = "transCode";
  public static final String ELEMENT_START_FLAG = "<";
  public static final String ELEMENT_START_FLAG_2 = "</";
  public static final String ELEMENT_END_FLAG = ">";
  public static final String BEFORE_INTERCEPTORS_NAME = "beforeInterceptorArray";
  public static final String[] BEFORE_INTERCEPTORS = { "SecurityInterceptor", "ValidationHeaderInterceptor" };
  public static final String AFTER_INTERCEPTORS_NAME = "afterInterceptorArray";
  public static final String[] AFTER_INTERCEPTORS = { "AfterInterceptor" };
  public static final String[] EXEC_INTERCEPTORS = { "BlogicInterceptor", "DubboFlowInterceptor" };
  public static final String REQUEST_DATAMAP = "requestDataMap";
  public static String ATTR_EXCEPTION = "exception";
  public static String ERRORCODE = "errorCode";
  public static String ERRORMSG = "errorMsg";
  public static String LOGFIELDDEFINE = "logFieldDefine";
  public static ValidationException VALIDATIONEXCEPTION = new ValidationException("SYEC0002", "数据验证失败");
  public static final String SESSIONID = "sessionID";
  public static final String INTERCEPTOR_ATTRIBUTE_KEY = "interceptorAttributeKey";
  public static final String BLOGIC_DEFAULT_PARAMS_KEY = "blogicDefautlParamsKey";
  public static final String OUT_PARAMS_FILTER_FLAG = "outParamsFilterFlag";
}