package com.ifp.web.manager.processor;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.ClogicContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.jdbc.DataSourceHandle;
import com.ifp.core.listener.ISettingReloadListener;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SettingUpdateProcessor
  implements IManageProcessor
{
  private String settingKeyName;
  private SystemConf systemConf;
  private DataSourceHandle dataSourceHandle;
  private String dataSourceName;

  public SettingUpdateProcessor()
  {
    this.settingKeyName = "key";
  }

  public synchronized void execute(ClogicContext context)
    throws BaseException
  {
    reloadSysApr();
    reloadAppApr();

    String key = (String)context.getValue(this.settingKeyName);
    if (StringUtil.hasText(key))
      if (key.toLowerCase().equals("all"))
        updateAllSetting();
      else
        updateSingleSetting(key);
  }

  private void reloadSysApr()
  {
    Trace.logInfo("MANAGE", "开始从数据库重载sys配置...");
    String querySql = "SELECT SPR_CODE,SPR_KEY,SPR_VALUE,SPR_DATATYPE FROM PUB_SYSAPR WHERE SPR_TYPE='1' AND SPR_CHANGEFLAG='1'";
    List rstList = this.dataSourceHandle.querySQL(this.dataSourceName, querySql);
    if ((null != rstList) && (rstList.size() > 0)) {
      Map confMap = this.systemConf.getConfMap();
      for (Iterator i$ = rstList.iterator(); i$.hasNext(); ) { String[] rst = (String[])i$.next();
        if (rst[3].equals("S")) {
          confMap.put(rst[0], rst[2]);
        } else if (rst[3].equals("B")) {
          confMap.put(rst[0], Boolean.valueOf(rst[2]));
        } else if (rst[3].equals("I")) {
          confMap.put(rst[0], Integer.valueOf(rst[2]));
        } else if (rst[3].equals("D")) {
          confMap.put(rst[0], Double.valueOf(rst[2]));
        } else if (rst[3].equals("M")) {
          Map map = (Map)confMap.get(rst[0]);
          if (null == map) {
            map = new HashMap();
          }

          map.put(rst[1], rst[2]);
          confMap.put(rst[0], map);
        } else if (rst[3].equals("L")) {
          List list = (List)confMap.get(rst[0]);
          if (null == list) {
            list = new ArrayList();
          }

          list.add(rst[2]);
          confMap.put(rst[0], list);
        }
      }
    }
    Trace.logInfo("MANAGE", "完成从数据库重载sys配置!");
  }

  private void reloadAppApr()
  {
    Trace.logInfo("MANAGE", "开始从数据库重载app配置...");
    String querySql = "SELECT APR_CODE,APR_VALUE,APR_LANGUAGE,APR_SHOW,APR_CHANNELID FROM PUB_APPAPR WHERE APR_CHANGEFLAG='1'";
    List rstList = this.dataSourceHandle.querySQL(this.dataSourceName, querySql);
    if ((null != rstList) && (rstList.size() > 0)) {
      Map aprMap = this.systemConf.getAprMap();
      for (Iterator i$ = rstList.iterator(); i$.hasNext(); ) { String key;
        String[] rst = (String[])i$.next();

        if (rst[2].toUpperCase().equals("ALL"))
          key = "all." + rst[0] + "." + rst[2];
        else
          key = rst[4] + "." + rst[0] + "." + rst[2];

        Map paramMap = (Map)aprMap.get(key);
        if (null == paramMap)
          paramMap = new LinkedHashMap();

        paramMap.put(rst[1], rst[3]);
        aprMap.put(key, paramMap);
      }
    }
    Trace.logInfo("MANAGE", "完成从数据库重载app配置!");
  }

  private void updateSingleSetting(String key) {
    ISettingReloadListener reloadListener = this.systemConf.getReloadListener(key);
    Trace.logInfo("MANAGE", "正在重载配置：{}", new Object[] { key });
    reloadListener.reload();
  }

  private void updateAllSetting()
  {
    Trace.logInfo("MANAGE", "开始重载配置所有配置...");
    Map reloadMap = this.systemConf.getReloadMap();
    if ((null != reloadMap) && (reloadMap.size() > 0)) {
      Iterator keyIterator = reloadMap.keySet().iterator();
      while (keyIterator.hasNext()) {
        String key = (String)keyIterator.next();
        ISettingReloadListener reloadListener = (ISettingReloadListener)reloadMap.get(key);
        Trace.logInfo("MANAGE", "正在重载配置：{}", new Object[] { key });
        reloadListener.reload();
      }
    }
    Trace.logInfo("MANAGE", "完成重载配置所有配置!");
  }

  public String getSettingKeyName() {
    return this.settingKeyName;
  }

  public void setSettingKeyName(String settingKeyName) {
    this.settingKeyName = settingKeyName;
  }

  public SystemConf getSystemConf() {
    return this.systemConf;
  }

  public void setSystemConf(SystemConf systemConf) {
    this.systemConf = systemConf;
  }

  public DataSourceHandle getDataSourceHandle() {
    return this.dataSourceHandle;
  }

  public void setDataSourceHandle(DataSourceHandle dataSourceHandle) {
    this.dataSourceHandle = dataSourceHandle;
  }

  public String getDataSourceName() {
    return this.dataSourceName;
  }

  public void setDataSourceName(String dataSourceName) {
    this.dataSourceName = dataSourceName;
  }
}