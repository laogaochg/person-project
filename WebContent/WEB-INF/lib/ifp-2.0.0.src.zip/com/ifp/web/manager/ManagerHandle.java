package com.ifp.web.manager;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.handle.ErrorCodeHandle;
import com.ifp.core.log.Trace;
import com.ifp.web.common.IFPConstance;
import com.ifp.web.manager.processor.IManageProcessor;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ManagerHandle
{
  private ErrorCodeHandle errorCodeHandle;
  private Map<String, List<IManageProcessor>> managerProcessorMap;

  public void executeProcessor(ClogicContext context)
    throws BaseException
  {
    String transCode = context.getTransCode();
    List manageProcessorList = (List)this.managerProcessorMap.get(transCode);
    if (null != manageProcessorList)
      for (Iterator i$ = manageProcessorList.iterator(); i$.hasNext(); ) { IManageProcessor manageProcessor = (IManageProcessor)i$.next();
        try {
          manageProcessor.execute(context);
        } catch (Exception e) {
          Trace.logError("MANAGE", "处理异常：{}", e);
        }
      }
    else
      throw new BaseException("SYEC0002", "未找到相关配置信息");
  }

  public Map<String, Object> createOutputMap(ClogicContext context) throws BaseException
  {
    Map dataMap = (Map)context.getDataMap();
    Map headerMap = (Map)context.getValue("header");

    Map outputMap = new LinkedHashMap();
    outputMap.put("header", headerMap);
    outputMap.put("body", context.getValue("body"));

    this.errorCodeHandle.fillErrorCodeAndMsg((String)dataMap.get(IFPConstance.ERRORCODE), (String)dataMap.get(IFPConstance.ERRORMSG), dataMap, headerMap);

    return outputMap;
  }

  public Map<String, List<IManageProcessor>> getManagerProcessorMap() {
    return this.managerProcessorMap;
  }

  public void setManagerProcessorMap(Map<String, List<IManageProcessor>> managerProcessorMap) {
    this.managerProcessorMap = managerProcessorMap;
  }

  public ErrorCodeHandle getErrorCodeHandle() {
    return this.errorCodeHandle;
  }

  public void setErrorCodeHandle(ErrorCodeHandle errorCodeHandle) {
    this.errorCodeHandle = errorCodeHandle;
  }
}