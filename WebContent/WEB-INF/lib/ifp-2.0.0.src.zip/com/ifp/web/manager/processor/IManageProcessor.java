package com.ifp.web.manager.processor;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.exception.BaseException;

public abstract interface IManageProcessor
{
  public abstract void execute(ClogicContext paramClogicContext)
    throws BaseException;
}