package com.ifp.web.exception;

import com.ifp.core.exception.BaseException;

public class RepetitionSubmitException extends BaseException
{
  public RepetitionSubmitException(String msg)
  {
    super(msg);
  }

  public RepetitionSubmitException(String msg, Exception cause)
  {
    super(msg, cause);
  }
}