package com.ifp.web.exception;

import com.ifp.core.exception.BaseException;

public class SyntaxException extends BaseException
{
  public SyntaxException(String msg)
  {
    super(msg);
  }

  public SyntaxException(String msg, Throwable cause)
  {
    super(msg, cause);
  }
}