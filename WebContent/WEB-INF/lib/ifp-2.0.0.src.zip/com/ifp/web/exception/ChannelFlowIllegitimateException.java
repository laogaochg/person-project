package com.ifp.web.exception;

import com.ifp.core.exception.BaseException;

public class ChannelFlowIllegitimateException extends BaseException
{
  public ChannelFlowIllegitimateException(String msg)
  {
    super(msg);
  }

  public ChannelFlowIllegitimateException(String msg, Exception cause)
  {
    super(msg, cause);
  }
}