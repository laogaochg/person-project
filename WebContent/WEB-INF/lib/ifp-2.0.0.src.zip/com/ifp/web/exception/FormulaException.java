package com.ifp.web.exception;

import com.ifp.core.exception.BaseException;

public class FormulaException extends BaseException
{
  public FormulaException(String msg)
  {
    super(msg);
  }

  public FormulaException(String msg, Exception cause)
  {
    super(msg, cause);
  }
}