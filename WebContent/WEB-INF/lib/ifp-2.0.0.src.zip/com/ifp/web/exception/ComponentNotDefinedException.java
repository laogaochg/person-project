package com.ifp.web.exception;

import com.ifp.core.exception.BaseException;

public class ComponentNotDefinedException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public ComponentNotDefinedException()
  {
  }

  public ComponentNotDefinedException(String message)
  {
    super(message);
  }
}