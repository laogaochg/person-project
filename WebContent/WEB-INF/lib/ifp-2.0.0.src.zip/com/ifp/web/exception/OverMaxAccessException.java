package com.ifp.web.exception;

import com.ifp.core.exception.BaseException;

public class OverMaxAccessException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public OverMaxAccessException()
  {
  }

  public OverMaxAccessException(String errorMessage)
  {
    super(errorMessage);
  }

  public OverMaxAccessException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public OverMaxAccessException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public OverMaxAccessException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public OverMaxAccessException(Throwable cause)
  {
    super(cause);
  }
}