package com.ifp.web.netty.handler;

import com.ifp.adapter.netty.LongConnectAdapter;
import com.ifp.core.log.Trace;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;

@ChannelHandler.Sharable
public class HeartbeatHandler extends ChannelDuplexHandler
  implements LongConnectAdapter
{
  private int unRecPingTimes;
  private int maxUnRecPingTimes;

  public HeartbeatHandler()
  {
    this.unRecPingTimes = 1;

    this.maxUnRecPingTimes = 3; }

  public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
    if (evt instanceof IdleStateEvent) {
      IdleStateEvent event = (IdleStateEvent)evt;
      if (event.state() == IdleState.READER_IDLE)
      {
        Trace.log("MESSAGE", 1, "===服务端长连接心跳===(READER_IDLE 读超时)");

        if (this.unRecPingTimes >= this.maxUnRecPingTimes)
        {
          Trace.log("MESSAGE", 1, "===服务端长连接心跳===(读超时已{}次，关闭chanel)", new Object[] { this.maxUnRecPingTimes + "" });
          ChannelFuture writeFuture = ctx.writeAndFlush(Unpooled.copiedBuffer("receive no msg for a long time.".getBytes()));
          writeFuture.addListener(ChannelFutureListener.CLOSE);
        }
        else
        {
          this.unRecPingTimes += 1;
        }
      } else if (event.state() == IdleState.WRITER_IDLE)
      {
        Trace.log("MESSAGE", 1, "===服务端长连接心跳===(WRITER_IDLE 写超时)");
      } else if (event.state() == IdleState.ALL_IDLE)
      {
        Trace.log("MESSAGE", 1, "===服务端长连接心跳===(ALL_IDLE 总超时)");
      }
    }
  }

  public int getMaxUnRecPingTimes() {
    return this.maxUnRecPingTimes;
  }

  public void setMaxUnRecPingTimes(int maxUnRecPingTimes) {
    this.maxUnRecPingTimes = maxUnRecPingTimes;
  }
}