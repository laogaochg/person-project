package com.ifp.web.netty.handler;

import com.ifp.adapter.message.BaseMessage;
import com.ifp.adapter.message.field.MessageField;
import com.ifp.adapter.netty.HandlerAdapter;
import com.ifp.adapter.netty.http.NettyRequest;
import com.ifp.adapter.netty.http.NettyResponse;
import com.ifp.adapter.process.Processor;
import com.ifp.core.log.Trace;
import com.ifp.core.monitor.Monitor;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.web.controller.MvcController;
import com.ifp.web.netty.IFPNettyServer;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageDecoder;
import io.netty.util.Attribute;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.util.StringUtils;

@ChannelHandler.Sharable
public class ByteToNettyRequestHandler extends MessageToMessageDecoder<ByteBuf>
  implements HandlerAdapter
{
  private ServletContext servletContext;
  private BaseMessage<MessageField> head;
  private MonitorManager monitorManager = (MonitorManager)SpringContextsUtil.getBean("monitorManager");
  private static Map<String, String> transCodeRequestMap = new HashMap();

  public ByteToNettyRequestHandler()
  {
  }

  public ByteToNettyRequestHandler(ServletContext servletContext)
  {
    this.servletContext = servletContext;
  }

  private NettyRequest createRequest(ByteBuf buf)
    throws UnsupportedEncodingException, Exception
  {
    NettyRequest servletRequest = new NettyRequest(this.servletContext);
    if (null != buf)
    {
      Map headMap = getHead().getFieldMap(buf);

      byte[] bodyByte = new byte[NumberUtils.toInt(((String)headMap.get("size")).trim())];
      buf.readBytes(bodyByte);
      String body = new String(bodyByte);
      Trace.log("MESSAGE", 0, "netty接收到的报文体:{}", new Object[] { body });

      Map bodyMap = this.head.getProcessor(new String[] { (String)headMap.get("type") }).unformat(body);

      Map msgMap = new HashMap();
      msgMap.put("header", headMap);
      msgMap.put("body", bodyMap);
      String msg = this.head.getProcessor(new String[0]).format(msgMap);
      Trace.log("MESSAGE", 1, "netty组装成的完整报文:{}", new Object[] { msg });

      String requestName = (String)transCodeRequestMap.get(headMap.get("transCode"));
      if (!(StringUtils.hasText(requestName)))
        return null;
      servletRequest.setRequestURI("/netty/" + requestName + ".do");
      servletRequest.setPathInfo("/netty/" + requestName + ".do");
      servletRequest.setMethod("POST");
      Trace.log("MESSAGE", 0, "requestURI:{}, pathInfo:{}, method:{}", new Object[] { servletRequest.getRequestURI(), servletRequest.getPathInfo(), servletRequest.getMethod() });

      servletRequest.addHeader("Connection", "keep-alive");
      servletRequest.addHeader("content-length", Integer.valueOf(msg.length()));

      Iterator keys = headMap.keySet().iterator();
      while (keys.hasNext()) {
        String key = (String)keys.next();
        servletRequest.addHeader(key, headMap.get(key));
      }

      servletRequest.setContent(Unpooled.copiedBuffer(msg.getBytes("UTF-8")).array());
    }

    return servletRequest;
  }

  protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> out)
    throws Exception
  {
    Attribute monitorAttr = ctx.attr(IFPNettyServer.ATTR_KEY_MONITOID);
    String monitorId = (String)monitorAttr.get();
    if (null != monitorId) {
      Monitor monitor = this.monitorManager.getMonitor(monitorId);
      if (null != monitor)
        monitor.setCurrentMonitorStep("TCP10");
      else
        Trace.log("MONITOR", 3, "netty的handler（{}）取monitor时发现丢失了", new Object[] { getClass() });
    } else {
      Trace.log("MESSAGE", 0, "{}取monitorId时发现丢失了", new Object[] { getClass() });
    }
    byte[] b = new byte[1];
    buf.getBytes(0, b);
    String type = new String(b);
    Trace.log("MESSAGE", 1, "netty协议接入接收到的请求类型type: {}", new Object[] { type });

    if (null != getHead().getProcessor(new String[] { type })) {
      NettyRequest createRequest = createRequest(buf);
      if (null != createRequest) {
        InetSocketAddress localAddress = (InetSocketAddress)ctx.channel().localAddress();
        createRequest.setServerPort(localAddress.getPort());

        createRequest.addHeader("monitorId", monitorId);

        out.add(createRequest);
      } else {
        NettyResponse servletResponse = new NettyResponse();
        servletResponse.sendError(404);
        ChannelFuture writeFuture = ctx.write(Unpooled.copiedBuffer(servletResponse.getStatus() + "".getBytes()));
        writeFuture.addListener(ChannelFutureListener.CLOSE);
        Trace.log("MESSAGE", 0, "不能访问的请求，返回后断开连接");
      }
    }
    else {
      ctx.fireChannelRead(buf);
    }
  }

  public void setServlet(HttpServlet servlet)
  {
    this.servletContext = servlet.getServletContext();
  }

  public void setServletContext(ServletContext servletContext) {
    this.servletContext = servletContext;
  }

  public BaseMessage<MessageField> getHead() {
    if (null == this.head)
      this.head = ((BaseMessage)SpringContextsUtil.getBean("tcpHead"));

    return this.head;
  }

  public void setHead(BaseMessage<MessageField> head)
  {
    this.head = head;
  }

  static
  {
    Map mvcControllerMap = SpringContextsUtil.getBeansOfType(MvcController.class);
    Iterator mvcControllers = mvcControllerMap.values().iterator();
    MvcController mvcController = null;
    while (true) { do { if (!(mvcControllers.hasNext())) return;
        mvcController = (MvcController)mvcControllers.next(); }
      while (!(StringUtils.hasText(mvcController.getSessionName())));
      transCodeRequestMap.put(mvcController.getTranCode(), mvcController.getId());
    }
  }
}