package com.ifp.web.netty.handler;

import com.ifp.adapter.netty.LongConnectAdapter;
import com.ifp.adapter.netty.ShortConnectAdapter;
import io.netty.buffer.ByteBuf;
import java.nio.ByteOrder;
import org.springframework.util.NumberUtils;

public class LengthFieldStringBasedFrameDecoder extends LengthFieldBasedFrameDecoder
  implements LongConnectAdapter, ShortConnectAdapter
{
  public LengthFieldStringBasedFrameDecoder(int maxFrameLength, int lengthFieldOffset, int lengthFieldLength)
  {
    this(maxFrameLength, lengthFieldOffset, lengthFieldLength, 0, 0);
  }

  public LengthFieldStringBasedFrameDecoder(int maxFrameLength, int lengthFieldOffset, int lengthFieldLength, int lengthAdjustment, int initialBytesToStrip)
  {
    this(maxFrameLength, lengthFieldOffset, lengthFieldLength, lengthAdjustment, initialBytesToStrip, true);
  }

  public LengthFieldStringBasedFrameDecoder(int maxFrameLength, int lengthFieldOffset, int lengthFieldLength, int lengthAdjustment, int initialBytesToStrip, boolean failFast)
  {
    this(ByteOrder.BIG_ENDIAN, maxFrameLength, lengthFieldOffset, lengthFieldLength, lengthAdjustment, initialBytesToStrip, failFast);
  }

  public LengthFieldStringBasedFrameDecoder(ByteOrder byteOrder, int maxFrameLength, int lengthFieldOffset, int lengthFieldLength, int lengthAdjustment, int initialBytesToStrip, boolean failFast)
  {
    super(byteOrder, maxFrameLength, lengthFieldOffset, lengthFieldLength, lengthAdjustment, initialBytesToStrip, failFast);
  }

  protected long getUnadjustedFrameLength(ByteBuf buf, int offset, int length, ByteOrder order)
  {
    buf = buf.order(order);
    byte[] dst = new byte[length];

    buf.getBytes(0, dst);
    return ((Integer)NumberUtils.parseNumber(new String(dst), Integer.class)).intValue();
  }
}