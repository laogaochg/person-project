package com.ifp.web.netty.handler;

import com.ifp.adapter.message.BaseMessage;
import com.ifp.adapter.message.field.MessageField;
import com.ifp.adapter.netty.HandlerAdapter;
import com.ifp.core.log.Trace;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import javax.servlet.http.HttpServlet;

@ChannelHandler.Sharable
public final class ExceptionHandler extends ChannelInboundHandlerAdapter
  implements HandlerAdapter
{
  public void setServlet(HttpServlet servlet)
  {
  }

  public void setHead(BaseMessage<MessageField> head)
  {
  }

  public void channelRead(ChannelHandlerContext ctx, Object msg)
    throws Exception
  {
  }

  public void channelReadComplete(ChannelHandlerContext ctx)
    throws Exception
  {
    ctx.flush();
  }

  public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
    throws Exception
  {
    Trace.log("MESSAGE", 3, cause.getMessage());
  }
}