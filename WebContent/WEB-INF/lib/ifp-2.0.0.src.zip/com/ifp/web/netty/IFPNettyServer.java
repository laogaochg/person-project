package com.ifp.web.netty;

import com.ifp.adapter.netty.HandlerAdapter;
import com.ifp.adapter.netty.LongConnectAdapter;
import com.ifp.adapter.netty.ShortConnectAdapter;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.Trace;
import com.ifp.core.monitor.Monitor;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.SpringContextsUtil;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.util.Attribute;
import io.netty.util.AttributeKey;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.servlet.http.HttpServlet;

public class IFPNettyServer
{
  public static final AttributeKey<Object> ATTR_KEY_MONITOID = AttributeKey.valueOf("monitorId");
  private final int port;
  private HttpServlet dispatcherServlet;
  private MonitorManager monitorManager;

  public IFPNettyServer(int port, HttpServlet dispatcherServlet)
  {
    this.port = port;
    this.dispatcherServlet = dispatcherServlet;
    this.monitorManager = ((MonitorManager)SpringContextsUtil.getBean("monitorManager"));
  }

  public void runShort()
    throws Exception
  {
    EventLoopGroup bossGroup = new NioEventLoopGroup();
    EventLoopGroup workerGroup = new NioEventLoopGroup();
    try {
      ServerBootstrap b = new ServerBootstrap();
      ((ServerBootstrap)b.group(bossGroup, workerGroup).channel(NioServerSocketChannel.class)).childHandler(new ChannelInitializer(this)
      {
        public void initChannel()
          throws Exception
        {
          Monitor monitor = IFPNettyServer.access$000(this.this$0);
          monitor.setCurrentMonitorStep("TCP01");
          Trace.log("MESSAGE", 1, "netty接收到tc短连接请求，创建monitorId: {}", new Object[] { monitor.getMonitorId() });

          Attribute monitorAttr = ch.attr(IFPNettyServer.ATTR_KEY_MONITOID);
          monitorAttr.set(monitor.getMonitorId());
          try
          {
            Map settingHandlers = SpringContextsUtil.getBeansOfType(ShortConnectAdapter.class);
            for (Iterator i$ = settingHandlers.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
              ch.pipeline().addLast((String)entry.getKey(), (ChannelHandler)entry.getValue());
            }

            Map handlers = SpringContextsUtil.getBeansOfType(HandlerAdapter.class);
            for (Iterator i$ = handlers.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
              HandlerAdapter handlerAdapter = (HandlerAdapter)entry.getValue();
              handlerAdapter.setServlet(IFPNettyServer.access$100(this.this$0));
              ch.pipeline().addLast((String)entry.getKey(), handlerAdapter);
            }
          } catch (Exception e) {
            Trace.log("MESSAGE", 0, "netty加载配置出错: {}", e);
          }
        }
      }).option(ChannelOption.SO_BACKLOG, Integer.valueOf(128));

      ChannelFuture f = b.bind(this.port).sync();

      f.channel().closeFuture().sync();
    } finally {
      workerGroup.shutdownGracefully();
      bossGroup.shutdownGracefully();
    }
  }

  public void runLong()
    throws Exception
  {
    EventLoopGroup bossGroup = new NioEventLoopGroup();
    EventLoopGroup workerGroup = new NioEventLoopGroup();
    try {
      ServerBootstrap b = new ServerBootstrap();
      ((ServerBootstrap)((ServerBootstrap)b.group(bossGroup, workerGroup).channel(NioServerSocketChannel.class)).childHandler(new ChannelInitializer(this)
      {
        public void initChannel()
          throws Exception
        {
          Monitor monitor = IFPNettyServer.access$000(this.this$0);
          monitor.setCurrentMonitorStep("TCP00");
          Trace.log("MESSAGE", 1, "netty接收到tcp长连接请求，创建monitorId: {}", new Object[] { monitor.getMonitorId() });

          Attribute monitorAttr = ch.attr(IFPNettyServer.ATTR_KEY_MONITOID);
          monitorAttr.set(monitor.getMonitorId());
          try
          {
            Map settingHandlers = SpringContextsUtil.getBeansOfType(LongConnectAdapter.class);
            for (Iterator i$ = settingHandlers.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
              ch.pipeline().addLast((String)entry.getKey(), (ChannelHandler)entry.getValue());
            }

            Map handlers = SpringContextsUtil.getBeansOfType(HandlerAdapter.class);
            for (Iterator i$ = handlers.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
              ((HandlerAdapter)entry.getValue()).setServlet(IFPNettyServer.access$100(this.this$0));
              ch.pipeline().addLast((String)entry.getKey(), (ChannelHandler)entry.getValue());
            }
          } catch (Exception e) {
            Trace.log("MESSAGE", 0, "netty加载配置出错: {}", e);
          }
        }
      }).option(ChannelOption.SO_BACKLOG, Integer.valueOf(128))).childOption(ChannelOption.SO_KEEPALIVE, Boolean.valueOf(true));

      ChannelFuture f = b.bind(this.port).sync();

      f.channel().closeFuture().sync();
    } finally {
      workerGroup.shutdownGracefully();
      bossGroup.shutdownGracefully();
    }
  }

  private Monitor initMonitor()
  {
    Long startTime = Long.valueOf(System.currentTimeMillis());
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    logHandle.init();

    String flumeCid = logHandle.getFlumeLogCid();
    logHandle.setFlumeLogInf(null, null, null, flumeCid, null, null, startTime);

    Monitor monitor = this.monitorManager.getMonitor(flumeCid);
    if (null == monitor) {
      monitor = new Monitor();

      monitor.setMonitorId(flumeCid);
      this.monitorManager.put(monitor);
    }

    if (null != logHandle) {
      logHandle.destroy();
    }

    return monitor;
  }
}