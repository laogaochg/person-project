package com.ifp.web.netty.handler;

import com.ifp.adapter.netty.LongConnectAdapter;
import com.ifp.adapter.netty.ShortConnectAdapter;
import com.ifp.core.log.Trace;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.ipfilter.IpFilterRule;
import io.netty.handler.ipfilter.IpFilterRuleType;
import io.netty.handler.ipfilter.RuleBasedIpFilter;
import java.net.InetAddress;
import java.net.InetSocketAddress;

@ChannelHandler.Sharable
public final class IpFilterHandler extends RuleBasedIpFilter
  implements LongConnectAdapter, ShortConnectAdapter
{
  private final IpFilterRule[] rules;

  public IpFilterHandler(IpFilterRule[] rules)
  {
    super(new IpFilterRule[0]);
    if (rules == null) {
      throw new NullPointerException("rules");
    }

    this.rules = rules;
  }

  protected boolean accept(ChannelHandlerContext ctx, InetSocketAddress remoteAddress) throws Exception
  {
    IpFilterRule[] arr$ = this.rules; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { IpFilterRule rule = arr$[i$];
      if (rule == null) {
        break;
      }

      if (rule.matches(remoteAddress)) {
        boolean accept = rule.ruleType() == IpFilterRuleType.ACCEPT;
        if (!(accept))
          Trace.log("MESSAGE", 2, "配置中配置了{}不允许访问，端口{}", new Object[] { remoteAddress.getAddress().toString(), remoteAddress.getPort() + "" });

        return accept;
      }
    }

    Trace.log("MESSAGE", 2, "所有ip过滤配置都没匹配上，所以不允许访问，ip:port -> {}", new Object[] { remoteAddress });
    return false;
  }
}