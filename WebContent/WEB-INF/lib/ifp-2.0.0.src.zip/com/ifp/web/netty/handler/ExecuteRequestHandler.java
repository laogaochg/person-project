package com.ifp.web.netty.handler;

import com.ifp.adapter.message.BaseMessage;
import com.ifp.adapter.message.field.MessageField;
import com.ifp.adapter.netty.HandlerAdapter;
import com.ifp.adapter.netty.http.NettyRequest;
import com.ifp.adapter.netty.http.NettyResponse;
import com.ifp.core.log.Trace;
import com.ifp.core.monitor.Monitor;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.web.netty.IFPNettyServer;
import com.ifp.web.servlet.NettyFrameworkServlet;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.util.Attribute;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

@ChannelHandler.Sharable
public final class ExecuteRequestHandler extends ChannelInboundHandlerAdapter
  implements HandlerAdapter
{
  private HttpServlet servlet;
  private MonitorManager monitorManager = (MonitorManager)SpringContextsUtil.getBean("monitorManager");

  public ExecuteRequestHandler()
  {
  }

  public ExecuteRequestHandler(HttpServlet servlet)
  {
    this.servlet = servlet;
  }

  public void setServlet(HttpServlet servlet)
  {
    this.servlet = servlet;
  }

  public void setHead(BaseMessage<MessageField> head)
  {
  }

  public void channelRead(ChannelHandlerContext ctx, Object msg)
    throws Exception
  {
    if (msg instanceof NettyRequest) {
      NettyRequest servletRequest = (NettyRequest)msg;
      NettyResponse servletResponse = new NettyResponse();

      Monitor monitor = null;
      Attribute monitorAttr = ctx.attr(IFPNettyServer.ATTR_KEY_MONITOID);
      String monitorId = (String)monitorAttr.get();
      if (null != monitorId) {
        monitor = this.monitorManager.getMonitor(monitorId);
        if (null != monitor)
          monitor.setCurrentMonitorStep("TCP20");
        else
          Trace.log("MONITOR", 3, "netty的handler（{}）取monitor时发现丢失了", new Object[] { getClass() });
      } else {
        Trace.log("MESSAGE", 0, "{}取monitorId时发现丢失了", new Object[] { getClass() });
      }

      this.servlet.service(servletRequest, servletResponse);

      int status = servletResponse.getStatus();
      ChannelFuture writeFuture = null;
      byte[] returnByte = null;
      if (200 == status)
        returnByte = servletResponse.getContentAsByteArray();
      else {
        returnByte = servletResponse.getStatus() + "".getBytes();
      }

      writeFuture = ctx.writeAndFlush(Unpooled.copiedBuffer(returnByte));

      if (NettyFrameworkServlet.netty_port_short.indexOf(servletRequest.getServerPort() + "") != -1) {
        writeFuture.addListener(ChannelFutureListener.CLOSE);
        Trace.log("MESSAGE", 0, "是短连接，返回后断开连接");
      }
      Trace.log("MESSAGE", 0, "return value: {}", new Object[] { new String(returnByte) });

      if (null != monitor) {
        monitor.setCurrentMonitorStep("TCP30");
        this.monitorManager.remove(monitor);
      }
    }
  }

  public void channelReadComplete(ChannelHandlerContext ctx) throws Exception
  {
    ctx.flush();
  }

  public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception
  {
    Trace.log("MESSAGE", 3, cause.getMessage());
  }

  private String getRequestAction(HttpServletRequest request)
  {
    String reqURI = request.getRequestURI();
    String contextPath = request.getContextPath();
    String reqStr = reqURI;
    if (reqURI.startsWith(contextPath))
      reqStr = reqURI.substring(contextPath.length());

    int idx = reqStr.lastIndexOf(46);
    if (idx != -1)
      reqStr = reqStr.substring(0, idx);
    if (reqStr.startsWith("/"))
      reqStr = reqStr.substring(1);

    int idx2 = reqStr.lastIndexOf(47);
    if (idx2 != -1)
      reqStr = reqStr.substring(idx2 + 1, reqStr.length());

    return reqStr;
  }
}