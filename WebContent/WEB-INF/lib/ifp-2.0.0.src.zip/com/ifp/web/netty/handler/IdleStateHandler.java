package com.ifp.web.netty.handler;

import com.ifp.adapter.netty.LongConnectAdapter;
import io.netty.channel.ChannelHandler.Sharable;
import java.util.concurrent.TimeUnit;

@ChannelHandler.Sharable
public class IdleStateHandler extends io.netty.handler.timeout.IdleStateHandler
  implements LongConnectAdapter
{
  public IdleStateHandler(long readerIdleTime, long writerIdleTime, long allIdleTime, TimeUnit unit)
  {
    super(readerIdleTime, writerIdleTime, allIdleTime, unit);
  }
}