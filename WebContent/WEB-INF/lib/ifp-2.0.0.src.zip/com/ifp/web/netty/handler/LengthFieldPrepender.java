package com.ifp.web.netty.handler;

import com.ifp.adapter.netty.LongConnectAdapter;
import com.ifp.adapter.netty.ShortConnectAdapter;
import java.nio.ByteOrder;

public class LengthFieldPrepender extends io.netty.handler.codec.LengthFieldPrepender
  implements LongConnectAdapter, ShortConnectAdapter
{
  public LengthFieldPrepender(int lengthFieldLength)
  {
    this(lengthFieldLength, false);
  }

  public LengthFieldPrepender(int lengthFieldLength, boolean lengthIncludesLengthFieldLength)
  {
    this(lengthFieldLength, 0, lengthIncludesLengthFieldLength);
  }

  public LengthFieldPrepender(int lengthFieldLength, int lengthAdjustment)
  {
    this(lengthFieldLength, lengthAdjustment, false);
  }

  public LengthFieldPrepender(int lengthFieldLength, int lengthAdjustment, boolean lengthIncludesLengthFieldLength)
  {
    this(ByteOrder.BIG_ENDIAN, lengthFieldLength, lengthAdjustment, lengthIncludesLengthFieldLength);
  }

  public LengthFieldPrepender(ByteOrder byteOrder, int lengthFieldLength, int lengthAdjustment, boolean lengthIncludesLengthFieldLength)
  {
    super(byteOrder, lengthFieldLength, lengthAdjustment, lengthIncludesLengthFieldLength);
  }
}