package com.ifp.web.flow.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.flow.action.AbstractAction;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;

public class ConnectAction extends AbstractAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws ActionException
  {
    String url = "http://localhost:8003/ifp-web/ifp2.do?type=K&flumeLogId=" + ((DataMap)context.getDataMap()).getElementValue("flumeLogId");
    HttpClient httpClient = new DefaultHttpClient();
    HttpPost httpPost = new HttpPost(url);
    try
    {
      HttpResponse response = httpClient.execute(httpPost);
      System.out.println("----------------------------------------");
      System.out.println(response.getStatusLine());
      System.out.println("----------------------------------------");
      HttpEntity entity = response.getEntity();
      if (entity != null) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(entity.getContent(), "UTF-8"));
        try {
          String value = reader.readLine();
          while (value != null) {
            System.out.println(value);
            value = reader.readLine();
          }
        }
        catch (IOException ex)
        {
        }
        catch (RuntimeException ex) {
          throw ex;
        } finally {
          reader.close();
        }
      }
      httpClient.getConnectionManager().shutdown();
    } catch (ClientProtocolException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }

    return 0;
  }
}