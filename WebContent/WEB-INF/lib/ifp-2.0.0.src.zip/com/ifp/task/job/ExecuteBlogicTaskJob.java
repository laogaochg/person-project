package com.ifp.task.job;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.data.OutputField;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.DataChangeException;
import com.ifp.core.flow.FlowHandle;
import com.ifp.core.flow.logic.BusinessLogic;
import com.ifp.core.flow.util.ContextMapChangeUtil;
import com.ifp.core.log.IfpActionLogInfo;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.Trace;
import com.ifp.core.monitor.Monitor;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.DataMapChangeUtil;
import com.ifp.core.util.DateUtil;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.web.common.IFPConstance;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExecuteBlogicTaskJob
{
  private String blogicId;
  private Map<String, Object> inputParams;

  public void execute()
  {
    Trace.logInfo("SCHEDULE", "execute blogic[{}] task job start...", new Object[] { this.blogicId });
    try {
      executeBlogic(null, this.blogicId, this.inputParams);
    } catch (BaseException e) {
      Trace.logError("SCHEDULE", "execute blogic[{}] task job fail!", new Object[] { this.blogicId, e });
    } catch (Exception e) {
      Trace.logError("SCHEDULE", "execute blogic[{}] task job fail!", new Object[] { this.blogicId, e });
    }
    Trace.logInfo("SCHEDULE", "execute blogic[{}] task job end", new Object[] { this.blogicId });
  }

  public void executeBlogic(Map<String, Object> context, String logicId, Map<String, Object> paramsMap)
    throws Exception
  {
    if (StringUtil.hasText(logicId)) {
      LogHandle logHandle = null;
      Monitor monitor = new Monitor();
      MonitorManager monitorMgr = (MonitorManager)SpringContextsUtil.getBean("monitorManager");
      try {
        Long startTime = Long.valueOf(new Date().getTime());
        logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
        logHandle.init();

        InetAddress addr = InetAddress.getLocalHost();
        String flumeReqIp = addr.getHostAddress().toString();
        String flumeReqId = null;
        String flumePid = null;
        String flumeCid = logHandle.getFlumeLogCid();

        logHandle.setFlumeLogInf(null, logicId, flumeReqId, flumeCid, flumePid, flumeReqIp, startTime);

        monitor.setLogicCode(logicId);
        monitor.setMonitorId(flumeCid);
        monitorMgr.put(monitor);

        FlowHandle blFlowHandle = (FlowHandle)SpringContextsUtil.getBean("blFlowHandle");
        blFlowHandle.setMonitorManager(monitorMgr);
        BusinessLogic businessLogic = (BusinessLogic)SpringContextsUtil.getBean(logicId);
        BlogicContext blogicContext = new BlogicContext();
        blogicContext.setLogicCode(logicId);
        blogicContext.setCreateTime(DateUtil.getStringToday());
        blogicContext.setMonitorId(flumeCid);

        if (null == paramsMap) {
          paramsMap = new HashMap();
        }

        DataMap dataMap = null;
        if (paramsMap instanceof DataMap)
        {
          blogicContext.setDataMap((DataMap)paramsMap);
        }
        else
        {
          ContextMapChangeUtil.doUpdateInputDataMap(paramsMap, blogicContext, businessLogic, true);
        }
        Trace.logInfo("SCHEDULE", "blogic[{}] input param: {}", new Object[] { logicId, dataMap });

        String result = blFlowHandle.execute(businessLogic, blogicContext);
        if (null != context)
          doUpdateOutputDataMap(context, businessLogic, blogicContext);

        Trace.logInfo("SCHEDULE", "execute blogic[{}] result: {}", new Object[] { logicId, result });
      } catch (Exception e) {
      }
      finally {
        if (monitor != null)
        {
          monitorMgr.remove(monitor);
        }
        if (null != logHandle)
          logHandle.destroy();
      }
    }
    else {
      Trace.logError("SCHEDULE", "cant not found logic: {}", new Object[] { logicId });
    }
  }

  private void doUpdateOutputDataMap(Map<String, Object> context, BusinessLogic businessLogic, BlogicContext blogicContext)
    throws ActionException, DataChangeException
  {
    if (null != blogicContext.getDataMap()) {
      DataMap dataMap = (DataMap)blogicContext.getDataMap();
      DataList outList = businessLogic.outputParamsList;
      if (null != outList)
        for (int i = 0; i < outList.size(); ++i) {
          OutputField outField = (OutputField)outList.get(i);
          DataElement dataElement = dataMap.get(outField.getName());
          if (null != dataElement)
            if (dataElement instanceof DataField) {
              DataField dataField = (DataField)dataElement;
              context.put(outField.getTargetName(), dataField.getValue());
            } else if (dataElement instanceof DataList) {
              DataList dataList = (DataList)dataElement;
              List list = new ArrayList();
              DataMapChangeUtil.dataListToList(dataList, list);
              context.put(outField.getTargetName(), list);
            }
          else
            context.put(outField.getTargetName(), "");
        }


      context.put(IFPConstance.LOGFIELDDEFINE, (IfpActionLogInfo)blogicContext.getTemp(IFPConstance.LOGFIELDDEFINE));
      context.put(IFPConstance.ERRORCODE, ((DataField)dataMap.get(IFPConstance.ERRORCODE)).getValue());
      context.put(IFPConstance.ERRORMSG, ((DataField)dataMap.get(IFPConstance.ERRORMSG)).getValue());
    }
  }

  public String getBlogicId() {
    return this.blogicId;
  }

  public void setBlogicId(String blogicId) {
    this.blogicId = blogicId;
  }

  public Map<String, Object> getInputParams() {
    return this.inputParams;
  }

  public void setInputParams(Map<String, Object> inputParams) {
    this.inputParams = inputParams;
  }
}