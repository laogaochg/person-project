package com.ifp.adapter;

public abstract interface IAdapter<T>
{
  public abstract void init();

  public abstract void execute(T paramT);

  public abstract void destory();
}