package com.ifp.adapter.util;

import com.ifp.core.log.Trace;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang.StringUtils;

public class FileUtil
{
  private static Map<String, InputStream> files = new HashMap();
  private static Map<String, Integer> userCount = new HashMap();

  public static InputStream getInputStream(String filePath)
  {
    if (StringUtils.isBlank(filePath))
      return null;

    if (null == files.get(filePath)) {
      files.put(filePath, FileUtil.class.getResourceAsStream(filePath));
      userCount.put(filePath, Integer.valueOf((null == userCount.get(filePath)) ? 0 : ((Integer)userCount.get(filePath)).intValue() + 1));
    }

    return ((InputStream)files.get(filePath));
  }

  public static void closeInputStream(String filePath) {
    Integer count = (Integer)userCount.get(filePath);
    if (null != count);
    count = Integer.valueOf(((count = Integer.valueOf(count.intValue() - 1)).intValue() < 0) ? 0 : count.intValue());
    if (count.intValue() == 0) {
      InputStream inputStream = (InputStream)files.remove(filePath);
      if (null != inputStream)
        closeInputStream(inputStream);
    }
  }

  public static void closeInputStream(InputStream in)
  {
    if (in != null)
      try {
        in.close();
      } catch (IOException e) {
        Trace.log("MESSAGE", 3, "close InputStream 异常", e);
      }
  }
}