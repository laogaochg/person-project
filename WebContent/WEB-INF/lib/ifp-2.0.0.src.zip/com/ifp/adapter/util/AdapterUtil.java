package com.ifp.adapter.util;

import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.dom4j.Document;
import org.xml.sax.InputSource;

public class AdapterUtil
{
  public static Document loadXMLDocument(InputStream in)
    throws Exception
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    try
    {
      DocumentBuilder builder = factory.newDocumentBuilder();

      InputSource inputSource = new InputSource();
      inputSource.setByteStream(in);

      Document document = (Document)builder.parse(inputSource);
      return document;
    }
    catch (Exception ioe) {
      throw ioe;
    }
  }

  public static int getIteratorSize(Iterator iterator)
  {
    int size = 0;
    while (iterator.hasNext())
    {
      ++size;
      iterator.next();
    }
    return size;
  }

  public static Object getValue(Map<String, Object> map, String key)
  {
    return map.get(key);
  }

  public static Object setValue(Map<String, Object> map, String key, Object obj)
  {
    return map.put(key, obj);
  }
}