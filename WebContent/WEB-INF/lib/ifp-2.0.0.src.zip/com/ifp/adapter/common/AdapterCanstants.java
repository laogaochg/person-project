package com.ifp.adapter.common;

public class AdapterCanstants
{
  public static final String DEFAULT_ENCODING = "UTF-8";
  public static final String SOAPENV = "soapenv:";
  public static final String SOAP_BODY_CONTEXT_NAME = "SOAP_BODY_CONTEXT_NAME";
  public static final String SOAP_BODY_ATTR_NAME = "name";
  public static final String SOAP_BODY_LIST_NODENAME = "list";
  public static final String SOAP_BODY_COLL_NODENAME = "coll";
  public static final String SOAP_BODY_FIELD_NODENAME = "field";
  public static final String SOAP_BODY_FIELD_ARRTNAME = "name";
  public static final String SOAP_HEADER_HEADTYPE = "HeadType";
  public static final String SOAP_Envelope = "SOAP_Envelope";
  public static final String SOAP_HEADER_HEADTYPE_ARRT = "SOAP_HEADER_HEADTYPE_ARRT";
  public static final String SOAP_HEADER = "soapenv:Header";
  public static final String SOAP_BODY = "soapenv:Body";
  public static final String SOAP_BODY_PREFIX = "SOAP_BODY_PREFIX";
  public static final String XML_BODY_CONTEXT_NAME = "XML_BODY_CONTEXT_NAME";
  public static final String XML_BODY_LIST_NODENAME = "XML_BODY_LIST_NODENAME";
  public static final String XML_BODY_LIST_ARRTNAME = "XML_BODY_LIST_ARRTNAME";
  public static final String XML_BODY_COLL_NODENAME = "XML_BODY_COLL_NODENAME";
  public static final String XML_VERSION = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>";
  public static final String BODY = "body";
  public static final String HEADER = "header";
  public static final String TOP_HEAD = "topHead";
  public static final String ENCRYPT_DATA = "encryptDataArea";
  public static final String SOAPMESSAGE_OBJECT = "soapMessageObject";
  public static final String REQUEST_DATAMAP = "requestDataMap";
  public static final String ATTR_EXCEPTION = "exception";
  public static final String FIELD_SRC_DATA = "srcData";
  public static final String FIELD_SIGN_DATA = "signData";
  public static final String SIGN_CHANNEL_CODE = "signChannelCode";
}