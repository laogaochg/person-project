package com.ifp.adapter;

import com.ifp.adapter.process.Processor;
import java.util.Map;

public abstract class BaseAdapter<T>
  implements IAdapter<T>
{
  private Map<String, Processor> processorMap;

  public void init()
  {
  }

  public void execute(T t)
  {
  }

  public void destory()
  {
  }

  public Map<String, Processor> getProcessorMap()
  {
    return this.processorMap;
  }

  public void setProcessorMap(Map<String, Processor> processorMap) {
    this.processorMap = processorMap;
  }
}