package com.ifp.adapter.process;

import com.ifp.adapter.exception.FormatException;
import com.ifp.adapter.exception.UnformatException;
import com.ifp.adapter.message.field.MessageField;
import com.ifp.adapter.message.head.DefaultHead;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;

public class KValueProcessor extends BaseProcessor
{
  DefaultHead defaultHead;
  private static final String LIST_PATTERN = "([^\\]]{1,})((\\[([^\\]]{1,})\\]){2}){1,}";
  private static final String LIST_PATTERN2 = "([^\\.]{1,})(\\.([^\\]]{1,})(\\[([^\\]]{1,})\\])){1,}";
  private String formatType;
  private List<String> headFieldList;

  public KValueProcessor()
  {
    this.formatType = "3";

    this.headFieldList = new ArrayList();
  }

  public String format(Map<String, Object> dataMap) throws BaseException {
    String repMsg;
    try {
      repMsg = mapToKValueStr(dataMap);
      if (repMsg.startsWith("&"))
        repMsg = repMsg.substring(1);
      Trace.log("ADAPTER", 0, "KValue format Context is :{}", new Object[] { repMsg });
    } catch (Exception e) {
      throw new FormatException("SAFF0001", "报文组装异常", e);
    }
    return repMsg;
  }

  public Map<String, Object> unformat(HttpServletRequest request) throws BaseException
  {
    Map kValueMap = new HashMap();
    try {
      Map.Entry paramsEntry;
      String name;
      String[] values;
      String listName;
      Map head = new HashMap();
      Map body = new HashMap();

      Map listMap = new HashMap();

      Map paramsMap = request.getParameterMap();

      for (Iterator i$ = this.headFieldList.iterator(); i$.hasNext(); ) { String headField = (String)i$.next();
        if (request.getHeader(headField) != null)
          head.put(headField, StringUtil.unformatHtmlText(request.getHeader(headField)));

      }

      Iterator paramsIterator = paramsMap.entrySet().iterator();
      if (this.formatType.equals("1")) while (true) {
          if (!(paramsIterator.hasNext())) break label724;
          paramsEntry = (Map.Entry)paramsIterator.next();
          name = (String)paramsEntry.getKey();
          values = (String[])paramsEntry.getValue();
          if (Pattern.matches("([^\\]]{1,})((\\[([^\\]]{1,})\\]){2}){1,}", name)) {
            listName = name.substring(0, name.indexOf(91));
            String fields = name.substring(name.indexOf(91));
            Map fieldsMap = (listMap.get(listName) == null) ? new HashMap() : (Map)listMap.get(listName);
            listMap.put(listName, putListValueToMap2(fields, values[0], fieldsMap));
          } else {
            body.put(name, StringUtil.unformatHtmlText(values[0]));
          }
        }
      if (this.formatType.equals("2")) while (true) {
          if (!(paramsIterator.hasNext())) break label724;
          paramsEntry = (Map.Entry)paramsIterator.next();
          name = (String)paramsEntry.getKey();
          values = (String[])paramsEntry.getValue();
          if (Pattern.matches("([^\\.]{1,})(\\.([^\\]]{1,})(\\[([^\\]]{1,})\\])){1,}", name)) {
            listName = name.substring(0, name.indexOf(46));
            Map fieldsMap = (listMap.get(listName) == null) ? new HashMap() : (Map)listMap.get(listName);
            listMap.put(listName, putListValueToMap(name.substring(name.indexOf(46) + 1), values[0], fieldsMap));
          } else {
            body.put(name, StringUtil.unformatHtmlText(values[0]));
          }
        }

      while (paramsIterator.hasNext()) {
        paramsEntry = (Map.Entry)paramsIterator.next();
        name = (String)paramsEntry.getKey();
        values = (String[])paramsEntry.getValue();
        if (values.length > 1) {
          listName = name.substring(0, name.indexOf(46));
          String keyName = name.substring(name.indexOf(46) + 1);
          Map childMap = (listMap.get(listName) == null) ? new HashMap() : (Map)listMap.get(listName);
          for (int i = 0; i < values.length; ++i)
          {
            Map indexMap = (childMap.get(String.valueOf(i)) == null) ? new HashMap() : (Map)childMap.get(String.valueOf(i));
            indexMap.put(keyName, StringUtil.unformatHtmlText(values[i]));
            childMap.put(String.valueOf(i), indexMap);
          }
          listMap.put(listName, childMap);
        } else {
          body.put(name, StringUtil.unformatHtmlText(values[0]));
        }

      }

      if (listMap.size() > 0) {
        label724: mapToList(listMap, body);
      }

      kValueMap.put("header", head);
      kValueMap.put("body", body);
      Trace.log("ADAPTER", 0, "unformat's Map is :{}", new Object[] { kValueMap });
    } catch (Exception e) {
      throw new UnformatException("SAFU0001", "报文解析异常", e);
    }
    return kValueMap;
  }

  private Map<String, Object> putListValueToMap(String fields, String value, Map<String, Object> fieldsMap)
  {
    String fieldName = fields.substring(0, fields.indexOf(91));
    String index = fields.substring(fields.indexOf(91) + 1, fields.indexOf(93));
    Map listParamMap = (fieldsMap.get(index) == null) ? new HashMap() : (Map)fieldsMap.get(index);
    if (fields.indexOf(46) != -1)
    {
      String childParamName = fields.substring(fields.indexOf(46) + 1);
      Map childMap = (listParamMap.get(fieldName) == null) ? new HashMap() : (Map)listParamMap.get(fieldName);
      listParamMap.put(fieldName, putListValueToMap(childParamName, value, childMap));
    } else {
      listParamMap.put(fieldName, StringUtil.unformatHtmlText(value));
    }
    fieldsMap.put(index, listParamMap);
    return fieldsMap;
  }

  private Map<String, Object> putListValueToMap2(String fields, String value, Map<String, Object> fieldsMap)
  {
    String index = fields.substring(fields.indexOf(91) + 1, fields.indexOf(93));
    String childFields = fields.substring(fields.indexOf(93) + 2);
    String fieldName = childFields.substring(0, childFields.indexOf(93));
    Map listParamMap = (fieldsMap.get(index) == null) ? new HashMap() : (Map)fieldsMap.get(index);
    if (childFields.indexOf(91) != -1)
    {
      String childParamName = childFields.substring(childFields.indexOf(91));
      Map childMap = (listParamMap.get(fieldName) == null) ? new HashMap() : (Map)listParamMap.get(fieldName);
      listParamMap.put(fieldName, putListValueToMap2(childParamName, value, childMap));
    } else {
      listParamMap.put(fieldName, StringUtil.unformatHtmlText(value));
    }
    fieldsMap.put(index, listParamMap);
    return fieldsMap;
  }

  private void mapToList(Map<String, Object> listMap, Map<String, Object> dataMap)
  {
    for (Iterator i$ = listMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();

      dataMap.put(entry.getKey(), objectToList(entry.getValue()));
    }
  }

  private List<Object> objectToList(Object obj)
  {
    List list = new ArrayList();
    if (obj instanceof Map)
    {
      Map listMap = (Map)obj;
      for (Iterator i$ = listMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();

        list.add(ObjectToMap(entry.getValue()));
      }
    }
    return list;
  }

  private Map<String, Object> ObjectToMap(Object obj)
  {
    Map map = (Map)obj;
    for (Iterator i$ = map.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();

      if (entry.getValue() instanceof Map)
      {
        map.put(entry.getKey(), objectToList(entry.getValue()));
      }
    }
    return map;
  }

  private String mapToKValueStr(Map<String, Object> dataMap)
  {
    if (null == dataMap)
      return "";

    StringBuffer repMsg = new StringBuffer();
    String key = null;
    Object value = null;
    for (Iterator i$ = dataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();

      key = (String)entry.getKey();
      value = dataMap.get(key);
      if (value instanceof String)
      {
        repMsg.append("&").append(key).append("=");
        repMsg.append(URLDecoder.decode((String)value).trim());
      } else if (value instanceof List)
      {
        repMsg.append(listToKValueStr((List)value, key));
      } else if (value instanceof Map)
      {
        repMsg.append(mapToKValueStr((Map)value));
      } else {
        repMsg.append(URLDecoder.decode(String.valueOf(value)).trim());
      }
    }
    return repMsg.toString();
  }

  private String listToKValueStr(List dataList, String listName)
  {
    if (null == dataList) {
      return "";
    }

    StringBuffer repMsg = new StringBuffer();
    for (int i = 0; i < dataList.size(); ++i)
    {
      if (dataList.get(i) instanceof Map)
      {
        Map dataMap = (Map)dataList.get(i);
        for (Iterator i$ = dataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();

          if (entry.getValue() instanceof List)
          {
            repMsg.append(listToKValueStr((List)entry.getValue(), listName + "." + ((String)entry.getKey()) + "[" + i + "]"));
          }
          else repMsg.append("&").append(listName).append(".").append((String)entry.getKey()).append("[").append(i).append("]").append("=");
        }
      }
    }

    return repMsg.toString();
  }

  public DefaultHead getDefaultHead() {
    return this.defaultHead;
  }

  public void setDefaultHead(DefaultHead defaultHead) {
    this.defaultHead = defaultHead;
    if (defaultHead != null) {
      List fieldOrder = defaultHead.getFieldOrder();
      for (int i = 0; i < fieldOrder.size(); ++i)
        this.headFieldList.add(((MessageField)fieldOrder.get(i)).getName());
    }
  }

  public String getFormatType()
  {
    return this.formatType;
  }

  public void setFormatType(String formatType) {
    this.formatType = formatType;
  }
}