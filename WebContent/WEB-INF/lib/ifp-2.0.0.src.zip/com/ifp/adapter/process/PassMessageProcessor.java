package com.ifp.adapter.process;

import com.ifp.adapter.exception.FormatException;
import com.ifp.adapter.exception.UnformatException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import java.util.HashMap;
import java.util.Map;

public class PassMessageProcessor extends BaseProcessor
{
  private String msgKey;

  public PassMessageProcessor()
  {
    this.msgKey = "passMessageInOne";
  }

  public Map<String, Object> unformat(String message) throws BaseException {
    Trace.log("ADAPTER", 1, "receive msg is :{}", new Object[] { message });
    Map dataMap = new HashMap();
    try {
      Map headMap = new HashMap();
      Map bodyMap = new HashMap();

      bodyMap.put(this.msgKey, message);

      dataMap.put("header", headMap);
      dataMap.put("body", bodyMap);
      Trace.log("ADAPTER", 1, "unformat's Map is :{}", new Object[] { dataMap });
    } catch (Exception e) {
      throw new UnformatException("SAFU0001", "报文解析异常", e);
    }
    return dataMap;
  }

  public String format(Map<String, Object> dataMap) throws BaseException {
    String message;
    Map bodyMap;
    try {
      bodyMap = (Map)dataMap.get("body");
      message = (String)bodyMap.get(this.msgKey);
      Trace.log("ADAPTER", 0, "response Context is :{}", new Object[] { message });
    } catch (Exception e) {
      throw new FormatException("SAFF0001", "报文组装异常", e);
    }
    return message;
  }

  public String getMsgKey() {
    return this.msgKey;
  }

  public void setMsgKey(String msgKey) {
    this.msgKey = msgKey;
  }
}