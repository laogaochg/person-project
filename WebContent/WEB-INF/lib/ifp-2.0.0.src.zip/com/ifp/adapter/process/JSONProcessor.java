package com.ifp.adapter.process;

import com.ifp.adapter.exception.FormatException;
import com.ifp.adapter.exception.UnformatException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public class JSONProcessor extends BaseProcessor
{
  public Map<String, Object> unformat(String message)
    throws BaseException
  {
    Trace.log("ADAPTER", 1, "receive msg is :{}", new Object[] { message });
    Map jsonMap = new HashMap();
    try {
      JSONObject jsonObject = new JSONObject(message);
      jsonMap = jsonToMap(jsonObject);
    } catch (Exception e) {
      throw new UnformatException("SAFU0001", "报文解析异常", e);
    }
    Trace.log("ADAPTER", 1, "unformat's Map is :{}", new Object[] { jsonMap });
    return jsonMap;
  }

  public String format(Map<String, Object> dataMap) throws BaseException
  {
    String repMsg;
    try
    {
      repMsg = mapToJson(dataMap);
      Trace.log("ADAPTER", 0, "json format Context is :{}", new Object[] { repMsg });
    } catch (Exception e) {
      throw new FormatException("SAFF0001", "报文组装异常", e);
    }
    return repMsg;
  }

  public String mapToJson(Map<String, Object> dataMap)
  {
    if (null == dataMap)
      return "{}";

    StringBuffer repMsg = new StringBuffer();
    String key = null;
    Object value = null;
    repMsg.append("{");
    for (Iterator i$ = dataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();

      key = (String)entry.getKey();
      repMsg.append("\"").append(key).append("\":");
      value = dataMap.get(key);
      if ((null == value) || (value instanceof String));
      switch (getOutHtmlFilter())
      {
      case 1:
        repMsg.append("\"").append(StringUtil.formatJSONText(StringUtil.formatHtmlText((String)value))).append("\"");
        break;
      case 2:
        repMsg.append("\"").append(StringUtil.formatJSONText(StringUtil.formatHtmlText1((String)value))).append("\"");
        break;
      case 3:
        repMsg.append("\"").append(StringUtil.formatJSONText(StringUtil.formatHtmlText2((String)value))).append("\"");
        break;
      default:
        repMsg.append("\"").append(StringUtil.formatJSONText((String)value)).append("\"");
        break label446:

        if (value instanceof Map)
        {
          repMsg.append(mapToJson((Map)value));
        } else if (value instanceof List)
        {
          repMsg.append(listToJson((List)value));
        }
        else switch (getOutHtmlFilter())
          {
          case 1:
            repMsg.append("\"").append(StringUtil.formatJSONText(StringUtil.formatHtmlText(value.toString()))).append("\"");
            break;
          case 2:
            repMsg.append("\"").append(StringUtil.formatJSONText(StringUtil.formatHtmlText1(value.toString()))).append("\"");
            break;
          case 3:
            repMsg.append("\"").append(StringUtil.formatJSONText(StringUtil.formatHtmlText2(value.toString()))).append("\"");
            break;
          default:
            repMsg.append("\"").append(StringUtil.formatJSONText(value.toString())).append("\"");
          }
      }

      label446: repMsg.append(",");
    }

    if (repMsg.toString().lastIndexOf(",") != -1) repMsg.deleteCharAt(repMsg.length() - 1);
    repMsg.append("}");
    return repMsg.toString();
  }

  public String listToJson(List<Object> dataList)
  {
    if (dataList == null) return "[]";
    StringBuffer repMsg = new StringBuffer();
    repMsg.append("[");

    for (int i = 0; i < dataList.size(); ++i)
    {
      if (dataList.get(i) instanceof Map)
      {
        repMsg.append(mapToJson((Map)dataList.get(i)));
      }
      if (i < dataList.size() - 1)
      {
        repMsg.append(",");
      }
    }
    repMsg.append("]");
    return repMsg.toString();
  }

  public List<Object> jsonToList(JSONArray jsonArray)
    throws Exception
  {
    List jsonList = new ArrayList();
    try {
      for (int i = 0; i < jsonArray.length(); ++i)
      {
        Object valueObject = jsonArray.get(i);
        if (valueObject instanceof JSONArray)
        {
          jsonList.add(jsonToList((JSONArray)valueObject));
        } else if (valueObject instanceof JSONObject)
        {
          jsonList.add(jsonToMap((JSONObject)valueObject));
        }
        else jsonList.add(StringUtil.unformatHtmlText(String.valueOf(valueObject)));
      }
    }
    catch (Exception e) {
      Trace.log("ADAPTER", 3, "JSONArray To List Error：{}", new Object[] { jsonArray.toString() });
      throw e;
    }
    return jsonList;
  }

  public Map<String, Object> jsonToMap(JSONObject jsonObject)
    throws Exception
  {
    Map jsonMap = new HashMap();
    Set keySet = jsonObject.keySet();
    try {
      for (Iterator i$ = keySet.iterator(); i$.hasNext(); ) { String key = (String)i$.next();

        Object valueObject = jsonObject.get(key);
        if (valueObject instanceof JSONArray)
        {
          jsonMap.put(key, jsonToList((JSONArray)valueObject));
        } else if (valueObject instanceof JSONObject)
        {
          jsonMap.put(key, jsonToMap((JSONObject)valueObject));
        }
        else jsonMap.put(key, StringUtil.unformatHtmlText(String.valueOf(valueObject)));
      }
    }
    catch (Exception e) {
      Trace.log("ADAPTER", 3, "jsonObject To Map Error：{}", new Object[] { jsonObject.toString() });
      throw e;
    }
    return jsonMap;
  }
}