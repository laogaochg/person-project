package com.ifp.adapter.process;

import com.ifp.adapter.exception.FormatException;
import com.ifp.adapter.exception.UnformatException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

public class XMLProcessor1 extends BaseProcessor
{
  private Map<String, String> xmlConfig;

  public Map<String, Object> unformat(String message)
    throws BaseException
  {
    Trace.log("ADAPTER", 0, "recive xml's Msg is :{}", new Object[] { message });
    Map xmlMap = new HashMap();
    try
    {
      Document document = DocumentHelper.parseText(message);
      Element rootElement = document.getRootElement();
      if (!(getRootName().equals(rootElement.getName())))
        throw new Exception("xml's Msg isn't Correct!!!");

      xmlMap = xmlToMap(rootElement);
    } catch (Exception e) {
      throw new UnformatException("SAFU0001", "报文解析异常", e);
    }
    Trace.log("ADAPTER", 1, "unformat's Map is :{}", new Object[] { xmlMap });
    return xmlMap;
  }

  public String format(Map<String, Object> dataMap)
    throws BaseException
  {
    StringBuffer repMsg = new StringBuffer();
    try {
      repMsg.append("<?xml version=").append("\"").append(getVersionConfig()).append("\"").append(" encoding=\"").append(getEncodeConfig()).append("\" ?>");
      repMsg.append("<").append(getRootName()).append(">");
      repMsg.append("<").append("header").append(">");
      repMsg.append(mapToXml((Map)dataMap.get("header")));
      repMsg.append("</header>");
      repMsg.append("<body>");
      repMsg.append(mapToXml((Map)dataMap.get("body")));
      repMsg.append("</body>");
      repMsg.append("</").append(getRootName()).append(">");
      Trace.log("ADAPTER", 0, "xml format Context is :{}", new Object[] { repMsg.toString() });
    } catch (Exception e) {
      throw new FormatException("SAFF0001", "报文组装异常", e);
    }
    return repMsg.toString();
  }

  private String mapToXml(Map<String, Object> dataMap)
    throws Exception
  {
    if (dataMap == null) return "";
    StringBuffer repMsg = new StringBuffer();
    try {
      String key = null;
      Object value = null;
      for (Iterator i$ = dataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        key = (String)entry.getKey();
        value = entry.getValue();
        if ((null == value) || (value instanceof String)) {
          repMsg.append("<").append(key).append(">");
          switch (getOutHtmlFilter())
          {
          case 1:
            repMsg.append(StringUtil.formatHtmlText((String)value));
            break;
          case 2:
            repMsg.append(StringUtil.formatHtmlText1((String)value));
            break;
          case 3:
            repMsg.append(StringUtil.formatHtmlText2((String)value));
            break;
          default:
            repMsg.append((String)value);
          }

          repMsg.append("</").append(key).append(">");
        } else if (value instanceof Map) {
          repMsg.append("<").append(key).append(">");
          repMsg.append(mapToXml((Map)value));
          repMsg.append("</").append(key).append(">");
        } else if (value instanceof List) {
          repMsg.append(listToXml((List)value, key));
        } else {
          repMsg.append("<").append(key).append(">");
          switch (getOutHtmlFilter())
          {
          case 1:
            repMsg.append(StringUtil.formatHtmlText(value.toString()));
            break;
          case 2:
            repMsg.append(StringUtil.formatHtmlText1(value.toString()));
            break;
          case 3:
            repMsg.append(StringUtil.formatHtmlText2(value.toString()));
            break;
          default:
            repMsg.append(value.toString());
          }

          repMsg.append("</").append(key).append(">");
        }
      }
    } catch (Exception e) {
      Trace.log("ADAPTER", 3, "dataMap To Xml Error:{}", e);
      throw e;
    }
    return repMsg.toString();
  }

  private String listToXml(List<Map<String, Object>> dataList, String key)
    throws Exception
  {
    StringBuffer repMsg = new StringBuffer();
    try
    {
      for (Iterator i$ = dataList.iterator(); i$.hasNext(); ) { Map dataMap = (Map)i$.next();
        repMsg.append("<").append(key).append(">");
        repMsg.append(mapToXml(dataMap));
        repMsg.append("</").append(key).append(">");
      }
    }
    catch (Exception e) {
      Trace.log("ADAPTER", 3, "dataList To Xml Error:{}", e);
      throw e;
    }
    return repMsg.toString();
  }

  private Map<String, Object> xmlToMap(Element element)
    throws Exception
  {
    if (element == null) return null;
    Map xmlMap = new HashMap();
    try
    {
      List childElementList = element.elements();
      Iterator i$ = childElementList.iterator();
      while (true) { Element childElement;
        String key;
        while (true) { if (!(i$.hasNext())) break label171; childElement = (Element)i$.next();
          key = childElement.getName();

          if (!(key.toLowerCase().endsWith(getListConfig().toLowerCase())))
            break label116;
          if (!(xmlMap.keySet().contains(key)))
            break;
        }

        xmlMap.put(key, xmlToList(element, key)); continue;
        label171: if (childElement.elements().size() == 0)
          label116: xmlMap.put(key, StringUtil.unformatHtmlText(childElement.getText()));
        else
          xmlMap.put(key, xmlToMap(childElement));
      }
    }
    catch (Exception e)
    {
      Trace.log("ADAPTER", 3, "xml's Msg To Map Error:{}", e);
      throw e;
    }
    return xmlMap;
  }

  private List<Map<String, Object>> xmlToList(Element element, String key)
    throws Exception
  {
    if (element == null) return null;
    List xmlList = new ArrayList();
    try {
      List dataList = element.elements(key);
      for (int j = 0; j < dataList.size(); ++j)
        xmlList.add(xmlToMap((Element)dataList.get(j)));
    }
    catch (Exception e) {
      Trace.log("ADAPTER", 3, "xml's Msg To List Error:{}", e);
      throw e;
    }
    return xmlList;
  }

  private String getRootName()
  {
    if ((this.xmlConfig != null) && 
      (this.xmlConfig.get("rootName") != null)) return ((String)this.xmlConfig.get("rootName"));

    return "ifp";
  }

  private String getListConfig()
  {
    if ((this.xmlConfig != null) && 
      (this.xmlConfig.get("listName") != null)) return ((String)this.xmlConfig.get("listName"));

    return "list";
  }

  private String getVersionConfig()
  {
    if ((this.xmlConfig != null) && 
      (this.xmlConfig.get("version") != null)) return ((String)this.xmlConfig.get("version"));

    return "1.0";
  }

  private String getEncodeConfig()
  {
    if ((this.xmlConfig != null) && 
      (this.xmlConfig.get("encode") != null)) return ((String)this.xmlConfig.get("encode"));

    return "UTF-8";
  }

  public Map<String, String> getXmlConfig() {
    return this.xmlConfig;
  }

  public void setXmlConfig(Map<String, String> xmlConfig) {
    this.xmlConfig = xmlConfig;
  }
}