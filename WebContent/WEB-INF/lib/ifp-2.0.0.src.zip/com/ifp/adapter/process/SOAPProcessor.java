package com.ifp.adapter.process;

import com.ifp.adapter.exception.FormatException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Node;

public class SOAPProcessor extends BaseProcessor
{
  private Map<String, String> soapConfig;
  private static MessageFactory msgFactory;

  public String format(Map<String, Object> dataMap)
    throws BaseException
  {
    SOAPPart soapPart;
    try
    {
      soapPart = initSoapPart();
      SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
      setSoapHeader((Map)dataMap.get("header"), soapEnvelope);
      setSoapBody((Map)dataMap.get("body"), soapEnvelope);
      return soapToString(soapPart.getContent());
    } catch (Exception e) {
      throw new FormatException("SAFF0001", "报文组装异常", e);
    }
  }

  public Map<String, Object> unformat(String message) throws BaseException
  {
    Trace.log("ADAPTER", 1, "receive msg is :{}", new Object[] { message });
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    try {
      message = formatInput(new ByteArrayInputStream(message.getBytes()));
      SOAPMessage soapMessage = getMessageFactory().createMessage(new MimeHeaders(), new ByteArrayInputStream(message.getBytes()));
      SOAPPart soapPart = soapMessage.getSOAPPart();
      SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
      soapMessage.writeTo(out);
      if (!(getIFPNamespaceURI().equals(soapEnvelope.getNamespaceURI(getRootName()))))
        throw new Exception("soap's Msg isn't Correct!!!");

      Map soapMap = new HashMap();

      soapMap.put("header", soapToMap(soapEnvelope.getHeader()));
      soapMap.put("body", soapToMap(soapEnvelope.getBody()));

      Trace.log("ADAPTER", 1, "unformat's Map is :{}", new Object[] { soapMap });
      Map localMap1 = soapMap;

      return localMap1;
    }
    catch (Exception e)
    {
    }
    finally
    {
      try
      {
        if (out != null) out.close();
      } catch (Exception e2) {
        Trace.log("ADAPTER", 2, "close error!!!{}", e2);
      }
    }
  }

  private Map<String, Object> soapToMap(SOAPElement soapElement)
    throws Exception
  {
    Map soapMap = new HashMap();
    try
    {
      Iterator iteratorElement = soapElement.getChildElements();
      while (iteratorElement.hasNext()) {
        SOAPElement element = (SOAPElement)iteratorElement.next();
        String fieldName = element.getAttribute(getAtrrNameConfig());
        if (getListConfig().equals(element.getLocalName()))
        {
          soapMap.put(fieldName, soapToList(element));
        } else {
          String value = element.getValue();
          soapMap.put(fieldName, StringUtil.unformatHtmlText(value));
        }
      }
    } catch (Exception e) {
      Trace.log("ADAPTER", 3, "soap's Msg To Map Error:{}", e);
      throw e;
    }

    return soapMap;
  }

  private List<Map<String, Object>> soapToList(SOAPElement soapElement)
    throws Exception
  {
    List list = new ArrayList();
    try
    {
      Iterator iteratorElement = soapElement.getChildElements();
      while (iteratorElement.hasNext()) {
        SOAPElement element = (SOAPElement)iteratorElement.next();
        list.add(soapToMap(element));
      }
    } catch (Exception e) {
      Trace.log("ADAPTER", 3, "soap's Msg To List Error:{}", e);
      throw e;
    }

    return list;
  }

  private String soapToString(Source source)
    throws Exception
  {
    StringWriter output = new StringWriter();
    try {
      if (source != null) {
        Node root = ((DOMSource)source).getNode();
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.transform(new DOMSource(root), new StreamResult(output));
        Trace.log("ADAPTER", 0, "soap format Context is :{}", new Object[] { output.toString() });
        String str = output.toString();

        return str;
      }
    }
    catch (Exception e)
    {
      throw e;
    } finally {
      try {
        if (output != null) output.close();
      }
      catch (Exception e2) {
      }
    }
    return "";
  }

  private void setSoapHeader(Map<String, Object> dataMap, SOAPEnvelope soapEnvelope)
    throws Exception
  {
    if (dataMap == null) return;
    try {
      SOAPHeader soapHeader = soapEnvelope.getHeader();
      for (Iterator i$ = dataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();

        SOAPElement element = soapHeader.addChildElement(getFieldConfig(), getRootName());
        element.setAttribute(getAtrrNameConfig(), (String)entry.getKey());
        element.setValue(String.valueOf(entry.getValue()));
      }
    } catch (Exception e) {
      Trace.log("ADAPTER", 3, "set SOAPHeader ERROR:", e);
      throw e;
    }
  }

  private void setSoapBody(Map<String, Object> dataMap, SOAPEnvelope soapEnvelope)
    throws Exception
  {
    if (dataMap == null) return;
    try {
      SOAPBody soapBody = soapEnvelope.getBody();
      for (Iterator i$ = dataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();

        if (entry.getValue() instanceof String)
        {
          setSoapBodyField((String)entry.getKey(), String.valueOf(entry.getValue()), soapBody);
        } else if (entry.getValue() instanceof List)
        {
          setSoapBodyList((String)entry.getKey(), (List)entry.getValue(), soapBody);
        }
        else Trace.log("ADAPTER", 2, "(key:{},value:{})the value's Type isn't Correct!!!", new Object[] { entry.getKey(), entry.getValue() });
      }
    }
    catch (Exception e) {
      Trace.log("ADAPTER", 3, "set SOAPHeader ERROR:", e);
      throw e;
    }
  }

  private void setSoapBodyField(String key, String value, SOAPElement soapElement)
    throws Exception
  {
    SOAPElement element;
    try
    {
      element = soapElement.addChildElement(getFieldConfig(), getRootName());
      element.setAttribute(getAtrrNameConfig(), key);
      switch (getOutHtmlFilter())
      {
      case 1:
        element.setValue(StringUtil.formatHtmlText(value));
        break;
      case 2:
        element.setValue(StringUtil.formatHtmlText1(value));
        break;
      case 3:
        element.setValue(StringUtil.formatHtmlText2(value));
        break;
      default:
        element.setValue(value);
      }
    }
    catch (Exception e) {
      Trace.log("ADAPTER", 3, "(key:{},value:{})set SOAPBody's Field ERROR:{}", new Object[] { key, value, e });
      throw e;
    }
  }

  private void setSoapBodyList(String key, List listValue, SOAPElement element)
    throws Exception
  {
    SOAPElement listElement;
    try
    {
      listElement = element.addChildElement(getListConfig(), getRootName());
      listElement.setAttribute(getAtrrNameConfig(), key);
      for (int i = 0; i < listValue.size(); ++i)
      {
        SOAPElement collElement = listElement.addChildElement(getCollConfig(), getRootName());
        Map map = (Map)listValue.get(i);
        for (Iterator i$ = map.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();

          if (entry.getValue() instanceof String)
          {
            setSoapBodyField((String)entry.getKey(), String.valueOf(entry.getValue()), collElement);
          } else if (entry.getValue() instanceof List)
          {
            setSoapBodyList((String)entry.getKey(), (List)entry.getValue(), collElement);
          }
        }
      }
    } catch (Exception e) {
      Trace.log("ADAPTER", 3, "(key:{},value:{})set SOAPBody's List ERROR:{}", new Object[] { key, listValue, e });
      throw e;
    }
  }

  public SOAPPart initSoapPart()
    throws SOAPException, Exception
  {
    SOAPMessage soapMessage = getMessageFactory().createMessage();
    SOAPPart soapPart = soapMessage.getSOAPPart();
    SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
    soapEnvelope.addNamespaceDeclaration(getRootName(), getIFPNamespaceURI());

    soapEnvelope.addNamespaceDeclaration("xsi", "http://www.w3.org/2001/XMLSchema-instance");

    soapEnvelope.addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");

    soapEnvelope.addNamespaceDeclaration("SOAP-ENV", "http://schemas.xmlsoap.org/soap/encoding/");

    return soapPart;
  }

  public MessageFactory getMessageFactory() throws Exception {
    if (msgFactory == null)
      try {
        msgFactory = MessageFactory.newInstance();
      } catch (Exception e) {
        throw e;
      }

    return msgFactory;
  }

  private String getAtrrNameConfig()
  {
    if ((this.soapConfig != null) && 
      (this.soapConfig.get("attrName") != null)) return ((String)this.soapConfig.get("attrName"));

    return "name";
  }

  private String getRootName()
  {
    if ((this.soapConfig != null) && 
      (this.soapConfig.get("rootName") != null)) return ((String)this.soapConfig.get("rootName"));

    return "ifp";
  }

  private String getFieldConfig()
  {
    if ((this.soapConfig != null) && 
      (this.soapConfig.get("bodyFieldName") != null)) return ((String)this.soapConfig.get("bodyFieldName"));

    return "field";
  }

  private String getListConfig()
  {
    if ((this.soapConfig != null) && 
      (this.soapConfig.get("listName") != null)) return ((String)this.soapConfig.get("listName"));

    return "list";
  }

  private String getCollConfig()
  {
    if ((this.soapConfig != null) && 
      (this.soapConfig.get("collName") != null)) return ((String)this.soapConfig.get("collName"));

    return "coll";
  }

  private String getIFPNamespaceURI()
  {
    if ((this.soapConfig != null) && 
      (this.soapConfig.get("namespaceURI") != null)) return ((String)this.soapConfig.get("namespaceURI"));

    return "http://www.echplus.com/ifp";
  }

  private String formatInput(InputStream in)
    throws Exception
  {
    String str = "";
    try {
      str = StringUtil.inputStreamToString(in);

      Pattern p1 = Pattern.compile("\r|\n");
      Matcher m1 = p1.matcher(str);
      String after1 = m1.replaceAll("");

      Pattern p2 = Pattern.compile(">\\s*<");
      Matcher m2 = p2.matcher(after1);
      String after2 = m2.replaceAll("><");
      String str1 = after2;

      return str1;
    }
    catch (Exception e)
    {
      throw e;
    } finally {
      try {
        if (in != null) in.close();
      }
      catch (Exception e2)
      {
      }
    }
  }
}