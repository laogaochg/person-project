package com.ifp.adapter.process;

import com.ifp.adapter.exception.FormatException;
import com.ifp.adapter.exception.UnformatException;
import com.ifp.adapter.message.field.MessageField;
import com.ifp.adapter.message.head.DefaultHead;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MixProcessor extends BaseProcessor
{
  private Processor processor;
  private DefaultHead headDefine;
  private int headIndex;
  private int headLength;
  private int securityIndex;
  private int securityLength;
  private static String MIX_PROCESSOR_UNFORMAT_ERR = "MIX_PROCESSOR_UNFORMAT_ERR";
  public static String ERRORCODE = "errorCode";
  public static String ERRORMSG = "errorMsg";

  public MixProcessor()
  {
    this.headIndex = 0;
    this.headLength = 16;
    this.securityIndex = 16;
    this.securityLength = 8;
  }

  public Map<String, Object> unformat(String message)
    throws BaseException
  {
    Trace.log("ADAPTER", 0, "recive mix xml's Msg is :{}", new Object[] { message });
    Map topHeadMap = new HashMap();
    try
    {
      List msgFieldList = this.headDefine.getFieldOrder();
      int startIndex = this.headIndex;
      int endIndex = startIndex;
      for (Iterator i$ = msgFieldList.iterator(); i$.hasNext(); ) { MessageField msgField = (MessageField)i$.next();
        endIndex = startIndex + msgField.getLength().intValue();
        String fieldValue = message.substring(startIndex, endIndex);
        String key = msgField.getName();
        topHeadMap.put(key, fieldValue);
        startIndex = endIndex;
      }

      startIndex = this.securityIndex;
      endIndex = this.securityIndex + this.securityLength;
      int securityTextLength = Integer.parseInt(message.substring(startIndex, endIndex));

      startIndex = endIndex;
      String securityValue = "";
      if (securityTextLength > 0) {
        endIndex = startIndex + securityTextLength;
        securityValue = message.substring(startIndex, endIndex);
      }

      String bodyMsg = message.substring(endIndex);

      bodyMsg = checkSecurityArea(bodyMsg, securityValue);

      Map messageMap = this.processor.unformat(bodyMsg);
      topHeadMap.put("securityArea", securityValue);
      messageMap.put("topHead", topHeadMap);

      Map mappingMap = unformatEncryptData(messageMap);
      messageMap.put("encryptDataArea", mappingMap);
      return messageMap;
    } catch (BaseException e) {
      Map dataMap = new HashMap();
      dataMap.put("topHead", topHeadMap);
      Map mappingMap = unformatEncryptData(dataMap);
      dataMap.put("encryptDataArea", mappingMap);
      Map headMap = new HashMap();
      String channelCode = message.substring(message.indexOf("<channelCode>") + 13, message.indexOf("</channelCode>"));
      headMap.put("signChannelCode", channelCode);
      headMap.put(ERRORCODE, e.getErrorCode());
      headMap.put(ERRORMSG, e.getErrorMessage());
      if (channelCode.startsWith("P2P")) {
        String transCode = message.substring(message.indexOf("<TRANSCODE>") + 11, message.indexOf("</TRANSCODE>"));
        String channelFlow = message.substring(message.indexOf("<channelFlow>") + 13, message.indexOf("</channelFlow>"));
        headMap.put("channelCode", channelCode);
        headMap.put("transCode", transCode);
        headMap.put("channelFlow", channelFlow);
      }

      dataMap.put("header", headMap);

      String returnMsg = format(dataMap);
      throw new UnformatException("SAFU0001", "报文解析异常:" + returnMsg);
    }
  }

  public String checkSecurityArea(String bodyMsg, String securityValue)
    throws BaseException
  {
    return "";
  }

  public Map<String, String> unformatEncryptData(Map<String, Object> messageMap)
  {
    return new HashMap();
  }

  public Map<String, String> createSecurityArea(Map<String, Object> dataMap, String messageContext, String channelCode)
    throws BaseException
  {
    return null;
  }

  public void formatEncryptData(Map<String, String> mapping, Map<String, Object> messageMap)
  {
  }

  public String format(Map<String, Object> dataMap)
    throws BaseException
  {
    StringBuffer repMsg = new StringBuffer();
    try {
      Map topHeadMap = (Map)dataMap.get("topHead");
      Map mappingMap = (Map)dataMap.get("encryptDataArea");

      Map headMap = (Map)dataMap.get("header");

      if (((String)headMap.get(ERRORCODE)).equals(MIX_PROCESSOR_UNFORMAT_ERR))
        return ((String)headMap.get(ERRORMSG));

      String channelCode = (String)headMap.get("signChannelCode");
      headMap.remove("signChannelCode");

      List msgFieldList = this.headDefine.getFieldOrder();
      for (Iterator i$ = msgFieldList.iterator(); i$.hasNext(); ) { String filed;
        MessageField msgField = (MessageField)i$.next();
        if (topHeadMap == null) {
          filed = msgField.getDefault();
          if ((!(StringUtil.hasText(filed))) || (filed.equals("null")))
            filed = fillStrByLength(" ", msgField.getLength().intValue());

          repMsg.append(filed);
        } else {
          filed = (String)topHeadMap.get(msgField.getName());
          repMsg.append(filed);
        }

      }

      formatEncryptData(mappingMap, dataMap);

      String messageContext = this.processor.format(dataMap);

      Map map = createSecurityArea(dataMap, messageContext, channelCode);
      String securityValue = (String)map.get("signData");
      messageContext = (String)map.get("srcData");

      int strLen = 0;
      int length = 1;
      if ((null != securityValue) && (securityValue.length() > 0)) {
        strLen = securityValue.length();
        length = String.valueOf(strLen).length();
      } else {
        securityValue = "";
      }

      for (int i = this.securityLength - length; i > 0; --i)
        repMsg.append(0);

      repMsg.append(strLen).append(securityValue);

      repMsg.append(messageContext);
    } catch (Exception e) {
      throw new FormatException("SAFF0001", "报文组装异常", e);
    }
    return repMsg.toString(); }

  public String fillStrByLength(String str, int length) {
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < length; ++i)
      sb.append(str);

    return sb.toString();
  }

  public Processor getProcessor() {
    return this.processor;
  }

  public void setProcessor(Processor processor) {
    this.processor = processor;
  }

  public DefaultHead getHeadDefine() {
    return this.headDefine;
  }

  public void setHeadDefine(DefaultHead headDefine) {
    this.headDefine = headDefine;
  }

  public int getHeadIndex() {
    return this.headIndex;
  }

  public void setHeadIndex(int headIndex) {
    this.headIndex = headIndex;
  }

  public int getHeadLength() {
    return this.headLength;
  }

  public void setHeadLength(int headLength) {
    this.headLength = headLength;
  }

  public int getSecurityIndex() {
    return this.securityIndex;
  }

  public void setSecurityIndex(int securityIndex) {
    this.securityIndex = securityIndex;
  }

  public int getSecurityLength() {
    return this.securityLength;
  }

  public void setSecurityLength(int securityLength) {
    this.securityLength = securityLength;
  }
}