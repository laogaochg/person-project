package com.ifp.adapter.process;

import com.ifp.core.exception.BaseException;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public abstract interface Processor
{
  public abstract Map<String, Object> unformat(String paramString)
    throws BaseException;

  public abstract Map<String, Object> unformat(HttpServletRequest paramHttpServletRequest)
    throws BaseException;

  public abstract String format(Map<String, Object> paramMap)
    throws BaseException;

  public abstract String getType();

  public abstract Map<String, Object> getProcSettings();
}