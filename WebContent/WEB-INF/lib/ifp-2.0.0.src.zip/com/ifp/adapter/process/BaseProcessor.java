package com.ifp.adapter.process;

import com.ifp.adapter.exception.UnformatException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.util.StringUtil;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public abstract class BaseProcessor
  implements Processor
{
  protected String type;
  protected Map<String, Object> procSettings;
  private int outHtmlFilter;

  public BaseProcessor()
  {
    this.outHtmlFilter = 2; }

  public Map<String, Object> unformat(String message) throws BaseException {
    return null;
  }

  public Map<String, Object> unformat(HttpServletRequest request) throws BaseException {
    String msg;
    try {
      msg = StringUtil.inputStreamToString(request.getInputStream());
    } catch (Exception e) {
      throw new UnformatException("SAFU0003", "报文字符流读取异常", e);
    }
    return unformat(msg);
  }

  public String format(Map<String, Object> dataMap) throws BaseException {
    return null;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public Map<String, Object> getProcSettings() {
    return this.procSettings;
  }

  public int getOutHtmlFilter() {
    return this.outHtmlFilter;
  }

  public void setOutHtmlFilter(int outHtmlFilter) {
    this.outHtmlFilter = outHtmlFilter;
  }
}