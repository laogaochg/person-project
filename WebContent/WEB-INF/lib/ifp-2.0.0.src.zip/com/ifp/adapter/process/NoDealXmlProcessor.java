package com.ifp.adapter.process;

import com.ifp.adapter.exception.AdapterException;
import com.ifp.adapter.exception.FormatException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class NoDealXmlProcessor extends BaseProcessor
{
  private Map<String, String> xmlConfig;

  private String getRootName()
  {
    if ((this.xmlConfig != null) && 
      (this.xmlConfig.get("rootName") != null)) return ((String)this.xmlConfig.get("rootName"));

    return "ifp";
  }

  public String format(Map<String, Object> dataMap) throws BaseException
  {
    StringBuffer repMsg = new StringBuffer();
    try {
      Map headMap = (Map)dataMap.get("header");
      Map bodyMap = (Map)dataMap.get("body");
      repMsg.append("<?xml version=").append("\"").append(getVersionConfig()).append("\"").append(" encoding=\"").append(getEncodeConfig()).append("\" ?>");
      repMsg.append("<").append(getRootName()).append(">");
      repMsg.append("<").append("header").append(">");
      repMsg.append(mapToXml(headMap, "header"));
      repMsg.append("</header>");
      repMsg.append("<body>");
      repMsg.append(mapToXml(bodyMap, "body"));
      repMsg.append("</body>");
      repMsg.append("</").append(getRootName()).append(">");
      Trace.log("ADAPTER", 0, "xml format Context is :{}", new Object[] { repMsg.toString() });
    } catch (Exception e) {
      throw new FormatException("SAFF0001", "报文组装异常", e);
    }
    return repMsg.toString();
  }

  private String mapToXml(Map<String, Object> dataMap, String type)
    throws AdapterException
  {
    if (dataMap == null) return "";
    StringBuffer repMsg = new StringBuffer();
    try {
      String key = null;
      Object value = null;
      for (Iterator i$ = dataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        key = (String)entry.getKey();
        value = entry.getValue();
        if (type.equalsIgnoreCase("header")) {
          if (value == null)
            value = "";

          repMsg.append("<").append(key).append(">");
          switch (getOutHtmlFilter())
          {
          case 1:
            repMsg.append(StringUtil.formatHtmlText(value.toString()));
            break;
          case 2:
            repMsg.append(StringUtil.formatHtmlText1(value.toString()));
            break;
          case 3:
            repMsg.append(StringUtil.formatHtmlText2(value.toString()));
            break;
          default:
            repMsg.append(value.toString());
          }

          repMsg.append("</").append(key).append(">");
        } else {
          repMsg.append(value.toString());
        }
      }
    }
    catch (Exception e) {
      Trace.log("ADAPTER", 3, "dataMap To Xml Error:{}", e);
      throw new AdapterException(e);
    }
    return repMsg.toString();
  }

  private String getVersionConfig()
  {
    if ((this.xmlConfig != null) && 
      (this.xmlConfig.get("version") != null)) return ((String)this.xmlConfig.get("version"));

    return "1.0";
  }

  private String getEncodeConfig()
  {
    if ((this.xmlConfig != null) && 
      (this.xmlConfig.get("encode") != null)) return ((String)this.xmlConfig.get("encode"));

    return "UTF-8";
  }

  public Map<String, String> getXmlConfig() {
    return this.xmlConfig;
  }

  public void setXmlConfig(Map<String, String> xmlConfig) {
    this.xmlConfig = xmlConfig;
  }
}