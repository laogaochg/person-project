package com.ifp.adapter.tcpip;

import com.ifp.adapter.BaseAdapter;

public class TcpipAdapter extends BaseAdapter<String>
{
  public void init()
  {
  }

  public void execute(String message)
  {
  }

  public void destory()
  {
  }
}