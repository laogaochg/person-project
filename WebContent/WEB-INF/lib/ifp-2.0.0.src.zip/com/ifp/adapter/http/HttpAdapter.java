package com.ifp.adapter.http;

import com.ifp.adapter.BaseAdapter;
import javax.servlet.http.HttpServletRequest;

public class HttpAdapter extends BaseAdapter<HttpServletRequest>
{
  public void init()
  {
  }

  public void execute(HttpServletRequest request)
  {
  }

  public void destory()
  {
  }
}