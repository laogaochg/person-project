package com.ifp.adapter;

import com.ifp.adapter.exception.AdapterException;
import com.ifp.adapter.process.Processor;
import com.ifp.core.exception.BaseException;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.SpringContextsUtil;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AdapterHandle
{
  private MonitorManager monitorManager;
  private Map<String, Processor> processorMap;

  public AdapterHandle()
  {
    this.processorMap = new HashMap();
  }

  public void init()
  {
    Map processors = SpringContextsUtil.getBeansOfType(Processor.class);
    for (Iterator i$ = processors.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entity = (Map.Entry)i$.next();
      this.processorMap.put(((Processor)entity.getValue()).getType(), entity.getValue());
    }
  }

  public Map<String, Object> unformat(String requestType, Object request, HttpServletResponse response)
    throws BaseException
  {
    Map dataMap = null;
    Processor processor = getProcessor(requestType);
    if (null != processor)
      try {
        if (request instanceof HttpServletRequest)
          dataMap = processor.unformat((HttpServletRequest)request);
        else
          dataMap = processor.unformat((String)request);
      }
      catch (BaseException e) {
        throw e;
      } catch (Exception e) {
        throw new AdapterException("SAFU0001", "报文解析异常", e);
      }

    throw new AdapterException("SAEC0002", "找不到报文适配器:requestType=" + requestType);

    return dataMap;
  }

  public Processor getProcessor(String requestType)
    throws BaseException
  {
    Processor processor = (Processor)this.processorMap.get(requestType);
    if (null == processor) {
      throw new AdapterException("can not found processor of requestType: " + requestType);
    }

    return processor;
  }

  public MonitorManager getMonitorManager() {
    return this.monitorManager;
  }

  public void setMonitorManager(MonitorManager monitorManager) {
    this.monitorManager = monitorManager;
  }
}