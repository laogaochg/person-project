package com.ifp.adapter.netty.http;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;

public class NettyRequestDispatcher
  implements RequestDispatcher
{
  private final Log logger = LogFactory.getLog(super.getClass());
  private final String url;

  public NettyRequestDispatcher(String url)
  {
    Assert.notNull(url, "URL must not be null");
    this.url = url;
  }

  public void forward(ServletRequest request, ServletResponse response) {
    Assert.notNull(request, "Request must not be null");
    Assert.notNull(response, "Response must not be null");
    if (response.isCommitted())
      throw new IllegalStateException("Cannot perform forward - response is already committed");

    getNettyResponse(response).setForwardedUrl(this.url);
    if (this.logger.isDebugEnabled())
      this.logger.debug("NettyRequestDispatcher: forwarding to URL [" + this.url + "]");
  }

  public void include(ServletRequest request, ServletResponse response)
  {
    Assert.notNull(request, "Request must not be null");
    Assert.notNull(response, "Response must not be null");
    getNettyResponse(response).addIncludedUrl(this.url);
    if (this.logger.isDebugEnabled())
      this.logger.debug("NettyRequestDispatcher: including URL [" + this.url + "]");
  }

  protected NettyResponse getNettyResponse(ServletResponse response)
  {
    if (response instanceof NettyResponse)
      return ((NettyResponse)response);
    if (response instanceof HttpServletResponseWrapper) {
      return getNettyResponse(((HttpServletResponseWrapper)response).getResponse());
    }

    throw new IllegalArgumentException("NettyRequestDispatcher requires NettyResponse");
  }
}