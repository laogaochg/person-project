package com.ifp.adapter.netty.http;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

public class NettyHeaderValueHolder
{
  private final List<Object> values;

  public NettyHeaderValueHolder()
  {
    this.values = new LinkedList();
  }

  public void setValue(Object value) {
    this.values.clear();
    this.values.add(value);
  }

  public void addValue(Object value) {
    this.values.add(value);
  }

  public void addValues(Collection<?> values) {
    this.values.addAll(values);
  }

  public void addValueArray(Object values) {
    CollectionUtils.mergeArrayIntoCollection(values, this.values);
  }

  public List<Object> getValues() {
    return Collections.unmodifiableList(this.values);
  }

  public List<String> getStringValues() {
    List stringList = new ArrayList(this.values.size());
    for (Iterator i$ = this.values.iterator(); i$.hasNext(); ) { Object value = i$.next();
      stringList.add(value.toString());
    }
    return Collections.unmodifiableList(stringList);
  }

  public Object getValue() {
    return ((!(this.values.isEmpty())) ? this.values.get(0) : null);
  }

  public String getStringValue() {
    return ((!(this.values.isEmpty())) ? this.values.get(0).toString() : null);
  }

  public static NettyHeaderValueHolder getByName(Map<String, NettyHeaderValueHolder> headers, String name)
  {
    Assert.notNull(name, "Header name must not be null");
    for (Iterator i$ = headers.keySet().iterator(); i$.hasNext(); ) { String headerName = (String)i$.next();
      if (headerName.equalsIgnoreCase(name))
        return ((NettyHeaderValueHolder)headers.get(headerName));
    }

    return null;
  }
}