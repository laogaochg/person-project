package com.ifp.adapter.netty.http;

import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.ServletOutputStream;
import org.springframework.util.Assert;

public class NettyServletOutputStream extends ServletOutputStream
{
  private final OutputStream targetStream;

  public NettyServletOutputStream(OutputStream targetStream)
  {
    Assert.notNull(targetStream, "Target OutputStream must not be null");
    this.targetStream = targetStream;
  }

  public final OutputStream getTargetStream() {
    return this.targetStream;
  }

  public void write(int b) throws IOException {
    this.targetStream.write(b);
  }

  public void flush() throws IOException {
    super.flush();
    this.targetStream.flush();
  }

  public void close() throws IOException {
    super.close();
    this.targetStream.close();
  }
}