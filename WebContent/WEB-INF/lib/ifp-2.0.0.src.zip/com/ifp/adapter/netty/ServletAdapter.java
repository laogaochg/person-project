package com.ifp.adapter.netty;

import javax.servlet.http.HttpServlet;

public abstract interface ServletAdapter
{
  public abstract void setServlet(HttpServlet paramHttpServlet);
}