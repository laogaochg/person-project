package com.ifp.adapter.netty.http;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import org.springframework.util.Assert;
import org.springframework.util.LinkedCaseInsensitiveMap;

public class NettyResponse
  implements HttpServletResponse
{
  private static final String CHARSET_PREFIX = "charset=";
  private static final String CONTENT_TYPE_HEADER = "Content-Type";
  private static final String CONTENT_LENGTH_HEADER = "Content-Length";
  private boolean outputStreamAccessAllowed;
  private boolean writerAccessAllowed;
  private String characterEncoding;
  private boolean charset;
  private final ByteArrayOutputStream content;
  private final ServletOutputStream outputStream;
  private PrintWriter writer;
  private int contentLength;
  private String contentType;
  private int bufferSize;
  private boolean committed;
  private Locale locale;
  private final List<Cookie> cookies;
  private final Map<String, NettyHeaderValueHolder> headers;
  private int status;
  private String errorMessage;
  private String redirectedUrl;
  private String forwardedUrl;
  private final List<String> includedUrls;

  public NettyResponse()
  {
    this.outputStreamAccessAllowed = true;

    this.writerAccessAllowed = true;

    this.characterEncoding = "ISO-8859-1";

    this.charset = false;

    this.content = new ByteArrayOutputStream();

    this.outputStream = new ResponseServletOutputStream(this, this.content);

    this.contentLength = 0;

    this.bufferSize = 4096;

    this.locale = Locale.getDefault();

    this.cookies = new ArrayList();

    this.headers = new LinkedCaseInsensitiveMap();

    this.status = 200;

    this.includedUrls = new ArrayList();
  }

  public void setOutputStreamAccessAllowed(boolean outputStreamAccessAllowed)
  {
    this.outputStreamAccessAllowed = outputStreamAccessAllowed;
  }

  public boolean isOutputStreamAccessAllowed()
  {
    return this.outputStreamAccessAllowed;
  }

  public void setWriterAccessAllowed(boolean writerAccessAllowed)
  {
    this.writerAccessAllowed = writerAccessAllowed;
  }

  public boolean isWriterAccessAllowed()
  {
    return this.writerAccessAllowed;
  }

  public void setCharacterEncoding(String characterEncoding) {
    this.characterEncoding = characterEncoding;
    this.charset = true;
    updateContentTypeHeader();
  }

  private void updateContentTypeHeader() {
    if (this.contentType != null) {
      StringBuilder sb = new StringBuilder(this.contentType);
      if ((this.contentType.toLowerCase().indexOf("charset=") == -1) && (this.charset))
        sb.append(";").append("charset=").append(this.characterEncoding);

      doAddHeaderValue("Content-Type", sb.toString(), true);
    }
  }

  public String getCharacterEncoding() {
    return this.characterEncoding;
  }

  public ServletOutputStream getOutputStream() {
    if (!(this.outputStreamAccessAllowed))
      throw new IllegalStateException("OutputStream access not allowed");

    return this.outputStream;
  }

  public PrintWriter getWriter() throws UnsupportedEncodingException {
    if (!(this.writerAccessAllowed))
      throw new IllegalStateException("Writer access not allowed");

    if (this.writer == null) {
      Writer targetWriter = new OutputStreamWriter(this.content);

      this.writer = new ResponsePrintWriter(this, targetWriter);
    }
    return this.writer;
  }

  public byte[] getContentAsByteArray() {
    flushBuffer();
    return this.content.toByteArray();
  }

  public String getContentAsString() throws UnsupportedEncodingException {
    flushBuffer();
    return ((this.characterEncoding != null) ? this.content.toString(this.characterEncoding) : this.content.toString());
  }

  public void setContentLength(int contentLength)
  {
    this.contentLength = contentLength;
    doAddHeaderValue("Content-Length", Integer.valueOf(contentLength), true);
  }

  public int getContentLength() {
    return this.contentLength;
  }

  public void setContentType(String contentType) {
    this.contentType = contentType;
    if (contentType != null) {
      int charsetIndex = contentType.toLowerCase().indexOf("charset=");
      if (charsetIndex != -1) {
        String encoding = contentType.substring(charsetIndex + "charset=".length());
        this.characterEncoding = encoding;
        this.charset = true;
      }
      updateContentTypeHeader();
    }
  }

  public String getContentType() {
    return this.contentType;
  }

  public void setBufferSize(int bufferSize) {
    this.bufferSize = bufferSize;
  }

  public int getBufferSize() {
    return this.bufferSize;
  }

  public void flushBuffer() {
    setCommitted(true);
  }

  public void resetBuffer() {
    if (isCommitted())
      throw new IllegalStateException("Cannot reset buffer - response is already committed");

    this.content.reset();
  }

  private void setCommittedIfBufferSizeExceeded() {
    int bufSize = getBufferSize();
    if ((bufSize > 0) && (this.content.size() > bufSize))
      setCommitted(true);
  }

  public void setCommitted(boolean committed)
  {
    this.committed = committed;
  }

  public boolean isCommitted() {
    return this.committed;
  }

  public void reset() {
    resetBuffer();
    this.characterEncoding = null;
    this.contentLength = 0;
    this.contentType = null;
    this.locale = null;
    this.cookies.clear();
    this.headers.clear();
    this.status = 200;
    this.errorMessage = null;
  }

  public void setLocale(Locale locale) {
    this.locale = locale;
  }

  public Locale getLocale() {
    return this.locale;
  }

  public void addCookie(Cookie cookie)
  {
    Assert.notNull(cookie, "Cookie must not be null");
    this.cookies.add(cookie);
  }

  public Cookie[] getCookies() {
    return ((Cookie[])this.cookies.toArray(new Cookie[this.cookies.size()]));
  }

  public Cookie getCookie(String name) {
    Assert.notNull(name, "Cookie name must not be null");
    for (Iterator i$ = this.cookies.iterator(); i$.hasNext(); ) { Cookie cookie = (Cookie)i$.next();
      if (name.equals(cookie.getName()))
        return cookie;
    }

    return null;
  }

  public boolean containsHeader(String name) {
    return (NettyHeaderValueHolder.getByName(this.headers, name) != null);
  }

  public Set<String> getHeaderNames()
  {
    return this.headers.keySet();
  }

  public String getHeader(String name)
  {
    NettyHeaderValueHolder header = NettyHeaderValueHolder.getByName(this.headers, name);
    return ((header != null) ? header.getStringValue() : null);
  }

  public List<String> getHeaders(String name)
  {
    NettyHeaderValueHolder header = NettyHeaderValueHolder.getByName(this.headers, name);
    if (header != null) {
      return header.getStringValues();
    }

    return Collections.emptyList();
  }

  public Object getHeaderValue(String name)
  {
    NettyHeaderValueHolder header = NettyHeaderValueHolder.getByName(this.headers, name);
    return ((header != null) ? header.getValue() : null);
  }

  public List<Object> getHeaderValues(String name)
  {
    NettyHeaderValueHolder header = NettyHeaderValueHolder.getByName(this.headers, name);
    if (header != null) {
      return header.getValues();
    }

    return Collections.emptyList();
  }

  public String encodeURL(String url)
  {
    return url;
  }

  public String encodeRedirectURL(String url)
  {
    return encodeURL(url);
  }

  public String encodeUrl(String url) {
    return encodeURL(url);
  }

  public String encodeRedirectUrl(String url) {
    return encodeRedirectURL(url);
  }

  public void sendError(int status, String errorMessage) throws IOException {
    if (isCommitted())
      throw new IllegalStateException("Cannot set error status - response is already committed");

    this.status = status;
    this.errorMessage = errorMessage;
    setCommitted(true);
  }

  public void sendError(int status) throws IOException {
    if (isCommitted())
      throw new IllegalStateException("Cannot set error status - response is already committed");

    this.status = status;
    setCommitted(true);
  }

  public void sendRedirect(String url) throws IOException {
    if (isCommitted())
      throw new IllegalStateException("Cannot send redirect - response is already committed");

    Assert.notNull(url, "Redirect URL must not be null");
    this.redirectedUrl = url;
    setCommitted(true);
  }

  public String getRedirectedUrl() {
    return this.redirectedUrl;
  }

  public void setDateHeader(String name, long value) {
    setHeaderValue(name, Long.valueOf(value));
  }

  public void addDateHeader(String name, long value) {
    addHeaderValue(name, Long.valueOf(value));
  }

  public void setHeader(String name, String value) {
    setHeaderValue(name, value);
  }

  public void addHeader(String name, String value) {
    addHeaderValue(name, value);
  }

  public void setIntHeader(String name, int value) {
    setHeaderValue(name, Integer.valueOf(value));
  }

  public void addIntHeader(String name, int value) {
    addHeaderValue(name, Integer.valueOf(value));
  }

  private void setHeaderValue(String name, Object value) {
    if (setSpecialHeader(name, value))
      return;

    doAddHeaderValue(name, value, true);
  }

  private void addHeaderValue(String name, Object value) {
    if (setSpecialHeader(name, value))
      return;

    doAddHeaderValue(name, value, false);
  }

  private boolean setSpecialHeader(String name, Object value) {
    if ("Content-Type".equalsIgnoreCase(name)) {
      setContentType((String)value);
      return true;
    }
    if ("Content-Length".equalsIgnoreCase(name)) {
      setContentLength(Integer.parseInt((String)value));
      return true;
    }

    return false;
  }

  private void doAddHeaderValue(String name, Object value, boolean replace)
  {
    NettyHeaderValueHolder header = NettyHeaderValueHolder.getByName(this.headers, name);
    Assert.notNull(value, "Header value must not be null");
    if (header == null) {
      header = new NettyHeaderValueHolder();
      this.headers.put(name, header);
    }
    if (replace) {
      header.setValue(value);
    }
    else
      header.addValue(value);
  }

  public void setStatus(int status)
  {
    this.status = status;
  }

  public void setStatus(int status, String errorMessage) {
    this.status = status;
    this.errorMessage = errorMessage;
  }

  public int getStatus() {
    return this.status;
  }

  public String getErrorMessage() {
    return this.errorMessage;
  }

  public void setForwardedUrl(String forwardedUrl)
  {
    this.forwardedUrl = forwardedUrl;
  }

  public String getForwardedUrl() {
    return this.forwardedUrl;
  }

  public void setIncludedUrl(String includedUrl) {
    this.includedUrls.clear();
    if (includedUrl != null)
      this.includedUrls.add(includedUrl);
  }

  public String getIncludedUrl()
  {
    int count = this.includedUrls.size();
    if (count > 1) {
      throw new IllegalStateException(new StringBuilder().append("More than 1 URL included - check getIncludedUrls instead: ").append(this.includedUrls).toString());
    }

    return ((count == 1) ? (String)this.includedUrls.get(0) : null);
  }

  public void addIncludedUrl(String includedUrl) {
    Assert.notNull(includedUrl, "Included URL must not be null");
    this.includedUrls.add(includedUrl);
  }

  public List<String> getIncludedUrls() {
    return this.includedUrls;
  }

  private class ResponsePrintWriter extends PrintWriter
  {
    public ResponsePrintWriter(, Writer paramWriter)
    {
      super(out, true);
    }

    public void write(, int off, int len) {
      super.write(buf, off, len);
      super.flush();
      NettyResponse.access$000(this.this$0);
    }

    public void write(, int off, int len) {
      super.write(s, off, len);
      super.flush();
      NettyResponse.access$000(this.this$0);
    }

    public void write() {
      super.write(c);
      super.flush();
      NettyResponse.access$000(this.this$0);
    }

    public void flush() {
      super.flush();
      this.this$0.setCommitted(true);
    }
  }

  private class ResponseServletOutputStream extends NettyServletOutputStream
  {
    public ResponseServletOutputStream(, OutputStream paramOutputStream)
    {
      super(out);
    }

    public void write() throws IOException {
      super.write(b);
      super.flush();
      NettyResponse.access$000(this.this$0);
    }

    public void flush() throws IOException {
      super.flush();
      this.this$0.setCommitted(true);
    }
  }
}