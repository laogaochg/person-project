package com.ifp.adapter.netty;

public abstract interface LongConnectAdapter
{
}