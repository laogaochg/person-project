package com.ifp.adapter.netty;

import com.ifp.adapter.message.BaseMessage;
import com.ifp.adapter.message.field.MessageField;

public abstract interface MessageHeadAdapter
{
  public abstract void setHead(BaseMessage<MessageField> paramBaseMessage);
}