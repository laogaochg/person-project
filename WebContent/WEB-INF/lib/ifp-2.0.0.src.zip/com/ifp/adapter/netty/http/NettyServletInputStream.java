package com.ifp.adapter.netty.http;

import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletInputStream;
import org.springframework.util.Assert;

public class NettyServletInputStream extends ServletInputStream
{
  private final InputStream sourceStream;

  public NettyServletInputStream(InputStream sourceStream)
  {
    Assert.notNull(sourceStream, "Source InputStream must not be null");
    this.sourceStream = sourceStream;
  }

  public final InputStream getSourceStream() {
    return this.sourceStream;
  }

  public int read() throws IOException {
    return this.sourceStream.read();
  }

  public void close() throws IOException {
    super.close();
    this.sourceStream.close();
  }
}