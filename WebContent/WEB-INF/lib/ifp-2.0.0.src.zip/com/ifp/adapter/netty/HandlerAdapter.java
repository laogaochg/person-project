package com.ifp.adapter.netty;

import io.netty.channel.ChannelInboundHandler;

public abstract interface HandlerAdapter
{
}