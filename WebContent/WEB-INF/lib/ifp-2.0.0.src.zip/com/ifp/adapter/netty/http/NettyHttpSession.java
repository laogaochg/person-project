package com.ifp.adapter.netty.http;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import javax.servlet.http.HttpSessionContext;
import org.springframework.util.Assert;

public class NettyHttpSession
  implements HttpSession
{
  private static int nextId = 1;
  private final String id;
  private final long creationTime;
  private int maxInactiveInterval;
  private long lastAccessedTime;
  private final ServletContext servletContext;
  private final Map attributes;
  private boolean invalid;
  private boolean isNew;

  public NettyHttpSession()
  {
    this(null);
  }

  public NettyHttpSession(ServletContext servletContext) {
    this(servletContext, null);
  }

  public NettyHttpSession(ServletContext servletContext, String id) {
    this.creationTime = System.currentTimeMillis();
    this.lastAccessedTime = System.currentTimeMillis();
    this.attributes = new LinkedHashMap();
    this.invalid = false;
    this.isNew = true;
    this.servletContext = ((servletContext == null) ? new NettyServletContext() : servletContext);

    this.id = ((id == null) ? Integer.toString(nextId++) : id);
  }

  public long getCreationTime() {
    return this.creationTime;
  }

  public String getId() {
    return this.id;
  }

  public void access() {
    this.lastAccessedTime = System.currentTimeMillis();
    this.isNew = false;
  }

  public long getLastAccessedTime() {
    return this.lastAccessedTime;
  }

  public ServletContext getServletContext() {
    return this.servletContext;
  }

  public void setMaxInactiveInterval(int interval) {
    this.maxInactiveInterval = interval;
  }

  public int getMaxInactiveInterval() {
    return this.maxInactiveInterval;
  }

  public HttpSessionContext getSessionContext() {
    throw new UnsupportedOperationException("getSessionContext");
  }

  public Object getAttribute(String name) {
    Assert.notNull(name, "Attribute name must not be null");
    return this.attributes.get(name);
  }

  public Object getValue(String name) {
    return getAttribute(name);
  }

  public Enumeration getAttributeNames() {
    return new Vector(this.attributes.keySet()).elements();
  }

  public String[] getValueNames() {
    return ((String[])(String[])this.attributes.keySet().toArray(new String[this.attributes.size()]));
  }

  public void setAttribute(String name, Object value)
  {
    Assert.notNull(name, "Attribute name must not be null");
    if (value != null) {
      this.attributes.put(name, value);
      if (value instanceof HttpSessionBindingListener)
        ((HttpSessionBindingListener)value).valueBound(new HttpSessionBindingEvent(this, name, value));
    }
    else
    {
      removeAttribute(name);
    }
  }

  public void putValue(String name, Object value) {
    setAttribute(name, value);
  }

  public void removeAttribute(String name) {
    Assert.notNull(name, "Attribute name must not be null");
    Object value = this.attributes.remove(name);
    if (value instanceof HttpSessionBindingListener)
      ((HttpSessionBindingListener)value).valueUnbound(new HttpSessionBindingEvent(this, name, value));
  }

  public void removeValue(String name)
  {
    removeAttribute(name);
  }

  public void clearAttributes() {
    for (Iterator it = this.attributes.entrySet().iterator(); it.hasNext(); ) {
      Map.Entry entry = (Map.Entry)it.next();
      String name = (String)entry.getKey();
      Object value = entry.getValue();
      it.remove();
      if (value instanceof HttpSessionBindingListener)
        ((HttpSessionBindingListener)value).valueUnbound(new HttpSessionBindingEvent(this, name, value));
    }
  }

  public void invalidate()
  {
    this.invalid = true;
    clearAttributes();
  }

  public boolean isInvalid() {
    return this.invalid;
  }

  public void setNew(boolean value) {
    this.isNew = value;
  }

  public boolean isNew() {
    return this.isNew;
  }

  public Serializable serializeState() {
    HashMap state = new HashMap();
    for (Iterator it = this.attributes.entrySet().iterator(); it.hasNext(); ) {
      Map.Entry entry = (Map.Entry)it.next();
      String name = (String)entry.getKey();
      Object value = entry.getValue();
      it.remove();
      if (value instanceof Serializable)
        state.put(name, (Serializable)value);
      else if (value instanceof HttpSessionBindingListener) {
        ((HttpSessionBindingListener)value).valueUnbound(new HttpSessionBindingEvent(this, name, value));
      }

    }

    return state;
  }

  public void deserializeState(Serializable state) {
    Assert.isTrue(state instanceof Map, "Serialized state needs to be of type [java.util.Map]");

    this.attributes.putAll((Map)state);
  }
}