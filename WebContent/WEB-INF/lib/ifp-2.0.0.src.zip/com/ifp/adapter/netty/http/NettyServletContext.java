package com.ifp.adapter.netty.http;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import javax.activation.FileTypeMap;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.util.ObjectUtils;

public class NettyServletContext
  implements ServletContext
{
  private static final String TEMP_DIR_SYSTEM_PROPERTY = "java.io.tmpdir";
  private final Log logger;
  private final ResourceLoader resourceLoader;
  private final String resourceBasePath;
  private String contextPath;
  private int majorVersion;
  private int minorVersion;
  private int effectiveMajorVersion;
  private int effectiveMinorVersion;
  private final Map contexts;
  private final Map initParameters;
  private final Map attributes;
  private String servletContextName;
  private final Set declaredRoles;

  public NettyServletContext()
  {
    this("", null);
  }

  public NettyServletContext(String resourceBasePath) {
    this(resourceBasePath, null);
  }

  public NettyServletContext(ResourceLoader resourceLoader) {
    this("", resourceLoader);
  }

  public NettyServletContext(String resourceBasePath, ResourceLoader resourceLoader)
  {
    this.logger = LogFactory.getLog(super.getClass());
    this.contextPath = "";
    this.majorVersion = 2;
    this.minorVersion = 5;
    this.effectiveMajorVersion = 2;
    this.effectiveMinorVersion = 5;
    this.contexts = new HashMap();
    this.initParameters = new LinkedHashMap();
    this.attributes = new LinkedHashMap();
    this.servletContextName = "NettyServletContext";
    this.declaredRoles = new HashSet();
    this.resourceLoader = ((resourceLoader == null) ? new DefaultResourceLoader() : resourceLoader);

    this.resourceBasePath = ((resourceBasePath == null) ? "" : resourceBasePath);

    String tempDir = System.getProperty("java.io.tmpdir");
    if (tempDir != null)
      this.attributes.put("javax.servlet.context.tempdir", new File(tempDir));
  }

  protected String getResourceLocation(String path) {
    if (!(path.startsWith("/")))
      path = "/" + path;
    return String.valueOf(this.resourceBasePath) + path;
  }

  public void setContextPath(String contextPath)
  {
    this.contextPath = ((contextPath == null) ? "" : contextPath);
  }

  public String getContextPath() {
    return this.contextPath;
  }

  public void registerContext(String contextPath, ServletContext context) {
    this.contexts.put(contextPath, context);
  }

  public ServletContext getContext(String contextPath) {
    if (this.contextPath.equals(contextPath))
      return this;

    return ((ServletContext)this.contexts.get(contextPath));
  }

  public void setMajorVersion(int majorVersion) {
    this.majorVersion = majorVersion;
  }

  public int getMajorVersion() {
    return this.majorVersion;
  }

  public void setMinorVersion(int minorVersion) {
    this.minorVersion = minorVersion;
  }

  public int getMinorVersion() {
    return this.minorVersion;
  }

  public void setEffectiveMajorVersion(int effectiveMajorVersion) {
    this.effectiveMajorVersion = effectiveMajorVersion;
  }

  public int getEffectiveMajorVersion() {
    return this.effectiveMajorVersion;
  }

  public void setEffectiveMinorVersion(int effectiveMinorVersion) {
    this.effectiveMinorVersion = effectiveMinorVersion;
  }

  public int getEffectiveMinorVersion() {
    return this.effectiveMinorVersion;
  }

  public String getMimeType(String filePath) {
    return MimeTypeResolver.getMimeType(filePath);
  }

  public Set getResourcePaths(String path)
  {
    String actualPath = String.valueOf(path) + "/";

    Resource resource = this.resourceLoader.getResource(getResourceLocation(actualPath));
    String[] fileList = null;
    try
    {
      File file = resource.getFile();
      fileList = file.list();
    } catch (IOException e) {
      e.printStackTrace();
    }
    if (ObjectUtils.isEmpty(fileList))
      return null;
    try {
      String[] as;
      Set resourcePaths = new LinkedHashSet(fileList.length);

      int j = (as = fileList).length;
      for (int i = 0; i < j; ++i) {
        String fileEntry = as[i];
        String resultPath = String.valueOf(actualPath) + fileEntry;

        if (resource.createRelative(fileEntry).getFile().isDirectory())
          resultPath = String.valueOf(resultPath) + "/";

        resourcePaths.add(resultPath);
      }

      return resourcePaths;
    } catch (IOException ex) {
      this.logger.warn("Couldn't get resource paths for " + resource, ex);
    }

    return null;
  }

  public URL getResource(String path) throws MalformedURLException {
    Resource resource = this.resourceLoader.getResource(getResourceLocation(path));

    if (!(resource.exists()))
      return null;
    try {
      return resource.getURL();
    } catch (MalformedURLException ex) {
      throw ex;
    } catch (IOException ex) {
      this.logger.warn("Couldn't get URL for " + resource, ex);
    }

    return null;
  }

  public InputStream getResourceAsStream(String path) {
    Resource resource = this.resourceLoader.getResource(getResourceLocation(path));

    if (!(resource.exists()))
      return null;
    try {
      return resource.getInputStream();
    } catch (IOException ex) {
      this.logger.warn("Couldn't open InputStream for " + resource, ex);
    }

    return null;
  }

  public RequestDispatcher getRequestDispatcher(String path) {
    if (!(path.startsWith("/"))) {
      throw new IllegalArgumentException("RequestDispatcher path at ServletContext level must start with '/'");
    }

    return new NettyRequestDispatcher(path);
  }

  public RequestDispatcher getNamedDispatcher(String path) {
    return null;
  }

  public Servlet getServlet(String name) {
    return null;
  }

  public Enumeration getServlets() {
    return Collections.enumeration(new HashSet());
  }

  public Enumeration getServletNames() {
    return Collections.enumeration(new HashSet());
  }

  public void log(String message) {
    this.logger.info(message);
  }

  public void log(Exception ex, String message) {
    this.logger.info(message, ex);
  }

  public void log(String message, Throwable ex) {
    this.logger.info(message, ex);
  }

  public String getRealPath(String path) {
    Resource resource = this.resourceLoader.getResource(getResourceLocation(path));
    try
    {
      return resource.getFile().getAbsolutePath();
    } catch (IOException ex) {
      this.logger.warn("Couldn't determine real path of resource " + resource, ex);
    }

    return null;
  }

  public String getServerInfo() {
    return "NettyServletContext";
  }

  public String getInitParameter(String name) {
    Assert.notNull(name, "Parameter name must not be null");
    return ((String)this.initParameters.get(name));
  }

  public Enumeration getInitParameterNames() {
    return Collections.enumeration(this.initParameters.keySet());
  }

  public boolean setInitParameter(String name, String value) {
    Assert.notNull(name, "Parameter name must not be null");
    if (this.initParameters.containsKey(name))
      return false;

    this.initParameters.put(name, value);
    return true;
  }

  public void addInitParameter(String name, String value)
  {
    Assert.notNull(name, "Parameter name must not be null");
    this.initParameters.put(name, value);
  }

  public Object getAttribute(String name) {
    Assert.notNull(name, "Attribute name must not be null");
    return this.attributes.get(name);
  }

  public Enumeration getAttributeNames() {
    return new Vector(this.attributes.keySet()).elements();
  }

  public void setAttribute(String name, Object value) {
    Assert.notNull(name, "Attribute name must not be null");
    if (value != null)
      this.attributes.put(name, value);
    else
      this.attributes.remove(name);
  }

  public void removeAttribute(String name) {
    Assert.notNull(name, "Attribute name must not be null");
    this.attributes.remove(name);
  }

  public void setServletContextName(String servletContextName) {
    this.servletContextName = servletContextName;
  }

  public String getServletContextName() {
    return this.servletContextName;
  }

  public ClassLoader getClassLoader() {
    return ClassUtils.getDefaultClassLoader();
  }

  public void declareRoles(String[] roleNames) {
    String[] as;
    Assert.notNull(roleNames, "Role names array must not be null");

    int j = (as = roleNames).length;
    for (int i = 0; i < j; ++i) {
      String roleName = as[i];
      Assert.hasLength(roleName, "Role name must not be empty");
      this.declaredRoles.add(roleName);
    }
  }

  public Set getDeclaredRoles()
  {
    return Collections.unmodifiableSet(this.declaredRoles);
  }

  private static class MimeTypeResolver
  {
    public static String getMimeType(String filePath)
    {
      return FileTypeMap.getDefaultFileTypeMap().getContentType(filePath);
    }
  }
}