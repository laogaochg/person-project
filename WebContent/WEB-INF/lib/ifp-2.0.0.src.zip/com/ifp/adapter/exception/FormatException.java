package com.ifp.adapter.exception;

public class FormatException extends AdapterException
{
  private static final long serialVersionUID = 1L;

  public FormatException()
  {
  }

  public FormatException(String errorMessage)
  {
    super(errorMessage);
  }

  public FormatException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public FormatException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public FormatException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public FormatException(Throwable cause)
  {
    super(cause);
  }
}