package com.ifp.adapter.exception;

import com.ifp.core.exception.BaseException;

public class AdapterException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public AdapterException()
  {
  }

  public AdapterException(String errorMessage)
  {
    super(errorMessage);
  }

  public AdapterException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public AdapterException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public AdapterException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public AdapterException(Throwable cause)
  {
    super(cause);
  }
}