package com.ifp.adapter.exception;

public class UnformatException extends AdapterException
{
  private static final long serialVersionUID = 1L;

  public UnformatException()
  {
  }

  public UnformatException(String errorMessage)
  {
    super(errorMessage);
  }

  public UnformatException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public UnformatException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public UnformatException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public UnformatException(Throwable cause)
  {
    super(cause);
  }
}