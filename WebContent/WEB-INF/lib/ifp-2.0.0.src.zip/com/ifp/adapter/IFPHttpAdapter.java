package com.ifp.adapter;

import com.ifp.adapter.process.JSONProcessor;
import com.ifp.adapter.process.KValueProcessor;
import com.ifp.adapter.process.Processor;
import com.ifp.adapter.process.SOAPProcessor;
import com.ifp.adapter.process.XMLProcessor;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public class IFPHttpAdapter extends BaseAdapter<HttpServletRequest>
{
  private Map<String, Processor> processorMap;

  public void init()
  {
    this.processorMap = new HashMap();
    this.processorMap.put("K", new KValueProcessor());
    this.processorMap.put("S", new SOAPProcessor());
    this.processorMap.put("X", new XMLProcessor());
    this.processorMap.put("J", new JSONProcessor());
  }

  public void execute(HttpServletRequest request)
  {
  }

  public void destory()
  {
  }

  public Map<String, Processor> getProcessorMap() {
    if (this.processorMap == null)
    {
      this.processorMap = new HashMap();
      this.processorMap.put("K", new KValueProcessor());
      this.processorMap.put("S", new SOAPProcessor());
      this.processorMap.put("X", new XMLProcessor());
      this.processorMap.put("J", new JSONProcessor());
    }
    return this.processorMap;
  }

  public void setProcessorMap(Map<String, Processor> processorMap) {
    this.processorMap = processorMap;
  }
}