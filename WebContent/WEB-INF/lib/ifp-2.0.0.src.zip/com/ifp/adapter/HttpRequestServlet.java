package com.ifp.adapter;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;

public class HttpRequestServlet extends HttpServlet
{
  private static final long serialVersionUID = 7135784274064513791L;

  public void init(ServletConfig config)
    throws ServletException
  {
    super.init(config);
  }

  public void service(ServletRequest req, ServletResponse res)
    throws ServletException, IOException
  {
  }
}