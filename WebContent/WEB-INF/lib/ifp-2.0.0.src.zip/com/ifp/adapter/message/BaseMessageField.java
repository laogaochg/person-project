package com.ifp.adapter.message;

public abstract class BaseMessageField
{
  private String name;
  private String cnname;
  private Integer start;
  private Integer length;
  private String description;
  private Boolean mustsent;
  private Boolean notnull;
  private String defaultValue;
  private byte[] byteValue;
  private String strValue;
  private Object value;

  public BaseMessageField()
  {
    this.mustsent = Boolean.valueOf(true);

    this.notnull = Boolean.valueOf(true);
  }

  public String getName()
  {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCnname() {
    return this.cnname;
  }

  public void setCnname(String cnname) {
    this.cnname = cnname;
  }

  public Integer getStart() {
    return this.start;
  }

  public void setStart(Integer start) {
    this.start = start;
  }

  public Integer getLength() {
    return this.length;
  }

  public void setLength(Integer length) {
    this.length = length;
  }

  public String getDescription() {
    return this.description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Boolean getMustsent() {
    return this.mustsent;
  }

  public void setMustsent(Boolean mustsent) {
    this.mustsent = mustsent;
  }

  public Boolean getNotnull() {
    return this.notnull;
  }

  public void setNotnull(Boolean notnull) {
    this.notnull = notnull;
  }

  public String getDefault() {
    return this.defaultValue;
  }

  public void setDefault(String defaultValue) {
    this.defaultValue = defaultValue;
  }

  public Object getValue() {
    return this.value;
  }

  public void setValue(Object value) {
    this.value = value;
  }

  public byte[] getByteValue() {
    return this.byteValue;
  }

  public void setByteValue(byte[] byteValue) {
    this.byteValue = byteValue;
  }

  public String getStrValue() {
    return this.strValue;
  }

  public void setStrValue(String strValue) {
    this.strValue = strValue;
  }
}