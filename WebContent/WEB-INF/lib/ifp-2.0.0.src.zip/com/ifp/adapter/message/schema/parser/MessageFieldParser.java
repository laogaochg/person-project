package com.ifp.adapter.message.schema.parser;

import com.ifp.adapter.message.field.MessageField;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

public class MessageFieldParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String name = element.getAttribute("name");
    if (StringUtils.hasText(name))
      builder.addPropertyValue("name", element.getAttribute("name"));

    String cnname = element.getAttribute("cnname");
    if (StringUtils.hasText(cnname))
      builder.addPropertyValue("cnname", element.getAttribute("cnname"));

    String start = element.getAttribute("start");
    if (StringUtils.hasText(start))
      builder.addPropertyValue("start", element.getAttribute("start"));

    String length = element.getAttribute("length");
    if (StringUtils.hasText(length))
      builder.addPropertyValue("length", element.getAttribute("length"));

    String description = element.getAttribute("description");
    if (StringUtils.hasText(description))
      builder.addPropertyValue("description", element.getAttribute("description"));

    String mustsent = element.getAttribute("mustsent");
    if (StringUtils.hasText(mustsent))
      builder.addPropertyValue("mustsent", Boolean.valueOf(element.getAttribute("mustsent")));

    String notnull = element.getAttribute("notnull");
    if (StringUtils.hasText(notnull))
      builder.addPropertyValue("notnull", Boolean.valueOf(element.getAttribute("notnull")));

    String defaultValue = element.getAttribute("default");
    if (StringUtils.hasText(defaultValue))
      builder.addPropertyValue("default", defaultValue);
  }

  protected Class<MessageField> getBeanClass(Element element)
  {
    return MessageField.class;
  }
}