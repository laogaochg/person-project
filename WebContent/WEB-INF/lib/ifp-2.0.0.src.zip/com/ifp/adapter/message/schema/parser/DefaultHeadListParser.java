package com.ifp.adapter.message.schema.parser;

import com.ifp.adapter.message.head.DefaultHead;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedList;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class DefaultHeadListParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    List list;
    try
    {
      list = parseDataListElement(element, parserContext, builder);

      if (list.size() > 0)
        builder.addPropertyValue("fieldOrder", list);
    }
    catch (Exception e) {
      parserContext.getReaderContext().error("class " + DefaultHeadListParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<DefaultHead> getBeanClass(Element element)
  {
    return DefaultHead.class;
  }

  private List<BeanDefinition> parseDataListElement(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List fieldList = DomUtils.getChildElementsByTagName(element, "field");
    ManagedList list = new ManagedList(fieldList.size());
    list.setMergeEnabled(true);
    list.setSource(parserContext.getReaderContext().extractSource(element));

    for (Iterator i$ = fieldList.iterator(); i$.hasNext(); ) { Element propertyElement = (Element)i$.next();
      list.add(parserContext.getDelegate().parseCustomElement(propertyElement, builder.getRawBeanDefinition()));
    }

    return list;
  }
}