package com.ifp.adapter.message.field;

import com.ifp.adapter.message.BaseMessageField;

public class MessageField extends BaseMessageField
{
}