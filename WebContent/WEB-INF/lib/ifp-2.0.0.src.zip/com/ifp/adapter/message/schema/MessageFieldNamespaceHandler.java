package com.ifp.adapter.message.schema;

import com.ifp.adapter.message.schema.parser.DefaultBodyListParser;
import com.ifp.adapter.message.schema.parser.DefaultHeadListParser;
import com.ifp.adapter.message.schema.parser.MessageFieldParser;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

public class MessageFieldNamespaceHandler extends NamespaceHandlerSupport
{
  public void init()
  {
    registerBeanDefinitionParser("head", new DefaultHeadListParser());
    registerBeanDefinitionParser("body", new DefaultBodyListParser());
    registerBeanDefinitionParser("field", new MessageFieldParser());
  }
}