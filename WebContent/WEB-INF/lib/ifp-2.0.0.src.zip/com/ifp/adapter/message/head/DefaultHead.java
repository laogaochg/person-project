package com.ifp.adapter.message.head;

import com.ifp.adapter.message.BaseMessage;
import com.ifp.adapter.message.field.MessageField;

public class DefaultHead extends BaseMessage<MessageField>
{
  private static DefaultHead head;

  private static synchronized DefaultHead init()
  {
    return new DefaultHead();
  }

  public static DefaultHead getInstance()
  {
    if (null == head)
      head = init();

    return head;
  }
}