package com.ifp.adapter.message;

import com.ifp.adapter.process.Processor;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public abstract class BaseMessage<T extends BaseMessageField>
{
  protected Processor processor;
  private Integer messageLength;
  private Integer headLength;
  private Integer bodyLength;
  private List<T> fieldOrder;

  public BaseMessage()
  {
    this.fieldOrder = new ArrayList();
  }

  public List<T> getFieldList(ByteBuf buf)
  {
    return getFieldList(buf, false);
  }

  public List<T> getFieldList(ByteBuf buf, boolean reset)
  {
    List fieldList = new ArrayList(getFieldOrder());
    for (Iterator i$ = fieldList.iterator(); i$.hasNext(); ) { BaseMessageField field = (BaseMessageField)i$.next();
      byte[] fb = new byte[field.getLength().intValue()];
      buf.readBytes(fb);
      field.setByteValue(fb);
      field.setStrValue(new String(fb));
    }
    if (reset)
      buf.resetReaderIndex();
    return fieldList;
  }

  public Map<String, String> getFieldMap(ByteBuf buf)
  {
    return getFieldMap(buf, false);
  }

  public Map<String, String> getFieldMap(ByteBuf buf, boolean reset)
  {
    Map msgMap = new HashMap();
    byte[] fieldByte = null;
    for (Iterator i$ = getFieldOrder().iterator(); i$.hasNext(); ) { BaseMessageField field = (BaseMessageField)i$.next();
      fieldByte = new byte[field.getLength().intValue()];
      buf.readBytes(fieldByte);
      msgMap.put(field.getName(), new String(fieldByte).trim());
    }
    if (reset)
      buf.resetReaderIndex();
    return msgMap;
  }

  public String mapToString(Map<String, Object> headMap) throws BaseException {
    Processor processor = getProcessor(new String[] { (String)headMap.get("type") });
    if (null == processor) {
      Trace.log("MESSAGE", 3, "processor not found. please confirm type is not null and value in [J,K,X,S]");

      return null;
    }
    return processor.format(headMap);
  }

  public Processor getProcessor(String[] type)
  {
    if ((type.length > 0) && (((null == this.processor) || ((null != this.processor) && (!(this.processor.getType().equalsIgnoreCase(type[0])))))))
    {
      this.processor = null;
      if ("J".equalsIgnoreCase(type[0])) {
        this.processor = ((Processor)SpringContextsUtil.getBean("JSONProcessor"));
      }
      else if ("K".equalsIgnoreCase(type[0])) {
        this.processor = ((Processor)SpringContextsUtil.getBean("KValueProcessor"));
      }
      else if ("S".equalsIgnoreCase(type[0])) {
        this.processor = ((Processor)SpringContextsUtil.getBean("SOAPProcessor"));
      }
      else if ("X".equalsIgnoreCase(type[0])) {
        this.processor = ((Processor)SpringContextsUtil.getBean("XMLProcessor"));
      }
      else if ("I".equalsIgnoreCase(type[0]))
        this.processor = ((Processor)SpringContextsUtil.getBean("ISO8583Processor"));

    }

    return this.processor;
  }

  public Integer getMessageLength() {
    return this.messageLength;
  }

  public void setMessageLength(Integer messageLength) {
    this.messageLength = messageLength;
  }

  public Integer getHeadLength() {
    return this.headLength;
  }

  public void setHeadLength(Integer headLength) {
    this.headLength = headLength;
  }

  public Integer getBodyLength() {
    return this.bodyLength;
  }

  public void setBodyLength(Integer bodyLength) {
    this.bodyLength = bodyLength;
  }

  public List<T> getFieldOrder()
  {
    return this.fieldOrder;
  }

  public void setFieldOrder(List<T> fieldOrder) {
    this.fieldOrder = fieldOrder;
  }
}