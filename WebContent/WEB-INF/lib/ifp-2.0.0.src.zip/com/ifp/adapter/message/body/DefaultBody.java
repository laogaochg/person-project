package com.ifp.adapter.message.body;

import com.ifp.adapter.message.BaseMessage;
import com.ifp.adapter.message.field.MessageField;

public class DefaultBody extends BaseMessage<MessageField>
{
  private static DefaultBody body;

  private static synchronized DefaultBody init()
  {
    return new DefaultBody();
  }

  public static DefaultBody getInstance()
  {
    if (null == body)
      body = init();

    return body;
  }
}