package com.ifp.cache.common;

public class Constants
{
  public static final int CACHE_VALUE_TYPE_STRING = 1;
  public static final int CACHE_VALUE_TYPE_LIST = 2;
  public static final int CACHE_VALUE_TYPE_OBJECT = 3;
}