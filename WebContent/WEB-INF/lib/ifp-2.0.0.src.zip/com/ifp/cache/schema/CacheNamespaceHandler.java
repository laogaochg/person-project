package com.ifp.cache.schema;

import com.ifp.cache.schema.parse.CacheParser;
import com.ifp.cache.schema.parse.CacheServerParser;
import com.ifp.cache.schema.parse.CacheServersParser;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

public class CacheNamespaceHandler extends NamespaceHandlerSupport
{
  public void init()
  {
    registerBeanDefinitionParser("cache", new CacheParser());
    registerBeanDefinitionParser("servers", new CacheServersParser());
    registerBeanDefinitionParser("server", new CacheServerParser());
  }
}