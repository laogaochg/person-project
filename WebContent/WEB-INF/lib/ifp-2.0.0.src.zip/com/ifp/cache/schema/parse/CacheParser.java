package com.ifp.cache.schema.parse;

import com.ifp.cache.bean.IFPCache;
import com.ifp.core.util.StringUtil;
import java.util.List;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class CacheParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    try
    {
      builder.addPropertyValue("id", element.getAttribute("id"));
      builder.addPropertyValue("type", element.getAttribute("type"));
      String intervalTime = element.getAttribute("intervalTime");
      if (StringUtil.hasText(intervalTime))
      {
        builder.addPropertyValue("intervalTime", Long.valueOf(Long.parseLong(intervalTime)));
      }
      else builder.addPropertyValue("intervalTime", Integer.valueOf(60000));

      String maxIdleConn = element.getAttribute("maxIdleConn");
      if (StringUtil.hasText(maxIdleConn))
      {
        builder.addPropertyValue("maxIdleConn", Integer.valueOf(Integer.parseInt(maxIdleConn)));
      }
      else builder.addPropertyValue("maxIdleConn", Integer.valueOf(50));

      String minIdleConn = element.getAttribute("minIdleConn");
      if (StringUtil.hasText(minIdleConn))
      {
        builder.addPropertyValue("minIdleConn", Integer.valueOf(Integer.parseInt(minIdleConn)));
      }
      else { builder.addPropertyValue("minIdleConn", Integer.valueOf(10));
      }

      String maxConn = element.getAttribute("maxConn");
      if (StringUtil.hasText(maxConn))
      {
        builder.addPropertyValue("maxConn", Integer.valueOf(Integer.parseInt(maxConn)));
      }
      else builder.addPropertyValue("maxConn", Integer.valueOf(5000));

      String maxWait = element.getAttribute("maxWait");
      if (StringUtil.hasText(maxWait))
      {
        builder.addPropertyValue("maxWait", Long.valueOf(Long.parseLong(maxWait)));
      }
      else { builder.addPropertyValue("maxWait", Integer.valueOf(1000));
      }

      String open = element.getAttribute("open");
      if (StringUtil.hasText(open))
      {
        builder.addPropertyValue("open", Boolean.valueOf(Boolean.parseBoolean(open.toLowerCase())));
      }
      else { builder.addPropertyValue("open", Boolean.valueOf(false));
      }

      builder.addPropertyValue("servers", parseServicesElement("servers", element, parserContext, builder));
    }
    catch (Exception e) {
      parserContext.getReaderContext().error("class " + CacheParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<IFPCache> getBeanClass(Element element)
  {
    return IFPCache.class;
  }

  private BeanDefinition parseServicesElement(String tagName, Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
    List listElement = DomUtils.getChildElementsByTagName(element, tagName);
    if (listElement.size() > 0)
    {
      Element inputElement = (Element)listElement.get(0);
      BeanDefinition beanDefinition = parserContext.getDelegate().parseCustomElement(inputElement, builder.getRawBeanDefinition());
      return beanDefinition;
    }
    return null;
  }
}