package com.ifp.cache.schema.parse;

import com.ifp.cache.bean.CacheServer;
import com.ifp.core.util.StringUtil;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.beans.factory.xml.XmlReaderContext;
import org.w3c.dom.Element;

public class CacheServerParser extends AbstractSimpleBeanDefinitionParser
{
  protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
  {
    String masterHost;
    try
    {
      masterHost = element.getAttribute("masterHost");
      if (StringUtil.hasText(masterHost))
      {
        builder.addPropertyValue("masterHost", element.getAttribute("masterHost"));
      }
      else builder.addPropertyValue("masterHost", null);

      String masterPost = element.getAttribute("masterPost");
      if (StringUtil.hasText(masterPost))
      {
        builder.addPropertyValue("masterPost", Integer.valueOf(Integer.parseInt(masterPost)));
      }
      String masterPassword = element.getAttribute("masterPassword");
      if (StringUtil.hasText(masterPassword))
      {
        builder.addPropertyValue("masterPassword", masterPassword);
      }
      else builder.addPropertyValue("masterPassword", null);

      String bakHost = element.getAttribute("bakHost");
      if (StringUtil.hasText(bakHost))
      {
        builder.addPropertyValue("bakHost", element.getAttribute("bakHost"));
      }
      else builder.addPropertyValue("bakHost", "");

      String bakPort = element.getAttribute("bakPort");
      if (StringUtil.hasText(bakPort))
      {
        builder.addPropertyValue("bakPort", Integer.valueOf(Integer.parseInt(bakPort)));
      }
      String bakPassword = element.getAttribute("bakPassword");
      if (StringUtil.hasText(bakPassword))
      {
        builder.addPropertyValue("bakPassword", bakPassword);
      }
      else { builder.addPropertyValue("bakPassword", null);
      }

      String sentinelHost = element.getAttribute("sentinelHost");
      if (StringUtil.hasText(sentinelHost))
      {
        builder.addPropertyValue("sentinelHost", element.getAttribute("sentinelHost"));
      }
      else builder.addPropertyValue("sentinelHost", null);

      String sentinelPost = element.getAttribute("sentinelPost");
      if (StringUtil.hasText(sentinelPost))
      {
        builder.addPropertyValue("sentinelPost", Integer.valueOf(Integer.parseInt(sentinelPost)));
      }
      String sentinelPassword = element.getAttribute("sentinelPassword");
      if (StringUtil.hasText(sentinelPassword))
      {
        builder.addPropertyValue("sentinelPassword", sentinelPassword);
      }
      else { builder.addPropertyValue("sentinelPassword", null);
      }

      builder.addPropertyValue("weight", Integer.valueOf(Integer.parseInt(element.getAttribute("weight"))));
      builder.addPropertyValue("timeout", Integer.valueOf(Integer.parseInt(element.getAttribute("timeout"))));

      String databases = element.getAttribute("databases");
      if (StringUtil.hasText(databases))
      {
        builder.addPropertyValue("databases", Integer.valueOf(Integer.parseInt(databases)));
      }
      else { builder.addPropertyValue("databases", Integer.valueOf(15));
      }

      builder.addPropertyValue("masterName", element.getAttribute("masterName"));
    } catch (Exception e) {
      parserContext.getReaderContext().error("class " + CacheServerParser.class.getName() + " can not be create", element, null, e);
    }
  }

  protected Class<CacheServer> getBeanClass(Element element)
  {
    return CacheServer.class;
  }
}