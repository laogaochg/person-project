package com.ifp.cache.redis.access;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class ECID
{
  private static final int ERROR_COUNT_LIMIT = 100000;
  private Queue<RedisKey> ecQueue;
  private int errorCount;

  public ECID()
  {
    this.ecQueue = new ConcurrentLinkedQueue();
  }

  public void add(RedisKey key)
  {
    if (this.errorCount < 100000) {
      this.ecQueue.add(key);
      counter(1);
    }
  }

  private synchronized void counter(int val) {
    this.errorCount += val;
  }

  public boolean isCleanable() {
    return (this.errorCount >= 100000);
  }

  public RedisKey next() {
    RedisKey rk = (RedisKey)this.ecQueue.poll();
    if (rk != null)
      counter(-1);

    return rk;
  }

  public void clean() {
    synchronized (this.ecQueue) {
      this.ecQueue.clear();
      this.errorCount = 0;
    }
  }
}