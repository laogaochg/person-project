package com.ifp.cache.redis.util;

import org.apache.commons.pool.PoolableObjectFactory;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.apache.commons.pool.impl.GenericObjectPool.Config;
import redis.clients.jedis.exceptions.JedisConnectionException;
import redis.clients.jedis.exceptions.JedisException;

public abstract class Pool<T>
{
  private final GenericObjectPool internalPool;

  public Pool(GenericObjectPool.Config poolConfig, PoolableObjectFactory factory)
  {
    this.internalPool = new GenericObjectPool(factory, poolConfig);
  }

  public T getResource()
  {
    try {
      return this.internalPool.borrowObject();
    } catch (Exception e) {
      throw new JedisConnectionException("Could not get a resource from the pool", e);
    }
  }

  public void returnResourceObject(Object resource)
  {
    try {
      this.internalPool.returnObject(resource);
    } catch (Exception e) {
      throw new JedisException("Could not return the resource to the pool", e);
    }
  }

  public void returnBrokenResource(T resource) {
    returnBrokenResourceObject(resource);
  }

  public void returnResource(T resource) {
    returnResourceObject(resource);
  }

  protected void returnBrokenResourceObject(Object resource)
  {
    try {
      this.internalPool.invalidateObject(resource);
    } catch (Exception e) {
      throw new JedisException("Could not return the resource to the pool", e);
    }
  }

  public void destroy() {
    try {
      this.internalPool.close();
    } catch (Exception e) {
      throw new JedisException("Could not destroy the pool", e);
    }
  }
}