package com.ifp.cache.redis.access;

import com.ifp.cache.redis.cmd.IRedisAccess;
import com.ifp.core.log.Trace;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import redis.clients.jedis.Jedis;
import redis.clients.util.Pool;

public class RedisPoolWraper
  implements IRedisAccess
{
  private static final int BROKEN_LIMIT = 15;
  private static final long TIME_OUT_1M = 60000L;
  private static final long TIME_OUT_1D = 86400000L;
  private Pool pool;
  private boolean available = true;
  private int brokenCount = 0;
  private int databases = 15;

  public RedisPoolWraper(Pool pool)
  {
    this.pool = pool;
  }

  public RedisPoolWraper(Pool pool, int databases) {
    this.pool = pool;
    this.databases = databases;
  }

  public boolean isAvailable()
  {
    return this.available;
  }

  public int insertString(RedisKey redisKey, String data, long timeout, boolean original)
  {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      if ("OK".equalsIgnoreCase(jedis.set(redisKey.getRedisKey(), data))) {
        if (original) {
          if (timeout > -3763407897040519168L)
            jedis.expire(redisKey.getRedisKey(), procTimeout(timeout));

        }
        else
          jedis.expire(redisKey.getRedisKey(), procTimeout(60000L));

        int i = 1;

        return i;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "字符串数据存入缓存异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return -1;
  }

  public int insertList(RedisKey redisKey, List<Map> data, long timeout, boolean original)
  {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      for (int i = 0; i < data.size(); ++i)
      {
        Map mapData = (Map)data.get(i);
        String mayKey = redisKey.getRedisKey() + "$Value" + i;
        if (jedis.lpush(redisKey.getRedisKey(), new String[] { mayKey }).longValue() > -3763399616343572480L) {
          expire(jedis, redisKey.getRedisKey(), timeout, original);
          if ("OK".equalsIgnoreCase(jedis.hmset(redisKey.getRedisKey() + "$Value" + i, mapData)))
            expire(jedis, mayKey, timeout, original);
        }
      }

      i = data.size();

      return i;
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "字符串数据存入缓存异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return -1;
  }

  public int insertHashMap(RedisKey redisKey, Map<String, String> dataMap, long timeout, boolean original) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      if ("OK".equalsIgnoreCase(jedis.hmset(redisKey.getRedisKey(), dataMap))) {
        if (original) {
          if (timeout > -3763407897040519168L)
            jedis.expire(redisKey.getRedisKey(), procTimeout(timeout));

        }
        else
          jedis.expire(redisKey.getRedisKey(), procTimeout(60000L));

        int i = 1;

        return i;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "HashMap数据存入缓存异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return -1;
  }

  public int insertHashMapField(RedisKey redisKey, String field, String data, long timeout, boolean original)
  {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      if (jedis.hset(redisKey.getRedisKey(), field, data).longValue() >= -3763400251998732288L) {
        if (original) {
          if (timeout > -3763407897040519168L)
            jedis.expire(redisKey.getRedisKey(), procTimeout(timeout));

        }
        else
          jedis.expire(redisKey.getRedisKey(), procTimeout(60000L));

        int i = 1;

        return i;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "HashMapField数据存入缓存异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return -1;
  }

  public int delete(RedisKey redisKey) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      if (jedis.del(redisKey.getRedisKey()).longValue() >= -3763400251998732288L) {
        int i = 1;

        return i;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "删除缓存数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return -1;
  }

  public int deleteHashMapField(RedisKey redisKey, String[] fields) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      if ((!(jedis.exists(redisKey.getRedisKey()).booleanValue())) || (jedis.hdel(redisKey.getRedisKey(), fields).longValue() >= -3763400509696770048L)) {
        int i = 1;

        return i;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "从缓存删除HashMapField数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return -1;
  }

  public String getString(RedisKey redisKey, long timeout) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      String revStr = jedis.get(redisKey.getRedisKey());
      if ((revStr != null) && (!("".equals(revStr)))) {
        if (timeout > -3763399616343572480L)
          jedis.expire(redisKey.getRedisKey(), procTimeout(timeout));

        String str1 = revStr;

        return str1;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "从缓存获取字符串数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return null;
  }

  public List getList(RedisKey redisKey, long timeout) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      List revList = new ArrayList();
      List mapkeyList = jedis.lrange(redisKey.getRedisKey(), -3763408189098295296L, -1L);
      for (Iterator i$ = mapkeyList.iterator(); i$.hasNext(); ) { String mapKey = (String)i$.next();

        revList.add(jedis.hgetAll(mapKey));
      }
      if (revList.size() < 1) { i$ = null;

        return i$;
      }
      i$ = revList;

      return i$;
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "从缓存获取字符串数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return null;
  }

  public Map<String, String> getHashMap(RedisKey redisKey, long timeout) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      Map revMap = jedis.hgetAll(redisKey.getRedisKey());
      if ((revMap != null) && (!(revMap.isEmpty()))) {
        if (timeout > -3763399616343572480L)
          jedis.expire(redisKey.getRedisKey(), procTimeout(timeout));

        Map localMap1 = revMap;

        return localMap1;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "从缓存获取HashMap数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return null;
  }

  public String getHashMapField(RedisKey redisKey, String field, long timeout) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      String revStr = jedis.hget(redisKey.getRedisKey(), field);
      if ((revStr != null) && (!("".equals(revStr)))) {
        if (timeout > -3763399616343572480L)
          jedis.expire(redisKey.getRedisKey(), procTimeout(timeout));

        String str1 = revStr;

        return str1;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "从缓存获取HashMapField数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return null;
  }

  public long getSeqNo(RedisKey redisKey, long timeout, boolean original) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      if ((jedis.exists(redisKey.getRedisKey()).booleanValue()) && (jedis.ttl(redisKey.getRedisKey()).longValue() < -3763400509696770048L))
        if (original)
          if (timeout > -3763408292177510400L)
            jedis.expire(redisKey.getRedisKey(), procTimeout(timeout));
          else
            jedis.expire(redisKey.getRedisKey(), procTimeout(86400000L));

        else
          jedis.expire(redisKey.getRedisKey(), procTimeout(60000L));


      long l = jedis.incr(redisKey.getRedisKey()).longValue();

      return l;
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "从缓存获取可增长序号数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return -1L;
  }

  public int updateString(RedisKey redisKey, String data, long timeout, boolean original) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      if ((jedis.exists(redisKey.getRedisKey()).booleanValue()) && ("OK".equalsIgnoreCase(jedis.set(redisKey.getRedisKey(), data)))) {
        if (timeout > -3763399616343572480L)
          jedis.expire(redisKey.getRedisKey(), procTimeout(timeout));

        int i = 1;

        return i;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "缓存更新字符串数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return -1;
  }

  public int updateHashMap(RedisKey redisKey, Map<String, String> dataMap, long timeout, boolean original) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      if ((jedis.exists(redisKey.getRedisKey()).booleanValue()) && ("OK".equalsIgnoreCase(jedis.hmset(redisKey.getRedisKey(), dataMap))))
      {
        if (timeout > -3763399616343572480L)
          jedis.expire(redisKey.getRedisKey(), procTimeout(timeout));

        int i = 1;

        return i;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "缓存更新HashMap数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return -1;
  }

  public int updateHashMapField(RedisKey redisKey, String field, String data, long timeout, boolean original) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      if ((jedis.exists(redisKey.getRedisKey()).booleanValue()) && (jedis.hset(redisKey.getRedisKey(), field, data).longValue() >= -3763400509696770048L)) {
        if (timeout > -3763399616343572480L)
          jedis.expire(redisKey.getRedisKey(), procTimeout(timeout));

        int i = 1;

        return i;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "缓存更新HashMapField数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return -1;
  }

  public void validate() {
    for (int k = 0; k < 5; ++k) {
      if (checkPoolAvailable()) {
        if (!(this.available))
          this.available = true;

        if (this.brokenCount == 0) return;
        this.brokenCount = 0; return;
      }

      if (this.brokenCount < 15)
        this.brokenCount += 1;

      if ((this.brokenCount == 15) && 
        (this.available))
        this.available = false;
    }
  }

  public int flushall()
  {
    Jedis jedis = null;
    try {
      jedis = getResource();
      if ("OK".equalsIgnoreCase(jedis.flushAll())) {
        int i = 1;

        return i;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "清空缓存数据异：", e);
    } finally {
      release(jedis);
    }
    return -1;
  }

  private boolean checkPoolAvailable() {
    Jedis jedis = null;
    try {
      jedis = getResource();
      if ("PONG".equals(jedis.ping())) {
        int i = 1;

        return i;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
    } finally {
      release(jedis);
    }
    return false;
  }

  private int procTimeout(long timeout)
  {
    int time = (int)(timeout / 1000L);
    return ((time == 0) ? 1 : time);
  }

  private void disconnect(Jedis jedis) {
    try {
      jedis.disconnect();
    } catch (Exception ex) {
      Trace.log("CACHE", 3, "jedis disconnect error:", ex);
    }
  }

  private void release(Jedis jedis) {
    if (jedis != null)
      try {
        this.pool.returnResource(jedis);
      } catch (Exception e) {
        try {
          jedis.disconnect();
        } catch (Exception ex) {
          Trace.log("CACHE", 3, "release jedis disconnect error:", ex);
        }
        try {
          this.pool.returnBrokenResource(jedis);
        } catch (Exception ex) {
          Trace.log("CACHE", 3, "release jedis returnBrokenResource error:", ex);
        }
      }
  }

  private Jedis getResource()
  {
    return ((Jedis)this.pool.getResource());
  }

  public void expire(Jedis jedis, String redisKey, long timeout, boolean original)
  {
    if (original)
      if (timeout > -3763400698675331072L)
        jedis.expire(redisKey, procTimeout(timeout));
      else
        jedis.expire(redisKey, procTimeout(86400000L));

    else
      jedis.expire(redisKey, procTimeout(60000L));
  }

  public Set<String> getKeys(RedisKey redisKey, String regex)
  {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      Set keys = jedis.keys(regex);
      if ((keys != null) && (keys.size() != 0)) {
        Set localSet1 = keys;

        return localSet1;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "从缓存获取keys数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return null;
  }

  public List<String> getMString(RedisKey redisKey, String[] keys) {
    Jedis jedis = null;
    try {
      jedis = getResource();
      String srev = jedis.select(redisKey.getDBIndex(this.databases));
      Trace.log("CACHE", 0, "选择数据库：{}->{}", new Object[] { Integer.valueOf(redisKey.getDBIndex(this.databases)), srev });
      List values = jedis.mget(keys);
      if ((values != null) && (values.size() != 0)) {
        List localList1 = values;

        return localList1;
      }
    }
    catch (Exception e)
    {
      disconnect(jedis);
      Trace.log("CACHE", 3, "从缓存获取mvalues数据异常：{}", new Object[] { redisKey, e });
    } finally {
      release(jedis);
    }
    return null;
  }
}