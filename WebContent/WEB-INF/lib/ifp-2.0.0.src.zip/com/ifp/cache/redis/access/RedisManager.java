package com.ifp.cache.redis.access;

import com.ifp.cache.bean.CacheServer;
import com.ifp.cache.bean.CacheServices;
import com.ifp.cache.bean.IFPCache;
import com.ifp.cache.redis.config.HostConfig;
import com.ifp.cache.redis.config.RedisConfig;
import com.ifp.cache.redis.config.RedisConfigReader;
import com.ifp.cache.redis.config.RedisNodeConfig;
import com.ifp.core.log.Trace;
import com.ifp.core.util.StringUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import redis.clients.jedis.JedisPoolConfig;

public class RedisManager
{
  private static RedisManager instance = new RedisManager();
  private RedisConfigReader configReader = null;
  private Timer intervalTimer = null;
  private List<RedisNode> redisNodeList = null;
  private boolean isInited;
  private int maxWeight = 0;

  public static RedisManager getInstance()
  {
    return instance;
  }

  public boolean init()
  {
    return init(RedisConfigReader.getConfigReader(RedisManager.class.getResourceAsStream("/redis.xml")));
  }

  public boolean init(String path)
  {
    return init(RedisConfigReader.getConfigReader(new File(path)));
  }

  public boolean init(RedisConfigReader configReader)
  {
    this.isInited = false;
    if (this.redisNodeList != null)
      this.redisNodeList.clear();

    if (configReader == null)
      this.configReader = RedisConfigReader.getConfigReader(RedisManager.class.getResourceAsStream("/redis.xml"));
    else
      this.configReader = configReader;

    if (this.configReader != null) {
      RedisConfig rcfg = this.configReader.getRedisConfig();
      if ((rcfg != null) && (rcfg.isOpen()))
        this.isInited = init(rcfg);
    }

    if (!(this.isInited))
      Trace.log("CACHE", 3, "初始化Redis失败，配置文件不存在或缓存开关已关闭...");

    return this.isInited;
  }

  public boolean init(IFPCache ifpCache)
  {
    this.isInited = false;
    if (this.redisNodeList != null)
      this.redisNodeList.clear();

    if ((ifpCache != null) && (ifpCache.isOpen()))
    {
      JedisPoolConfig poolConfig = new JedisPoolConfig();
      poolConfig.setMaxIdle(ifpCache.getMaxIdleConn());
      poolConfig.setMinIdle(ifpCache.getMinIdleConn());
      poolConfig.setMaxTotal(ifpCache.getMaxConn());
      poolConfig.setMaxWaitMillis(ifpCache.getMaxWait());

      CacheServices servers = ifpCache.getServers();
      if (servers != null) {
        if (this.redisNodeList == null)
          this.redisNodeList = new ArrayList();

        int count = 1;
        for (Iterator i$ = servers.getServers().iterator(); i$.hasNext(); ) { CacheServer ser = (CacheServer)i$.next();
          if (ser != null)
          {
            this.maxWeight += ser.getWeight();
            HostConfig master = null;
            if (StringUtil.hasText(ser.getMasterHost()))
            {
              master = new HostConfig(ser.getMasterHost(), ser.getMasterPost(), ser.getMasterPassword(), ser.getTimeout(), ser.getDatabases());
              Trace.log("CACHE", 1, "添加第{}个缓存节点:{}", new Object[] { Integer.valueOf(count++), ser.getMasterHost(), Integer.valueOf(ser.getMasterPost()) });
            }
            HostConfig salver = null;
            if (StringUtil.hasText(ser.getBakHost()))
            {
              salver = new HostConfig(ser.getBakHost(), ser.getBakPort(), ser.getBakPassword(), ser.getTimeout(), ser.getDatabases());
            }
            HostConfig sentinel = null;
            if (StringUtil.hasText(ser.getSentinelHost()))
            {
              sentinel = new HostConfig(ser.getSentinelHost(), ser.getSentinelPost(), ser.getSentinelPassword(), ser.getTimeout(), ser.getDatabases(), ser.getMasterName());

              Trace.log("CACHE", 1, "添加第{}个缓存节点:{}", new Object[] { Integer.valueOf(count++), ser.getSentinelHost(), Integer.valueOf(ser.getSentinelPost()) });
            }
            this.redisNodeList.add(new RedisNode(poolConfig, master, salver, sentinel, ser.getWeight()));
          }
        }

        if (ifpCache.getIntervalTime() != -3763400509696770048L) {
          if (this.intervalTimer != null) {
            this.intervalTimer.cancel();
            this.intervalTimer = null;
          }
          this.intervalTimer = new Timer();
          this.intervalTimer.schedule(new IntervalValidateTask(this, null), ifpCache.getIntervalTime(), ifpCache.getIntervalTime());
          Trace.log("CACHE", 1, "心跳检测线程已经启动...");
        }
        if ((this.redisNodeList != null) && (!(this.redisNodeList.isEmpty())))
          this.isInited = true;
      }
    }

    if (!(this.isInited))
      Trace.log("CACHE", 3, "初始化Redis失败，配置文件不存在或缓存开关已关闭...");

    return this.isInited;
  }

  private boolean init(RedisConfig rcfg)
  {
    GenericObjectPoolConfig poolConfig = rcfg.getPoolConfig();

    List servers = rcfg.getServers();
    if ((servers == null) || (servers.isEmpty())) break label245;
    if (this.redisNodeList == null)
      this.redisNodeList = new ArrayList();

    int count = 1;
    for (Iterator i$ = servers.iterator(); i$.hasNext(); ) { RedisNodeConfig rnc = (RedisNodeConfig)i$.next();
      if (rnc != null)
      {
        this.maxWeight += rnc.getWeight();
        this.redisNodeList.add(new RedisNode(poolConfig, rnc.getMaster(), rnc.getBak(), null, rnc.getWeight()));
        Trace.log("CACHE", 1, "添加第{}个缓存节点...", new Object[] { Integer.valueOf(count++) });
      }
    }

    if (rcfg.getIntervalTime() != -3763400956373368832L) {
      if (this.intervalTimer != null) {
        this.intervalTimer.cancel();
        this.intervalTimer = null;
      }
      this.intervalTimer = new Timer();
      this.intervalTimer.schedule(new IntervalValidateTask(this, null), rcfg.getIntervalTime(), rcfg.getIntervalTime());
      Trace.log("CACHE", 1, "心跳检测线程已经启动...");
    }

    label245: return ((this.redisNodeList != null) && (!(this.redisNodeList.isEmpty())));
  }

  public boolean isRedisInited()
  {
    return this.isInited;
  }

  public RedisAccess getRedisAccess(RedisKey redisKey) {
    if (!(this.isInited)) {
      Trace.log("CACHE", 3, "缓存尚未初始化...");
      return null;
    }
    if ((this.redisNodeList != null) && (!(this.redisNodeList.isEmpty()))) {
      int nodeCount = this.redisNodeList.size();
      long hashValue = redisKey.getRedisKeyHashValue();

      int index = 0;

      if (this.maxWeight == 0) {
        index = (int)(hashValue % nodeCount);
      } else {
        int rand = (int)(hashValue % this.maxWeight);
        int sum = 0;
        for (int i = 0; i < nodeCount; ++i) {
          sum += ((RedisNode)this.redisNodeList.get(i)).getWeight();
          if (rand < sum) {
            index = i;
            break;
          }
        }
      }

      RedisNode node = (RedisNode)this.redisNodeList.get(index);
      if (node.isAvailable()) {
        return node.getRedisAccess(true);
      }

      int c = nodeCount - 1;
      while (c > 0) {
        ++index;
        if (index == nodeCount)
          index = 0;

        node = (RedisNode)this.redisNodeList.get(index);
        if (node.isAvailable())
          return node.getRedisAccess(false);

        --c;
      }
    }

    return null;
  }

  private void validate()
  {
    if ((this.configReader != null) && 
      (this.configReader.needLoad())) {
      init(this.configReader);
    }

    if ((this.redisNodeList != null) && (!(this.redisNodeList.isEmpty())))
      for (Iterator i$ = this.redisNodeList.iterator(); i$.hasNext(); ) { RedisNode node = (RedisNode)i$.next();
        node.validate();
      }
  }

  public void flushAll()
  {
    if ((this.redisNodeList != null) && (!(this.redisNodeList.isEmpty())))
      for (Iterator i$ = this.redisNodeList.iterator(); i$.hasNext(); ) { RedisNode node = (RedisNode)i$.next();
        node.flushall();
      }
  }

  public void shutdown()
  {
    if (this.intervalTimer != null) {
      this.intervalTimer.cancel();
      this.intervalTimer = null;
    }
  }

  private class IntervalValidateTask extends TimerTask
  {
    public void run()
    {
      RedisManager.access$100(this.this$0);
    }
  }
}