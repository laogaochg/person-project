package com.ifp.cache.redis.access;

import com.ifp.cache.redis.config.HostConfig;
import com.ifp.core.log.LogHandle;
import com.ifp.core.util.SpringContextsUtil;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class RedisAccess
{
  private RedisNode redisNode;
  private boolean original;

  public RedisAccess(RedisNode redisNode, boolean original)
  {
    this.redisNode = redisNode;
    this.original = original;
  }

  public int insertString(RedisKey key, String data, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    int rt = -1;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.insertString(key, data, timeout, this.original);
      logHandle.logFlumeCacheSvc("INSERT_STR@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx("INSERT_STR@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public int insertHashMap(RedisKey key, Map<String, String> dataMap, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    int rt = -1;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.insertHashMap(key, dataMap, timeout, this.original);
      logHandle.logFlumeCacheSvc("INSERT_MAP@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx("INSERT_MAP@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public int insertList(RedisKey key, List data, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    int rt = -1;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.insertList(key, data, timeout, this.original);
      logHandle.logFlumeCacheSvc("INSERT_LIST@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx("INSERT_LIST@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public int insertHashMapField(RedisKey key, String field, String data, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    int rt = -1;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    StringBuffer method = new StringBuffer("INSERT_MAP_FIELD@key=");
    method.append(key).append("&field=").append(field);
    try {
      rt = this.redisNode.insertHashMapField(key, field, data, timeout, this.original);
      logHandle.logFlumeCacheSvc(method.toString(), conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx(method.toString(), conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public int delete(RedisKey key) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    int rt = -1;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.delete(key);
      logHandle.logFlumeCacheSvc("DELETE@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx("DELETE@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public int deleteHashMapField(RedisKey key, String[] fields) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    int rt = -1;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    StringBuffer method = new StringBuffer("DELETE_MAP_FIELD@key=");
    method.append(key).append("&").append("fields=").append(Arrays.toString(fields));
    try {
      rt = this.redisNode.deleteHashMapField(key, fields);
      logHandle.logFlumeCacheSvc(method.toString(), conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx(method.toString(), conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public String getString(RedisKey key, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    String rt = "";
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.getString(key, timeout);
      logHandle.logFlumeCacheSvc("QUERY_STR@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx("QUERY_STR@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public List getList(RedisKey key, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    List rt = Collections.EMPTY_LIST;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.getList(key, timeout);
      logHandle.logFlumeCacheSvc("QUERY_LIST@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx("QUERY_LIST@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public Map<String, String> getHashMap(RedisKey key, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    Map rt = Collections.EMPTY_MAP;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.getHashMap(key, timeout);
      logHandle.logFlumeCacheSvc("QUERY_MAP@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx("QUERY_MAP@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public String getHashMapField(RedisKey key, String field, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    String rt = "";
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    StringBuffer method = new StringBuffer("QUERY_MAP_FIELD@key=");
    method.append(key).append("&field=").append(field);
    try {
      rt = this.redisNode.getHashMapField(key, field, timeout);
      logHandle.logFlumeCacheSvc(method.toString(), conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx(method.toString(), conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public long getSeqNo(RedisKey key, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    long rt = -1L;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.getSeqNo(key, timeout, this.original);
      logHandle.logFlumeCacheSvc("QUERY_SEQ@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx("QUERY_SEQ@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public int updateString(RedisKey key, String data, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    int rt = -1;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.updateString(key, data, timeout, this.original);
      logHandle.logFlumeCacheSvc("UPDATE_STR@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx("UPDATE_STR@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public int updateHashMap(RedisKey key, Map<String, String> dataMap, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    int rt = -1;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.updateHashMap(key, dataMap, timeout, this.original);
      logHandle.logFlumeCacheSvc("UPDATE_MAP@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx("UPDATE_MAP@key=" + key, conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public int updateHashMapField(RedisKey key, String field, String data, long timeout) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    int rt = -1;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    StringBuffer method = new StringBuffer("UPDATE_MAP_FIELD@key=");
    method.append(key).append("&field=").append(field);
    try {
      rt = this.redisNode.updateHashMapField(key, field, data, timeout, this.original);
      logHandle.logFlumeCacheSvc(method.toString(), conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime);
    }
    catch (Exception e)
    {
      logHandle.logFlumeCacheSvcEx(method.toString(), conf.getPort() + "." + conf.getDatabases(), conf.getHost(), "REDIS", startTime, e);
    }

    return rt;
  }

  public int flushall() {
    return this.redisNode.flushall();
  }

  public void validate()
  {
    this.redisNode.validate();
  }

  public Set<String> getKeys(RedisKey redisKey, String regex) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    Set rt = Collections.EMPTY_SET;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.getKeys(redisKey, regex);
    }
    catch (Exception e)
    {
    }

    return rt;
  }

  public List<String> getMString(RedisKey redisKey, String[] keys) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    List rt = Collections.EMPTY_LIST;
    Long startTime = Long.valueOf(System.currentTimeMillis());
    HostConfig conf = this.redisNode.getConfig();
    try {
      rt = this.redisNode.getMString(redisKey, keys);
    }
    catch (Exception e)
    {
    }

    return rt;
  }
}