package com.ifp.cache.redis.config;

public class RedisNodeConfig
{
  private HostConfig master;
  private HostConfig bak;
  private int weight;

  public RedisNodeConfig()
  {
  }

  public RedisNodeConfig(HostConfig master, HostConfig bak, int weight)
  {
    this.master = master;
    this.bak = bak;
    this.weight = weight;
  }

  public HostConfig getMaster()
  {
    return this.master;
  }

  public void setMaster(HostConfig master)
  {
    this.master = master;
  }

  public HostConfig getBak()
  {
    return this.bak;
  }

  public void setBak(HostConfig bak)
  {
    this.bak = bak;
  }

  public int getWeight()
  {
    return this.weight;
  }

  public void setWeight(int weight)
  {
    this.weight = weight;
  }
}