package com.ifp.cache.redis.manager;

import com.ifp.cache.bean.IFPCache;
import com.ifp.cache.redis.access.RedisClient;
import com.ifp.cache.redis.access.RedisKey;
import com.ifp.cache.redis.access.RedisManager;
import com.ifp.core.cache.CacheManager;
import com.ifp.core.exception.BaseException;
import com.ifp.core.util.SerializeUtils;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import net.sf.ehcache.Cache;

public class IFPRedisManager
  implements CacheManager
{
  public String locations;
  public RedisManager redisManager = RedisManager.getInstance();
  public RedisClient cache;
  public String[] cacheNames;
  public long timeOut = 3600000L;
  private String prefix = "ifp";
  public IFPCache ifpCache;

  public IFPRedisManager()
  {
    init();
  }

  public IFPRedisManager(String path)
  {
    init(path);
  }

  public void init() {
    List IFPCaches = getIfpCaches();
    for (int i = 0; i < IFPCaches.size(); ++i)
    {
      this.redisManager.init((IFPCache)IFPCaches.get(i));
    }
    this.cache = new RedisClient(this.redisManager); }

  public void init(String path) {
    this.redisManager.init(path);
    this.cache = new RedisClient(this.redisManager);
  }

  public void removeAll() {
    this.redisManager.flushAll();
  }

  public void put(String cacheKey, String key, Object value) throws BaseException
  {
    put(cacheKey, key, value, this.timeOut);
  }

  public void put(String cacheKey, String key, Object value, long timeout) throws BaseException {
    if (value instanceof String)
    {
      this.cache.saveString(new RedisKey(cacheKey, key), (String)value, timeout);
    } else if (value instanceof Map)
    {
      this.cache.saveMap(new RedisKey(cacheKey, key), (Map)value, timeout);
    } else if (value instanceof List)
    {
      List listValue = (List)value;
      this.cache.saveList(new RedisKey(cacheKey, key), listValue, timeout);
    } else {
      this.cache.saveString(new RedisKey(cacheKey, key), SerializeUtils.serialize(value), timeout);
    }
  }

  public void remove(String cacheKey, String key) {
    this.cache.delete(new RedisKey(cacheKey, key));
  }

  public void removeAll(String cacheKey) {
    this.redisManager.flushAll();
  }

  public Object get(String cacheKey, String key) {
    String result = this.cache.getString(new RedisKey(cacheKey, key), this.timeOut);
    if (result == null) return null;
    return result;
  }

  public Object get(String cacheKey, String key, int dataType) throws BaseException {
    String result;
    if (dataType == 1)
    {
      result = this.cache.getString(new RedisKey(cacheKey, key), this.timeOut);
      if (!(StringUtil.hasText(result))) return null;
      return result; }
    if (dataType == 2)
    {
      Object result = this.cache.getList(new RedisKey(cacheKey, key), this.timeOut);
      if (!(StringUtil.hasText(result))) return null;
      return result; }
    if (dataType == 3)
    {
      result = this.cache.getString(new RedisKey(cacheKey, key), this.timeOut);
      if (!(StringUtil.hasText(result))) return null;
      return SerializeUtils.unSerialize(result);
    }
    return null;
  }

  public String getLocations() {
    return this.locations;
  }

  public void setLocations(String locations) {
    this.locations = locations;
  }

  public RedisManager getRedisManager() {
    return this.redisManager;
  }

  public RedisClient getCache() {
    return this.cache;
  }

  public void setCache(RedisClient cache) {
    this.cache = cache;
  }

  public String getPrefix() {
    return this.prefix;
  }

  public void setPrefix(String prefix) {
    this.prefix = prefix;
  }

  public void setRedisManager(RedisManager redisManager) {
    this.redisManager = redisManager;
  }

  public String[] getCacheNames() {
    return this.cacheNames;
  }

  public void setCacheNames(String[] cacheNames) {
    this.cacheNames = cacheNames;
  }

  public List<String> getKeys(String cacheKey)
  {
    return getCache(cacheKey).getKeys();
  }

  public Cache getCache(String cacheKey) {
    return null;
  }

  public List<Object> query(String cacheKey, String sqel) {
    return null;
  }

  public List<Object> query(String cacheName, String sqel, int page, int count) throws BaseException
  {
    return null;
  }

  public int queryCount(String cacheName, String sqel) throws BaseException
  {
    return 0;
  }

  public long getTimeOut() {
    return this.timeOut;
  }

  public void setTimeOut(long timeOut) {
    this.timeOut = timeOut;
  }

  public IFPCache getIfpCache() {
    if (this.ifpCache == null)
    {
      Map caches = SpringContextsUtil.getBeansOfType(IFPCache.class);
      for (Iterator i$ = caches.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entity = (Map.Entry)i$.next();
        if ("redis".equals(((IFPCache)entity.getValue()).type))
          this.ifpCache = ((IFPCache)entity.getValue());
      }
    }
    return this.ifpCache;
  }

  public List<IFPCache> getIfpCaches() {
    List IFPCaches = new ArrayList();
    Map caches = SpringContextsUtil.getBeansOfType(IFPCache.class);
    for (Iterator i$ = caches.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entity = (Map.Entry)i$.next();
      if ("redis".equals(((IFPCache)entity.getValue()).type))
        IFPCaches.add(entity.getValue());
    }
    return IFPCaches;
  }

  public void setIfpCache(IFPCache ifpCache) {
    this.ifpCache = ifpCache;
  }

  public int removeAll(String cacheKey, String sqel)
  {
    return 0;
  }

  public Set<String> getKeys(String cacheKey, String regex) {
    return this.cache.getKeys(new RedisKey(cacheKey, null), regex);
  }

  public List<String> getMString(String cacheKey, String[] keys) {
    return this.cache.getMString(new RedisKey(cacheKey, null), keys);
  }
}