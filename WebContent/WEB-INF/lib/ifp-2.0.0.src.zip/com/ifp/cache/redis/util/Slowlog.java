package com.ifp.cache.redis.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Slowlog
{
  private final long id;
  private final long timeStamp;
  private final long executionTime;
  private final List<String> args;

  public static List<Slowlog> from(List<Object> nestedMultiBulkReply)
  {
    List logs = new ArrayList(nestedMultiBulkReply.size());
    for (Iterator i$ = nestedMultiBulkReply.iterator(); i$.hasNext(); ) { Object obj = i$.next();
      List properties = (List)obj;
      logs.add(new Slowlog(properties));
    }

    return logs;
  }

  private Slowlog(List<Object> properties)
  {
    this.id = ((Long)properties.get(0)).longValue();
    this.timeStamp = ((Long)properties.get(1)).longValue();
    this.executionTime = ((Long)properties.get(2)).longValue();

    List bargs = (List)properties.get(3);
    this.args = new ArrayList(bargs.size());

    for (Iterator i$ = bargs.iterator(); i$.hasNext(); ) { byte[] barg = (byte[])i$.next();
      this.args.add(SafeEncoder.encode(barg));
    }
  }

  public long getId() {
    return this.id;
  }

  public long getTimeStamp() {
    return this.timeStamp;
  }

  public long getExecutionTime() {
    return this.executionTime;
  }

  public List<String> getArgs() {
    return this.args;
  }
}