package com.ifp.cache.redis.access;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class RedisClient
{
  RedisManager redisManager;

  public RedisClient()
  {
  }

  public RedisClient(RedisManager redisManager)
  {
    this.redisManager = redisManager;
  }

  public int saveString(RedisKey redisKey, String data, long timeout) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.insertString(redisKey, data, timeout);

    return -1;
  }

  public int saveMap(RedisKey redisKey, Map<String, String> data, long timeout) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.insertHashMap(redisKey, data, timeout);

    return -1;
  }

  public int saveMapField(RedisKey redisKey, String data, long timeout) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.insertHashMapField(redisKey, redisKey.getField(), data, timeout);

    return -1;
  }

  public int saveList(RedisKey redisKey, List data, long timeout)
  {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.insertList(redisKey, data, timeout);

    return 0;
  }

  public int delete(RedisKey redisKey) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null) {
      String field = redisKey.getField();
      if ((field != null) && (!("".equals(field.trim()))))
        return ra.deleteHashMapField(redisKey, new String[] { field });

      return ra.delete(redisKey);
    }

    return -1;
  }

  public String getString(RedisKey redisKey, long timeout) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.getString(redisKey, timeout);

    return null;
  }

  public List getList(RedisKey redisKey, long timeout) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.getList(redisKey, timeout);

    return null;
  }

  public Map<String, String> getMap(RedisKey redisKey, long timeout) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.getHashMap(redisKey, timeout);

    return null;
  }

  public String getMapField(RedisKey redisKey, long timeout)
  {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.getHashMapField(redisKey, redisKey.getField(), timeout);

    return null;
  }

  public String getSeqNo(RedisKey redisKey, long timeout) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null) {
      long rev = ra.getSeqNo(redisKey, timeout);
      if (rev >= -3763400183279255552L)
        return String.valueOf(rev);
    }

    return null;
  }

  public int updateString(RedisKey redisKey, String data, long timeout) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.updateString(redisKey, data, timeout);

    return -1;
  }

  public int updateMap(RedisKey redisKey, Map<String, String> data, long timeout) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.updateHashMap(redisKey, data, timeout);

    return -1;
  }

  public int updateMapField(RedisKey redisKey, String data, long timeout) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.updateHashMapField(redisKey, redisKey.getField(), data, timeout);

    return -1;
  }

  public Set<String> getKeys(RedisKey redisKey, String regex) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.getKeys(redisKey, regex);

    return null;
  }

  public List<String> getMString(RedisKey redisKey, String[] keys) {
    RedisAccess ra = this.redisManager.getRedisAccess(redisKey);
    if (ra != null)
      return ra.getMString(redisKey, keys);

    return null;
  }
}