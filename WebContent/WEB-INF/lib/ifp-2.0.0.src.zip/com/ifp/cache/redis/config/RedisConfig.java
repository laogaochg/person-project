package com.ifp.cache.redis.config;

import java.util.ArrayList;
import java.util.List;
import redis.clients.jedis.JedisPoolConfig;

public class RedisConfig
{
  private boolean open;
  private long intervalTime;
  private JedisPoolConfig poolConfig;
  private List<RedisNodeConfig> servers;

  public RedisConfig()
  {
    this.poolConfig = new JedisPoolConfig();

    this.servers = new ArrayList(); }

  public void setMaxIdleConn(int value) {
    this.poolConfig.setMaxIdle(value);
  }

  public void setMinIdleConn(int value) {
    this.poolConfig.setMinIdle(value);
  }

  public void setMaxConn(int value) {
    this.poolConfig.setMaxTotal(value);
  }

  public void setMaxWait(long value) {
    this.poolConfig.setMaxWaitMillis(value);
  }

  public void addNode(RedisNodeConfig rnc) {
    this.servers.add(rnc);
  }

  public long getIntervalTime()
  {
    return this.intervalTime;
  }

  public void setIntervalTime(long intervalTime)
  {
    this.intervalTime = intervalTime;
  }

  public JedisPoolConfig getPoolConfig()
  {
    return this.poolConfig;
  }

  public void setPoolConfig(JedisPoolConfig poolConfig)
  {
    this.poolConfig = poolConfig;
  }

  public List<RedisNodeConfig> getServers()
  {
    return this.servers;
  }

  public void setServers(List<RedisNodeConfig> servers)
  {
    this.servers = servers;
  }

  public boolean isOpen() {
    return this.open;
  }

  public void setOpen(boolean open) {
    this.open = open;
  }
}