package com.ifp.cache.redis.config;

import com.ifp.core.util.StringUtil;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class RedisConfigReader
{
  private static RedisConfigReader reader = null;
  private File file;
  private RedisConfig redisConfig;
  private InputStream inStream;
  private long lastTime = -3763401832546697216L;

  private RedisConfigReader(File file)
  {
    this.file = file;
  }

  private RedisConfigReader(InputStream inStream) {
    this.inStream = inStream;
  }

  public static RedisConfigReader getConfigReader(String path) {
    return getConfigReader(new File(path));
  }

  public static RedisConfigReader getConfigReader(File file) {
    if (reader == null)
      reader = new RedisConfigReader(file);

    return reader;
  }

  public static RedisConfigReader getConfigReader(InputStream inStream) {
    if (reader == null)
      reader = new RedisConfigReader(inStream);

    return reader;
  }

  public RedisConfig getRedisConfig() {
    if (this.redisConfig == null) {
      this.lastTime = System.currentTimeMillis();
      load();
    }
    return this.redisConfig;
  }

  public boolean needLoad()
  {
    return ((this.file != null) && 
      (this.file.lastModified() > this.lastTime));
  }

  protected void load()
  {
    SAXReader srd = new SAXReader();
    try {
      Document document = null;
      if (this.file != null)
        document = srd.read(this.file);
      else if (this.inStream != null) {
        document = srd.read(this.inStream);
      }

      if (document != null)
        readXml(document);
    }
    catch (DocumentException e) {
      e.printStackTrace();
    }
  }

  protected void readXml(Document document)
  {
    this.redisConfig = new RedisConfig();
    if (document != null) {
      Element rootElement = document.getRootElement();
      if (rootElement != null) {
        Iterator iter = rootElement.elementIterator();
        while (iter.hasNext()) {
          Element el = (Element)iter.next();
          if (el != null) {
            String eName = el.getName();
            String eValue = el.getText();
            if ((eName != null) && (!("".equals(eName.trim())))) {
              eName = eName.trim();

              if ("servers".equals(eName)) {
                List servers = new ArrayList();
                Iterator nodeIter = el.elementIterator();
                while (nodeIter.hasNext())
                {
                  RedisNodeConfig rnc = doRedisNode((Element)nodeIter.next());

                  if (rnc != null)
                    servers.add(rnc);
                }

                if (!(servers.isEmpty()))
                  this.redisConfig.setServers(servers);
              }
              else if ("open".equals(eName)) {
                this.redisConfig.setOpen(toBoolean(eValue, false));
              } else if ("intervalTime".equals(eName)) {
                this.redisConfig.setIntervalTime(toLong(eValue, -3763405302880272384L));
              } else if ("minIdleConn".equals(eName)) {
                this.redisConfig.setMinIdleConn(toInt(eValue, 0));
              } else if ("maxIdleConn".equals(eName)) {
                this.redisConfig.setMaxIdleConn(toInt(eValue, 8));
              } else if ("maxWait".equals(eName)) {
                this.redisConfig.setMaxWait(toLong(eValue, 1000L));
              } else if ("maxConn".equals(eName)) {
                this.redisConfig.setMaxConn(toInt(eValue, 8));
              }
            }
          }
        }
      }
    }
  }

  private boolean toBoolean(String str, boolean defaultValue) {
    if ((str != null) && (!("".equals(str.trim()))))
      try {
        return Boolean.parseBoolean(str.trim());
      } catch (Exception e) {
        e.printStackTrace();
      }

    return defaultValue;
  }

  private int toInt(String str, int defaultValue) {
    if ((str != null) && (!("".equals(str.trim()))))
      try {
        return Integer.parseInt(str.trim());
      } catch (Exception e) {
        e.printStackTrace();
      }

    return defaultValue;
  }

  private long toLong(String str, long defaultValue) {
    if ((str != null) && (!("".equals(str.trim()))))
      try {
        return Long.parseLong(str.trim());
      } catch (Exception e) {
        e.printStackTrace();
      }

    return defaultValue;
  }

  private RedisNodeConfig doRedisNode(Element element)
  {
    if (element != null) {
      String masterHost = element.attributeValue("masterHost");
      String masterPort = element.attributeValue("masterPost");
      String masterPassword = element.attributeValue("masterPassword");
      String bakHost = element.attributeValue("bakHost");
      String bakPort = element.attributeValue("bakPort");
      String bakPassword = element.attributeValue("bakPassword");
      String nodeTimeout = element.attributeValue("timeout");
      String nodeWeight = element.attributeValue("weight");
      String databases = element.attributeValue("databases");

      if (!(StringUtil.hasText(databases)))
        databases = "15";
      int timeout = toInt(nodeTimeout, 2000);
      int weight = toInt(nodeWeight, 1);

      HostConfig mhc = null;
      if ((masterHost != null) && (!("".equals(masterHost.trim())))) {
        int port = toInt(masterPort, 6379);
        if ((masterPassword == null) || ("".equals(masterPassword.trim())))
          masterPassword = null;

        mhc = new HostConfig(masterHost, port, masterPassword, timeout, Integer.parseInt(databases));
      }
      HostConfig bhc = null;
      if ((bakHost != null) && (!("".equals(bakHost.trim())))) {
        int port = toInt(bakPort, 6379);
        if ((bakPassword == null) || ("".equals(bakPassword.trim())))
          bakPassword = null;

        bhc = new HostConfig(bakHost, port, bakPassword, timeout, Integer.parseInt(databases));
      }
      if (mhc != null)
        return new RedisNodeConfig(mhc, bhc, weight);
    }

    return null;
  }
}