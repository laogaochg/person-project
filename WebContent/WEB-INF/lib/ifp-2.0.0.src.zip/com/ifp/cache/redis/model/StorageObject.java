package com.ifp.cache.redis.model;

public class StorageObject
{
  public static final int STRING = 0;
  public static final int HASH = 1;
  public static final int HASH_FIELD = 2;
  public static final int SEQ = 3;
  private String storageId;
  private Object storageObject;
  private int storageType;

  public StorageObject()
  {
  }

  public StorageObject(String storageId, Object storageObject)
  {
    this.storageId = storageId;
    this.storageObject = storageObject;
  }

  public StorageObject(String storageId, Object storageObject, int storageType) {
    this(storageId, storageObject);
    this.storageType = storageType;
  }

  public String getStorageId()
  {
    return this.storageId;
  }

  public void setStorageId(String storageId)
  {
    this.storageId = storageId;
  }

  public int getStorageType()
  {
    return this.storageType;
  }

  public void setStorageType(int storageType)
  {
    this.storageType = storageType;
  }

  public Object getStorageObject()
  {
    return this.storageObject;
  }

  public void setStorageObject(Object storageObject)
  {
    this.storageObject = storageObject;
  }

  public String toString() {
    return "storageId:" + this.storageId + ", storageObject=" + this.storageObject + ", storageType:" + this.storageType;
  }
}