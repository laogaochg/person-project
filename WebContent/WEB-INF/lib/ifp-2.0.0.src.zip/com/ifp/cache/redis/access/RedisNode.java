package com.ifp.cache.redis.access;

import com.ifp.cache.redis.config.HostConfig;
import com.ifp.core.log.Trace;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisSentinelPool;

public class RedisNode
{
  private ECID ecid = new ECID();
  private RedisPoolWraper masterPoolWraper;
  private RedisPoolWraper slavePoolWraper;
  private HostConfig config;
  private int weight;

  public RedisNode(GenericObjectPoolConfig poolConfig, HostConfig masterConfig, HostConfig slaveConfig, HostConfig sentinelConfig, int weight)
  {
    this.weight = weight;
    if (sentinelConfig != null)
    {
      this.config = sentinelConfig;
      Set sentinels = new HashSet();
      sentinels.add(sentinelConfig.toString());
      JedisSentinelPool sentinelPool = new JedisSentinelPool(sentinelConfig.getMasterName(), sentinels, poolConfig, sentinelConfig.getTimeout(), sentinelConfig.getPassword());

      this.masterPoolWraper = new RedisPoolWraper(sentinelPool, sentinelConfig.getDatabases());
    }
    else {
      this.config = masterConfig;

      JedisPool mpool = new JedisPool(poolConfig, masterConfig.getHost(), masterConfig.getPort(), masterConfig.getTimeout(), masterConfig.getPassword());

      this.masterPoolWraper = new RedisPoolWraper(mpool, masterConfig.getDatabases());
    }
    if (slaveConfig != null)
    {
      JedisPool spool = new JedisPool(poolConfig, slaveConfig.getHost(), slaveConfig.getPort(), slaveConfig.getTimeout(), slaveConfig.getPassword());

      this.slavePoolWraper = new RedisPoolWraper(spool, masterConfig.getDatabases());
    }
  }

  public int getWeight() {
    return this.weight;
  }

  public boolean isAvailable()
  {
    if (this.masterPoolWraper.isAvailable()) break label33: if (this.slavePoolWraper == null);
    label33: return ((this.slavePoolWraper.isAvailable()) && (!(this.ecid.isCleanable())));
  }

  public RedisAccess getRedisAccess(boolean original)
  {
    if (this.ecid.isCleanable()) {
      Trace.log("CACHE", 3, "节点故障，等待清理节点数据...");
      return null;
    }
    return new RedisAccess(this, original);
  }

  public int insertString(RedisKey key, String data, long timeout, boolean original)
  {
    Trace.log("CACHE", 0, "字符串数据存入缓存：key={},data={},timeout={},original={}", new Object[] { key, data, Long.valueOf(timeout), Boolean.valueOf(original) });
    int rev = -1;
    if (this.masterPoolWraper.isAvailable()) {
      rev = this.masterPoolWraper.insertString(key, data, timeout, original);
    }

    Trace.log("CACHE", 0, "字符串数据存入缓存：result={}", new Object[] { Integer.valueOf(rev) });
    return rev;
  }

  public int insertList(RedisKey key, List data, long timeout, boolean original)
  {
    Trace.log("CACHE", 0, "集合数据存入缓存：key={},data={},timeout={},original={}", new Object[] { key, data, Long.valueOf(timeout), Boolean.valueOf(original) });

    int rev = -1;
    if (this.masterPoolWraper.isAvailable()) {
      rev = this.masterPoolWraper.insertList(key, data, timeout, original);
    }

    Trace.log("CACHE", 0, "集合数据存入缓存：result={}", new Object[] { Integer.valueOf(rev) });
    return rev;
  }

  public int insertHashMap(RedisKey key, Map<String, String> dataMap, long timeout, boolean original)
  {
    Trace.log("CACHE", 0, "HashMap数据存入缓存：key={},data={},timeout={},original={}", new Object[] { key, dataMap, Long.valueOf(timeout), Boolean.valueOf(original) });
    int rev = -1;
    if (this.masterPoolWraper.isAvailable()) {
      rev = this.masterPoolWraper.insertHashMap(key, dataMap, timeout, original);
    }

    Trace.log("CACHE", 0, "HashMap数据存入缓存：result={}", new Object[] { Integer.valueOf(rev) });
    return rev;
  }

  public int insertHashMapField(RedisKey key, String field, String data, long timeout, boolean original)
  {
    Trace.log("CACHE", 0, "HashMap-Field数据存入缓存：key={},field={},data={},timeout={},original={}", new Object[] { key, field, data, Long.valueOf(timeout), Boolean.valueOf(original) });

    int rev = -1;
    if (this.masterPoolWraper.isAvailable()) {
      rev = this.masterPoolWraper.insertHashMapField(key, field, data, timeout, original);
    }

    Trace.log("CACHE", 0, "HashMap-Field数据存入缓存：result={}", new Object[] { Integer.valueOf(rev) });
    return rev;
  }

  public int delete(RedisKey key)
  {
    Trace.log("CACHE", 0, "从缓存删除数据：key={}", new Object[] { key });
    int rev = -1;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.delete(key);

    if (rev == -1) {
      addErrCache(key);
      if ((this.slavePoolWraper != null) && (this.slavePoolWraper.isAvailable()))
        this.slavePoolWraper.delete(key);
    }

    Trace.log("CACHE", 0, "从缓存删除数据：result={}", new Object[] { Integer.valueOf(rev) });
    return rev;
  }

  public int deleteHashMapField(RedisKey key, String[] fields)
  {
    Trace.log("CACHE", 0, "从缓存删除HashMap-Field数据：key={},fields={}", new Object[] { key, fields });
    int rev = -1;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.deleteHashMapField(key, fields);

    if (rev == -1) {
      addErrCache(key);
      if ((this.slavePoolWraper != null) && (this.slavePoolWraper.isAvailable()))
        this.slavePoolWraper.delete(key);
    }

    Trace.log("CACHE", 0, "从缓存删除HashMap-Field数据：result={}", new Object[] { Integer.valueOf(rev) });
    return rev;
  }

  public String getString(RedisKey key, long timeout)
  {
    Trace.log("CACHE", 0, "从缓获取字符串数据：key={},timeout={}", new Object[] { key, Long.valueOf(timeout) });
    String rev = null;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.getString(key, timeout);

    if ((((rev == null) || ("".equals(rev)))) && 
      (this.slavePoolWraper != null) && (this.slavePoolWraper.isAvailable())) {
      rev = this.slavePoolWraper.getString(key, timeout);
    }

    if (rev.length() < 1000)
    {
      Trace.log("CACHE", 0, "从缓获取字符串数据：result={}", new Object[] { rev });
    }
    else Trace.log("CACHE", 0, "从缓获取字符串数据：result={}{}", new Object[] { rev.substring(0, 1000), "......" });

    return rev;
  }

  public List getList(RedisKey key, long timeout)
  {
    Trace.log("CACHE", 0, "从缓获取List数据：key={},timeout={}", new Object[] { key, Long.valueOf(timeout) });
    List rev = null;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.getList(key, timeout);

    if ((((rev == null) || ("".equals(rev)))) && 
      (this.slavePoolWraper != null) && (this.slavePoolWraper.isAvailable())) {
      rev = this.slavePoolWraper.getList(key, timeout);
    }

    if (rev.size() < 10)
    {
      Trace.log("CACHE", 0, "从缓获取List数据：result={}", new Object[] { rev });
    }
    else Trace.log("CACHE", 0, "从缓获取List数据大小：size={}", new Object[] { Integer.valueOf(rev.size()) });

    return rev;
  }

  public Map<String, String> getHashMap(RedisKey key, long timeout)
  {
    Trace.log("CACHE", 0, "从缓获取HashMap数据：key={},timeout={}", new Object[] { key, Long.valueOf(timeout) });
    Map rev = null;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.getHashMap(key, timeout);

    if ((((rev == null) || (rev.isEmpty()))) && 
      (this.slavePoolWraper != null) && (this.slavePoolWraper.isAvailable())) {
      rev = this.slavePoolWraper.getHashMap(key, timeout);
    }

    Trace.log("CACHE", 0, "从缓获取HashMap数据：result={}", new Object[] { rev });
    return rev;
  }

  public String getHashMapField(RedisKey key, String field, long timeout)
  {
    Trace.log("CACHE", 0, "从缓获取HashMap-Field数据：key={},field={},timeout={}", new Object[] { key, field, Long.valueOf(timeout) });
    String rev = null;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.getHashMapField(key, field, timeout);

    if ((((rev == null) || ("".equals(rev)))) && 
      (this.slavePoolWraper != null) && (this.slavePoolWraper.isAvailable())) {
      rev = this.slavePoolWraper.getHashMapField(key, field, timeout);
    }

    Trace.log("CACHE", 0, "从缓获取HashMap-Field数据：result={}", new Object[] { rev });
    return rev;
  }

  public long getSeqNo(RedisKey key, long timeout, boolean original)
  {
    Trace.log("CACHE", 0, "从缓获取序号数据：key={},original={},timeout={}", new Object[] { key, Boolean.valueOf(original), Long.valueOf(timeout) });
    long rev = -1L;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.getSeqNo(key, timeout, original);

    if ((rev < -3763401076632453120L) && 
      (this.slavePoolWraper != null) && (this.slavePoolWraper.isAvailable())) {
      rev = this.slavePoolWraper.getSeqNo(key, timeout, original);
    }

    Trace.log("CACHE", 0, "从缓获取序号数据：result={}", new Object[] { Long.valueOf(rev) });
    return rev;
  }

  public int updateString(RedisKey key, String data, long timeout, boolean original)
  {
    Trace.log("CACHE", 0, "更新缓存字符串数据：key={},data={},original={},timeout={}", new Object[] { key, data, Boolean.valueOf(original), Long.valueOf(timeout) });
    int rev = -1;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.updateString(key, data, timeout, original);

    if (rev == -1)
      delete(key);

    Trace.log("CACHE", 0, "更新缓存字符串数据：result={}", new Object[] { Integer.valueOf(rev) });
    return rev;
  }

  public int updateHashMap(RedisKey key, Map<String, String> dataMap, long timeout, boolean original)
  {
    Trace.log("CACHE", 0, "更新缓存HashMap数据：key={},data={},original={},timeout={}", new Object[] { key, dataMap, Boolean.valueOf(original), Long.valueOf(timeout) });
    int rev = -1;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.updateHashMap(key, dataMap, timeout, original);

    if (rev == -1)
      delete(key);

    Trace.log("CACHE", 0, "更新缓存HashMap数据：result={}", new Object[] { Integer.valueOf(rev) });
    return rev;
  }

  public int updateHashMapField(RedisKey key, String field, String data, long timeout, boolean original)
  {
    Trace.log("CACHE", 0, "更新缓存HashMap-Field数据：key={},field={},data={},original={},timeout={}", new Object[] { key, field, data, Boolean.valueOf(original), Long.valueOf(timeout) });

    int rev = -1;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.updateHashMapField(key, field, data, timeout, original);

    if (rev == -1)
      delete(key);

    Trace.log("CACHE", 0, "更新缓存HashMap-Field数据：result={}", new Object[] { Integer.valueOf(rev) });
    return rev;
  }

  public int flushall()
  {
    Trace.log("CACHE", 0, "清空缓存数据...");
    int rev = -1;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.flushall();

    if ((rev == -1) && 
      (this.slavePoolWraper != null) && (this.slavePoolWraper.isAvailable())) {
      this.slavePoolWraper.flushall();
    }

    Trace.log("CACHE", 0, "清空缓存数据:result={}", new Object[] { Integer.valueOf(rev) });
    return rev;
  }

  public void validate()
  {
    if (this.masterPoolWraper != null)
      this.masterPoolWraper.validate();

    if (this.slavePoolWraper != null)
      this.slavePoolWraper.validate();

    if (this.masterPoolWraper.isAvailable())
      if (this.ecid.isCleanable()) {
        if (flushall() == 1)
          this.ecid.clean();
      }
      else {
        RedisKey key = null;
        while (!(this.ecid.isCleanable())) { if ((key = this.ecid.next()) == null) return;
          delete(key);
        }
      }
  }

  public HostConfig getConfig()
  {
    return this.config;
  }

  public void setConfig(HostConfig config) {
    this.config = config;
  }

  private void addErrCache(RedisKey key)
  {
    this.ecid.add(key);
  }

  public Set<String> getKeys(RedisKey key, String regex) {
    Trace.log("CACHE", 0, "从缓获取Keys数据：regex={}", new Object[] { regex });
    Set rev = null;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.getKeys(key, regex);

    if ((((rev == null) || (rev.isEmpty()))) && 
      (this.slavePoolWraper != null) && (this.slavePoolWraper.isAvailable())) {
      rev = this.slavePoolWraper.getKeys(key, regex);
    }

    String keyStr = Arrays.toString(rev.toArray(new String[0]));
    if (keyStr.length() < 1000)
    {
      Trace.log("CACHE", 0, "从缓获取Keys数据：result={}", new Object[] { keyStr });
    }
    else Trace.log("CACHE", 0, "从缓获取Keys数据：result={}", new Object[] { keyStr.substring(0, 1000), "......" });

    return rev;
  }

  public List<String> getMString(RedisKey key, String[] keys) {
    String keyStr = Arrays.toString(keys);
    if (keyStr.length() < 1000)
    {
      Trace.log("CACHE", 0, "从缓获取mString数据：keys={}", new Object[] { keyStr });
    }
    else Trace.log("CACHE", 0, "从缓获取mString数据：keys={}{}", new Object[] { keyStr.substring(0, 1000), "......" });

    List rev = null;
    if (this.masterPoolWraper.isAvailable())
      rev = this.masterPoolWraper.getMString(key, keys);

    if ((((rev == null) || (rev.isEmpty()))) && 
      (this.slavePoolWraper != null) && (this.slavePoolWraper.isAvailable())) {
      rev = this.slavePoolWraper.getMString(key, keys);
    }

    Trace.log("CACHE", 0, "从缓获取mString数据：size={}", new Object[] { Integer.valueOf(rev.size()) });
    return rev;
  }
}