package com.ifp.cache.redis.cmd;

import com.ifp.cache.redis.access.RedisKey;
import java.util.Map;

public abstract interface IRedisAccess
{
  public abstract int insertString(RedisKey paramRedisKey, String paramString, long paramLong, boolean paramBoolean);

  public abstract int insertHashMap(RedisKey paramRedisKey, Map<String, String> paramMap, long paramLong, boolean paramBoolean);

  public abstract int insertHashMapField(RedisKey paramRedisKey, String paramString1, String paramString2, long paramLong, boolean paramBoolean);

  public abstract int delete(RedisKey paramRedisKey);

  public abstract int deleteHashMapField(RedisKey paramRedisKey, String[] paramArrayOfString);

  public abstract String getString(RedisKey paramRedisKey, long paramLong);

  public abstract Map<String, String> getHashMap(RedisKey paramRedisKey, long paramLong);

  public abstract String getHashMapField(RedisKey paramRedisKey, String paramString, long paramLong);

  public abstract long getSeqNo(RedisKey paramRedisKey, long paramLong, boolean paramBoolean);

  public abstract int updateString(RedisKey paramRedisKey, String paramString, long paramLong, boolean paramBoolean);

  public abstract int updateHashMap(RedisKey paramRedisKey, Map<String, String> paramMap, long paramLong, boolean paramBoolean);

  public abstract int updateHashMapField(RedisKey paramRedisKey, String paramString1, String paramString2, long paramLong, boolean paramBoolean);

  public abstract int flushall();
}