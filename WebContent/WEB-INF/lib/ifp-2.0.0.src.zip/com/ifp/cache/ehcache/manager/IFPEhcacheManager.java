package com.ifp.cache.ehcache.manager;

import com.ifp.core.base.SystemConf;
import com.ifp.core.exception.BaseException;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.Trace;
import com.ifp.core.util.SpringContextsUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.search.Attribute;
import net.sf.ehcache.search.Query;
import net.sf.ehcache.search.Result;
import net.sf.ehcache.search.Results;

public class IFPEhcacheManager
  implements com.ifp.core.cache.CacheManager
{
  public String locations;
  private SystemConf systemConf;
  public CacheManager cacheManager;
  public Cache cache;
  public String[] cacheNames;

  public IFPEhcacheManager()
  {
  }

  public IFPEhcacheManager(String locations, SystemConf systemConf)
  {
    this.locations = locations;
    this.systemConf = systemConf;
    init();
  }

  public void init()
  {
    String rootPath;
    try
    {
      rootPath = this.systemConf.getWebRootPath();
      if (this.locations != null)
      {
        if (this.locations.startsWith("/")) this.locations = this.locations.substring(1);
        this.cacheManager = CacheManager.newInstance(rootPath + this.locations);
      } else {
        this.cacheManager = CacheManager.newInstance(rootPath + "WEB-INF/conf/cache/ehcache.xml");
      }
      this.cacheNames = this.cacheManager.getCacheNames();
    } catch (Exception e) {
      Trace.logError("CACHE", "IFPEhcacheManager init error!", e);
    }
  }

  public void put(String key, Object value) {
    if (this.cache == null)
    {
      this.cacheManager.addCache("defaultCache");
      this.cache = this.cacheManager.getCache("defaultCache");
    }
    this.cache.put(new Element(key, (Serializable)value));
  }

  public void remove(String key) {
    if (this.cache == null) return;
    if (this.cache.get(key) == null) return;
    this.cache.remove(key);
  }

  public void removeAll() {
    if (this.cache == null) return;
    this.cache.removeAll();
  }

  public Object get(String key) {
    if (this.cache == null) return null;
    if (this.cache.get(key) == null) return null;
    return this.cache.get(key).getObjectValue();
  }

  public void put(String cacheKey, String key, Object value) {
    if (getCacheManager().getCache(cacheKey) == null) return;
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    Long startTime = Long.valueOf(System.currentTimeMillis());
    try {
      getCacheManager().getCache(cacheKey).put(new Element(key, (Serializable)value));
      logHandle.logFlumeCacheSvc("SAVE@key=" + key, cacheKey, null, null, startTime);
    }
    catch (IllegalStateException e) {
      logHandle.logFlumeCacheSvcEx("SAVE@key=" + key, cacheKey, null, null, startTime, e);
      throw e;
    } catch (ClassCastException e) {
      logHandle.logFlumeCacheSvcEx("SAVE@key=" + key, cacheKey, null, null, startTime, e);
      throw e;
    }
  }

  public void remove(String cacheKey, String key)
  {
    if (getCacheManager().getCache(cacheKey) == null) return;
    if (getCacheManager().getCache(cacheKey).get(key) == null) return;
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    Long startTime = Long.valueOf(System.currentTimeMillis());
    StringBuffer method = new StringBuffer("DELETE@key=");
    method.append(key);
    try {
      getCacheManager().getCache(cacheKey).remove(key);
      logHandle.logFlumeCacheSvc(method.toString(), cacheKey, null, null, startTime);
    }
    catch (IllegalStateException e) {
      logHandle.logFlumeCacheSvcEx(method.toString(), cacheKey, null, null, startTime, e);
      throw e;
    } catch (ClassCastException e) {
      logHandle.logFlumeCacheSvcEx(method.toString(), cacheKey, null, null, startTime, e);
      throw e;
    }
  }

  public void removeAll(String cacheKey)
  {
    if (getCacheManager().getCache(cacheKey) == null) return;
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    Long startTime = Long.valueOf(System.currentTimeMillis());
    StringBuffer method = new StringBuffer("DELETE@key=");
    method.append("ALL");
    try {
      getCacheManager().getCache(cacheKey).removeAll();
      logHandle.logFlumeCacheSvc(method.toString(), cacheKey, null, null, startTime);
    }
    catch (IllegalStateException e) {
      logHandle.logFlumeCacheSvcEx(method.toString(), cacheKey, null, null, startTime, e);
      throw e;
    } catch (ClassCastException e) {
      logHandle.logFlumeCacheSvcEx(method.toString(), cacheKey, null, null, startTime, e);
      throw e;
    }
  }

  public Object get(String cacheKey, String key)
  {
    if (getCacheManager().getCache(cacheKey) == null) return null;
    if (getCacheManager().getCache(cacheKey).get(key) == null) return null;
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    Long startTime = Long.valueOf(System.currentTimeMillis());
    Object rt = null;
    try {
      rt = getCacheManager().getCache(cacheKey).get(key).getObjectValue();
      logHandle.logFlumeCacheSvc("QUERY@key=" + key, cacheKey, null, null, startTime);
    }
    catch (IllegalStateException e) {
      logHandle.logFlumeCacheSvcEx("QUERY@key=" + key, cacheKey, null, null, startTime, e);
      throw e;
    } catch (ClassCastException e) {
      logHandle.logFlumeCacheSvcEx("QUERY@key=" + key, cacheKey, null, null, startTime, e);
      throw e;
    }
    return rt;
  }

  public Object get(String cacheKey, String key, int dataType) {
    return get(cacheKey, key);
  }

  public String getLocations() {
    return this.locations;
  }

  public void setLocations(String locations) {
    this.locations = locations;
  }

  public CacheManager getCacheManager() {
    return this.cacheManager;
  }

  public void setCacheManager(CacheManager cacheManager) {
    this.cacheManager = cacheManager;
  }

  public Cache getCache() {
    return this.cache;
  }

  public void setCache(Cache cache) {
    this.cache = cache;
  }

  public String[] getCacheNames() {
    if ((this.cacheNames == null) && (this.cacheManager != null)) this.cacheNames = this.cacheManager.getCacheNames();
    return this.cacheNames;
  }

  public void setCacheNames(String[] cacheNames) {
    this.cacheNames = cacheNames;
  }

  public List<String> getKeys(String cacheKey)
  {
    return getCache(cacheKey).getKeys();
  }

  public Cache getCache(String cacheKey) {
    return this.cacheManager.getCache(cacheKey);
  }

  public List<Object> query(String cacheKey, String sqel) {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    Long startTime = Long.valueOf(System.currentTimeMillis());
    List queryList = Collections.EMPTY_LIST;
    try {
      Results results = queryResults(cacheKey, sqel);

      List resultList = results.all();
      queryList = new ArrayList();
      for (Iterator i$ = resultList.iterator(); i$.hasNext(); ) { Result result = (Result)i$.next();
        Object[] objValue = new String[2];

        if ((results.hasKeys()) && (results.hasValues())) {
          objValue[0] = result.getKey();
          objValue[1] = result.getValue();
        }
        queryList.add(objValue);
      }
      logHandle.logFlumeCacheSvc("QUERY_LIST@key=" + sqel, cacheKey, null, null, startTime);
    } catch (IllegalStateException e) {
      logHandle.logFlumeCacheSvcEx("QUERY_LIST@key=" + sqel, cacheKey, null, null, startTime, e);
      throw e;
    } catch (ClassCastException e) {
      logHandle.logFlumeCacheSvcEx("QUERY_LIST@key=" + sqel, cacheKey, null, null, startTime, e);
      throw e;
    }

    return queryList;
  }

  public int queryCount(String cacheKey, String sqel) throws BaseException {
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    Long startTime = Long.valueOf(System.currentTimeMillis());
    int size = 0;
    try {
      Results results = queryResults(cacheKey, sqel);
      size = results.size();
      logHandle.logFlumeCacheSvc("QUERY_SIZE@key=" + sqel, cacheKey, null, null, startTime);
    } catch (IllegalStateException e) {
      logHandle.logFlumeCacheSvcEx("QUERY_SIZE@key=" + sqel, cacheKey, null, null, startTime, e);
      throw e;
    } catch (ClassCastException e) {
      logHandle.logFlumeCacheSvcEx("QUERY_SIZE@key=" + sqel, cacheKey, null, null, startTime, e);
      throw e;
    }

    return size;
  }

  public List<Object> query(String cacheKey, String sqel, int page, int count) {
    if (page <= 0)
      page = 1;
    if (count <= 0)
      count = 10;

    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    Long startTime = Long.valueOf(System.currentTimeMillis());
    List queryList = Collections.EMPTY_LIST;
    try {
      Results results = queryResults(cacheKey, sqel);

      List resultList = results.range((page - 1) * count, count);
      queryList = new ArrayList();
      for (Iterator i$ = resultList.iterator(); i$.hasNext(); ) { Result result = (Result)i$.next();
        Object[] objValue = new String[2];

        if ((results.hasKeys()) && (results.hasValues())) {
          objValue[0] = result.getKey();
          objValue[1] = result.getValue();
        }
        queryList.add(objValue);
      }
      logHandle.logFlumeCacheSvc("QUERY_MULT_LIST@key=" + sqel, cacheKey, null, null, startTime);
    } catch (IllegalStateException e) {
      logHandle.logFlumeCacheSvcEx("QUERY_MULT_LIST@key=" + sqel, cacheKey, null, null, startTime, e);
      throw e;
    } catch (ClassCastException e) {
      logHandle.logFlumeCacheSvcEx("QUERY_MULT_LIST@key=" + sqel, cacheKey, null, null, startTime, e);
      throw e;
    }

    return queryList;
  }

  private Results queryResults(String cacheKey, String sqel)
  {
    Cache cache = getCache(cacheKey);
    Attribute name = cache.getSearchAttribute("key");
    Query query = cache.createQuery();
    query.includeKeys();
    query.includeValues();

    query.addCriteria(name.ilike(sqel));

    return query.execute();
  }

  public SystemConf getSystemConf() {
    return this.systemConf;
  }

  public void setSystemConf(SystemConf systemConf) {
    this.systemConf = systemConf;
  }

  public void put(String cacheKey, String key, Object value, long timeOut)
  {
    put(cacheKey, key, value);
  }

  public int removeAll(String cacheKey, String sqel)
  {
    return 0;
  }
}