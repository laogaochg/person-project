package com.ifp.cache.exception;

import com.ifp.core.exception.BaseException;

public class CacheException extends BaseException
{
  private static final long serialVersionUID = 1L;

  public CacheException()
  {
  }

  public CacheException(String errorMessage)
  {
    super(errorMessage);
  }

  public CacheException(String errorCode, String errorMessage)
  {
    super(errorCode, errorMessage);
  }

  public CacheException(String errorMessage, Throwable cause)
  {
    super(errorMessage, cause);
  }

  public CacheException(String errorCode, String errorMessage, Throwable cause)
  {
    super(errorCode, errorMessage, cause);
  }

  public CacheException(Throwable cause)
  {
    super(cause);
  }
}