package com.ifp.cache.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.util.DataMapChangeUtil;
import java.util.List;
import org.springframework.util.StringUtils;

public class GetFieldFromCacheAction extends AbstractCacheAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    String cacheName;
    try
    {
      cacheName = confMap.getElementValue("cacheName");
      if (!(StringUtils.hasText(cacheName)))
        throw new ActionException("缓存名为null");

      String cacheKey = confMap.getElementValue("cacheKey");

      if (!(StringUtils.hasText(cacheKey))) {
        throw new ActionException("缓存Key为null");
      }

      String fieldName = confMap.getElementValue("fieldName");

      if (!(StringUtils.hasText(fieldName))) {
        throw new ActionException("字段名为null");
      }

      String[] cacheKeys = cacheKey.split(getFieldSeperatorRegex());
      String[] fieldNames = fieldName.split(getFieldSeperatorRegex());
      DataMap dataMap = (DataMap)context.getDataMap();

      for (int i = 0; i < cacheKeys.length; ++i)
      {
        Object value;
        DataElement dataElement = dataMap.get(fieldNames[i]);
        String key = cacheKeys[i];
        if (key.startsWith("#"))
          key = dataMap.getElementValue(key.substring(1));

        if (dataElement instanceof DataField)
        {
          value = getValue(cacheName, key, 1);
          if (value instanceof String)
          {
            dataMap.setElementValue(fieldNames[i], (String)value);
          } else if (value instanceof DataElement)
          {
            dataMap.put(fieldNames[i], (DataElement)value);
          }
        } else if (dataElement instanceof DataList)
        {
          value = getValue(cacheName, key, 2);
          if (value instanceof DataElement)
          {
            dataMap.put(fieldNames[i], (DataElement)value);
          } else if (value instanceof List)
          {
            dataMap.put(fieldNames[i], DataMapChangeUtil.listToDataList((List)value, ((DataList)dataMap.get(fieldNames[i])).getDefineMap()));
          }

        }

      }

    }
    catch (Exception e)
    {
      throw new ActionException(e);
    }

    return 0;
  }
}