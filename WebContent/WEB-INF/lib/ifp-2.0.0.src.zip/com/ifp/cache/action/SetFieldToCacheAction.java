package com.ifp.cache.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataElement;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.util.DataMapChangeUtil;
import com.ifp.core.util.StringUtil;
import java.util.ArrayList;
import java.util.List;
import org.springframework.util.StringUtils;

public class SetFieldToCacheAction extends AbstractCacheAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    String cacheName;
    try
    {
      cacheName = confMap.getElementValue("cacheName");
      if (!(StringUtils.hasText(cacheName)))
        throw new ActionException("缓存名为null");

      String cacheKey = confMap.getElementValue("cacheKey");

      if (!(StringUtils.hasText(cacheKey))) {
        throw new ActionException("缓存Key为null");
      }

      String fieldName = confMap.getElementValue("fieldName");

      if (!(StringUtils.hasText(fieldName))) {
        throw new ActionException("字段名为null");
      }

      String timeOut = confMap.getElementValue("timeOut");

      if ((StringUtil.hasText(timeOut)) && (!(timeOut.matches("[0-9]+"))))
      {
        throw new ActionException("超时时间字段应为数字型");
      }

      String[] cacheKeys = cacheKey.split(getFieldSeperatorRegex());
      String[] fieldNames = fieldName.split(getFieldSeperatorRegex());
      DataMap dataMap = (DataMap)context.getDataMap();

      for (int i = 0; i < cacheKeys.length; ++i)
      {
        String key = cacheKeys[i];
        if (key.startsWith("#"))
          key = dataMap.getElementValue(key.substring(1));
        String fieldn = fieldNames[i];
        Object value = null;
        if (fieldn.startsWith("#"))
        {
          DataElement dataElement = dataMap.get(fieldn.substring(1));
          if (dataElement instanceof DataField)
          {
            value = ((DataField)dataElement).getValue();
          } else if (dataElement instanceof DataList)
          {
            DataList dataList = (DataList)dataElement;
            List list = new ArrayList();
            DataMapChangeUtil.dataListToList(dataList, list);
            value = list;
          }
        } else {
          value = fieldn;
        }
        saveValue(cacheName, key, value, timeOut);
      }

    }
    catch (Exception e)
    {
      throw new ActionException(e);
    }
    return 0;
  }
}