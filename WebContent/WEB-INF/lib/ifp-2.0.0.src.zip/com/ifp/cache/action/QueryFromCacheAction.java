package com.ifp.cache.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import org.springframework.util.StringUtils;

public class QueryFromCacheAction extends AbstractCacheAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try
    {
      String cacheName = confMap.getElementValue("cacheName");
      if (!(StringUtils.hasText(cacheName)))
        throw new ActionException("缓存名为null");

      String queryKey = confMap.getElementValue("queryKey");

      if (!(StringUtils.hasText(queryKey)))
        throw new ActionException("查询Key为null");

      String listName = confMap.getElementValue("listName");

      if (!(StringUtils.hasText(listName))) {
        throw new ActionException("集合名称为null");
      }

      String outputFields = confMap.getElementValue("outputFields");
      if (!(StringUtils.hasText(outputFields))) {
        throw new ActionException("输出字段为null");
      }

      String[] outputField = outputFields.split(getFieldSeperatorRegex());

      if (outputField.length != 2) throw new ActionException("输出字段配置有误，仅支持配置两个字段！");
      queryKey = replaceString(dataMap, queryKey, "");
      List queryList = query(cacheName, queryKey);
      sort(queryList);
      if ((queryList != null) && (queryList.size() > 0))
      {
        DataList dataList = (DataList)dataMap.get(listName);
        for (int i = 0; i < queryList.size(); ++i)
        {
          Object listValue = queryList.get(i);
          if (listValue instanceof String[])
          {
            String[] strValue = (String[])(String[])listValue;
            DataMap map = new DataMap();
            map.setDefineMap(dataList.getDefineMap());
            map.put(outputField[0], new DataField(outputField[0], strValue[0]));
            map.put(outputField[1], new DataField(outputField[1], strValue[1]));
            dataList.add(map);
          }
        }

        return queryList.size();
      }
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }

  protected String replaceString(DataMap dataMap, String sourceStr, String connector)
    throws ActionException
  {
    if (!(StringUtils.hasText(connector)))
      connector = "";
    else
      connector = connector.trim();

    if (!(StringUtils.hasText(sourceStr))) {
      return sourceStr;
    }

    List fieldList = getFieldList(sourceStr);
    try {
      sourceStr = sourceStr.replaceAll("\\s+", "").replaceAll("\\|\\|", connector);
      for (Iterator i$ = fieldList.iterator(); i$.hasNext(); ) { String field = (String)i$.next();
        field = field.trim();
        if ((field.startsWith("'")) && (field.endsWith("'")))
          sourceStr = sourceStr.replaceAll("\\s*" + field.trim() + "\\s*", dataMap.getElementValue(field.replaceAll("'", "")));
      }
    }
    catch (Exception e) {
      throw new ActionException(e);
    }
    return sourceStr;
  }

  protected void sort(List<Object> queryList)
  {
    if ((null != queryList) && (!(queryList.isEmpty())))
      Collections.sort(queryList, new Comparator(this)
      {
        public int compare(, Object o2) {
          if ((null != o1) && (null != o2) && (o1 instanceof String[]) && (o2 instanceof String[]))
            return ((String[])(String[])o1)[0].compareTo(((String[])(String[])o2)[0]);

          return 0;
        }
      });
  }
}