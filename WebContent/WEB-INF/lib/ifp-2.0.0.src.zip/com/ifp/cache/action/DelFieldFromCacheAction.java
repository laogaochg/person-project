package com.ifp.cache.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import org.springframework.util.StringUtils;

public class DelFieldFromCacheAction extends AbstractCacheAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    String cacheName;
    try
    {
      cacheName = confMap.getElementValue("cacheName");
      if (!(StringUtils.hasText(cacheName)))
        throw new ActionException("缓存名为null");

      String cacheKey = confMap.getElementValue("cacheKey");

      if (!(StringUtils.hasText(cacheKey))) {
        throw new ActionException("缓存Key为null");
      }

      String[] cacheKeys = cacheKey.split(getFieldSeperatorRegex());
      DataMap dataMap = (DataMap)context.getDataMap();
      for (int i = 0; i < cacheKeys.length; ++i)
      {
        if (cacheKeys[i].startsWith("#"))
          remove(cacheName, dataMap.getElementValue(cacheKeys[i].substring(1)));
        else {
          remove(cacheName, cacheKeys[i]);
        }

      }

    }
    catch (Exception e)
    {
      throw new ActionException(e);
    }

    return 0;
  }
}