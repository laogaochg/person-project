package com.ifp.cache.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import org.springframework.util.StringUtils;

public class ClearCacheAction extends AbstractCacheAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    String cacheName;
    try
    {
      cacheName = confMap.getElementValue("cacheName");

      if (!(StringUtils.hasText(cacheName))) {
        throw new ActionException("缓存名为null");
      }

      removeAll(cacheName);
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}