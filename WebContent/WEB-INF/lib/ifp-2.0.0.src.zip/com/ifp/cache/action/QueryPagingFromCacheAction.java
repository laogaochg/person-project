package com.ifp.cache.action;

import com.ifp.core.context.BlogicContext;
import com.ifp.core.data.DataField;
import com.ifp.core.data.DataList;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.ActionException;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.RecordOutOfRangeException;
import java.util.List;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.util.StringUtils;

public class QueryPagingFromCacheAction extends QueryFromCacheAction
{
  public int execute(BlogicContext context, DataMap confMap)
    throws BaseException
  {
    DataMap dataMap = (DataMap)context.getDataMap();
    try
    {
      String cacheName = confMap.getElementValue("cacheName");
      if (!(StringUtils.hasText(cacheName))) {
        throw new ActionException("缓存名为null");
      }

      String queryKey = confMap.getElementValue("queryKey");
      if (!(StringUtils.hasText(queryKey))) {
        throw new ActionException("查询Key为null");
      }

      String listName = confMap.getElementValue("listName");
      if (!(StringUtils.hasText(listName))) {
        throw new ActionException("集合名称为null");
      }

      String outputFields = confMap.getElementValue("outputFields");
      if (!(StringUtils.hasText(outputFields))) {
        throw new ActionException("输出字段为null");
      }

      String pageNo = confMap.getElementValue("pageNo");
      String pageSize = confMap.getElementValue("pageSize");
      String totalSize = confMap.getElementValue("totalSize");

      String[] outputField = outputFields.split(getFieldSeperatorRegex());

      if (outputField.length != 2) throw new ActionException("输出字段配置有误，仅支持配置两个字段！");
      queryKey = replaceString(dataMap, queryKey, "");

      int pNo = NumberUtils.toInt(dataMap.getElementValue(pageNo));
      int pSize = NumberUtils.toInt(dataMap.getElementValue(pageSize));
      int startIndex = (pNo - 1) * pSize + 1;
      int tSize = queryCount(cacheName, queryKey);
      if (tSize > 0)
      {
        if (startIndex > tSize) {
          throw new RecordOutOfRangeException("there had no cache record for page:" + pNo + "[startIndex:" + startIndex + ", totalSize:" + tSize + "]");
        }

        dataMap.setElementValue(totalSize, String.valueOf(tSize));
        List queryList = query(cacheName, queryKey, pNo, pSize);
        sort(queryList);
        if ((queryList != null) && (queryList.size() > 0))
        {
          DataList dataList = (DataList)dataMap.get(listName);
          for (int i = 0; i < queryList.size(); ++i)
          {
            Object listValue = queryList.get(i);
            if (listValue instanceof String[])
            {
              String[] strValue = (String[])(String[])listValue;
              DataMap map = new DataMap();
              map.setDefineMap(dataList.getDefineMap());
              map.put(outputField[0], new DataField(outputField[0], strValue[0]));
              map.put(outputField[1], new DataField(outputField[1], strValue[1]));
              dataList.add(map);
            }
          }

          return queryList.size();
        }
      }
    } catch (Exception e) {
      throw new ActionException(e);
    }

    return 0;
  }
}