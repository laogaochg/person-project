package com.ifp.cache.action;

import com.ifp.cache.handle.CacheHandler;
import com.ifp.core.flow.action.AbstractAction;
import com.ifp.core.util.StringUtil;
import java.util.List;

public abstract class AbstractCacheAction extends AbstractAction
{
  public CacheHandler cacheHandler;

  public CacheHandler getCacheHandler()
  {
    return this.cacheHandler;
  }

  public void setCacheHandler(CacheHandler cacheHandler) {
    this.cacheHandler = cacheHandler;
  }

  public void saveValue(String cacheKey, String key, Object value, String timeOut)
  {
    if (StringUtil.hasText(timeOut))
      this.cacheHandler.put(cacheKey, key, value, Long.parseLong(timeOut));
    else
      this.cacheHandler.put(cacheKey, key, value);
  }

  public Object getValue(String cacheKey, String key, int dataType)
  {
    return this.cacheHandler.get(cacheKey, key, dataType);
  }

  public List<Object> query(String cacheName, String sqel)
  {
    return this.cacheHandler.query(cacheName, sqel);
  }

  public List<Object> query(String cacheName, String sqel, int page, int count)
  {
    return this.cacheHandler.query(cacheName, sqel, page, count);
  }

  public int queryCount(String cacheName, String sqel)
  {
    return this.cacheHandler.queryCount(cacheName, sqel);
  }

  public void removeAll(String cacheKey)
  {
    this.cacheHandler.removeAll(cacheKey);
  }

  public void remove(String cacheKey, String key)
  {
    this.cacheHandler.remove(cacheKey, key);
  }
}