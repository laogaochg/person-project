package com.ifp.cache.bean;

public abstract class AbstractCache
  implements ICache
{
  public String id;
  public String type;
  public long intervalTime;
  public int maxIdleConn;
  public int minIdleConn;
  public int maxConn;
  public long maxWait;
  public boolean open;

  public String getId()
  {
    return this.id; }

  public void setId(String id) {
    this.id = id; }

  public String getType() {
    return this.type; }

  public void setType(String type) {
    this.type = type; }

  public long getIntervalTime() {
    return this.intervalTime; }

  public void setIntervalTime(long intervalTime) {
    this.intervalTime = intervalTime; }

  public int getMaxIdleConn() {
    return this.maxIdleConn; }

  public void setMaxIdleConn(int maxIdleConn) {
    this.maxIdleConn = maxIdleConn; }

  public int getMinIdleConn() {
    return this.minIdleConn; }

  public void setMinIdleConn(int minIdleConn) {
    this.minIdleConn = minIdleConn; }

  public int getMaxConn() {
    return this.maxConn;
  }

  public long getMaxWait() {
    return this.maxWait; }

  public void setMaxWait(long maxWait) {
    this.maxWait = maxWait; }

  public void setMaxConn(int maxConn) {
    this.maxConn = maxConn; }

  public void setMaxWait(int maxWait) {
    this.maxWait = maxWait; }

  public boolean isOpen() {
    return this.open; }

  public void setOpen(boolean open) {
    this.open = open;
  }
}