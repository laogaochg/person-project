package com.ifp.cache.bean;

public abstract interface ICache
{
  public abstract String getId();

  public abstract void setId(String paramString);

  public abstract String getType();

  public abstract void setType(String paramString);

  public abstract long getIntervalTime();

  public abstract void setIntervalTime(long paramLong);

  public abstract int getMaxIdleConn();

  public abstract void setMaxIdleConn(int paramInt);

  public abstract boolean isOpen();

  public abstract void setOpen(boolean paramBoolean);

  public abstract int getMinIdleConn();

  public abstract void setMinIdleConn(int paramInt);

  public abstract int getMaxConn();

  public abstract void setMaxConn(int paramInt);

  public abstract long getMaxWait();

  public abstract void setMaxWait(long paramLong);
}