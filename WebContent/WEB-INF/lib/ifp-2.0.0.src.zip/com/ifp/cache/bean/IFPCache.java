package com.ifp.cache.bean;

public class IFPCache extends AbstractCache
{
  public CacheServices servers;

  public IFPCache()
  {
    this.servers = new CacheServices(); }

  public CacheServices getServers() {
    return this.servers;
  }

  public void setServers(CacheServices servers) {
    this.servers = servers;
  }
}