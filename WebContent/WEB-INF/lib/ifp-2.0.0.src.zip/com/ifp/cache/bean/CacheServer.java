package com.ifp.cache.bean;

public class CacheServer
{
  public String masterHost;
  public int masterPost;
  public String masterPassword;
  public String bakHost;
  public int bakPort;
  public String bakPassword;
  public String sentinelHost;
  public int sentinelPost;
  public String sentinelPassword;
  public String masterName;
  public int weight;
  public int timeout;
  public int databases;

  public String getMasterHost()
  {
    return this.masterHost; }

  public void setMasterHost(String masterHost) {
    this.masterHost = masterHost; }

  public int getMasterPost() {
    return this.masterPost; }

  public void setMasterPost(int masterPost) {
    this.masterPost = masterPost; }

  public String getMasterPassword() {
    return this.masterPassword; }

  public void setMasterPassword(String masterPassword) {
    this.masterPassword = masterPassword; }

  public String getBakHost() {
    return this.bakHost; }

  public void setBakHost(String bakHost) {
    this.bakHost = bakHost; }

  public int getBakPort() {
    return this.bakPort; }

  public void setBakPort(int bakPort) {
    this.bakPort = bakPort; }

  public String getBakPassword() {
    return this.bakPassword; }

  public void setBakPassword(String bakPassword) {
    this.bakPassword = bakPassword; }

  public int getWeight() {
    return this.weight; }

  public void setWeight(int weight) {
    this.weight = weight; }

  public int getTimeout() {
    return this.timeout; }

  public void setTimeout(int timeout) {
    this.timeout = timeout; }

  public int getDatabases() {
    return this.databases; }

  public void setDatabases(int databases) {
    this.databases = databases; }

  public String getSentinelHost() {
    return this.sentinelHost; }

  public void setSentinelHost(String sentinelHost) {
    this.sentinelHost = sentinelHost; }

  public int getSentinelPost() {
    return this.sentinelPost; }

  public void setSentinelPost(int sentinelPost) {
    this.sentinelPost = sentinelPost; }

  public String getSentinelPassword() {
    return this.sentinelPassword; }

  public void setSentinelPassword(String sentinelPassword) {
    this.sentinelPassword = sentinelPassword; }

  public String getMasterName() {
    return this.masterName; }

  public void setMasterName(String masterName) {
    this.masterName = masterName;
  }
}