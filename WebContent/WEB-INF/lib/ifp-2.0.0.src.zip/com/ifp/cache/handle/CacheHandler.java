package com.ifp.cache.handle;

import com.ifp.core.cache.CacheManager;
import com.ifp.core.log.Trace;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CacheHandler
  implements CacheManager
{
  private Map<String, CacheManager> cacheMap;
  private String[] cacheNames;

  public CacheHandler()
  {
    this.cacheMap = new HashMap();
  }

  public Object get(String cacheName, String key)
  {
    try {
      return ((CacheManager)this.cacheMap.get(cacheName)).get(cacheName, key);
    } catch (Exception e) {
      Trace.log("CACHE", 2, "get Value from Cahce Error:", e); }
    return null;
  }

  public void put(String cacheName, String key, Object value)
  {
    try {
      ((CacheManager)this.cacheMap.get(cacheName)).put(cacheName, key, value);
    } catch (Exception e) {
      Trace.log("CACHE", 2, "put Value to Cahce Error:", e);
    }
  }

  public void remove(String cacheName, String key) {
    try {
      ((CacheManager)this.cacheMap.get(cacheName)).remove(cacheName, key);
    } catch (Exception e) {
      Trace.log("CACHE", 2, "remove from Cahce Error:", e);
    }
  }

  public void removeAll(String cacheName) {
    try {
      ((CacheManager)this.cacheMap.get(cacheName)).removeAll(cacheName);
    } catch (Exception e) {
      Trace.log("CACHE", 2, "removeAll from Cahce Error:", e);
    }
  }

  public String[] getCacheNames() {
    if (null == this.cacheNames)
    {
      this.cacheNames = new String[this.cacheMap.size()];
      int i = 0;
      for (Iterator i$ = this.cacheMap.keySet().iterator(); i$.hasNext(); ) { String cacheName = (String)i$.next();

        this.cacheNames[i] = cacheName;
        ++i;
      }
    }

    return this.cacheNames;
  }

  public Map<String, CacheManager> getCacheMap() {
    return this.cacheMap;
  }

  public void setCacheMap(Map<String, CacheManager> cacheMap) {
    this.cacheMap = cacheMap;
  }

  public List<Object> query(String cacheName, String sqel) {
    try {
      return ((CacheManager)this.cacheMap.get(cacheName)).query(cacheName, sqel);
    } catch (Exception e) {
      Trace.log("CACHE", 2, "query from Cahce Error:", e); }
    return null;
  }

  public List<Object> query(String cacheName, String sqel, int page, int count)
  {
    try {
      return ((CacheManager)this.cacheMap.get(cacheName)).query(cacheName, sqel, page, count);
    } catch (Exception e) {
      Trace.log("CACHE", 2, "query from Cahce Error:", e); }
    return null;
  }

  public int queryCount(String cacheName, String sqel)
  {
    try {
      return ((CacheManager)this.cacheMap.get(cacheName)).queryCount(cacheName, sqel);
    } catch (Exception e) {
      Trace.log("CACHE", 2, "query from Cahce Error:", e); }
    return 0;
  }

  public List<String> getKeys(String cacheName)
  {
    return ((CacheManager)this.cacheMap.get(cacheName)).getKeys(cacheName);
  }

  public Object getCache(String cacheName) {
    return ((CacheManager)this.cacheMap.get(cacheName)).getCache(cacheName); }

  public int removeAll(String cacheName, String sqel) {
    List queryList;
    try {
      queryList = query(cacheName, sqel);
      int count = 0;
      for (Iterator i$ = queryList.iterator(); i$.hasNext(); ) { Object queryCache = i$.next();
        remove(cacheName, ((Object[])(Object[])queryCache)[0].toString());
        ++count;
      }
      return count;
    }
    catch (Exception e) {
      Trace.log("CACHE", 2, "removeAll from Cahce Error:", e); }
    return 0;
  }

  public Object get(String cacheName, String key, int valueType)
  {
    try {
      return ((CacheManager)this.cacheMap.get(cacheName)).get(cacheName, key, valueType);
    } catch (Exception e) {
      Trace.log("CACHE", 2, "get Value from Cahce Error:", e); }
    return null;
  }

  public void put(String cacheName, String key, Object value, long timeOut)
  {
    try {
      ((CacheManager)this.cacheMap.get(cacheName)).put(cacheName, key, value, timeOut);
    } catch (Exception e) {
      Trace.log("CACHE", 2, "save Value to Cahce Error:", e);
    }
  }
}