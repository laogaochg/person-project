package com.ifp.rpc;

import com.ifp.core.base.SystemConf;
import com.ifp.core.context.BlogicContext;
import com.ifp.core.context.ClogicContext;
import com.ifp.core.data.DataMap;
import com.ifp.core.exception.BaseException;
import com.ifp.core.exception.DataChangeException;
import com.ifp.core.exception.FlowException;
import com.ifp.core.flow.service.FlowService;
import com.ifp.core.flow.util.ContextMapChangeUtil;
import com.ifp.core.flow.util.FieldMapping4IFPUtil;
import com.ifp.core.flow.util.FieldMappingUtil;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.RemoteCallInfo;
import com.ifp.core.log.Trace;
import com.ifp.core.monitor.Monitor;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.IpUtils;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.rpc.service.ControlService;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import org.springframework.util.StringUtils;

public class RPCHandle
{
  private LogHandle logHandle;
  private MonitorManager monitorManager;

  public void executeRemoteServiceForCL(ClogicContext clogicContext, String logicId)
    throws BaseException
  {
    long startTime = System.currentTimeMillis();
    Object service = SpringContextsUtil.getRemoteBean(logicId);
    if (null != service) {
      RemoteCallInfo rc;
      String cid;
      Map sendContextMap;
      Map returnContextMap;
      long endTime;
      BaseException ex;
      if (service instanceof ControlService) {
        Trace.log("RPC", 1, ">> exec remote cl: {}", new Object[] { logicId });
        ControlService ControlService = (ControlService)service;

        rc = new RemoteCallInfo(this.monitorManager.getMonitor(clogicContext.getMonitorId()).getCurrentMonitorStep(), logicId, "RPCCLIENT", null);
        this.logHandle.logFlumeRemote(rc);
        cid = IpUtils.getHostAddress() + this.logHandle.getAppName() + String.valueOf(System.currentTimeMillis()) + StringUtil.generateRandomString(7);

        sendContextMap = new HashMap();

        sendContextMap.put("dataMap", clogicContext.getDataMap());
        this.logHandle.getFlumeLogInfToMap(sendContextMap);
        if (this.logHandle.isPrintRPCSvcInfo())
          sendContextMap.put("pcid", cid);

        try
        {
          Trace.log("RPC", 0, ">> exec remote cl, params: {}", new Object[] { sendContextMap });
          returnContextMap = ControlService.execute(sendContextMap);

          if (null == returnContextMap) {
            Trace.log("RPC", 0, "<< exec ajax remote cl");
          } else {
            Trace.log("RPC", 0, "<< exec remote cl, params: {}", new Object[] { returnContextMap });

            ContextMapChangeUtil.copyDataMap((Map)returnContextMap.get("dataMap"), (Map)clogicContext.getDataMap());
          }

          this.logHandle.logFlumeRPCService("RPCAction@svcId=" + logicId, null, null, null, Long.valueOf(startTime), cid);
        }
        catch (BaseException e)
        {
        }
        catch (Exception e)
        {
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          rc.setType("RPCSERVER");
          rc.setMarkTime(Long.valueOf(endTime));
          this.logHandle.logFlumeRemote(rc);
          Trace.log("RPC", 1, "<< exec remote cl: {}, time:{}ms", new Object[] { logicId, Long.valueOf(endTime - startTime) });
        }
      } else {
        Trace.log("RPC", 1, ">> exec remote bl: {}", new Object[] { logicId });
        FlowService flowService = (FlowService)service;

        rc = new RemoteCallInfo(this.monitorManager.getMonitor(clogicContext.getMonitorId()).getCurrentMonitorStep(), logicId, "RPCCLIENT", null);
        this.logHandle.logFlumeRemote(rc);
        cid = IpUtils.getHostAddress() + this.logHandle.getAppName() + String.valueOf(System.currentTimeMillis()) + StringUtil.generateRandomString(7);

        sendContextMap = new HashMap();

        sendContextMap.put("dataMap", clogicContext.getDataMap());
        this.logHandle.getFlumeLogInfToMap(sendContextMap);
        if (this.logHandle.isPrintRPCSvcInfo())
          sendContextMap.put("pcid", cid);

        try
        {
          Trace.log("RPC", 0, ">> exec remote bl, params: {}", new Object[] { sendContextMap });
          e = flowService.execute(sendContextMap);

          if (null == e) {
            Trace.log("RPC", 0, "<< exec ajax remote bl");
          } else {
            Trace.log("RPC", 0, "<< exec remote bl, params: {}", new Object[] { e });

            ContextMapChangeUtil.copyDataMap((Map)e.get("dataMap"), (Map)clogicContext.getDataMap());
          }

          this.logHandle.logFlumeRPCService("RPCAction@svcId=" + logicId, null, null, null, Long.valueOf(startTime), cid);
        }
        catch (BaseException e)
        {
        }
        catch (Exception e)
        {
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          rc.setType("RPCSERVER");
          rc.setMarkTime(Long.valueOf(endTime));
          this.logHandle.logFlumeRemote(rc);
          Trace.log("RPC", 1, "<< exec remote bl: {}, time:{}ms", new Object[] { logicId, Long.valueOf(endTime - startTime) });
        }
      }
    } else {
      throw new BaseException("SCEC0001", "get logic service failed: " + logicId);
    }
  }

  public void executeRemoteServiceForCL(Map<String, Object> inDataMap, Map<String, Object> outDataMap, String logicId, String monitorId)
    throws BaseException
  {
    long startTime = System.currentTimeMillis();
    Object service = SpringContextsUtil.getRemoteBean(logicId);
    if (null != service) {
      RemoteCallInfo rc;
      String cid;
      Map sendContextMap;
      Map returnContextMap;
      long endTime;
      BaseException ex;
      if (service instanceof ControlService) {
        Trace.log("RPC", 1, ">> exec remote cl: {}", new Object[] { logicId });
        ControlService ControlService = (ControlService)service;

        rc = new RemoteCallInfo(this.monitorManager.getMonitor(monitorId).getCurrentMonitorStep(), logicId, "RPCCLIENT", null);
        this.logHandle.logFlumeRemote(rc);
        cid = IpUtils.getHostAddress() + this.logHandle.getAppName() + String.valueOf(System.currentTimeMillis()) + StringUtil.generateRandomString(7);

        sendContextMap = new HashMap();

        sendContextMap.put("dataMap", inDataMap);
        this.logHandle.getFlumeLogInfToMap(sendContextMap);
        if (this.logHandle.isPrintRPCSvcInfo())
          sendContextMap.put("pcid", cid);
        try
        {
          Trace.log("RPC", 0, ">> exec remote cl, params: {}", new Object[] { sendContextMap });
          returnContextMap = ControlService.execute(sendContextMap);

          if (null == returnContextMap) {
            Trace.log("RPC", 0, "<< exec ajax remote cl");
          } else {
            Trace.log("RPC", 0, "<< exec remote cl, params: {}", new Object[] { returnContextMap });

            ContextMapChangeUtil.copyDataMap((Map)returnContextMap.get("dataMap"), outDataMap);
          }

          this.logHandle.logFlumeRPCService("RPCAction@svcId=" + logicId, null, null, null, Long.valueOf(startTime), cid);
        }
        catch (BaseException e)
        {
        }
        catch (Exception e)
        {
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          rc.setType("RPCSERVER");
          rc.setMarkTime(Long.valueOf(endTime));
          this.logHandle.logFlumeRemote(rc);
          Trace.log("RPC", 1, "<< exec remote cl: {}, time:{}ms", new Object[] { logicId, Long.valueOf(endTime - startTime) });
        }
      } else {
        Trace.log("RPC", 1, ">> exec remote bl: {}", new Object[] { logicId });
        FlowService flowService = (FlowService)service;

        rc = new RemoteCallInfo(this.monitorManager.getMonitor(monitorId).getCurrentMonitorStep(), logicId, "RPCCLIENT", null);
        this.logHandle.logFlumeRemote(rc);
        cid = IpUtils.getHostAddress() + this.logHandle.getAppName() + String.valueOf(System.currentTimeMillis()) + StringUtil.generateRandomString(7);

        sendContextMap = new HashMap();

        sendContextMap.put("dataMap", inDataMap);
        this.logHandle.getFlumeLogInfToMap(sendContextMap);
        if (this.logHandle.isPrintRPCSvcInfo())
          sendContextMap.put("pcid", cid);
        try
        {
          Trace.log("RPC", 0, ">> exec remote bl, params: {}", new Object[] { sendContextMap });
          e = flowService.execute(sendContextMap);

          if (null == e) {
            Trace.log("RPC", 0, "<< exec ajax remote bl");
          } else {
            Trace.log("RPC", 0, "<< exec remote bl, params: {}", new Object[] { e });

            ContextMapChangeUtil.copyDataMap((Map)e.get("dataMap"), outDataMap);
          }

          this.logHandle.logFlumeRPCService("RPCAction@svcId=" + logicId, null, null, null, Long.valueOf(startTime), cid);
        }
        catch (BaseException e)
        {
        }
        catch (Exception e)
        {
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          rc.setType("RPCSERVER");
          rc.setMarkTime(Long.valueOf(endTime));
          this.logHandle.logFlumeRemote(rc);
          Trace.log("RPC", 1, "<< exec remote bl: {}, time:{}ms", new Object[] { logicId, Long.valueOf(endTime - startTime) });
        }
      }
    } else {
      throw new BaseException("SCEC0001", "get logic service failed: " + logicId);
    }
  }

  public void executeRemoteServiceForBL(BlogicContext blogicContext, String logicId, String methodName, String mappingId)
    throws BaseException
  {
    Object service = null;
    SystemConf systemConf = (SystemConf)SpringContextsUtil.getBean("systemConf");
    DataMap dataMap = (DataMap)blogicContext.getDataMap();
    boolean isMock = systemConf.isServiceMock(logicId);
    if (isMock)
    {
      try
      {
        Map mockMap = (Map)SpringContextsUtil.getBean(logicId + "_" + methodName + "_" + mappingId);
        Trace.logWarn("RPC", "这里是个挡板调用, consumerId:{}, data: {}", new Object[] { logicId, mockMap });
        if (StringUtils.hasText(mappingId))
          FieldMappingUtil.unformat(mappingId, dataMap, mockMap);
        else
          ContextMapChangeUtil.copyDataMap(mockMap, dataMap);
      }
      catch (Exception e) {
        Trace.logWarn("RPC", "挡板未设置，或者挡板调用后，字段映射失败, consumerId:{}, exception: {}", new Object[] { logicId, e }); }
    }
    else if (null != (service = SpringContextsUtil.getRemoteBean(logicId)))
      if (service instanceof ControlService) {
        Trace.log("RPC", 1, ">> exec remote cl: {}", new Object[] { logicId });
        ControlService ControlService = (ControlService)service;

        RemoteCallInfo rc = new RemoteCallInfo(this.monitorManager.getMonitor(blogicContext.getMonitorId()).getCurrentMonitorStep(), logicId, "RPCCLIENT", null);
        this.logHandle.logFlumeRemote(rc);
        String cid = IpUtils.getHostAddress() + this.logHandle.getAppName() + String.valueOf(System.currentTimeMillis()) + StringUtil.generateRandomString(7);

        Map sendContextMap = new HashMap();

        Map sendDataMap = ContextMapChangeUtil.dataMap2Map(dataMap);
        sendContextMap.put("dataMap", sendDataMap);
        this.logHandle.getFlumeLogInfToMap(sendContextMap);
        if (this.logHandle.isPrintRPCSvcInfo())
          sendContextMap.put("pcid", cid);

        Map returnContextMap = null;
        long startTime = System.currentTimeMillis();
        try {
          Trace.log("RPC", 0, ">> exec remote cl, params: {}", new Object[] { sendContextMap });
          returnContextMap = ControlService.execute(sendContextMap);

          if (null == returnContextMap) {
            Trace.log("RPC", 0, "<< exec ajax remote cl");
          } else {
            Trace.log("RPC", 0, "<< exec remote cl, params: {}", new Object[] { returnContextMap });

            ContextMapChangeUtil.copyDataMap((Map)returnContextMap.get("dataMap"), dataMap);
          }

          this.logHandle.logFlumeRPCService("RPCAction@svcId=" + logicId, null, null, null, Long.valueOf(startTime), cid);
        }
        catch (BaseException e)
        {
        }
        catch (Exception e)
        {
        }
        finally
        {
          long endTime;
          BaseException ex;
          long endTime = System.currentTimeMillis();
          rc.setType("RPCSERVER");
          rc.setMarkTime(Long.valueOf(endTime));
          this.logHandle.logFlumeRemote(rc);
          Trace.log("RPC", 1, "<< exec remote cl: {}, time:{}ms", new Object[] { logicId, Long.valueOf(endTime - startTime) });
        }
      } else if (service instanceof FlowService)
      {
        executeFlowService(blogicContext, service, logicId, mappingId);
      }
      else {
        executeOtherService(blogicContext, service, logicId, methodName, mappingId);
      }
    else
      throw new BaseException("SCEC0001", "get logic service failed: " + logicId);
  }

  protected void executeFlowService(BlogicContext blogicContext, Object service, String logicId, String mappingId)
    throws DataChangeException, FlowException
  {
    long startTime = System.currentTimeMillis();
    Trace.log("RPC", 1, ">> exec remote bl: {}", new Object[] { logicId });
    FlowService flowService = (FlowService)service;

    RemoteCallInfo rc = null;
    String cid = null;
    if ((StringUtils.hasText(blogicContext.getMonitorId())) && (null != this.monitorManager.getMonitor(blogicContext.getMonitorId()))) {
      rc = new RemoteCallInfo(this.monitorManager.getMonitor(blogicContext.getMonitorId()).getCurrentMonitorStep(), logicId, "RPCCLIENT", null);
      this.logHandle.logFlumeRemote(rc);
      cid = IpUtils.getHostAddress() + this.logHandle.getAppName() + String.valueOf(System.currentTimeMillis()) + StringUtil.generateRandomString(7);
    }

    DataMap dataMap = (DataMap)blogicContext.getDataMap();

    this.logHandle.getFlumeLogInfToDataMap(dataMap);
    if (this.logHandle.isPrintRPCSvcInfo()) {
      dataMap.put("pcid", cid);
    }

    if (StringUtils.hasText(mappingId)) {
      BlogicContext rpcBlogicContext = new BlogicContext();
      DataMap rpcDataMap = new DataMap();
      try
      {
        rpcBlogicContext.setMonitorId(blogicContext.getMonitorId());
        rpcBlogicContext.setLogicPath(blogicContext.getLogicPath());
        FieldMapping4IFPUtil.format(mappingId, dataMap, rpcDataMap);
      }
      catch (Exception e) {
        Trace.logWarn("ACTION", "rpc前参数转换出错, {}", e);
        throw new DataChangeException(e);
      }

      try
      {
        rpcDataMap.put("flumeReqIp", dataMap.getElementValue("flumeReqIp"));
        rpcDataMap.put("reqId", dataMap.getElementValue("reqId"));
        rpcDataMap.put("pcid", dataMap.getElementValue("pcid"));
      } catch (Exception e) {
        Trace.logDebug("DATA", "dataMap has no flume's params, but ignore it.");
      }

      rpcBlogicContext.setDataMap(rpcDataMap);
      blogicContext = rpcBlogicContext;
    }

    try
    {
      Trace.log("RPC", 0, ">> exec remote bl, params: {}", new Object[] { blogicContext.getDataMap() });
      BlogicContext returnBlogicContext = flowService.execute(blogicContext);

      if (null == returnBlogicContext) {
        Trace.log("RPC", 0, "<< exec ajax remote bl");
      } else {
        DataMap returnDataMap = (DataMap)returnBlogicContext.getDataMap();
        Trace.log("RPC", 0, "<< exec remote bl, params: {}", new Object[] { returnDataMap });

        if (StringUtils.hasText(mappingId)) {
          FieldMapping4IFPUtil.unformat(mappingId, dataMap, returnDataMap);
        }
        else
          ContextMapChangeUtil.copyDataMap(returnDataMap, dataMap);

      }

      this.logHandle.logFlumeRPCService("RPCAction@svcId=" + logicId, null, null, null, Long.valueOf(startTime), cid);
    }
    catch (BaseException e)
    {
    }
    catch (Exception e)
    {
    }
    finally
    {
      BaseException ex;
      Trace.log("RPC", 1, "<< exec remote bl: {}, time:{}ms", new Object[] { logicId, Long.valueOf(System.currentTimeMillis() - startTime) });
    }
  }

  protected void executeOtherService(BlogicContext blogicContext, Object service, String logicId, String methodName, String mappingId)
    throws BaseException, FlowException
  {
    long startTime = System.currentTimeMillis();
    Trace.log("RPC", 1, ">> exec remote service: serviceId{}", new Object[] { logicId });
    if (!(StringUtils.hasText(mappingId))) {
      throw new BaseException("mappingId can not be null.");
    }

    RemoteCallInfo rc = null;
    String cid = null;
    if ((StringUtils.hasText(blogicContext.getMonitorId())) && (null != this.monitorManager.getMonitor(blogicContext.getMonitorId()))) {
      rc = new RemoteCallInfo(this.monitorManager.getMonitor(blogicContext.getMonitorId()).getCurrentMonitorStep(), logicId, "RPCCLIENT", null);
      this.logHandle.logFlumeRemote(rc);
      cid = IpUtils.getHostAddress() + this.logHandle.getAppName() + String.valueOf(System.currentTimeMillis()) + StringUtil.generateRandomString(7);
    }

    DataMap dataMap = (DataMap)blogicContext.getDataMap();
    Map sendDataMap = new HashMap();
    try {
      FieldMappingUtil.format(mappingId, dataMap, sendDataMap);
    } catch (Exception e1) {
      throw new BaseException("调其它系统的服务时，入参转换出错", e1);
    }
    Map returnContextMap = null;
    try {
      Trace.logDebug("RPC", ">> exec remote {} method of service, params: {}", new Object[] { methodName, sendDataMap });

      if (!(StringUtils.hasText(methodName))) {
        methodName = "execute";
      }

      Method executeMethod = service.getClass().getMethod(methodName, new Class[] { Map.class });
      returnContextMap = (Map)executeMethod.invoke(service, new Object[] { sendDataMap });

      if (null == returnContextMap) {
        Trace.log("RPC", 0, "<< exec ajax remote service");
      } else {
        Trace.log("RPC", 0, "<< exec remote service, params: {}", new Object[] { returnContextMap });

        FieldMappingUtil.unformat(mappingId, dataMap, returnContextMap);
      }

      this.logHandle.logFlumeRPCService("RPCAction@svcId=" + logicId, null, null, null, Long.valueOf(startTime), cid);
    }
    catch (BaseException e)
    {
    }
    catch (Exception e)
    {
    }
    finally
    {
      BaseException ex;
      Trace.log("RPC", 1, "<< exec remote bl: {}, time:{}ms", new Object[] { logicId, Long.valueOf(System.currentTimeMillis() - startTime) });
    }
  }

  public LogHandle getLogHandle()
  {
    return this.logHandle;
  }

  public void setLogHandle(LogHandle logHandle) {
    this.logHandle = logHandle;
  }

  public MonitorManager getMonitorManager() {
    return this.monitorManager;
  }

  public void setMonitorManager(MonitorManager monitorManager) {
    this.monitorManager = monitorManager;
  }
}