package com.ifp.rpc.service.impl;

import com.ifp.core.context.ClogicContext;
import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.util.ContextMapChangeUtil;
import com.ifp.core.log.FlumeLogInf;
import com.ifp.core.log.LogHandle;
import com.ifp.core.log.LogThread;
import com.ifp.core.log.RemoteCallInfo;
import com.ifp.core.log.Trace;
import com.ifp.core.monitor.Monitor;
import com.ifp.core.monitor.MonitorManager;
import com.ifp.core.util.DateUtil;
import com.ifp.core.util.IpUtils;
import com.ifp.core.util.SpringContextsUtil;
import com.ifp.core.util.StringUtil;
import com.ifp.rpc.service.ControlService;
import com.ifp.web.controller.ControllerHandle;
import com.ifp.web.controller.IController;
import com.ifp.web.controller.IMvcController;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControlServiceImpl
  implements ControlService
{
  private transient ControllerHandle controllerHandle;
  private transient IController controller;
  private transient String actionId;
  private transient MonitorManager monitorManager;

  public Map<String, Object> execute(Map<String, Object> dataMap)
    throws BaseException
  {
    long startTime = System.currentTimeMillis();
    Trace.log("RPC", 1, "start CL flow service, params：{}", new Object[] { dataMap });
    IMvcController mvcController = this.controller.getMvcController();
    LogHandle logHandle = (LogHandle)SpringContextsUtil.getBean("logHandle");
    LogThread logThread = logHandle.getLogThread();

    String flumeReqIp = (String)dataMap.get("flumeReqIp");
    String flumeReqId = (String)dataMap.get("reqId");
    String flumePid = (String)dataMap.get("pcid");
    String flumeCid = (String)dataMap.get("cid");
    if (!(StringUtil.hasText(flumeCid)))
      flumeCid = IpUtils.getHostAddress() + logHandle.getAppName() + String.valueOf(System.currentTimeMillis()) + StringUtil.generateRandomString(7);

    String flumeSessionId = "";
    String flumeServiceId = mvcController.getId();
    ClogicContext clogicContext = new ClogicContext();
    List interceptorList = new ArrayList();
    Monitor monitor = new Monitor();
    monitor.setLogicCode(flumeServiceId);
    monitor.setMonitorId(flumeCid);
    if (null == this.monitorManager)
      this.monitorManager = ((MonitorManager)SpringContextsUtil.getBean("monitorManager"));

    this.monitorManager.put(monitor);
    logHandle.setFlumeLogInf(flumeSessionId, flumeServiceId, flumeReqId, flumeCid, flumePid, flumeReqIp, Long.valueOf(startTime));
    logHandle.getFlumeLogInf().setType("DUBBO");
    RemoteCallInfo rc = new RemoteCallInfo(flumeReqId, flumeCid, flumePid, "RPCSERVER", Long.valueOf(startTime));
    logHandle.logFlumeRemote(rc);
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    try {
      Trace.log("RPC", 0, "远程调用，参数map: {}", new Object[] { dataMap });

      clogicContext.setCreateTime(DateUtil.getStringToday());
      clogicContext.setMonitorId(flumeCid);
      clogicContext.setRequestType("DRPC");
      clogicContext.setTransCode(mvcController.getTranCode());
      clogicContext.setSecurityType(mvcController.getSecurityType());
      clogicContext.setLogicCode(mvcController.getBid());
      clogicContext.setDataMap((Map)dataMap.get("dataMap"));

      getControllerHandle().execute(this.controller, request, response, this.actionId, clogicContext, interceptorList);
      long startTime2 = System.currentTimeMillis();
      dataMap = ContextMapChangeUtil.clContext2MapForCLOutput(clogicContext, mvcController.getOutputParamsList());
      Trace.log("RPC", 0, "远程调用完，blogicContext转成map[{}ms]，并返回 map: {}", new Object[] { Long.valueOf(System.currentTimeMillis() - startTime2), dataMap });

      getControllerHandle().triggerAfterCompletion(interceptorList, request, response, clogicContext, null);

      rc.setType("RPCCLIENT");
      rc.setMarkTime(Long.valueOf(System.currentTimeMillis()));
      logHandle.logFlumeRemote(rc);
    }
    catch (BaseException e)
    {
    }
    catch (Exception e)
    {
    }
    finally
    {
      List flumeLogInfList;
      BaseException e1;
      logHandle.logFlumeService();
      if (monitor != null)
        this.monitorManager.remove(monitor);

      List flumeLogInfList = logHandle.getLogThread().getFlumeLogInfList();
      if (flumeLogInfList.size() > 1) {
        flumeLogInfList.remove(flumeLogInfList.size() - 1);
        logHandle.getLogThread().setFlumeLogInfList(flumeLogInfList);
      }
      Trace.log("RPC", 1, "complete CL flow service, time：{}ms", new Object[] { Long.valueOf(System.currentTimeMillis() - startTime) });
    }
    return dataMap;
  }

  public ControllerHandle getControllerHandle() {
    if (null == this.controllerHandle)
      this.controllerHandle = ((ControllerHandle)SpringContextsUtil.getBean("clControllerHandle"));

    return this.controllerHandle;
  }

  public void setControllerHandle(ControllerHandle controllerHandle) {
    this.controllerHandle = controllerHandle;
  }

  public IMvcController getMvcController() throws BaseException {
    loadController();
    return this.controller.getMvcController();
  }

  public String getActionId() {
    return this.actionId;
  }

  public void setActionId(String actionId) {
    this.actionId = actionId;
    try
    {
      loadController();
    } catch (BaseException e) {
      Trace.log("RPC", 3, "设置完actionId，加载对应controller失败，exception: {}", e);
    }
  }

  private void loadController()
    throws BaseException
  {
    if (null == this.controller)
      this.controller = getControllerHandle().getController(this.actionId);
  }
}