package com.ifp.rpc.service;

import com.ifp.core.exception.BaseException;
import com.ifp.core.flow.service.Service;
import com.ifp.web.controller.IMvcController;

public abstract interface ControlService extends Service
{
  public abstract IMvcController getMvcController()
    throws BaseException;
}